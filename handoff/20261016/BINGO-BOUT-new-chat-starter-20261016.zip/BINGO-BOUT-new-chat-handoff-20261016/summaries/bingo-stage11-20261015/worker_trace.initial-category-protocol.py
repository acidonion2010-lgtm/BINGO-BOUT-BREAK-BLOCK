#!/usr/bin/env python3
"""Read-only app investigation; only the ephemeral Worker handler is instrumented."""
import argparse
import base64
import hashlib
import http.server
import json
import platform
import threading
import time
from pathlib import Path
from playwright.sync_api import sync_playwright
from analyse_trace import analyse_trace

ROOT=Path(__file__).resolve().parent
PROJECT=Path('/workspace/handoff/BINGO-BOUT-handoff/project')
FILES={'stage5':PROJECT/'stages/index.handoff-20261015.html','stage9':PROJECT/'index.html'}
EXPECTED={'stage5':'fea09e995bfc1036515b92771925bd7968f3c453425ea5517b7a5b480293be64',
          'stage9':'59fff4685ff3f36e18d73fe9fa524ee57d81a348352e7b2912db4b7ecc1bb513'}
CATEGORIES=['toplevel','blink.user_timing','devtools.timeline','v8',
            'disabled-by-default-v8.gc','disabled-by-default-v8.compile']

INSTALL = '''prefix => {
 const original=wholeGameWorkerSource;
 const pristine=original();
 const replaceOnce=(text,anchor,replacement)=>{
  if(text.split(anchor).length!==2)throw Error('Worker anchor mismatch: '+anchor);
  return text.replace(anchor,replacement);
 };
 wholeGameWorkerSource=function(){
  let source=original();
  source=replaceOnce(source,'self.onmessage = (event) => {','self.onmessage = async (event) => {');
  const marker=JSON.stringify(prefix);
  const probe=`
   self.postMessage({type:'stage11-before',generation:data.generation});
   await new Promise(resolve=>{__stage11Resume=resolve});
   performance.mark(${marker}+'.solve.start');
   const stats = dp.solve();
   performance.mark(${marker}+'.solve.end');
   self.postMessage({type:'stage11-after',generation:data.generation,stats});
   await new Promise(resolve=>{__stage11Resume=resolve});
  `;
  source=replaceOnce(source,'const stats = dp.solve();',probe);
  return `let __stage11Resume;
   self.addEventListener('message',event=>{
    if(event.data?.type==='stage11-resume' && __stage11Resume){
     const resume=__stage11Resume;__stage11Resume=null;resume();
    }
   });\n`+source;
 };
 window.__stage11Events=[];
 return {pristine,instrumented:wholeGameWorkerSource()};
}'''
START = '''() => {
 Object.assign(state,{gameMode:'cpu',cpuDifficulty:'master',seatChosen:true,isStarting:true,
  gameEnded:false,firstPlayer:1,p1NumberLayout:[8,1,6,3,5,7,4,9,2],p2NumberLayout:[5,9,1,7,2,6,3,8,4]});
 startWholeGameCpu();
 if(!cpuWholeWorker)throw Error('Worker not created');
 cpuWholeWorker.addEventListener('message',event=>{
  if(event.data?.type?.startsWith('stage11-')) __stage11Events.push(event.data);
 });
}'''
FINISH = '''async () => {
 if(cpuWholeStatus!=='ready')throw Error('Expected actual ready status');
 const bytes=new Uint8Array(cpuWholeStats.valueTableBytes);
 let offset=0;
 for(const layer of cpuWholeDp.layers){
  const view=new Uint8Array(layer.values.buffer,layer.values.byteOffset,layer.values.byteLength);
  bytes.set(view,offset);offset+=view.length;
 }
 const digest=await crypto.subtle.digest('SHA-256',bytes);
 const hash=Array.from(new Uint8Array(digest),v=>v.toString(16).padStart(2,'0')).join('');
 const result={stats:cpuWholeStats,valueTableSha256:hash,events:__stage11Events};
 releaseWholeGameCpu(); return result;
}'''


def sha(data): return hashlib.sha256(data).hexdigest()


def write_json(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2));tmp.replace(path)


def cpu_stat():
    path=Path('/sys/fs/cgroup/cpu.stat')
    try:return dict(line.split() for line in path.read_text().splitlines())
    except OSError as error:return {'unavailable':str(error)}


def snapshot(session):
    result={'startMonotonicNs':time.monotonic_ns(),'tasks':{},'errors':[]}
    try:
        pids=[int(p['id']) for p in session.send('SystemInfo.getProcessInfo')['processInfo'] if p['type']=='renderer']
        result['rendererPids']=pids
        for pid in pids:
            try: tasks=list((Path('/proc')/str(pid)/'task').iterdir())
            except OSError as error:
                result['errors'].append({'pid':pid,'error':str(error)});continue
            for task in tasks:
                try:
                    fields=[int(v) for v in (task/'schedstat').read_text().split()]
                    assert len(fields)==3
                    row={'pid':pid,'tid':int(task.name),'schedstat':fields,'comm':(task/'comm').read_text().strip()}
                    statuses=(task/'status').read_text().splitlines()
                    row['contextSwitches']={k:int(v.strip()) for k,v in (line.split(':',1) for line in statuses if line.startswith(('voluntary_ctxt_switches:','nonvoluntary_ctxt_switches:')))}
                    result['tasks'][f'{pid}:{task.name}']=row
                except (OSError,ValueError,AssertionError) as error:
                    result['errors'].append({'pid':pid,'tid':task.name,'error':str(error)})
    except Exception as error:result['errors'].append({'error':repr(error)})
    result['endMonotonicNs']=time.monotonic_ns();return result


class Trace:
    def __init__(self,session,page,path):
        self.session=session;self.page=page;self.path=path;self.complete=None;self.usage=[];self.active=False
        self.listener=lambda event:setattr(self,'complete',event)
        self.usage_listener=lambda event:self.usage.append(event)
        session.on('Tracing.tracingComplete',self.listener)
        session.on('Tracing.bufferUsage',self.usage_listener)

    def start(self,categories):
        self.session.send('Tracing.start',{'categories':','.join(categories),'options':'record-until-full',
            'transferMode':'ReturnAsStream','streamFormat':'json','streamCompression':'none','bufferUsageReportingInterval':100})
        self.active=True

    def finish(self):
        if self.active:
            self.session.send('Tracing.end');self.active=False
        deadline=time.monotonic()+15
        while self.complete is None and time.monotonic()<deadline:self.page.wait_for_timeout(20)
        assert self.complete is not None,'No tracingComplete'
        stream=self.complete['stream'];total=0
        try:
            with self.path.open('wb') as f:
                for _ in range(3000):
                    chunk=self.session.send('IO.read',{'handle':stream,'size':131072})
                    data=base64.b64decode(chunk['data']) if chunk.get('base64Encoded') else chunk['data'].encode()
                    f.write(data);total+=len(data)
                    assert total<=128*1024*1024,'Trace over fixed 128MB cap'
                    if chunk.get('eof'):break
                else:raise AssertionError('Trace read did not terminate')
        finally:
            self.session.send('IO.close',{'handle':stream})
            self.session.remove_listener('Tracing.tracingComplete',self.listener)
            self.session.remove_listener('Tracing.bufferUsage',self.usage_listener)
        assert self.complete.get('dataLossOccurred') is not True,'Trace data loss'
        return {'complete':self.complete,'bufferUsage':self.usage,'bytes':total,'sha256':sha(self.path.read_bytes())}


def selected_delta(before,after,pid,tid):
    key=f'{pid}:{tid}';a=before['tasks'].get(key);b=after['tasks'].get(key)
    result={'key':key,'available':bool(a and b),'scope':'handshake envelope, includes dispatch and probe overhead'}
    if not a or not b:return result
    delta=[v-u for u,v in zip(a['schedstat'],b['schedstat'])]
    result.update({'before':a,'after':b,'runtimeMs':delta[0]/1e6,'runnableWaitMs':delta[1]/1e6,'timeslices':delta[2],
        'nonnegativeCounters':all(v>=0 for v in delta),
        'zeroWaitDoesNotProveAbsence':True,
        'contextSwitches':{k:b['contextSwitches'][k]-v for k,v in a['contextSwitches'].items()}})
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();assert not args.output.exists(),'Refuse overwrite'
    args.output.mkdir(parents=True);raw={name:p.read_bytes() for name,p in FILES.items()}
    for name,data in raw.items():assert sha(data)==EXPECTED[name],name+' hash mismatch'
    report={'status':'running','scriptSha256':sha(Path(__file__).read_bytes()),
        'analyserSha256':sha((ROOT/'analyse_trace.py').read_bytes()),'planSha256':sha((ROOT/'PLAN.md').read_bytes()),
        'inputs':EXPECTED,'conditions':{'platform':platform.platform(),'viewport':[1280,900],
            'cpuMax':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'requestedCategories':CATEGORIES,
            'diagnosticOnly':True,'noConcurrentBrowserJobs':True},'samples':[]}
    output=args.output/'results.json';write_json(output,report)

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            body=raw.get(self.path.strip('/'))
            if body is None:self.send_error(404);return
            self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store')
            self.end_headers();self.wfile.write(body)
        def log_message(self,*unused):pass

    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
    threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        with sync_playwright() as p:
            for run in range(2):
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
                report['conditions']['browserVersion']=browser.version
                session=browser.new_browser_cdp_session()
                available=session.send('Tracing.getCategories')['categories']
                categories=[c for c in CATEGORIES if c in available]
                report['conditions']['availableCategories']=available
                report['conditions']['selectedCategories']=categories
                page=browser.new_page(viewport={'width':1280,'height':900});errors=[]
                page.on('pageerror',lambda error:errors.append(str(error)))
                for round_number in range(4):
                    order=['stage5','stage9'] if (run+round_number)%2==0 else ['stage9','stage5']
                    for arm in order:
                        name=f'run{run+1}.round{round_number+1}.{arm}';prefix='bingo.stage11.'+name
                        row={'run':run+1,'round':round_number+1,'arm':arm,'id':name,'firstNavigationInProcess':not any(r['run']==run+1 for r in report['samples'])}
                        report['currentSample']=row;write_json(output,report)
                        response=page.goto(f'http://127.0.0.1:{server.server_port}/{arm}',wait_until='load',timeout=60000)
                        assert response.status==200
                        tests=json.loads(page.locator('#rule-test-results').text_content())
                        assert tests=={'passed':322,'total':322,'failures':[]},tests
                        row['selfTests']=tests
                        sources=page.evaluate(INSTALL,prefix)
                        row['workerSourceSha256']={key:sha(value.encode()) for key,value in sources.items()}
                        row['cgroupBefore']=cpu_stat()
                        trace=Trace(session,page,args.output/(name+'.trace.json'));trace.start(categories)
                        try:
                            page.evaluate(START)
                            page.wait_for_function("__stage11Events.some(e=>e.type==='stage11-before') || cpuWholeStatus==='fallback'",timeout=30000)
                            assert page.evaluate('cpuWholeStatus')=='preparing'
                            before=snapshot(session)
                            write_json(args.output/(name+'.proc.before.json'),before)
                            page.evaluate("cpuWholeWorker.postMessage({type:'stage11-resume'})")
                            page.wait_for_function("__stage11Events.some(e=>e.type==='stage11-after') || cpuWholeStatus==='fallback'",timeout=30000)
                            assert page.evaluate('cpuWholeStatus')=='preparing'
                            after=snapshot(session)
                            write_json(args.output/(name+'.proc.after.json'),after)
                            page.evaluate("cpuWholeWorker.postMessage({type:'stage11-resume'})")
                            page.wait_for_function("cpuWholeStatus==='ready' || cpuWholeStatus==='fallback'",timeout=30000)
                            row['traceCapture']=trace.finish()
                            row['functional']=page.evaluate(FINISH)
                            assert row['functional']['stats']['initialValue']==-119.69864675486676
                            assert row['functional']['stats']['maxGap']<=1e-5
                            assert row['functional']['stats']['valueTableBytes']==18324976
                            assert row['functional']['valueTableSha256']=='ba68eace30ba61d0e99ad06a824edebf04cf202b90e807c436091c10b2cd6ede'
                            assert not errors,errors
                            row['analysis']=analyse_trace(trace.path,prefix)
                            pid,tid=row['analysis']['pid'],row['analysis']['tid']
                            row['scheduler']=selected_delta(before,after,pid,tid)
                            write_json(args.output/(name+'.proc.json'),{'before':before,'after':after})
                            row['cgroupAfter']=cpu_stat()
                        except BaseException as error:
                            if trace.active:
                                try:row['traceCapture']=trace.finish()
                                except Exception as error:row['traceFailure']=repr(error)
                            row['failed']=True;row['error']=repr(error)
                            try:row['failureState']=page.evaluate('({status:cpuWholeStatus,failure:cpuWholeFailure,events:__stage11Events})')
                            except Exception as diagnostic_error:row['failureStateError']=repr(diagnostic_error)
                            report['samples'].append(row);write_json(output,report);raise
                        report['samples'].append(row);report.pop('currentSample',None);write_json(output,report)
                        m=row['analysis']
                        print(name,json.dumps({'wallMs':m['solveWallMs'],'threadCpuMs':m['solveThreadCpuMs'],
                            'nonCpuMs':m['nonCpuMs'],'gcCpuMs':m['gc']['cpuUnionMs'],'jitCpuMs':m['jit']['cpuUnionMs'],
                            'schedulerRuntimeMs':row['scheduler'].get('runtimeMs'),'schedulerWaitMs':row['scheduler'].get('runnableWaitMs')},ensure_ascii=False),flush=True)
                browser.close()
        assert len(report['samples'])==16
        hashes={r['functional']['valueTableSha256'] for r in report['samples']}
        assert len(hashes)==1,'Fixed-layout DP table hashes differ'
        assert len({r['workerSourceSha256']['pristine'] for r in report['samples']})==1
        report['allFixedLayoutTablesEqual']=True;report['fixedLayoutSha256']=hashes.pop()
        report['status']='completed'
    except BaseException as error:
        report['status']='failed';report['error']=repr(error)
        current=report.get('currentSample')
        if current is not None and not any(r['id']==current['id'] for r in report['samples']):
            current['failed']=True;current['error']=repr(error);report['samples'].append(current)
        raise
    finally:write_json(output,report);server.shutdown();server.server_close()


if __name__=='__main__':main()
