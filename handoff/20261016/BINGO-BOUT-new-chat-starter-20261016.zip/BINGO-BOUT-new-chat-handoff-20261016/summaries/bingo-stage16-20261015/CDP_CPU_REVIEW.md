# CDP PerformanceのCPU時計：固定Chromiumソースの確認

対象revisionは`73c14f6228d7cd537c855007e8f88678969cc0eb`。公式Chromium GitHub mirrorの固定commit URLからソースを保存した。ブラウザー、DP、性能ジョブ、時計の実測は行っていない。

**結論：pageのCDP sessionで`Performance.enable({timeDomain:'threadTicks'})`を有効にし、`Performance.getMetrics`の`ThreadTime`と`TaskDuration`を取得する経路は、Perfettoのtrace/exporterを経ずrendererのmain thread CPU時計を直接読む。** ただしgetMetricsの前後差はCDP照会を含む包絡区間であり、JS handlerの開始・終了markerと同じ端点ではない。また、Perfettoと下位のLinux CPU時計は共有しており、完全に独立した物理時計という意味ではない。

## 実装経路

主要ファイルを`official-sources/cdp-cpu-review/`へ保存し、URL・revision・bytes・SHA-256を`MANIFEST.json`へ記録した。Chromium/PerfettoのLICENSEも同梱した。

1. [Performance.pdl](official-sources/cdp-cpu-review/third_party/blink/public/devtools_protocol/domains/Performance.pdl)のenableはtimeDomainに`timeTicks`/`threadTicks`を受け取り、getMetricsはname/valueの配列を返す。
2. [inspector_performance_agent.cc](official-sources/cdp-cpu-review/third_party/blink/renderer/core/inspector/inspector_performance_agent.cc)の`InnerSetTimeDomain`（156行付近）は、threadTicksで`ThreadTicks::IsSupported()`を確認し、初期化後に`use_thread_ticks_`を設定する。`GetTimeTicksNow`（140行付近）はこの設定でCPU時計へ切り替える。
3. `GetThreadTimeNow`（145行付近）は`base::ThreadTicks::Now().since_origin().InMicroseconds()`を使う。`getMetrics`の`ThreadTime`（239行付近）は、これをenable時の`thread_time_origin_`から差し引き、秒のdoubleで返す。**ThreadTimeはtimeTicksドメインでもCPU時計を読む。** threadTicks指定が必要なのはTaskDuration等のduration指標もCPU時間として読むためである。
4. `WillProcessTask/DidProcessTask`（403行付近）は渡されたtask時刻を無視し、同じ`GetTimeTicksNow`の差を`task_duration_`へ累積する。getMetricsの`TaskDuration`（226行付近）は累積値と、実行中taskがある場合の現在までの差を返す。
5. [time.cc](official-sources/cdp-cpu-review/base/time/time.cc)の`ThreadTicks::Now`は関数pointerを経由し、既定値は`ThreadTicksNowIgnoringOverride`。固定Linux/POSIX実装の[time_now_posix.cc](official-sources/cdp-cpu-review/base/time/time_now_posix.cc)では`clock_gettime(CLOCK_THREAD_CPUTIME_ID)`を読む。trace packet、counter復元、trace processor、JSON exporterはこの計算経路に登場しない。

[WebDevToolsAgentImpl::AttachSession](official-sources/cdp-cpu-review/third_party/blink/renderer/core/exported/web_dev_tools_agent_impl.cc)はLocalFrameのInspectedFramesとMainThreadDebuggerを使い、355行付近でInspectorPerformanceAgentを登録する。PerformanceAgentは`Thread::Current()->AddTaskTimeObserver(this)`を使う。したがって今回の**page/frame session**で得るCPU値はそのrenderer main threadのもので、専用Workerや背景コンパイルスレッドのCPU合計ではない。getMetrics自体はpid/tidを返さないので、trace/proc側で選んだrenderer mainとの対応も保存する必要がある。

## getMetricsの端点

1回の応答中の値は、同時刻の原子的snapshotではない。

- `Timestamp`は190行付近の`base::TimeTicks::Now()`によるwall時計。threadTicksを指定してもwallのまま。
- TaskDuration等に足す現在時刻は201行付近の`now=GetTimeTicksNow()`。
- ThreadTimeはその後、239行付近でCPU時計をもう一度読む。
- ThreadTime採取後にもprocess CPU照会、heap統計、timing取得、応答の生成・送信が続く。

getMetrics前→操作→getMetrics後という比較のThreadTime差には、最初の照会のCPU採取後の処理、操作のdispatch・JS・描画等、途中の他のmain task、次の照会のCPU採取前の処理が入る。TaskDuration差にも同様のtask包絡があり、TaskDurationとThreadTimeの読取り点も少し違う。handler markerの範囲と同一視したり、差をそのままselector CPUと命名したりしない。

TaskDurationは同threadで観測したtask全体のCPU時間で、JSだけではない。ScriptDuration/V8CompileDuration/DevToolsCommandDurationなどは別のprobeから記録され、ネストの重複を除く調整もある。TaskOtherDurationはこれらを引いた計算上の残りであり、スケジューラー待ち時間や未分類のGC専用指標ではない。

同じpage CDP sessionでenableを一度だけ行い、その後の前後差を使うのが明確である。enable済みのまま別timeDomainへ変更するとエラーになる。disable→enableでは`thread_time_origin_`が設定し直される一方、task等の累積durationメンバーを同じ箇所でゼロへ戻してはいないため、原点をまたいだ差や絶対値比較に使わない。enableしていない場合のgetMetricsは空配列であり、欠測をCPUゼロと解釈しない。

## 精度・共有するソース・解釈の限界

Linuxの`ConvertTimespecToMicros`は`tv_nsec/1000`で整数µsへ切り捨てる。CDP値の小数桁や後からのns表現はµsより細かい時計精度を与えない。getMetrics自体や有効化したtask/script probeもCPU時計を読み、計測対象の実行履歴と負荷を変える。[time.h](official-sources/cdp-cpu-review/base/time/time.h)もThreadTicksについて、近似的な仕事時間、clock読取りの負荷、短すぎる区間への注意を明記している。今回のソース調査は実機のaccuracy、分解能、syscall費用を測定したものではない。

Chromiumの[DEPS](official-sources/cdp-cpu-review/DEPS)はPerfettoを`5dbeaad4ceb91470a835426b52e0cb43a3e5ef10`へ固定している。この版の[track_event_internal.cc](official-sources/cdp-cpu-review/perfetto/src/tracing/internal/track_event_internal.cc)はthread-time sampling時に`base::GetThreadCPUTimeNs()`を呼び、その[time.h](official-sources/cdp-cpu-review/perfetto/include/perfetto/base/time.h)のLinux実装も`CLOCK_THREAD_CPUTIME_ID`を読む。従ってCDPとTraceは**下位のカーネルCPU counterを共有し、採取・単位変換・応答/保存/exportの経路が異なる**。CDPの一致はexporterを迂回した裏付けになるが、時計そのものの独立検証にはならない。schedstatも別の読取り窓とカーネルの会計値なので、その端点を明記して比較する。

ThreadTimeはCPU上で動いたmain-threadの仕事全体を含む。そこで壁時計から引いた残りも、時刻範囲が一致していなければ厳密な非CPU時間ではなく、ましてrunqueue待ちだけではない。GC/JIT/JSの個別寄与をThreadTime単独から分離できない。フレームや処理が同じrendererを共有する場合、そのthreadの他の仕事も含まれる。

`ThreadTicks::Now`はテスト等でoverride可能な関数pointerを経由する既定実装であり、対応する実行バイナリのrevision・設定とrawのCDP responseを保存する。ここで検証したのは固定revisionの通常Linuxコード経路で、実行環境が必ずその経路を使ったことはroot側の収集記録と照合する必要がある。

## 保存した主要ソースのhash

全件と取得に失敗した候補パスはMANIFESTに残す。下表のファイルは取得成功した実ファイルである。

| ソース | SHA-256 |
| --- | --- |
| `inspector_performance_agent.cc` | `0eee80a8c94d9bd303ddefe49fb419b2e07665df371273bbe451a399b5159262` |
| `inspector_performance_agent.h` | `c0290ecd613a85ad57c00323c7fc7b5a672ae00f708e5e66184d077558323c8a` |
| `Performance.pdl` | `a05354d3aac5e6922895f8efeccab64221eebdf49f2b62008aa464f21c944bdd` |
| Chromium `base/time/time_now_posix.cc` | `ad8a692b7c94b84c6a8e516b61074485a3414fa419401630ad73b58d13f1ebf7` |
| Chromium `base/time/time.cc` | `f5c89f500ff155adadc892561423e306bdfe0f7a7d5a61df4656616a6aa7a95f` |
| Chromium `base/time/time.h` | `e66bef19df9d66cb48f6e6cc7eff68faf35dd46b29ac469206b6e7d122c1bb80` |
| Chromium `web_dev_tools_agent_impl.cc`（core/exported） | `49dcf1b29634c32465404c33459ab3cc567c81c584715d0518ab082991f3a320` |
| Chromium `DEPS` | `cd59c0f5c31e1dbbc65b2db96bb11a18f7bdc91496fafb5b6a4e7f94d8ad797c` |
| Perfetto `include/perfetto/base/time.h` | `d6510d1400b05c4450b73a12e944c96a7036f7525f1e742f5d572969d60afc14` |
| Perfetto `src/tracing/internal/track_event_internal.cc` | `c2939b1663639427d51fd8f940490cce478f9c21e691810192dbf05e57195fde` |

公式の固定commit参照は[Chromium PerformanceAgent](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/third_party/blink/renderer/core/inspector/inspector_performance_agent.cc)、[Linux時計](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/base/time/time_now_posix.cc)、[Perfetto時計](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/include/perfetto/base/time.h)。取得・保存にTLS検証の無効化は使っていない。
