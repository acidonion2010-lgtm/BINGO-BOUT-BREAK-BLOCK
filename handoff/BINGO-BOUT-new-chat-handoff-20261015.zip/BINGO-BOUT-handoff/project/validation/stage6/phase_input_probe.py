#!/usr/bin/env python3
"""Diagnose trusted CDP mouse clicks after fixed RAF/timer cues.

This is a separate input protocol from the ordinary Playwright locator clicks.
Requested timer delays are not claimed to equal actual click-capture phase.
No game source, audio, animation, or timer implementation is changed. The shared
stage5 harness retains its real Worker, three-RAF fixture, behavior assertions,
A/A and A/B visits, reversed visit order, and RAF timestamp observations.
"""

import argparse
import json
from pathlib import Path
import sys
import time


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'stage5'))
import raf_phase_response as shared


REQUESTED_DELAYS_MS = (1, 5, 9, 13)
INPUT_ATTEMPTS = []
CDP_SESSIONS = {}

CHECK_TARGET = r"""point => {
    const target = getCellButton(1, 2);
    const hit = document.elementFromPoint(point.x, point.y);
    return {
        observedNowMs: performance.now(),
        hitTarget: Boolean(target && hit && hit.closest('#board1 .cell') === target),
        canHumanInteract: canHumanInteractWithBoard(1),
        currentPlayer: getCurrentPlayer(),
        overlayPointerGuardActive: isOverlayPointerGuardActive(),
        gameRootInert: document.getElementById('game-root').inert,
        targetDisabled: target ? target.disabled : null,
        targetIndex: target ? Array.prototype.indexOf.call(target.parentElement.children, target) : null,
        documentVisible: !document.hidden && document.visibilityState === 'visible',
        probeArmed: uiResponseProbe.armed,
        probePending: uiResponseProbe.pending !== null,
        probeHasResult: uiResponseProbe.result !== null
    };
}"""

CUE = r"""async requestedDelayMs => {
    return await new Promise(resolve => {
        requestAnimationFrame(timestamp => {
            const callbackNowMs = performance.now();
            const monitorSequenceAtCue = rafPhaseMonitor.sequence;
            setTimeout(() => {
                const timeoutCallbackNowMs = performance.now();
                resolve({
                    requestedDelayMs,
                    cueRafTimestampMs: timestamp,
                    cueRafCallbackNowMs: callbackNowMs,
                    monitorSequenceAtCue,
                    timeoutCallbackNowMs,
                    actualTimerDelayMs: timeoutCallbackNowMs - callbackNowMs,
                    monitorSequenceAtTimeout: rafPhaseMonitor.sequence
                });
            }, requestedDelayMs);
        });
    });
}"""


def assert_target(check):
    if not (check['hitTarget'] and check['canHumanInteract']
            and check['currentPlayer'] == 1 and check['targetIndex'] == 2
            and not check['overlayPointerGuardActive'] and not check['gameRootInert']
            and not check['targetDisabled'] and check['documentVisible']
            and check['probeArmed'] and not check['probePending']
            and not check['probeHasResult']):
        raise AssertionError(check)


def click_trial(page):
    """Replace only the shared harness's input transport and timing cue."""
    attempt_number = len(INPUT_ATTEMPTS) + 1
    requested_delay = REQUESTED_DELAYS_MS[(attempt_number - 1) % len(REQUESTED_DELAYS_MS)]
    attempt = {
        'attemptNumber': attempt_number,
        'requestedDelayMs': requested_delay,
        'outcome': 'preparing',
    }
    INPUT_ATTEMPTS.append(attempt)
    try:
        page.evaluate(shared.FIXTURE, 'hard')
        locator = page.locator('#board1 .cell:not([disabled])').first
        # Trial actionability checks never send a game click. They may scroll or
        # take extra frames, which belongs to this separate diagnostic condition.
        locator.click(trial=True, timeout=10000)
        box = locator.bounding_box()
        if not box or box['width'] <= 0 or box['height'] <= 0:
            raise AssertionError({'targetBox': box})
        point = {'x': box['x'] + box['width'] / 2,
                 'y': box['y'] + box['height'] / 2}
        attempt['targetPoint'] = point
        attempt['targetBox'] = box
        attempt['beforeMoveTargetCheck'] = page.evaluate(CHECK_TARGET, point)
        assert_target(attempt['beforeMoveTargetCheck'])
        page.mouse.move(point['x'], point['y'])
        descriptor = page.evaluate(shared.DESCRIBE)
        attempt['preCueDescriptor'] = descriptor
        if descriptor['crossOriginIsolated']:
            raise AssertionError(descriptor)
        attempt['preCueTargetCheck'] = page.evaluate(CHECK_TARGET, point)
        assert_target(attempt['preCueTargetCheck'])

        if page not in CDP_SESSIONS:
            CDP_SESSIONS[page] = page.context.new_cdp_session(page)
        session = CDP_SESSIONS[page]
        # No style/layout/animation queries, host busy wait, or click retries
        # occur between the cue and the CDP input. Browser/host transport remains
        # part of this protocol, so actual capture phase must be observed.
        attempt['cue'] = page.evaluate(CUE, requested_delay)
        attempt['outcome'] = 'dispatching'
        attempt['hostMousePressedSendMonotonicNs'] = time.monotonic_ns()
        session.send('Input.dispatchMouseEvent', {
            'type': 'mousePressed',
            'x': point['x'], 'y': point['y'],
            'button': 'left', 'buttons': 1, 'clickCount': 1,
        })
        attempt['hostMouseReleasedSendMonotonicNs'] = time.monotonic_ns()
        session.send('Input.dispatchMouseEvent', {
            'type': 'mouseReleased',
            'x': point['x'], 'y': point['y'],
            'button': 'left', 'buttons': 0, 'clickCount': 1,
        })
        attempt['hostMouseReleasedAcknowledgedMonotonicNs'] = time.monotonic_ns()
        page.wait_for_function('uiResponseProbe.result !== null', timeout=10000)
        sample = page.evaluate('uiResponseProbe.result')
        shared.assert_sample(sample, 'hard')
        shared.decompose(sample)
        attempt.update({
            'outcome': 'accepted',
            'trusted': sample['trusted'],
            'actualClickPhaseMs': sample['clickPhaseMs'],
            'actualClickPhaseAfterCallbackMs': sample['clickPhaseAfterCallbackMs'],
            'captureMinusCueRafTimestampMs': sample['clickCaptureNowMs'] - attempt['cue']['cueRafTimestampMs'],
            'captureMinusCueTimeoutMs': sample['clickCaptureNowMs'] - attempt['cue']['timeoutCallbackNowMs'],
            'monitorSequenceAtCapture': sample['previousRafSequence'],
            'clickedIndex': sample['clickedIndex'],
        })
        sample['preClickDescriptor'] = descriptor
        sample['inputProtocolDiagnostic'] = dict(attempt)
        return sample
    except Exception as error:
        attempt.update({'outcome': 'failed',
                        'failure': {'type': type(error).__name__, 'detail': str(error)}})
        raise


def annotate_report(output):
    if not output.exists():
        return
    data = json.loads(output.read_text())
    data.setdefault('conditions', {})['inputProtocolDiagnostic'] = {
        'protocol': 'Trusted CDP mousePressed then mouseReleased; left button, clickCount 1; no supplied event timestamp.',
        'separateCondition': 'This protocol differs from ordinary locator.click() and its results are reported separately.',
        'preCueWork': 'Shared three-RAF FIXTURE, locator.click(trial=True) actionability checks, coordinates/hit checks, mouse.move, hover/animation/BGM descriptor, and CDP session creation occur before scheduling.',
        'cue': 'Next RAF callback schedules setTimeout with the requested delay; after its resolution reaches the host, two ordinary CDP mouse input commands are sent.',
        'requestedDelaysMs': list(REQUESTED_DELAYS_MS),
        'delayDefinition': 'Requested setTimeout delay after the cue RAF callback; not a guarantee of click phase after a RAF timestamp.',
        'cycle': 'One continuous 1,5,9,13 ms cycle counts every warmup and measured attempt across visits. With 16 measured clicks, each visit has four observations per requested delay; its warmup shifts the starting position of the next visit.',
        'actualPhase': 'Shared capture-time observation and decompose() remain unchanged; host transport and input queues can move capture into a later frame.',
        'retention': 'Every attempt is retained; missed requested timing is neither retried nor excluded. A failed behavior assertion ends the run and preserves failure metadata.',
        'queriesDuringReservation': 'No added DOM, layout, animation, hover, or actionability query occurs between cue scheduling and dispatch.',
        'hostClock': 'Host monotonic nanosecond timestamps identify command order; they are not subtracted from page performance.now timestamps.',
        'limits': 'No requested/actual phase equality, latency PASS, A/A subtraction, or physical-display guarantee is assessed. Game source, sound, and animation remain unchanged.',
    }
    data['inputProtocolAttempts'] = INPUT_ATTEMPTS
    output.write_text(json.dumps(data, ensure_ascii=False, indent=2,
                                 allow_nan=False) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('before', type=Path)
    parser.add_argument('after', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--runs', type=int, default=4)
    parser.add_argument('--trials', type=int, default=16)
    args = parser.parse_args()
    if args.runs < 1 or args.trials < 1:
        parser.error('Use positive run and trial counts')
    previous_argv = sys.argv
    shared.click_trial = click_trial
    sys.argv = [str(Path(shared.__file__)), str(args.before), str(args.after),
                str(args.output), '--runs', str(args.runs), '--trials', str(args.trials)]
    try:
        shared.main()
    finally:
        sys.argv = previous_argv
        annotate_report(args.output)


if __name__ == '__main__':
    main()
