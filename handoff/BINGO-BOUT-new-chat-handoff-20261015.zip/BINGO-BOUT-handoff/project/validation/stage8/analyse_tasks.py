#!/usr/bin/env python3
"""Task/frame and response-marker diagnostics; no latency PASS."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import statistics
import sys

from marker_windows import analyse as marker_analysis, union_us


def perf_windows(sample, trace, marks):
    selected = sample.get('selectedRendererPerf')
    if not selected:
        return {'requested': False, 'available': False}
    assert selected['matchedCandidate'] and selected['captureChecksPassed']
    capture = selected['candidateCapture']['collectorReport']
    assert capture['integrityChecksPassed'] and capture['recordEmissionVerified']
    assert capture['lostRecords'] == capture['lostSamples'] == capture['throttleRecords'] == capture['unthrottleRecords'] == 0
    assert not capture['overflow'] and not capture['truncation']
    ring = capture['mmapFinalBeforeRead']
    assert ring['dataSize'] - (ring['dataHead'] - ring['dataTail']) >= 2 * 56
    assert capture['resourceClosure']['fdClosed'] and capture['resourceClosure']['mapClosed']
    assert capture['clock']['explicitUseClockid'] and capture['clock']['id'] == 1
    assert capture['clock']['hostImplementation'] == 'clock_gettime(CLOCK_MONOTONIC)'
    assert trace['metadata']['clock-domain'] == 'LINUX_CLOCK_MONOTONIC'
    assert capture['enableIoctlEndHostNs'] <= marks['capture']['ts'] * 1000
    assert marks['second-raf']['ts'] * 1000 <= capture['disableIoctlStartHostNs']
    records = [r for r in capture['records'] if r['type'] == 14]
    assert all(r['tid'] == marks['capture']['tid'] and r['pid'] == marks['capture']['pid'] for r in records)
    assert records and capture['switchDirectionsAlternate'] and capture['switchTimestampsNondecreasing']
    intervals = []
    for a, b in zip(records, records[1:]):
        if a['switchOut']:
            assert not b['switchOut'] and b['timeNs'] >= a['timeNs']
            intervals.append({'startNs': a['timeNs'], 'endNs': b['timeNs'],
                              'switchOutPreemptedTaskRunning': a['preemptedTaskRunning'],
                              'outCpu': a['cpu'], 'inCpu': b['cpu']})
    # The observable intervals are complete OUT->IN pairs. Every application
    # mark must follow a known IN (or precede a known OUT) within recording.
    # This rejects missing initial/final switch information for marker windows.
    for mark in marks.values():
        stamp = mark['ts'] * 1000
        previous = [r for r in records if r['timeNs'] <= stamp]
        following = [r for r in records if r['timeNs'] >= stamp]
        known_running = bool(previous and not previous[-1]['switchOut'])
        if not previous and following:
            known_running = following[0]['switchOut']
        assert known_running, {'markOutsideKnownRunningInterval': mark, 'previous': previous[-1:]}
    result = {'requested': True, 'available': True, 'clockAndThreadCorrespondencePassed': True,
              'allResponseMarksInKnownRunningIntervals': True,
              'switchRecordCount': len(records),
              'scope': 'Complete same-thread OUT/IN pairs clipped to response marks. Explicit CLOCK_MONOTONIC, matched Linux trace clock, same PID/TID, enable/disable brackets and mark running-state checks. No wakeup timestamps.',
              'windows': {}}
    pid, tid = marks['capture']['pid'], marks['capture']['tid']
    waits = [e for e in trace['traceEvents'] if e.get('pid') == pid and e.get('tid') == tid
             and e.get('ph') == 'X' and e.get('name') == 'LayerTreeHost::WaitForCommitCompletion']
    for name, a, b in [('handler', 'capture', 'handler-end'),
                       ('firstToSecondRaf', 'first-raf', 'second-raf'),
                       ('captureToSecondRaf', 'capture', 'second-raf')]:
        lo, hi = marks[a]['ts'] * 1000, marks[b]['ts'] * 1000
        clipped = []
        for interval in intervals:
            start, end = max(lo, interval['startNs']), min(hi, interval['endNs'])
            if end > start:
                clipped.append({**interval, 'clippedStartNs': start, 'clippedEndNs': end,
                                'clippedWallMs': (end - start) / 1e6})
        off = sum(r['clippedWallMs'] for r in clipped)
        wall = (hi - lo) / 1e6
        cpu = (marks[b]['tts'] - marks[a]['tts']) / 1000
        row = {'offCpuMs': off, 'onCpuWallMs': wall - off,
               'traceThreadCpuMs': cpu, 'onCpuWallMinusThreadCpuMs': wall - off - cpu,
               'preemptFlagOffCpuMs': sum(r['clippedWallMs'] for r in clipped
                                         if r['switchOutPreemptedTaskRunning']),
               'nonPreemptFlagOffCpuMs': sum(r['clippedWallMs'] for r in clipped
                                            if not r['switchOutPreemptedTaskRunning']),
               'offCpuIntervals': clipped}
        observed_waits = [e for e in waits if e['ts'] * 1000 < hi
                          and (e['ts'] + e.get('dur', 0)) * 1000 > lo]
        row['commitWaits'] = [event_record(e) for e in observed_waits]
        row['commitWaitWallUnionMs'] = union_us([(e['ts'] * 1000, (e['ts'] + e['dur']) * 1000)
                                                for e in observed_waits], lo, hi) / 1e6
        overlaps = []
        for interval in clipped:
            overlaps.extend((max(interval['clippedStartNs'], e['ts'] * 1000),
                             min(interval['clippedEndNs'], (e['ts'] + e['dur']) * 1000))
                            for e in observed_waits
                            if min(interval['clippedEndNs'], (e['ts'] + e['dur']) * 1000)
                            > max(interval['clippedStartNs'], e['ts'] * 1000))
        row['offCpuInsideCommitWaitMs'] = union_us(overlaps, lo, hi) / 1e6
        result['windows'][name] = row
    return result


def event_record(event):
    return {key: event[key] for key in ('name', 'cat', 'pid', 'tid', 'ts', 'dur', 'tts', 'tdur', 'args')
            if key in event}


def frame_for_mark(events, mark):
    frames = [e for e in events if e.get('pid') == mark['pid'] and e.get('tid') == mark['tid']
              and e.get('name') == 'ProxyMain::BeginMainFrame' and e.get('ph') == 'X'
              and e['ts'] <= mark['ts'] <= e['ts'] + e.get('dur', 0)]
    result = {'containingMainFrames': len(frames), 'available': False}
    if len(frames) != 1:
        return result
    frame = frames[0]
    pipeline = frame.get('args', {}).get('main_frame_pipeline', {})
    main_id = pipeline.get('main_frame_id')
    sends = [e for e in events if e.get('name') == 'SendBeginMainFrame' and e.get('ph') == 'I'
             and e.get('pid') == mark['pid'] and main_id is not None
             and e.get('args', {}).get('main_frame_pipeline', {}).get('main_frame_id') == main_id]
    result.update({'mainFrame': event_record(frame), 'sendCandidates': len(sends)})
    if len(sends) != 1:
        return result
    send = sends[0]
    sequence = send['args']['main_frame_pipeline']['begin_frame_id']['sequence_number']
    schedulers = [e for e in events if e.get('name') == 'Scheduler::BeginFrame'
                  and e.get('pid') == send['pid'] and e.get('tid') == send['tid']
                  and e.get('ph') == 'X'
                  and e.get('args', {}).get('args', {}).get('sequence_number') == sequence
                  and e['ts'] <= send['ts']]
    result.update({'send': event_record(send), 'schedulerCandidates': len(schedulers)})
    if len(schedulers) != 1:
        return result
    scheduler = schedulers[0]
    frame_time = scheduler['args']['args']['frame_time_us']
    ticks = [e for e in events if e.get('name') == 'DelayBasedBeginFrameSource::OnTimerTick'
             and e.get('ph') == 'X' and e.get('args', {}).get('frame_time') == frame_time
             and e['ts'] <= send['ts']]
    result.update({'available': True, 'scheduler': event_record(scheduler),
                   'frameTimeUs': frame_time, 'frameIntervalUs': scheduler['args']['args']['interval_us'],
                   'matchingVizTicks': [event_record(e) for e in ticks],
                   'traceCallbackLagMs': (mark['ts'] - frame_time) / 1000,
                   'frameTimeToSendMs': (send['ts'] - frame_time) / 1000,
                   'sendToMainStartMs': (frame['ts'] - send['ts']) / 1000,
                   'mainStartToCallbackMarkMs': (mark['ts'] - frame['ts']) / 1000})
    # The three clock intervals telescope to callback lag, without phase fitting.
    assert abs(result['traceCallbackLagMs'] - sum(result[key] for key in
               ('frameTimeToSendMs', 'sendToMainStartMs', 'mainStartToCallbackMarkMs'))) < 1e-9
    if len(ticks) == 1:
        tick = ticks[0]
        result.update({'vizTickLatenessMs': (tick['ts'] - frame_time) / 1000,
                       'vizTickToSendMs': (send['ts'] - tick['ts']) / 1000})
    return result


def task_window(tasks, lo, hi):
    inside = [e for e in tasks if e['ts'] < hi and e['ts'] + e['dur'] > lo]
    intervals = sorted((max(lo, e['ts']), min(hi, e['ts'] + e['dur'])) for e in inside)
    gaps = []
    end = lo
    for a, b in intervals:
        if a > end:
            gaps.append({'startUs': end, 'endUs': a, 'wallMs': (a - end) / 1000})
        end = max(end, b)
    if end < hi:
        gaps.append({'startUs': end, 'endUs': hi, 'wallMs': (hi - end) / 1000})
    covered = union_us(intervals, lo, hi)
    assert covered + sum((g['endUs'] - g['startUs']) for g in gaps) == hi - lo
    return {'recordedTopLevelTaskUnionMs': covered / 1000,
            'notCoveredByRecordedTasksMs': (hi - lo - covered) / 1000,
            'taskCountOverlappingWindow': len(inside),
            'largestUncoveredIntervals': sorted(gaps, key=lambda g: g['wallMs'], reverse=True)[:5],
            'tasks': [event_record(e) for e in inside],
            'limits': 'Task wall spans include off-CPU time. An uncovered interval is not proof of idle or lack of runnable work.'}


def analyse(folder):
    primary = marker_analysis(folder)
    by_name = {row['sample']: row for row in primary['samples']}
    rows = []
    for file in sorted((folder / 'samples').glob('*.json')):
        sample = json.loads(file.read_text())
        if not sample['traced']:
            continue
        raw = Path(sample['trace']['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == sample['trace']['sha256']
        trace = json.loads(raw)
        events = trace['traceEvents']
        marks = {marker['label']: next(e for e in events if e['name'] == marker['name']
                                       and e['cat'] == 'blink.user_timing')
                 for marker in sample['markers']}
        pid, tid = marks['capture']['pid'], marks['capture']['tid']
        tasks = [e for e in events if e.get('pid') == pid and e.get('tid') == tid
                 and e.get('name') in ('ThreadControllerImpl::RunTask', 'RunTask')
                 and e.get('ph') == 'X' and e.get('dur', 0) > 0]
        assert tasks, 'No recorded renderer main top-level tasks'
        row = by_name[file.name]
        row['topLevelTasks'] = {}
        for name, a, b in [('firstToSecondRaf', 'first-raf', 'second-raf'),
                           ('captureToSecondRaf', 'capture', 'second-raf')]:
            row['topLevelTasks'][name] = task_window(tasks, marks[a]['ts'], marks[b]['ts'])
        row['callbackFrame'] = {name: frame_for_mark(events, marks[name])
                                for name in ('first-raf', 'second-raf')}
        row['perfSwitches'] = perf_windows(sample, trace, marks)
        proc = sample.get('selectedRendererProc', {})
        row['selectedRendererProc'] = proc
        before, after = proc.get('before', {}), proc.get('after', {})
        # Both clocks explicitly use Linux CLOCK_MONOTONIC. Check the host-read
        # brackets against trace timestamps, never against page-relative clocks.
        row['hostProcReadsBracketResponseMarks'] = bool(
            before.get('hostReadEndMonotonicNs', float('inf')) / 1000 <= marks['capture']['ts']
            and after.get('hostReadStartMonotonicNs', -float('inf')) / 1000 >= marks['second-raf']['ts'])
        proc_valid = (proc.get('sameProcessIdentityConfirmed') is True
                      and proc.get('runqueueWaitInterpretationAvailable') is True
                      and proc.get('schedstatCountersMonotonic') is True
                      and proc.get('tracePid') == pid and proc.get('traceTid') == tid
                      and row['hostProcReadsBracketResponseMarks'])
        row['procDeltasValidatedForAccountingComparison'] = proc_valid
        if proc_valid and proc.get('schedstatDeltas'):
            row['hostBracketRunqueueWaitMs'] = proc['schedstatDeltas']['runqueueWaitNs'] / 1e6
            row['hostBracketRuntimeMs'] = proc['schedstatDeltas']['runtimeNs'] / 1e6
        rows.append(row)
    primary['interpretation']['intervals'] = ('Nested timeline X intervals are clipped and unioned. '
        'Top-level task and frame events are added in this run; perf switch records are assessed separately. '
        'Categories overlap and must not be added; uncovered task time is not proof of idle.')
    return {'markerAnalysisInterpretation': primary['interpretation'],
            'limits': 'Task/frame/proc tracing is a separate diagnostic condition. No physical presentation or all-path non-regression PASS. A same-thread proc delta is cumulative across a wider host bracket and cannot be allocated exactly to each RAF segment. Frame clock decomposition locates observed timing, not ultimate OS/GPU causes.',
            'groups': primary['groups'], 'samples': rows,
            'allSharedThrottleDeltasZero': primary['allSharedThrottleDeltasZero'],
            'allProcReadsBracketResponseMarks': all(r['hostProcReadsBracketResponseMarks'] for r in rows),
            'allCallbackFramesMatched': all(frame['available'] for r in rows
                                           for frame in r['callbackFrame'].values()),
            'allRequestedPerfClockChecksPassed': all(not r['perfSwitches']['requested']
                or r['perfSwitches']['clockAndThreadCorrespondencePassed'] for r in rows),
            'largestCallbackLag': sorted(rows, key=lambda r: r['pageMetrics']['secondRafCallbackLagMs'], reverse=True)[:6]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('folder', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = analyse(args.folder)
    output = args.output or args.folder.parent / (args.folder.name + '-analysis.json')
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    with output.with_suffix('.csv').open('w', newline='') as destination:
        writer = csv.writer(destination)
        writer.writerow(['sample', 'twoRafMs', 'secondRafCallbackLagMs', 'firstToSecondWallMs',
                         'firstToSecondMainCpuMs', 'firstToSecondTaskCoveredMs', 'hostBracketRunqueueWaitMs',
                         'secondFrameTimeToSendMs', 'secondSendToMainStartMs', 'secondMainStartToCallbackMs'])
        for row in result['samples']:
            frame = row['callbackFrame']['second-raf']
            writer.writerow([row['sample'], row['pageMetrics']['twoRafMs'], row['pageMetrics']['secondRafCallbackLagMs'],
                             row['windows']['firstToSecondRaf']['traceWallMs'],
                             row['windows']['firstToSecondRaf']['rendererMainThreadCpuMs'],
                             row['topLevelTasks']['firstToSecondRaf']['recordedTopLevelTaskUnionMs'],
                             row.get('hostBracketRunqueueWaitMs'), *[frame.get(k) for k in
                             ('frameTimeToSendMs', 'sendToMainStartMs', 'mainStartToCallbackMarkMs')]])
    print(json.dumps({key: value for key, value in result.items() if key not in ('samples', 'largestCallbackLag')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
