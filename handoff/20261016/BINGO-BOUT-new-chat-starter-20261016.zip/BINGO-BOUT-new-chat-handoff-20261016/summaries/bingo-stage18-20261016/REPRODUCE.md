# 段階18の再計算

新しい実測は不要。段階17一式を /workspace/bingo-stage17-20261015 に保持する。解析は既存run3/4/7/8のraw-counter-runN.json、official-sql/runN-{slices,counters}.csv、runN.json、report.jsonを読み取る。各出力に入力SHAとscript SHAを保存しており、過去データは書き換えない。

既存JSONがあるので、その場で上書き実行しない。空の別フォルダーへ解析器・PLAN.md・PLAN_ADDITION.md・precision-sourcesと必要な補助ファイルを複製する。コピー先を /workspace の直下にすれば固定のstage17入力配置を維持できる。

実際に実行したコードは次の4本（それぞれ既存出力を拒否する）。

```sh
python3 residual_census.py
python3 precision_census.py
python3 boundary_census.py
python3 marker_ns_census.py
```

marker_ns_census.pyは同じフォルダーのboundary_census.pyを補助として使う。source auditはaudit_endpoint_sources.py、独立再計算コードと結果はPOST_RUN_REVIEW.mdを参照。raw decoder・browser・Workerの再実行はしない。

sourceの追加取得には固定commitの公式URLと既定TLSを使い、取得失敗も保存した。再解析にネットワークは不要で、source原本・LICENSEは同梱。binary側add693d8b…とproducer側5dbeaad…のexport_json.ccは別々に保存し、全文同一を照合した。

JSON Xのduration整数化とmarkerの4端点整数化は異なる。符号、ゼロ、欠測、曖昧候補、次点なしを残し、±1µs等の許容幅を足さない。次wall gapと超過量の条件付き比較は、遅延原因の確定でも時計の妥当性判定でもない。

precisionには保存済みJSONを変更しないreplayモードもある（絶対パスを使う）。この完全一致検算はprecision-replay-check.jsonに保存済み。

```sh
python3 /workspace/bingo-stage18-20261016/precision_census.py --verify-output /workspace/bingo-stage18-20261016/precision-census.json
```

別フォルダーでの再計算は出力中のsource/出力パスが変わり得るため、ファイル全体のbyte一致と数値集計の一致を区別する。
