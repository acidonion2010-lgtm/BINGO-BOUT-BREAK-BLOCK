#!/usr/bin/env python3
"""Package evidence without DP binaries, nested archives or environment files."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
ARCHIVE = ROOT / 'BINGO-BOUT-CPU-verification9.zip'
RECORD = ROOT / 'validation/stage9/package-verification.json'
EXPECTED = '59fff4685ff3f36e18d73fe9fa524ee57d81a348352e7b2912db4b7ecc1bb513'
ORIGINAL = 'e872443dc9764f3b9647f4797d1411ca98f865b9c2f69c6e694529e2685cd3a9'


def allowed(path):
    rel = path.relative_to(ROOT)
    return (path.is_file() and path.suffix not in {'.zip', '.bin', '.pyc'}
            and not any(part in {'.git', '.aws', '.codex', '.agents', '__pycache__'}
                        for part in rel.parts)
            and path.name != 'package-verification.json')


files = sorted(p for p in ROOT.rglob('*') if allowed(p))
with zipfile.ZipFile(ARCHIVE, 'w', compression=zipfile.ZIP_DEFLATED,
                     compresslevel=9) as package:
    for path in files:
        package.write(path, path.relative_to(ROOT).as_posix())

with zipfile.ZipFile(ARCHIVE) as package:
    assert package.testzip() is None
    names = package.namelist()
    assert len(names) == len(set(names)) == len(files)
    assert hashlib.sha256(package.read('index.html')).hexdigest() == EXPECTED
    assert hashlib.sha256(package.read('index.before.html')).hexdigest() == ORIGINAL
    assert package.read('index.html') == package.read('stages/index.stage9.html')
    assert package.read('index.html') == package.read('stages/index.stage9.candidate.html')
    assert '段階9比較結果.md' in names and 'download-index.ps1' in names
    json_count = 0
    for name in names:
        if name.endswith('.json'):
            json.loads(package.read(name))
            json_count += 1

result = {
    'archive': ARCHIVE.name, 'bytes': ARCHIVE.stat().st_size,
    'sha256': hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
    'entries': len(names), 'jsonFilesParsed': json_count,
    'crcPassed': True, 'originalSha256': ORIGINAL, 'completedSha256': EXPECTED,
    'completedStageCopiesByteEqual': True,
    'exclusions': ['DP .bin files', 'nested .zip archives', 'Python cache',
                   'environment metadata', 'package verification records'],
    'completed': True,
}
RECORD.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
