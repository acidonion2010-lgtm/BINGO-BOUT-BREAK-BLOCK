# 段階18：1ns記録に残るCPU超過と、読取端点の条件

**実効1ns設定でCPUカウンターの差分端数項を除いても、wall timestampとCPU timestampは同時snapshotにならない。** 通常のTRACE_EVENTではwallを先に読み、TLS・incremental state・packetを準備した後にCPUを読む。したがって、対応するraw CPU値とraw wall値がns単位で復元できても、その2値を同じ実時点の座標としてCPU≤wallを要求する根拠にはならない。一方、取得順序だけで全残差を説明したことにもならない。

本調査は保存済みstage17 SQLと、実行ブラウザーの申告revisionに対応する固定公式ソースの読み取りである。新しいbrowser・DP・性能ジョブ、ビルド、ゲーム変更、過去成果物の編集を行っていない。配布binaryと無改変upstreamビルド全体の同一性検証ではない。

## 対象と保存原本

Chromium `73c14f6228d7cd537c855007e8f88678969cc0eb`、DEPS固定Perfetto `5dbeaad4ceb91470a835426b52e0cb43a3e5ef10`。revision根拠は段階15の`source-revision-evidence.json`で既に保存されている。

必要な既存原本16件は、段階15/17の`SHA256SUMS`と照合してから本文を変更せず本段階へコピーした。新しいcallsite等7原本を同じcommitの公式raw URLから取得した。候補旧path2件のHTTP 404も保持した。URL・bytes・SHA256・line count・コピー元は[原本manifest群](official-sources/endpoint-review/)に記録し、全保存原本を[source-endpoint-audit.json](source-endpoint-audit.json)で再照合する。

ChromiumおよびPerfettoのLICENSE全文も保存した。Chromium LICENSEはSHA256 `368cca1106be99d39ecd32a38d8305585d802a475effb66380b91ffc9bcf709b`、Perfetto LICENSEは`9a682a56cffc9524dfa9b0b1c0dca9cb81a19e96d5bd0793aaf02c08a95ee7ca`。ソース中の著作権・ライセンスheaderを変更していない。配布物の法的条件は各LICENSE原文を参照する。

## 通常TRACE_EVENTの順序

以下はimplicit current-thread trackでthread samplingが有効な経路である。任意の明示trackや無効なCPU samplingへ一般化しない。

| 順序 | 固定Perfetto原本 | 処理 |
| --- | --- | --- |
| 1 | `track_event_data_source.h:1078–1084` | timestamp引数なしの`WriteTrackEvent`が`GetTraceTime()`でwallを読む |
| 2 | 同`989–1003` | TLS、incremental state、必要なclear/reset・descriptorを準備 |
| 3 | `track_event_internal.cc:591–596` | `NewTracePacket`、EventContext、event type |
| 4 | 同`598–610` | `GetThreadCPUTimeNs()`を読み、CPU差分と倍率を記録 |
| 5 | `track_event_data_source.h:1011`以降、`1144–1146`等 | event name/categoryとargs callbackを書き込む |

通常wallは`track_event_internal.cc:409–420`から設定clockを読み、stage17のprimary clock 3ではMONOTONICになる。POSIX実装`include/perfetto/base/time.h:270–277,293–295,307–309`はwallに`CLOCK_MONOTONIC`、CPUに`CLOCK_THREAD_CPUTIME_ID`のchecked `clock_gettime`を使う。CPU取得はChromiumの`base::ThreadTicks` overrideを経由しない。

実効倍率1は`thread_time_delta_ns / 1`なのでproducerのCPU差分整数除算で端数を失わない（internal.cc:603–610）。wall側も通常incremental差分を1で表現する（同535–542）。これは**単位化の事実**であり、各時計がkernel/VMで理想通りに進むことや、両読取が原子的であることの実証ではない。

scoped `TRACE_EVENT`はmacro `track_event.h:392–393`から`track_event_macros.h:172–204`へ入り、BEGINと、destructor時の`TRACE_EVENT_END(category)`に展開される。`TRACE_EVENT0`も`track_event_legacy.h:211–213,254–255`から同じscoped macroへ入る。したがって、次節のcallsiteではENDにも通常wall→準備→CPUの順序がある。BEGINのargs callback等は、そのBEGINのCPU snapshot後に実行されるため、callbackが重いことだけでENDのwall→CPU遅延量を特定することはできない。

## 残差のある4名称のcallsite

保存済みstage17正式unit1 SQLの最大例は、run8 `ThreadControllerImpl::RunTask`、slice id 13466、wall 1,701,211ns、CPU 1,831,199ns、差+129,988nsである。次の4名称に関係する固定sourceのcallsiteを確認した。

| 名称 | Chromium原本の箇所 | timestampの扱い |
| --- | --- | --- |
| `ThreadControllerImpl::RunTask` | `base/task/sequence_manager/thread_controller_with_message_pump_impl.cc:475–487`が`TaskAnnotator::RunTask`へ名称を渡す。`base/task/common/task_annotator.h:102–115`が`TRACE_EVENT("toplevel", event_name, callback, ...)` | 明示timestampなし。argsのtask start情報はannotationでありevent wallの置換指定ではない |
| `BlinkScheduler_OnTaskCompleted` | `third_party/blink/renderer/platform/scheduler/main_thread/main_thread_scheduler_impl.cc:2611–2619` | 通常scoped `TRACE_EVENT`、明示timestampなし |
| `LocalFrameView::ScheduleAnimation` | `third_party/blink/renderer/core/frame/local_frame_view.cc:3950–3958` | 通常scoped `TRACE_EVENT`、frame/delay/locationはargs |
| `RecordingSource::FinishDisplayItemListUpdate` | `cc/layers/recording_source.cc:45–58` | 通常scoped `TRACE_EVENT0`、明示timestampなし |

関連する`BlinkScheduler_PerformMicrotaskCheckpoint`も同scheduler原本1263–1264行で通常`TRACE_EVENT`。既に段階15で確認した`ParseHTML`は`inspector_trace_events.cc:243–259`の通常BEGIN/ENDであり、両端とも明示timestampを渡さない。

`TaskAnnotator::EmitTaskTimingDetails`（task_annotator.cc:279–310）の`task_start_time_us`等はChromeTrackEventのcurrent_task annotationである。同じファイルでも、別名称`LongTaskTracker`（389–398）、`InterestingTask_QueueingTime`/`InterestingTask_ProcessingTime`（449–473）は保存した明示timestampとThreadScoped trackを使う。`ThreadControllerImpl::RunTask`の通常timestampと混同せず、隣接eventすべてが通常timestampだとは推論しない。

以上はこれらの名称を発行するcallsiteのソース事実である。全Chromium callsiteの完全検索や各raw eventの実行スタック同定を行ったという意味ではない。event名だけからpacketのC++発行位置・clock read実時点を測定したとは扱わない。

## UserTimingとconsole stampを区別する

`performance.mark(name)`はoptionsなしでも、`performance_mark.cc:54–81`で先に`base::TimeTicks::Now()`を保存する。その後、timeline挿入、detail、`callTime`の別読取、profilerの処理等を経て、`performance_user_timing.cc:75–120`が`mark.UnsafeTimeForTraces()`を明示wall timestampとしてtraceへ渡す。CPUは通常のemit時点に読む。利用者による過去startTimeの指定は今回のhelperにはないが、**optionsなしでもtraceのwallはemitより前**である。

標準POSIX `base::TimeTicks::Now()`は`base/time/time_now_posix.cc:31–43,100–102`でnsからusへ切り捨てる。1ns設定にしても、この明示timestampの元のus精度を回復しない。`args.data.callTime`もCPU時計の読取時点ではない。

一方、引数がlabelだけの`console.timeStamp(name)`は`thread_debugger_common_impl.cc:1032–1044`、`inspector_trace_events.h:149–165`を通り、通常timestampの`TRACE_EVENT_INSTANT`を呼ぶ。先に保存したUserTimingのwallを再利用しない。`inspector_trace_events.cc:1511–1540`のData callbackはCPU snapshot後のargs処理である。したがってUserTiming固有の先行timestampを、通常TimeStampや上記4名称すべての原因として扱えない。

## 次イベントを使う条件付きの包絡

同一threadのBEGIN/ENDについて、復元済みwallを`Wb, We`、CPU値を`Cb, Ce`とし、観測超過を`E=(Ce−Cb)−(We−Wb)`とする。通常timestampのwall読取の実時点と同じ単位・原点で、CPU取得実時点を`Tb≥Wb, Te≥We`と書く。

さらに、理想CPU関数`C(t)`が単調かつ任意区間で`C(y)−C(x)≤y−x`を満たすと仮定すると、

`E ≤ (Te−We) − (Tb−Wb) ≤ Te−We`。

同じthreadでENDのCPU取得後に読み取られた**通常wall**の次イベントがあり、その値が`Wn`なら、`Te≤Wn`から必要条件`E≤Wn−We`を得る。これはENDの可変読取遅延だけで説明する仮説の、次イベントとの整合条件である。

この条件の利用には、同一thread/current-thread CPU、正しいB/E対応、raw CPUとwall clockの正しい復元、通常timestamp、実行順、理想CPU増分上限という仮定が必要になる。raw packetのindex順やSQL時刻順だけを、wallとCPUの実際の読取順の観測として扱わない。明示timestampや別thread trackを含む一般event、他sequenceへの切替、欠測を含む列へ無条件で当てはめない。

次イベントがUserTiming等の保存済み時刻であれば、`Wn`自体が前のCPU取得より後の読取を示すとは限らない。今回のoptionsなしmarkでも、少なくともTimeTicksのus切捨てを区別する必要がある。JSONの`ts+dur`も次節の理由でns包絡の端点に使用しない。

`E≤Wn−We`を満たす記録は遅延仮説と両立するが、遅延が実際の原因である証明ではない。不満足な記録も、全仮定のうちどれが外れたかをこの比較だけで確定できない。とくにkernel/VMのCPU会計を検証せず、全残差をtrace処理の遅延と断定しない。

## JSONのµs表現と派生END

固定Perfetto importerは`track_event_event_importer.h:802–807`でthread_time counterをthread timestampへ直接入れ、`814–865`でBEGINのCPUとENDのCPUの差をslice thread_durとして保存する。調査した経路にwallからのCPU補間やCPU≤wallのclampはない。

exporter `export_json.cc:800,900–914`は正のns値を別々に1000で整数除算し、`ts`, `dur`, `tts`, `tdur`を書く。したがって正の完了sliceについて、JSONの`tdur−dur`とSQL ns差の単位換算は同一ではない。余りを`rC, rW`（各0..999ns）とすると、

`1000×(tdur_json−dur_json) = (thread_dur_ns−dur_ns) + rW−rC`。

この表現誤差は±999nsの範囲にある。ただしduration同士へ同じfloorを適用する関数は単調なので、Xの正負は0へ潰れ得るが、正から負・負から正への反転は起こらない。後述のmarker端点4値を別々に整数化してから差を取る場合とは異なる。0µsになったこともnsのstrict超過の解消ではない。

さらに、`floor(start/1000)+floor(duration/1000)`は`floor((start+duration)/1000)`より0または1µs小さい。`tts+tdur`にも同じcarryの問題がある。したがってJSONの`ts+dur`/`tts+tdur`は、元END eventの独立したclock snapshotではなく、整数化された値からの派生端点である。rawの元BEGIN/ENDおよびns SQLを使う比較と区別する。marker間の差も各端点がµsへ整数化されており、値を1000倍しても失った精度は回復しない。

## 本段階で変わらない判定

実効1nsで差分端数項が0になること、通常TRACE_EVENTで端点がずれること、JSONでstrict符号が変わり得ることは別の事実である。どれも単独では、残るstrict CPU>wallをすべて救済する根拠にならない。小さい正の差を事後許容幅で合格扱いせず、raw値を削除・clamp・補正しない。

このsource reviewはゲームの速度改善、厳密なCPU寄与率、全経路の非退行、kernel時計の正確さを認定しない。保存済みraw/SQLの対応と条件付き包絡の集計は、root側の本段階解析に別途記録する。
