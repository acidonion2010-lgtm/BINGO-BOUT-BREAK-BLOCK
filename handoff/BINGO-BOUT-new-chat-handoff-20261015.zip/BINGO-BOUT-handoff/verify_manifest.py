#!/usr/bin/env python3
"""Verify files inside this extracted handoff using Python's standard library."""
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
checked = 0
failures = []
for line in (root / 'MANIFEST.sha256').read_text(encoding='utf-8').splitlines():
    expected, name = line.split('  ', 1)
    path = (root / name).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        failures.append(name)
        continue
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        failures.append(name)
    checked += 1
if failures:
    raise SystemExit('File verification failed: ' + ', '.join(failures))
print(f'Verified {checked} files: all SHA-256 hashes match.')
