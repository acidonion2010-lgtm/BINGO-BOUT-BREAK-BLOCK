#!/usr/bin/env python3
"""Tiny explicit encoder; field numbers independently checked in CONFIG_REVIEW.md."""
import base64,hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent
CATEGORIES=['toplevel','cc','viz','devtools.timeline','blink.user_timing','renderer.scheduler','v8','disabled-by-default-devtools.timeline.frame','__metadata']
def varint(n):
 assert isinstance(n,int) and n>=0
 out=bytearray()
 while n>127:out.append((n&127)|128);n>>=7
 out.append(n);return bytes(out)
def number(field,value):return varint(field<<3)+varint(value)
def data(field,value):
 b=value.encode() if isinstance(value,str) else value
 return varint((field<<3)|2)+varint(len(b))+b

def build(unit):
 assert unit in [1,1000]
 chrome=number(2,0)+number(3,0)+number(6,0)
 track=data(1,'*')+b''.join(data(2,x) for x in CATEGORIES)+number(5,0)+number(6,unit)+number(8,1)+number(10,0)
 source=data(1,'track_event')+number(2,0)+data(101,chrome)+data(113,track)
 meta=data(1,'org.chromium.trace_metadata2')+number(2,1)+data(101,chrome)
 raw=data(1,number(1,204800)+number(4,2))+data(1,number(1,256)+number(4,2))+data(2,data(1,source))+data(2,data(1,meta))+data(20,number(5,3))+data(21,number(1,500))
 semantic={'buffers':[{'size_kb':204800,'fill_policy':'DISCARD'},{'size_kb':256,'fill_policy':'DISCARD'}],'data_sources':[{'config':{'name':'track_event','target_buffer':0,'chrome_config':{'privacy_filtering_enabled':False,'convert_to_legacy_json':False,'event_package_name_filter_enabled':False},'track_event_config':{'disabled_categories':['*'],'enabled_categories':CATEGORIES,'disable_incremental_timestamps':False,'timestamp_unit_multiplier':unit,'enable_thread_time_sampling':True,'thread_time_subsampling_ns':0}}},{'config':{'name':'org.chromium.trace_metadata2','target_buffer':1,'chrome_config':{'privacy_filtering_enabled':False,'convert_to_legacy_json':False,'event_package_name_filter_enabled':False}}}],'builtin_data_sources':{'primary_trace_clock':3},'incremental_state_config':{'clear_period_ms':500}}
 return raw,semantic

def main():
 records=[]
 for unit in [1000,1]:
  raw,semantic=build(unit);prefix=R/f'trace-config.unit{unit}'
  for suffix,payload in [('.pb',raw),('.json',(json.dumps(semantic,indent=2)+'\n').encode()),('.base64',base64.b64encode(raw)+b'\n')]:
   with Path(str(prefix)+suffix).open('xb') as f:f.write(payload)
  records.append({'unit':unit,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'semantic':semantic})
 a=records[0]['semantic'];b=records[1]['semantic'];a['data_sources'][0]['config']['track_event_config']['timestamp_unit_multiplier']=1;assert a==b
 for r in records:r.pop('semantic')
 (R/'config-manifest.json').write_text(json.dumps({'scriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'onlySemanticDifference':'track_event_config.timestamp_unit_multiplier','configs':records},indent=2)+'\n')
 print(json.dumps(records,indent=2))
if __name__=='__main__':main()
