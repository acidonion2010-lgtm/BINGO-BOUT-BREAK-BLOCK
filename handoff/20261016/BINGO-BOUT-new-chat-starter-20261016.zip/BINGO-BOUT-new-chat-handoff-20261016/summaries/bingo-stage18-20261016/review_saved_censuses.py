#!/usr/bin/env python3
"""Independent arithmetic/link review of existing stage17/18 files only."""
import csv,hashlib,json,math
from collections import Counter,defaultdict
from decimal import Decimal
from pathlib import Path
R=Path(__file__).resolve().parent; OLD=R.parent/'bingo-stage17-20261015'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def load(p):return json.loads(p.read_text())
def csvrows(p):
    with p.open(newline='') as f:return list(csv.DictReader(f))
def sign(n):return 'positive' if n>0 else 'negative' if n<0 else 'zero'
def finiteint(s):
    x=Decimal(str(s));assert x==int(x);return int(x)
def main():
    out=R/'independent-census-review.json';assert not out.exists()
    report=load(OLD/'report.json');bc=load(R/'boundary-census.json');mc=load(R/'marker-ns-census.json')
    residual=load(R/'residual-census.json');precision=load(R/'precision-census.json')
    for name,d in [('residual',residual),('precision',precision),('boundary',bc),('marker-ns',mc)]:
        source={'residual':'residual_census.py','precision':'precision_census.py','boundary':'boundary_census.py','marker-ns':'marker_ns_census.py'}[name]
        assert d['scriptSha256']==sha(R/source)
    assert residual['planSha256']==sha(R/'PLAN.md')
    assert bc['report']['sha256']==mc['report']['sha256']==residual['sourceReportSha256']==sha(OLD/'report.json')
    assert mc['helperScriptSha256']==sha(R/'boundary_census.py')
    aggregate=Counter();positive_values=[];transitions=Counter();carry=Counter();marker_transitions=Counter();runs=[];special=[]
    for run in [3,4,7,8]:
        visit=report['visits'][run];assert visit['run']==run and visit['unit']==1 and not visit['preflight']
        sql=csvrows(OLD/'official-sql'/f'run{run}-slices.csv')
        all_complete=[s for s in sql if int(s['dur'])>=0]
        cpu=[s for s in all_complete if s['thread_ts']!='[NULL]' and s['thread_dur']!='[NULL]']
        posdur=[s for s in cpu if int(s['dur'])>0];inst=[s for s in cpu if int(s['dur'])==0]
        values=[int(s['thread_dur'])-int(s['dur']) for s in cpu]; positives=[x for x in values if x>0];positive_values+=positives
        c=Counter({'sqlComplete':len(all_complete),'sqlCpu':len(cpu),'sqlMissingCpu':len(all_complete)-len(cpu),'sqlInstantCpu':len(inst),
            'sqlPositiveDurationCpu':len(posdur),'strictPositive':len(positives),'instantStrictPositive':sum(int(s['thread_dur'])>0 for s in inst)})
        for x in values:c['sqlSign.'+sign(x)]+=1
        for s in posdur:
            w=int(s['dur']);t=int(s['thread_dur']);assert w>=0 and t>=0
            transitions[(sign(t-w),sign(t//1000-w//1000))]+=1
            wc=(int(s['ts'])+w)//1000-(int(s['ts'])//1000+w//1000)
            tc=(int(s['thread_ts'])+t)//1000-(int(s['thread_ts'])//1000+t//1000)
            assert wc in [0,1] and tc in [0,1];carry[(wc,tc)]+=1
        pid,tid=visit['conversion']['rendererPidTid']
        j=load(OLD/f'run{run}.json');jx=[e for e in j['traceEvents'] if e.get('ph')=='X' and (e.get('pid'),e.get('tid'))==(pid,tid)]
        assert all(all(k in e for k in ['dur','tdur','tts']) for e in jx)
        st=Counter((s['name'],int(s['ts'])//1000,int(s['dur'])//1000,int(s['thread_ts'])//1000,int(s['thread_dur'])//1000) for s in posdur)
        jt=Counter((e['name'],e['ts'],e['dur'],e['tts'],e['tdur']) for e in jx);assert st==jt
        c['jsonX']=len(jx);c['jsonStrictPositive']=sum(e['tdur']>e['dur'] for e in jx)
        c['ambiguousJsonEvents']=sum(n for key,n in jt.items() if st[key]>1)
        del j,jx
        raw_path=OLD/f'raw-counter-run{run}.json'; raw=load(raw_path)
        assert raw['script_sha256']==bc['rawDecoderSha256']
        rows=[x for x in raw['ledger'] if (x['event_association_at_end'].get('pid'),x['event_association_at_end'].get('tid'))==(pid,tid) and x['cpu_ns'] is not None]
        cmap=defaultdict(list)
        for x in csvrows(OLD/'official-sql'/f'run{run}-counters.csv'):
            if x['name']=='thread_time':cmap[(str(int(x['uuid'])&((1<<64)-1)),finiteint(x['value']))].append(int(x['ts']))
        def wall(row):
            candidates=cmap[(row['cpu_counter_uuid'],finiteint(row['cpu_ns']))]
            assert len(candidates)==1;return candidates[0]
        by_index={x['packet_index']:x for x in rows};index={x['packet_index']:i for i,x in enumerate(rows)}
        for x in rows:wall(x)
        c['rawCpuPoints']=len(rows);stacks=defaultdict(list);pairs=defaultdict(list)
        for x in rows:
            key=(x['sequence_id'],x['event_track_uuid'])
            if x['type']==1:stacks[key].append(x)
            if x['type']==2:
                assert stacks[key];start=stacks[key].pop()
                pairs[(start['name'],finiteint(start['cpu_ns']),finiteint(x['cpu_ns']))].append((start,x))
        assert not any(stacks.values())
        point_order=[x['packet_index'] for x in rows]
        wall_order=[x['packet_index'] for x in sorted(rows,key=lambda x:(wall(x),x['packet_index']))]
        assert point_order==wall_order
        for a,b in zip(rows,rows[1:]):assert wall(b)>wall(a) and b['cpu_ns']>a['cpu_ns']
        saved=next(v for v in bc['visits'] if v['run']==run)
        assert sha(raw_path)==saved['inputs']['rawLedger']['sha256']
        assert Counter(x['sql']['id'] for x in saved['strictPositiveSliceRecords'])==Counter(int(s['id']) for s in cpu if int(s['thread_dur'])>int(s['dur']))
        for x in saved['strictPositiveSliceRecords']:
            s=x['sql'];key=(s['name'],s['thread_ts'],s['thread_ts']+s['thread_dur']);assert len(pairs[key])==1
            start,end=pairs[key][0];assert x['excessNs']==s['thread_dur']-s['dur']>0
            assert start['packet_index']==x['begin']['packetIndex'] and end['packet_index']==x['end']['packetIndex']
            assert wall(start)==s['ts'] and wall(end)==s['ts']+s['dur']
            inside=[t for t in raw['transitions'] if t['sequence_id']==start['sequence_id'] and start['packet_index']<t['packet_index']<=end['packet_index']]
            c['positivePairClearInside']+=any(t['action']=='clear' for t in inside)
            c['positivePairSameEpoch']+=start['sequence_epoch']==end['sequence_epoch']
            i=index[end['packet_index']];nextpoint=rows[i+1] if i+1<len(rows) else None
            if nextpoint is None:
                assert x['packetOrder']['status']=='noNextRetainedPoint';c['positiveNoNext']+=1;continue
            gap=wall(nextpoint)-wall(end);cpugap=nextpoint['cpu_ns']-end['cpu_ns']
            assert gap==x['packetOrder']['wallGapNs'] and cpugap==x['packetOrder']['cpuGapNs']
            assert nextpoint['packet_index']==x['packetOrder']['nextPacketIndex']==x['wallOrder']['nextPacketIndex']
            assert gap>=x['excessNs'] and gap>0 and cpugap>0
            for point in [end,nextpoint]:
                assert point['packet_clock_id_raw'] is None and point['default_clock_id_raw']==64
                assert point['event_timestamp_delta_us_raw'] is None and point['event_timestamp_absolute_us_raw'] is None
            c['positiveNextGapAtLeastExcess']+=1
            c['positiveNextAvailable']+=1
        assert len(saved['strictPositiveSliceRecords'])==len(positives)
        for sample in visit['samples']:
            marker_names={m['label']:m['name'] for m in sample['markers']};lookup={m['name']:m for m in visit['conversion']['markers']}
            savedvisit=next(v for v in mc['visits'] if v['run']==run)
            for kind in ['mark','stamp']:
                for label in ['handler-end','first-raf','second-raf']:
                    savedwin=next(w for w in savedvisit['windows'] if w['branch']==sample['branch'] and w['trial']==sample['trial'] and w['kind']==kind and w['to']==label)
                    points=[]
                    for endpoint,ename in [('start',marker_names['capture']),('end',marker_names[label])]:
                        row=by_index[savedwin[endpoint]['packetIndex']];name=row.get('data_message') if kind=='stamp' else row['name']
                        assert name==ename and (row['name']=='TimeStamp')==(kind=='stamp')
                        e=lookup[ename][kind];w=wall(row);t=finiteint(row['cpu_ns'])
                        assert w//1000==e['ts'] and t//1000==e['tts'];points.append((w,t,e))
                    a,b=points;ns=(b[1]-a[1])-(b[0]-a[0]);us=(b[2]['tts']-a[2]['tts'])-(b[2]['ts']-a[2]['ts'])
                    assert ns==savedwin['savedNs']['excessNs'] and us*1000==savedwin['jsonUsMultipliedBy1000']['excessNs']
                    marker_transitions[(sign(ns),sign(us))]+=1;c['markerWindows']+=1
                    if ns>0 or us>0:special.append({'run':run,'branch':sample['branch'],'trial':sample['trial'],'kind':kind,'to':label,'nsExcess':ns,'jsonUsExcess':us})
        aggregate.update(c);runs.append({'run':run,'counts':dict(c),'rawLedgerSha256':sha(raw_path)})
        del raw,rows,by_index,pairs
    positive_values.sort()
    quant={f'p{p}':positive_values[math.ceil(len(positive_values)*p/100)-1] for p in [50,95,99]}
    assert quant=={'p50':30,'p95':960,'p99':1788};assert max(positive_values)==129988
    assert aggregate['strictPositive']==27879 and aggregate['sqlCpu']==83817
    assert aggregate['positiveNextAvailable']==27876 and aggregate['positiveNoNext']==3
    assert aggregate['markerWindows']==192
    result={'status':'completed','scriptSha256':sha(Path(__file__)),'scope':'Independent saved-data arithmetic/link review; no measurements or proto decoding.',
        'inputHashes':{n:sha(R/n) for n in ['PLAN.md','PLAN_ADDITION.md','residual-census.json','precision-census.json','boundary-census.json','marker-ns-census.json']},
        'runs':runs,'totals':dict(aggregate),'positiveQuantilesNs':quant,'maxPositiveNs':max(positive_values),
        'durationSignTransitions':{f'{a}->{b}':n for (a,b),n in transitions.items()},
        'durationEndpointCarry':{f'{a},{b}':n for (a,b),n in carry.items()},
        'markerSignTransitions':{f'{a}->{b}':n for (a,b),n in marker_transitions.items()},'markerSpecialCases':special}
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'counts':dict(aggregate),'quantiles':quant,'markerTransitions':result['markerSignTransitions']}))
if __name__=='__main__':main()
