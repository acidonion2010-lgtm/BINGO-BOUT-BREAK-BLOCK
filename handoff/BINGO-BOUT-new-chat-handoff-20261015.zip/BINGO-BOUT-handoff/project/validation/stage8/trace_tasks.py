#!/usr/bin/env python3
"""Trace trusted HARD clicks with top-level tasks and frame categories.

Reuses stage7 fixtures, input transports, four response markers and integrity
checks. Extra categories and read-only /proc snapshots are diagnostic overhead,
not production changes or a normal latency benchmark. The source HTML is read
without modification. No scheduler settings or kernel switches are changed.
"""

import argparse
import collections
import functools
import gzip
import hashlib
import http.server
import json
import os
from pathlib import Path
import statistics
import sys
import threading
import time
from urllib.parse import quote

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'stage7'))
import trace_response as stage7


BASE_CATEGORIES = ('toplevel', 'cc', 'viz', 'devtools.timeline',
                   'blink.user_timing', 'renderer.scheduler', 'v8')
FRAME_CATEGORY = 'disabled-by-default-devtools.timeline.frame'
CATEGORIES = BASE_CATEGORIES
KERNEL_CONFIG = {'readAvailable': False, 'notReadYet': True}
shared = stage7.shared
write_json = stage7.write_json
INSTALL_MARKER = stage7.INSTALL_MARKER.replace('bingo.stage7.', 'bingo.stage8.')


class PerfCandidateCapture:
    """Optional per-candidate collectors; always preserve errors and close FDs."""

    def __init__(self, discovery):
        self.discovery = discovery
        self.collectors = {}
        self.result = {'requested': True, 'rendererCandidates': discovery,
                       'candidateCaptures': {}, 'clockAlignment': 'unverified; requires trace/perf timestamp analysis'}

    def start(self):
        self.result['hostEnableStartMonotonicNs'] = time.monotonic_ns()
        try:
            from perf_switch import PerfSwitchCollector
        except Exception as error:
            self.result['moduleImportFailure'] = {'type': type(error).__name__, 'detail': str(error)}
            self.result['hostEnableEndMonotonicNs'] = time.monotonic_ns()
            return
        for pid in self.discovery.get('rendererPids', []):
            key = str(pid)
            item = {'requestedTid': pid, 'hostStartCallMonotonicNs': time.monotonic_ns(),
                    'startReturned': False}
            self.result['candidateCaptures'][key] = item
            try:
                collector = PerfSwitchCollector(pid, ring_bytes=65536)
                self.collectors[key] = collector
                item['startReturned'] = bool(collector.start())
            except Exception as error:
                item['startFailure'] = {'type': type(error).__name__, 'detail': str(error)}
            item['hostStartReturnedMonotonicNs'] = time.monotonic_ns()
        self.result['hostEnableEndMonotonicNs'] = time.monotonic_ns()

    def finish(self):
        self.result['hostDisableStartMonotonicNs'] = time.monotonic_ns()
        for key, collector in self.collectors.items():
            item = self.result['candidateCaptures'][key]
            item['hostFinishCallMonotonicNs'] = time.monotonic_ns()
            try:
                item['collectorReport'] = collector.finish()
            except Exception as error:
                item['finishFailure'] = {'type': type(error).__name__, 'detail': str(error)}
                try:
                    collector.close()
                except Exception as close_error:
                    item['closeFailure'] = {'type': type(close_error).__name__, 'detail': str(close_error)}
            item['hostFinishReturnedMonotonicNs'] = time.monotonic_ns()
        self.collectors.clear()
        self.result['hostDisableEndMonotonicNs'] = time.monotonic_ns()
        return self.result

    def select_thread(self, pid, tid):
        selection = {'tracePid': pid, 'traceTid': tid, 'matchedCandidate': False,
                     'captureChecksPassed': False,
                     'clockAlignment': 'unverified; requires trace/perf timestamp analysis'}
        item = self.result['candidateCaptures'].get(str(tid))
        if not item or item['requestedTid'] != tid or pid != tid:
            selection['unavailableReason'] = 'Trace main PID/TID did not directly match a collected renderer candidate.'
            return selection
        selection.update({'matchedCandidate': True, 'candidateCapture': item})
        report = item.get('collectorReport', {})
        count = report.get('switchRecordCount', 0)
        selection['switchRecordCount'] = count
        selection['captureChecksPassed'] = bool(item.get('startReturned')
            and report.get('integrityChecksPassed') is True
            and isinstance(count, int) and count > 0)
        selection['zeroRecordsWarning'] = (None if count > 0
            else 'No switch records; emission and clock alignment remain unverified. This is not evidence that no scheduling wait occurred.')
        if not selection['captureChecksPassed']:
            selection['unavailableReason'] = 'Selected-thread recording was unavailable, empty or failed integrity checks; see raw collector report.'
        return selection


def read_scheduler_flag():
    path = Path('/proc/sys/kernel/sched_schedstats')
    try:
        raw = path.read_text().strip()
        value = int(raw)
        return {'path': str(path), 'readAvailable': True, 'value': value,
                'detailedSchedstatsEnabled': value == 1,
                'limits': 'This optional detailed-schedstats switch does not alone establish whether basic CONFIG_SCHED_INFO run_delay counters are collected.'}
    except (OSError, ValueError) as error:
        return {'path': str(path), 'readAvailable': False,
                'detailedSchedstatsEnabled': None,
                'failure': {'type': type(error).__name__, 'detail': str(error)}}


def read_kernel_config():
    path = Path('/proc/config.gz')
    wanted = {'CONFIG_SCHED_INFO', 'CONFIG_SCHEDSTATS', 'CONFIG_FTRACE'}
    result = {'path': str(path), 'readAvailable': False, 'fields': {}}
    try:
        with gzip.open(path, 'rt') as source:
            for line in source:
                line = line.strip()
                if line.startswith('# ') and line.endswith(' is not set'):
                    key = line[2:-11]
                    if key in wanted:
                        result['fields'][key] = 'n'
                elif '=' in line:
                    key, value = line.split('=', 1)
                    if key in wanted:
                        result['fields'][key] = value
        result['readAvailable'] = True
    except (OSError, UnicodeError) as error:
        result['failure'] = {'type': type(error).__name__, 'detail': str(error)}
    return result


def discover_renderers(browser_session):
    result = {'hostStartMonotonicNs': time.monotonic_ns(), 'available': False}
    try:
        processes = browser_session.send('SystemInfo.getProcessInfo')['processInfo']
        candidates = [process for process in processes if process.get('type') == 'renderer']
        pids = sorted({int(process['id']) for process in candidates
                       if int(process['id']) > 0})
        result.update({'available': True, 'rendererPids': pids,
                       'rendererProcesses': candidates})
    except Exception as error:
        result.update({'rendererPids': [],
                       'failure': {'type': type(error).__name__, 'detail': str(error)}})
    result['hostEndMonotonicNs'] = time.monotonic_ns()
    return result


def read_renderer_main(pid):
    """Read candidate main task pid==tid; trace identity is checked afterward."""
    task = Path('/proc') / str(pid) / 'task' / str(pid)
    result = {'hostReadStartMonotonicNs': time.monotonic_ns(),
              'candidatePid': pid, 'candidateTid': pid, 'taskPath': str(task)}
    try:
        raw = (task / 'schedstat').read_text().strip()
        fields = [int(value) for value in raw.split()]
        if len(fields) != 3:
            raise ValueError('Expected runtime, runqueue wait, timeslices')
        result['schedstat'] = {'readAvailable': True, 'raw': raw,
                               'runtimeNs': fields[0], 'runqueueWaitNs': fields[1],
                               'timeslices': fields[2]}
    except (OSError, ValueError) as error:
        result['schedstat'] = {'readAvailable': False,
                               'failure': {'type': type(error).__name__, 'detail': str(error)}}
    try:
        parsed = dict(line.split(':', 1) for line in (task / 'status').read_text().splitlines()
                      if ':' in line)
        selected = {name: parsed[name].strip() for name in (
            'Name', 'State', 'Tgid', 'Pid', 'PPid', 'Threads', 'NSpid', 'NStgid',
            'Cpus_allowed_list', 'voluntary_ctxt_switches', 'nonvoluntary_ctxt_switches')
                    if name in parsed}
        result['status'] = {'readAvailable': True, 'fields': selected}
    except (OSError, ValueError) as error:
        result['status'] = {'readAvailable': False,
                            'failure': {'type': type(error).__name__, 'detail': str(error)}}
    # A pid can be reused. Compare process start ticks before interpreting deltas.
    try:
        raw_stat = (task / 'stat').read_text()
        suffix = raw_stat[raw_stat.rfind(')') + 2:].split()
        result['processStartTicks'] = int(suffix[19])  # full stat field 22
    except (OSError, ValueError, IndexError) as error:
        result['processStartTicks'] = None
        result['identityReadFailure'] = {'type': type(error).__name__, 'detail': str(error)}
    result['hostReadEndMonotonicNs'] = time.monotonic_ns()
    return result


def proc_snapshot(discovery):
    result = {'hostReadStartMonotonicNs': time.monotonic_ns(),
              'processDiscovery': discovery, 'schedulerStats': read_scheduler_flag(),
              'kernelConfig': KERNEL_CONFIG}
    result['rendererMainCandidates'] = {str(pid): read_renderer_main(pid)
                                         for pid in discovery.get('rendererPids', [])}
    result['hostReadEndMonotonicNs'] = time.monotonic_ns()
    return result


def select_proc_thread(before, after, pid, tid):
    result = {'tracePid': pid, 'traceTid': tid, 'matchedCandidate': False,
              'deltaInterval': 'Host before-input through after-callback snapshots, not exact response marker boundaries.'}
    if pid != tid:
        result['unavailableReason'] = 'Trace main task is not pid==tid; no guessed namespace mapping.'
        return result
    a = before.get('rendererMainCandidates', {}).get(str(pid))
    b = after.get('rendererMainCandidates', {}).get(str(pid))
    if not a or not b:
        result['unavailableReason'] = 'Trace pid did not directly match a candidate in both host /proc snapshots.'
        return result
    result.update({'matchedCandidate': True, 'before': a, 'after': b})
    same_process = (a.get('processStartTicks') is not None
                    and a['processStartTicks'] == b.get('processStartTicks'))
    result['sameProcessIdentityConfirmed'] = same_process
    if not same_process:
        result['unavailableReason'] = 'Process start identity unavailable or changed; counter deltas not interpreted.'
        return result
    sched_a, sched_b = a.get('schedstat', {}), b.get('schedstat', {})
    if sched_a.get('readAvailable') and sched_b.get('readAvailable'):
        deltas = {name: sched_b[name] - sched_a[name]
                  for name in ('runtimeNs', 'runqueueWaitNs', 'timeslices')}
        result['schedstatDeltas'] = deltas
        result['schedstatCountersMonotonic'] = all(value >= 0 for value in deltas.values())
    else:
        result['schedstatDeltas'] = None
        result['schedstatCountersMonotonic'] = False
    configured = all(snapshot.get('kernelConfig', {}).get('fields', {}).get('CONFIG_SCHED_INFO') == 'y'
                     for snapshot in (before, after))
    result['basicSchedInfoConfigured'] = configured
    result['runqueueWaitInterpretationAvailable'] = (configured
        and result['schedstatDeltas'] is not None and result['schedstatCountersMonotonic'])
    result['positiveRunqueueDeltaObserved'] = (result['schedstatDeltas'] is not None
        and result['schedstatCountersMonotonic'] and result['schedstatDeltas']['runqueueWaitNs'] > 0)
    result['availabilityValidity'] = ('Basic sched_info configured and cumulative counters readable; positive run_delay delta is supporting evidence of runnable wait within the host bracket.'
        if result['runqueueWaitInterpretationAvailable']
        else 'Basic accounting configuration or counter validity is unverified; retain raw values without treating zero as absence of wait.')
    result['zeroMayBeUnimplemented'] = not result['runqueueWaitInterpretationAvailable']
    result['runqueueWaitWarning'] = 'Zero delta never proves no runnable wait: boundaries are coarse, and a current wait may not be accounted until the task runs again. Detailed schedstats sysctl is separate from basic CONFIG_SCHED_INFO counters.'
    status_a, status_b = a.get('status', {}), b.get('status', {})
    switches = {}
    if status_a.get('readAvailable') and status_b.get('readAvailable'):
        for name in ('voluntary_ctxt_switches', 'nonvoluntary_ctxt_switches'):
            try:
                switches[name] = int(status_b['fields'][name]) - int(status_a['fields'][name])
            except (KeyError, ValueError):
                switches[name] = None
    result['contextSwitchDeltas'] = switches
    return result


class TaskTraceCapture(stage7.TraceCapture):
    def start(self):
        self.summary['categories'] = list(CATEGORIES)
        self.summary['hostStartSendMonotonicNs'] = time.monotonic_ns()
        self.session.send('Tracing.start', {
            'categories': ','.join(CATEGORIES), 'options': 'record-until-full',
            'bufferUsageReportingInterval': 100, 'transferMode': 'ReturnAsStream',
            'streamFormat': 'json', 'streamCompression': 'none',
        })
        self.active = True
        self.summary['started'] = True
        self.summary['hostStartAcknowledgedMonotonicNs'] = time.monotonic_ns()

    def finish(self, markers):
        super().finish(markers)
        try:
            self._inspect_tasks(markers)
        except Exception as error:
            self.summary['integrityChecksPassed'] = False
            self.summary['failure'] = {'type': type(error).__name__, 'detail': str(error)}
            raise

    def _inspect_tasks(self, markers):
        trace = json.loads(self.path.read_text())
        events = trace['traceEvents']
        capture_name = markers[0]['name']
        candidates = [event for event in events if event.get('name') == capture_name
                      and event.get('cat') == 'blink.user_timing']
        if len(candidates) != 1:
            raise AssertionError('Expected a unique capture PerformanceMark')
        pid, tid = candidates[0]['pid'], candidates[0]['tid']
        marker_events = [event for event in events if event.get('name') in
                         {marker['name'] for marker in markers}
                         and event.get('cat') == 'blink.user_timing']
        if len(marker_events) != 4 or len({(e['pid'], e['tid']) for e in marker_events}) != 1:
            raise AssertionError('Response markers do not identify a single renderer thread')
        main = [event for event in events if event.get('pid') == pid and event.get('tid') == tid]
        main_names = collections.Counter(event.get('name') for event in main)
        task_names = {name: count for name, count in main_names.items()
                      if name and (name == 'RunTask' or 'RunTask' in name or 'ThreadController' in name)}
        self.summary['taskAvailability'] = {
            'rendererPid': pid, 'rendererTid': tid,
            'mainThreadNameCounts': dict(main_names), 'mainThreadTaskNameCounts': task_names,
            'mainThreadRunTaskCount': main_names.get('RunTask', 0),
            'mainThreadRunTaskLikeCount': sum(count for name, count in task_names.items()
                                               if 'RunTask' in name),
            'hasMainThreadTaskEvents': bool(task_names),
            'synchronousBeginEndCounts': {phase: sum(event.get('ph') == phase for event in main)
                                          for phase in ('B', 'E')},
            'wholeTraceTaskNameCounts': dict(collections.Counter(
                event['name'] for event in events if 'RunTask' in event.get('name', ''))),
            'frameNameCounts': dict(collections.Counter(
                event['name'] for event in events
                if any(word in event.get('name', '')
                       for word in ('BeginFrame', 'BeginMainFrame', 'DrawFrame', 'Presentation', 'SubmitCompositorFrame')))),
            'notAPerformancePass': True,
        }


def trial(page, session, browser_session, protocol, version, number, folder, traced, use_proc, use_perf=False):
    locator, metadata = stage7.prepare_input(page, protocol)
    token = f'{protocol}.{version}.{number:02d}'
    page.evaluate('''data => {
        traceResponseState.enabled = data.enabled;
        traceResponseState.token = data.token;
        traceResponseState.markers = [];
    }''', {'enabled': traced, 'token': token})
    discovery = discover_renderers(browser_session) if (use_proc or (traced and use_perf)) else {'disabled': True}
    trace = TaskTraceCapture(session, page, folder / 'traces' / f'{token}.json') if traced else None
    perf = PerfCandidateCapture(discovery) if traced and use_perf else None
    perf_finished = False
    output = {'trial': number, 'traced': traced, 'outcome': 'preparing'}
    try:
        if trace:
            trace.start()
        output['procBeforeInput'] = proc_snapshot(discovery) if use_proc else {'disabled': True}
        if perf:
            perf.start()
        output['cpuGroupBeforeInput'] = stage7.cpu_group_snapshot()
        output['outcome'] = 'dispatching'
        delay = stage7.phase_input.REQUESTED_DELAYS_MS[(number - 1) % len(stage7.phase_input.REQUESTED_DELAYS_MS)]
        output['requestedDelayMs'] = delay if protocol == 'cdp-cue' else None
        output['sample'] = stage7.dispatch_input(page, session, locator, metadata, delay)
        if perf:
            output['perfCapture'] = perf.finish()
            perf_finished = True
        output['cpuGroupAfterCallbacks'] = stage7.cpu_group_snapshot()
        after_discovery = discover_renderers(browser_session) if use_proc else {'disabled': True}
        output['procAfterCallbacks'] = proc_snapshot(after_discovery) if use_proc else {'disabled': True}
        output['outcome'] = 'accepted'
    except Exception as error:
        output.update({'outcome': 'failed',
                       'failure': {'type': type(error).__name__, 'detail': str(error)}})
        raise
    finally:
        try:
            if perf and not perf_finished:
                output['perfCapture'] = perf.finish()
                perf_finished = True
            try:
                output['markers'] = page.evaluate('traceResponseState.markers')
            except Exception as error:
                output['markers'] = []
                output['markerReadFailure'] = {'type': type(error).__name__, 'detail': str(error)}
            if trace:
                trace.finish(output['markers'])
                identity = trace.summary['taskAvailability']
                if use_proc:
                    output['selectedRendererProc'] = select_proc_thread(
                        output.get('procBeforeInput', {}), output.get('procAfterCallbacks', {}),
                        identity['rendererPid'], identity['rendererTid'])
                if perf:
                    output['selectedRendererPerf'] = perf.select_thread(
                        identity['rendererPid'], identity['rendererTid'])
                    output['perfCaptureChecksPassed'] = output['selectedRendererPerf']['captureChecksPassed']
                    output['perfRecordingFailureIsProductionFailure'] = False
        finally:
            if trace:
                output['trace'] = trace.summary
            if perf:
                perf_path = folder / 'perf' / f'{token}.json'
                write_json(perf_path, {'capture': output.get('perfCapture', perf.result),
                                      'selectedRenderer': output.get('selectedRendererPerf'),
                                      'recordingFailureIsProductionFailure': False})
                output['perfFile'] = str(perf_path)
            write_json(folder / 'samples' / f'{token}.json', output)
    if perf and not output.get('perfCaptureChecksPassed'):
        raise AssertionError(f'Selected renderer perf recording unavailable/empty/incomplete; raw data preserved at {output["perfFile"]}')
    return output


def main():
    global CATEGORIES, KERNEL_CONFIG
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('before', type=Path)
    parser.add_argument('after', type=Path)
    parser.add_argument('outputfolder', type=Path)
    parser.add_argument('--trials', type=int, default=8,
                        help='CDP trials per version; also the ceiling for default normal trials')
    parser.add_argument('--normal-trials', type=int,
                        help='Normal trials per version (default: min(4, --trials))')
    parser.add_argument('--protocol', choices=('normal-locator', 'cdp-cue', 'both'), default='both')
    parser.add_argument('--order', choices=('before-after', 'after-before', 'reverse-second', 'inverse-reverse-second'),
                        default='reverse-second', help='Version order; reverse-second reverses the second protocol')
    parser.add_argument('--frame-events', action='store_true', help=f'Also include {FRAME_CATEGORY}')
    parser.add_argument('--no-proc', action='store_true',
                        help='Skip /proc snapshots; perf still discovers renderer candidates when enabled')
    parser.add_argument('--perf-switches', action='store_true',
                        help='Also collect optional per-renderer perf switch records; unavailable/empty/incomplete selected capture fails after saving trace')
    args = parser.parse_args()
    if args.trials < 1 or (args.normal_trials is not None and args.normal_trials < 1):
        parser.error('Use positive trial counts')
    CATEGORIES = BASE_CATEGORIES + ((FRAME_CATEGORY,) if args.frame_events else ())
    KERNEL_CONFIG = read_kernel_config() if not args.no_proc else {'disabled': True}
    protocols = ('normal-locator', 'cdp-cue') if args.protocol == 'both' else (args.protocol,)
    counts = {'cdp-cue': args.trials,
              'normal-locator': args.normal_trials if args.normal_trials is not None else min(4, args.trials)}
    folder = args.outputfolder.resolve()
    paths = {version: getattr(args, version).resolve(strict=True)
             for version in ('before', 'after')}
    serve_root = Path(os.path.commonpath([str(path.parent) for path in paths.values()]))

    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *unused):
            pass

    server = http.server.ThreadingHTTPServer(
        ('127.0.0.1', 0), functools.partial(Handler, directory=str(serve_root)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    report = {
        'conditions': {
            'executable': '/usr/bin/chromium', 'viewport': [1280, 900], 'foregroundPages': 1,
            'protocols': list(protocols), 'trialsPerVersion': {p: counts[p] for p in protocols},
            'versionOrder': args.order, 'untracedWarmupClicksPerVisit': 1,
            'sources': {version: {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                        for version, path in paths.items()},
            'reusedHarness': {'path': str(Path(stage7.__file__).resolve()),
                              'sha256': hashlib.sha256(Path(stage7.__file__).read_bytes()).hexdigest()},
            'harnessSource': {'path': str(Path(__file__).resolve()),
                              'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
            'traceCategories': list(CATEGORIES), 'transferMode': 'ReturnAsStream',
            'traceMarkers': list(stage7.LABELS),
            'hostClock': {key: getattr(time.get_clock_info('monotonic'), key)
                          for key in ('implementation', 'monotonic', 'adjustable', 'resolution')},
            'kernelConfig': KERNEL_CONFIG,
            'realBlobWorkerPreparationsPerVisit': 1,
            'fixture': 'Stage7 fixed HARD P1 midgame, masks3/24,t8, fixed random0.8; normal HTTP, 3 RAF reset, sound/BGM/game animations retained.',
            'sourcePolicy': 'No HTML edits or selection/drawing/audio/timer substitutions; stage7 result files are not changed.',
            'traceBoundary': 'After fixture/descriptor, before input. CDP trial actionability/hover precedes tracing; normal locator internal actionability/move remains inside tracing. After the second callback, host CPU/proc observations occur before Tracing.end.',
            'procSnapshots': {'enabled': not args.no_proc,
                'discovery': 'Browser-level SystemInfo.getProcessInfo lists renderer PIDs before trace and after observed callbacks. Read candidate main tasks pid==tid; match to trace capture PerformanceMark PID/TID after collecting trace.',
                'files': ['/proc/PID/task/PID/schedstat', '/proc/PID/task/PID/status', '/proc/PID/task/PID/stat', '/proc/sys/kernel/sched_schedstats', '/proc/config.gz'],
                'identity': 'Direct PID/TID match and equal process start ticks are required for counter differences. No speculative namespace mapping.',
                'schedstat': 'runtime/runqueue_wait in nanoseconds; timeslices count. Basic CONFIG_SCHED_INFO accounting is checked separately from optional detailed CONFIG_SCHEDSTATS/sysctl. Positive monotonic run_delay deltas support runnable wait in the coarse host bracket; zero never proves absence of wait. Settings are read only.',
                'scope': 'Host snapshot intervals include input transport and automation after callback; not exact marker windows. Runtime, context switches and run delay cannot be assigned exactly to each RAF interval.',
                'failurePolicy': 'Discovery/proc unavailable is retained as unavailable metadata, not silently reported as zero. Trace/click integrity still fails on missing/incomplete data.'},
            'perfSwitches': {'enabled': args.perf_switches,
                'collectorModule': str(Path(__file__).with_name('perf_switch.py')),
                'targets': 'Renderer candidates from browser-level SystemInfo; one per-thread FD for each candidate main TID. Match capture marker PID/TID afterward.',
                'enabledBoundary': 'After proc-before-input snapshots, before CPU-group-before-input and trusted input.',
                'disabledBoundary': 'Immediately after dispatch_input returns its accepted second-RAF sample, before CPU-group-after-callback and proc observations.',
                'warmup': 'No perf collection for the separate untraced warmup.',
                'ringBytesPerThread': 65536,
                'clock': 'Collector requests CLOCK_MONOTONIC; actual clock/attr/records are retained in raw reports. Clock alignment still requires separate analysis.',
                'failurePolicy': 'Unavailable, empty, LOST/overflow/truncated or invalid selected-thread capture does not receive PASS; raw reports and trace are preserved before nonzero exit. This is a measurement failure, not a production-game failure.',
                'scope': 'All candidate reports saved separately in perf/*.json; selected-thread record timestamps support later trace analysis. This option changes the diagnostic observation condition.'},
            'clocks': 'Trace and page marker correspondence is retained. Host monotonic ns identifies observation order only, never directly subtracted from page performance.now.',
            'limits': 'Additional categories, SystemInfo requests and proc reads perturb scheduling. No normal-latency or non-regression PASS; no historical untraced causal attribution. Physical presentation and speaker output unmeasured; Playwright headless uses --mute-audio.',
        },
        'visits': [], 'pageErrors': [], 'browserLogs': [],
        'behaviorChecksPassed': False, 'traceIntegrityChecksPassed': False,
        'perfCaptureChecksPassed': False if args.perf_switches else None,
        'latencyPassAssessed': False,
    }
    current = {}
    report_path = folder / 'report.json'

    def save():
        write_json(report_path, report)

    save()
    try:
        with stage7.sync_playwright() as playwright:
            browser = playwright.chromium.launch(
                executable_path='/usr/bin/chromium', headless=True,
                args=['--no-sandbox', '--disable-dev-shm-usage'])
            report['conditions']['browserVersion'] = browser.version
            page = browser.new_page(viewport={'width': 1280, 'height': 900})
            page.on('pageerror', lambda error: report['pageErrors'].append({**current, 'error': str(error)}))
            page.on('console', lambda message: report['browserLogs'].append(
                {**current, 'type': message.type, 'text': message.text})
                if message.type in ('error', 'warning') else None)
            session = page.context.new_cdp_session(page)
            browser_session = browser.new_browser_cdp_session()
            try:
                for protocol_index, protocol in enumerate(protocols):
                    reverse = (args.order == 'after-before'
                               or (args.order == 'reverse-second' and protocol_index == 1)
                               or (args.order == 'inverse-reverse-second' and protocol_index == 0))
                    order = ('after', 'before') if reverse else ('before', 'after')
                    for version in order:
                        current.clear()
                        current.update({'protocol': protocol, 'version': version, 'trial': None})
                        source = paths[version]
                        relative = quote(source.relative_to(serve_root).as_posix())
                        page.goto(f'http://127.0.0.1:{server.server_port}/{relative}',
                                  wait_until='load', timeout=60000)
                        page.bring_to_front()
                        tests = json.loads(page.locator('#rule-test-results').text_content())
                        if tests['total'] != 322 or tests['passed'] != 322:
                            raise AssertionError(tests)
                        preparation = page.evaluate(shared.PREPARE)
                        page.evaluate(INSTALL_MARKER)
                        page.evaluate(stage7.TRACE_INSTRUMENT)
                        page.evaluate(shared.INSTALL_MONITOR)
                        visit = {'protocol': protocol, 'version': version,
                                 'selfTests': tests, 'preparation': preparation, 'samples': []}
                        report['visits'].append(visit)
                        current['trial'] = 0
                        visit['warmup'] = trial(page, session, browser_session, protocol, version,
                                                0, folder, False, not args.no_proc, False)
                        for number in range(1, counts[protocol] + 1):
                            current['trial'] = number
                            result = trial(page, session, browser_session, protocol, version,
                                           number, folder, True, not args.no_proc, args.perf_switches)
                            visit['samples'].append(result)
                            save()
                        visit['traceConditionMediansMs'] = {
                            key: statistics.median(sample['sample'][key] for sample in visit['samples'])
                            for key in shared.METRICS}
                        availability = [sample['trace']['taskAvailability'] for sample in visit['samples']]
                        visit['mainThreadRunTaskCounts'] = [a['mainThreadRunTaskCount'] for a in availability]
                        visit['mainThreadTaskEventCounts'] = [a['mainThreadTaskNameCounts'] for a in availability]
                        print(f"{protocol} {version}: {counts[protocol]} accepted traced clicks; "
                              f"main-thread task events {visit['mainThreadTaskEventCounts']}", flush=True)
                        page.evaluate('''() => {
                            state.turnToken++; discardThinkTimer(); releaseWholeGameCpu();
                            rafPhaseMonitor.running = false; cancelAnimationFrame(rafPhaseMonitor.handle);
                        }''')
                        save()
                if report['pageErrors']:
                    raise AssertionError(report['pageErrors'])
                samples = [sample for visit in report['visits'] for sample in visit['samples']]
                expected = sum(counts[p] * 2 for p in protocols)
                if len(samples) != expected or not all(sample['outcome'] == 'accepted'
                        and sample['trace']['integrityChecksPassed'] for sample in samples):
                    raise AssertionError('Incomplete behavior/trace samples')
                report['behaviorChecksPassed'] = True
                report['traceIntegrityChecksPassed'] = True
                report['acceptedMeasuredClicks'] = len(samples)
                report['acceptedWarmupClicks'] = len(report['visits'])
                if args.perf_switches:
                    report['perfCaptureChecksPassed'] = all(sample.get('perfCaptureChecksPassed')
                                                            for sample in samples)
                report['allSamplesHaveMainThreadTasks'] = all(
                    sample['trace']['taskAvailability']['hasMainThreadTaskEvents'] for sample in samples)
            finally:
                browser.close()
    except Exception as error:
        report['failure'] = {'context': dict(current), 'type': type(error).__name__, 'detail': str(error)}
        save()
        raise
    finally:
        server.shutdown()
        server.server_close()
        save()


if __name__ == '__main__':
    main()
