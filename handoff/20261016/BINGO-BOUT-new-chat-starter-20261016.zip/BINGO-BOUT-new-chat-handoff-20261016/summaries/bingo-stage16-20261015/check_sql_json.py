#!/usr/bin/env python3
"""Match every JSON complete CPU event to the same proto's SQL slice data."""
import csv,json,collections,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent
report=json.loads((R/'report.json').read_text());out={'scriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'reportSha256':hashlib.sha256((R/'report.json').read_bytes()).hexdigest(),'visits':[]}
for v in report['visits']:
 run=v['run'];pid,tid=v['conversion']['rendererPidTid'];rows=list(csv.DictReader((R/f'official-sql/run{run}-slices.csv').open()));slices=[]
 for r in rows:
  if r['thread_ts']=='[NULL]' or r['thread_dur']=='[NULL]' or int(r['dur'])<0:continue
  slices.append({k:(int(val) if k!='name' and val!='[NULL]' else val) for k,val in r.items()})
 events=json.loads((R/f'run{run}.json').read_text())['traceEvents'];xs=[e for e in events if (e.get('pid'),e.get('tid'))==(pid,tid) and e.get('ph')=='X' and 'dur' in e and 'tts' in e and 'tdur' in e]
 index=collections.defaultdict(list)
 for s in slices:index[(s['name'],s['ts']//1000,s['dur']//1000,s['thread_ts']//1000,s['thread_dur']//1000)].append(s)
 missing=[];large=[]
 for e in xs:
  matches=index.get((e['name'],e['ts'],e['dur'],e['tts'],e['tdur']),[])
  if not matches:missing.append(e)
  if e['tdur']-e['dur']>1000:large.append({'json':e,'sqlCandidates':matches})
 # Intersection is descriptive; no events are excluded from the above counts.
 formal=[];warm=[]
 for s in v['samples']:
  found={m['name']:m['mark'] for m in v['conversion']['markers']};labels={m['label']:m['name'] for m in s['markers']}
  window=(found[labels['capture']]['ts'],found[labels['second-raf']]['ts'])
  (warm if s['warmup'] else formal).append(window)
 for item in large:
  e=item['json'];lo=e['ts'];hi=lo+e['dur']
  item['intersectsFormalResponse']=any(lo<=b and hi>=a for a,b in formal)
  item['intersectsWarmupResponse']=any(lo<=b and hi>=a for a,b in warm)
 result={'run':run,'sqlSlicesWithCpu':len(slices),'jsonCompleteWithCpu':len(xs),'jsonCompleteMissingSql':len(missing),'missing':missing,'sqlStrictCpuGreaterThanWall':sum(s['thread_dur']>s['dur'] for s in slices),'sqlCpuExcessOver1ms':sum(s['thread_dur']-s['dur']>1000000 for s in slices),'largeEvents':large}
 out['visits'].append(result)
(R/'same-proto-sql-json-check.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'jsonCompleteMissingSql':sum(v['jsonCompleteMissingSql'] for v in out['visits']),'largeEvents':sum(len(v['largeEvents']) for v in out['visits']),'largeEventsIntersectingFormal':sum(e['intersectsFormalResponse'] for v in out['visits'] for e in v['largeEvents']),'largeEventsIntersectingWarmup':sum(e['intersectsWarmupResponse'] for v in out['visits'] for e in v['largeEvents'])},indent=2))
