# HARD同期handler・2RAF差の過去記録と段階14の範囲

2026-10-15。添付projectの保存済みコード・JSON・段階3/4/5報告・追加検証6報告を読み、
HARDサンプルの中央値と分岐counterを保存値から再照合した。ブラウザー・DP・性能ジョブは
追加実行していない。本体HTMLと過去成果物は変更していない。

## 問題の3数値は別の比較

単位はms。差は各版の全計測クリックをプールした中央値の「後−前」で、対応クリックの
対差中央値ではない。各scriptは1ブラウザーを起動して同じ前面pageを往復するため、
round数を独立ブラウザープロセス数とは数えない。

| 保存記録 | HTML比較 | HARDの計測数・warmup | handler中央値 | 2RAF中央値 | 入力 |
|---|---|---|---|---|---|
| stage3/ui-response.json | 原本→stage3.final | 2round×2版×9=36、warmup4 | 2.50→2.95、**+0.45** | 28.20→27.50、-0.70 | locator.click |
| stage4/ui-response.json | 原本→stage4 | 5round×2版×9=90、warmup10 | 2.80→2.70、-0.10 | 26.70→27.20、**+0.50** | locator.click |
| stage5/raf-phase-response.jsonのA/B | 原本→stage5 | 5round×2版×9=90、warmup10 | 2.80→2.50、-0.30 | 27.10→27.90、**+0.80** | locator.click＋RAF監視 |

stage3全体はNORMAL/HARD/MASTERの108計測＋12warmup。各visitはこの難易度順なので、
HARDはNORMALのwarmup1＋計測9の後にHARD用warmup1を行っている。
stage4はHARDだけ。stage5はA/A（原本/原本）90計測＋10warmupを先に行い、次に上表のA/B。
全体180計測＋20warmupであり、A/AをA/Bから差し引いていない。

stage3/4のui-response.json自体には入力HTMLのpath/hash欄がない。版の対応は同梱の
各README・比較報告と凍結snapshotに基づく。報告の完成版hashはstage3.finalが
`11bbe3d0653c…`、stage4が`9f7a071e7dc3…`。stage5のJSONはsource hashを直接保存し、
原本`e872443dc976…`、stage5`fea09e995bfc…`を確認できる。段階9比較ではない。

## 共通の操作・状態

コードはstage3/ui_response.pyのPREPARE・FIXTURE・INSTRUMENTを基礎にする。

- Chromium154.0.8037.57、headless、1280×900、前面の単一page。
  各visitは通常読込・322自己テスト後、実Blob Workerを1回準備してreadyを待つ。
  PREPAREは一時的にMASTERを設定するが、計測fixtureはHARDへ戻す。
- **先攻P1、人間P1のBREAK入力**。CPU(P2)はこのクリックで**BLOCK**を選ぶ。
  board1の最初の有効セルはindex2（0始まり）。人間のselectedBreakCellも2。
- 配置P1=[8,1,6,3,5,7,4,9,2]、P2=[5,9,1,7,2,6,3,8,4]。
  maskP1=3、maskP2=24、t=8、5回表、turnRole=0、両者4ターン済み。
  phase=break、isStarting=false、isProcessing=falseから開始。
- 固定Math.random()=0.8。HARD mix値0.8>=0.7でreadyの全体DP分岐へ進む。
  保存されたHARD全計測・warmupでwholeDecisions=1、hardDpDecisions=1、hardLegacyDecisions=0。
  全件trusted、clickedIndex=2、wholeStatus=ready、turns=[4,4]も再確認した。
- 履歴はbreak/blockの記憶cell0・streak2・cooldown0へ復元。
  turnToken更新、discardThinkTimer等の既存guardで前試行のcallbackを無効化する。
  音・BGM・CSS演出は有効。時計や本番timer/animation/audio関数を置換しない。
- FIXTUREはDOMのstart-panel/inert/overlayを通常開始状態へ同期し、render後に3回RAFを待つ。
  elementFromPointで標的を検査し、force clickは使わない。
  3RAF待機は有限animationの終了を保証しない。
- 入力は`#board1 .cell:not([disabled])`のfirstへ通常のPlaywright locator.click。
  自動actionability/stability待ちを含む。各visit・各難易度の別warmupは1クリック。

handlerMsはdocumentのclick capture observerから、ゲームhandler後のdocument bubble observerまで。
handleCellClick関数だけの自己時間ではなく、同期DOM・音・演出処理やobserver間の費用を含む。
twoRafMsは同じcaptureから、bubble後に登録する2段のrequestAnimationFrameの2回目実行まで。
物理入力→提示、実画面のpaint完了、REVEAL演出完了、音が聞こえるまでの遅延ではない。

## 既存の補助診断

**stage4/click_causality.py**は通常の2版HTML比較ではない。
stage3.finalを1page・同じDP receiverで読み、solveState/packStrategy/equilibrium/
sanitizePair/sanitize/strategyGapの6メソッドを原本本文とstage3本文で交換する。
A/AとCPU変更、3RAFのみと有限animation自然終了待ちを各15対、計120クリック＋8warmup。
HARD0.8/P1/同じ中盤fixtureを使うが、COOP/COEPによる時計と包括的な関数wrapperが追加される。
3RAFのhandler対差中央値はA/A+0.180、CPU変更+0.035ms、CPU選択は+0.005/-0.010ms。
自然終了待ちのhandlerはA/A-0.030、CPU変更+0.110ms。包括時間は重複するため合計しない。
クリック前には100msのcell background-color transitionがあり、3RAFだけでは終了しなかった。
これらで元の+0.45msの直接原因が確定したとは扱われていない。

stage3の100µs設定CPU profilerも別診断で48計測＋4warmup。
sampling自体が時間を変え、stack sampleの割合を正確なwall寄与へ換算できない。

**stage5/raf_phase_response.py**は通常HTTPでCOOP/COEPを追加せず、連続RAF監視とscalar capture観測を追加。
直前RAFのtimestamp/実行時刻、最初と2回目のRAF timestamp/実行時刻を同時保存する。
hover/animation/BGM descriptorは計時外だが入力位相へ影響し得る。
A/Bの+0.80msはプール中央値差で、visit中央値差は0.0,+2.4,+1.2,0.0,-0.1ms、その中央値は0.0ms。
統計量が異なるため、どちらか一方でPASSにしない。
各sampleの恒等式「2RAF=直前RAF→2回目timestamp幅−click位相＋2回目callback遅れ」は記述的な分解。
平均差は加算できるが中央値差は加算できず、共有timestampによる相関を因果証明にしない。
stage3/4旧記録には直前RAF観測がなく、この追加測定から過去位相を復元することはできない。

**stage6/phase_input_probe.py**は同じ原本→stage5の別CDP入力条件。
stage5のfixture/監視を使い、cue前にlocator.click(trial=True)、座標・hit検査、mouse.move、
descriptorを済ませ、次のRAF callbackがsetTimeout(1/5/9/13ms)を予約する。
hostへ戻ってからCDP mousePressed/mouseReleasedを送る。event timestampの指定・強制click・再試行はない。
要求delayは実際のcapture位相を保証しない。全attemptを保持し、host monotonicはpage時刻から引かない。
4round×2版×16=128計測＋8warmupをA/A、A/Bそれぞれ実行、全体256＋16。
0.8のHARD readyDP・P1中盤は共通だが、locator.clickとは別履歴/入力transport。
A/Bプール差はhandler-0.10、2RAF-0.35msであり、以前の+0.80msを取り消す結果とは扱わない。

## 段階14で既存trace harnessを使う場合

1. 最終計画は原本/段階3.final/段階5/段階9、HARD0.3従来と0.8全体DPの新しいlocator＋trace診断。
   +0.45のstage3と+0.80のstage5は対象版に含むが、+0.50のstage4は含めない。
   旧無trace測定とは履歴や計装が異なるため集約せず、過去原因の直接再現とは呼ばない。
   0.3はDPをreadyに保ったHARD従来分岐で、cpuWholeStatus=fallbackとは別。
2. 旧assert_sample('hard')はDP1/legacy0/whole1を要求する。0.3には分岐別の契約
   （legacy1/DP0/whole0）を追加し、0.8の既存契約は維持する。
   実CPU BLOCK値はhandleCellClick内のlocalからexecuteTurnWithAnimation第2引数へ渡る。
   旧probeは人間selectedBreakCellしか記録しないため、選択同値も確認するなら
   selectCpuBlockCell戻り値をscalarで保存する必要がある。
3. 今回はstage7からTraceのCDP stream回収・hash・dataLoss/buffer検査を再利用し、
   同期B/Eと区間和は別解析器で検証する。
   Worker専用の.solve marker、pid/tid特定、GC/JIT専用分類器をそのままclickへ流用しない。
   一意なclick/capture/bubble/RAF markerからmain rendererの対象pid/tidと境界を確定する。
4. カテゴリは既知のものを明示指定する。getCategories=[]を非対応と解釈して空指定へ落とさない。
   UserTiming、EventDispatch、Layout/UpdateLayoutTree、Paint等の実イベントを確認し、
   記録されなかった活動を0コストとしない。元trace・要求/実カテゴリ・clock・欠測を保持する。
5. handlerの壁時間と同スレッドCPU時計を分け、tts/tdur欠測は不明のまま。
   main threadのGC/JIT・layout等の区間はネストをunionし、包括時間の二重加算を避ける。
   背景raster/GPU/audio threadの重なりをhandlerの直接寄与へ配賦しない。
6. performance.now/RAF引数、trace ts、host monotonicは同じ数値原点ではない。
   一意markerで区間を対応付け、未確認の絶対時刻を直接引かない。
   performance.mark自体やwrapper/traceにも費用があり、従来の無trace時間と同じとみなさない。
   traceの開始・停止・解析やsnapshot取得を同期handler内へ入れない。
7. 今回の通常locator入力でもtrusted、cell2の受理、REVEAL表示、処理状態、audio running、分岐counter、
   DOM応答、callback順序を維持する。要求位相の外れを除外/再試行せず実測位相を保存する。
   新しいcold/warmup回数と版/分岐順序は計測前に固定し、A/A補正や後付け許容差を導入しない。

主要資料：validation/stage3/ui_response.py・ui-response.json・ui_profile.py、
stage4/click_causality.py・click-causality.json・ui-response.json、
stage5/raf_phase_response.py・raf-phase-response.json・analyse_raf.py、
stage6/phase_input_probe.py・phase-input-response.json、および各README・日本語比較報告。
