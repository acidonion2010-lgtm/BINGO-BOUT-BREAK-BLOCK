#!/usr/bin/env python3
"""Independent saved-proc endpoint arithmetic; no browser or CPU job is started."""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys


def require(condition, detail):
    if not condition: raise ValueError(detail)


def stat_fields(raw):
    pid_text, remainder = raw.split('(', 1)
    comm, tail = remainder.rsplit(')', 1)
    fields = tail.split()
    require(len(fields) >= 37, 'Missing /proc stat field39')
    return {'pid': int(pid_text), 'comm': comm, 'state': fields[0],
            'utimeTicks': int(fields[11]), 'stimeTicks': int(fields[12]),
            'threadCount': int(fields[17]), 'starttimeTicks': int(fields[19]),
            'processor': int(fields[36]), 'fieldCount': len(fields) + 2}


def endpoint(snapshot, pid, tid):
    selected = [r for r in snapshot['renderers'] if (r['pid'], r['tid']) == (pid, tid)]
    require(len(selected) == 1 and 'readError' not in selected[0], 'Target proc read unavailable/ambiguous')
    raw = selected[0]; stat = stat_fields(raw['stat'])
    require(stat['pid'] == tid and stat['comm'] == raw['comm'], 'Proc identity string mismatch')
    sched = list(map(int, raw['schedstat'].split()))
    require(len(sched) == 3 and all(v >= 0 for v in sched), 'Invalid schedstat')
    require(snapshot['hostStartMonotonicNs'] <= snapshot['metricSendMonotonicNs']
            <= snapshot['metricReturnMonotonicNs'] <= raw['hostBeforeReadNs']
            <= raw['hostAfterReadNs'] <= snapshot['hostEndMonotonicNs'], 'Snapshot host-order mismatch')
    return {'pid': pid, 'tid': tid, 'stat': stat,
            'schedstat': {'cpuRuntimeNs': sched[0], 'runqueueWaitNs': sched[1], 'scheduleCount': sched[2]},
            'hostProcReadBeforeNs': raw['hostBeforeReadNs'], 'hostProcReadAfterNs': raw['hostAfterReadNs'],
            'wholeSnapshotStartNs': snapshot['hostStartMonotonicNs'],
            'wholeSnapshotEndNs': snapshot['hostEndMonotonicNs'],
            'procStringsSha256': hashlib.sha256((raw['comm'] + '\n' + raw['stat'] + '\n' + raw['schedstat']).encode()).hexdigest()}


def describe(rows):
    keys = ('cpuRuntimeDeltaNs', 'runqueueWaitDeltaNs', 'scheduleCountDelta',
            'statCoarseCpuDeltaNs', 'hostProcReadOuterWallNs', 'betweenProcReadsWallNs')
    return {'samples': len(rows), 'metrics': {key: {'min': min(r[key] for r in rows),
            'median': statistics.median(r[key] for r in rows), 'max': max(r[key] for r in rows)} for key in keys},
            'lastCpuBookendDifferentCount': sum(r['differentLastCpuBookends'] for r in rows),
            'recordedRuntimeDeltaExceedsHostProcReadOuterCount': sum(r['cpuRuntimeDeltaNs'] > r['hostProcReadOuterWallNs'] for r in rows),
            'allCountersMonotonic': all(r['countersMonotonic'] for r in rows)}


def main():
    report_path, output_path = map(Path, sys.argv[1:])
    require(not output_path.exists(), 'Refuse overwrite')
    report_bytes = report_path.read_bytes(); report = json.loads(report_bytes)
    require(report['status'] == 'completed' and len(report['visits']) == 5, 'Incomplete source report')
    capability_path = report_path.parent / 'cpu-sampler-capability.json'
    capability = json.loads(capability_path.read_text()); hz = capability['sysClkTck']
    require(hz > 0, 'Invalid stat tick unit')
    rows, visits = [], []
    for visit in report['visits']:
        require(visit['completed'] is True, 'Incomplete visit')
        pid, tid = visit['conversion']['rendererPidTid']
        require(pid == tid, 'Target is not renderer main TID')
        converted = {r['name']: r for r in visit['conversion']['markers']}
        if visit['preflight']:
            actions = [{'branch': 'preflight', 'trial': None, 'warmup': False,
                        'before': visit['before'], 'after': visit['after'],
                        'markers': [{'name': name} for name in converted]}]
        else:
            actions = visit['samples']
            require(len(actions) == 8 and {(r['branch'], r['trial']) for r in actions}
                    == {(b, t) for b in ('dp', 'legacy') for t in range(4)}, 'Wrong formal action grid')
            require(all(r['warmup'] is (r['trial'] == 0) and r['outcome'] == 'accepted'
                        for r in actions), 'Warmup/outcome mismatch')
        visit_rows = []
        identities = set()
        for action in actions:
            before = endpoint(action['before'], pid, tid); after = endpoint(action['after'], pid, tid)
            for e in (before, after):
                identities.add((e['pid'], e['tid'], e['stat']['comm'], e['stat']['starttimeTicks']))
            require(before['wholeSnapshotEndNs'] <= after['wholeSnapshotStartNs'], 'Overlapping outer snapshots')
            counter_deltas = {key: after['schedstat'][key] - before['schedstat'][key]
                              for key in ('cpuRuntimeNs', 'runqueueWaitNs', 'scheduleCount')}
            ut = after['stat']['utimeTicks'] - before['stat']['utimeTicks']
            st = after['stat']['stimeTicks'] - before['stat']['stimeTicks']
            marker_checks = []
            for marker in action['markers']:
                for kind in ('mark', 'stamp'):
                    e = converted[marker['name']][kind]
                    require((e['pid'], e['tid']) == (pid, tid), 'Marker is on another thread')
                    ns = e['ts'] * 1000
                    contained = before['hostProcReadAfterNs'] <= ns <= after['hostProcReadBeforeNs']
                    marker_checks.append({'name': marker['name'], 'kind': kind,
                                          'traceTimestampUs': e['ts'], 'insideBetweenProcReadEnvelope': contained})
                    require(contained, 'Marker outside target proc read envelope')
            row = {'run': visit['run'], 'preflight': visit['preflight'],
                   'branch': action['branch'], 'trial': action['trial'], 'warmup': action['warmup'],
                   'before': before, 'after': after,
                   'cpuRuntimeDeltaNs': counter_deltas['cpuRuntimeNs'],
                   'runqueueWaitDeltaNs': counter_deltas['runqueueWaitNs'],
                   'scheduleCountDelta': counter_deltas['scheduleCount'],
                   'statUtimeDeltaTicks': ut, 'statStimeDeltaTicks': st,
                   'statCoarseCpuDeltaNs': (ut + st) * (10**9 / hz),
                   'hostProcReadOuterWallNs': after['hostProcReadAfterNs'] - before['hostProcReadBeforeNs'],
                   'betweenProcReadsWallNs': after['hostProcReadBeforeNs'] - before['hostProcReadAfterNs'],
                   'differentLastCpuBookends': before['stat']['processor'] != after['stat']['processor'],
                   'countersMonotonic': all(v >= 0 for v in counter_deltas.values()) and ut >= 0 and st >= 0,
                   'markerChecks': marker_checks}
            visit_rows.append(row); rows.append(row)
        require(len(identities) == 1, 'Renderer identity changed within visit')
        identity = next(iter(identities))
        require(visit['rendererIdentity'] == {'comm': identity[2], 'starttimeTicks': str(identity[3])},
                'Independent identity disagrees with collector')
        visits.append({'run': visit['run'], 'preflight': visit['preflight'],
                       'rendererIdentity': {'pid': identity[0], 'tid': identity[1], 'comm': identity[2], 'starttimeTicks': identity[3]},
                       'summary': describe(visit_rows)})
    formal = [r for r in rows if not r['preflight'] and not r['warmup']]
    warm = [r for r in rows if not r['preflight'] and r['warmup']]
    require(len(rows) == 33 and len(formal) == 24 and len(warm) == 8, 'Wrong source count')
    result = {'status': 'completed', 'reportSha256': hashlib.sha256(report_bytes).hexdigest(),
              'scriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'capabilitySha256': hashlib.sha256(capability_path.read_bytes()).hexdigest(),
              'statTicksPerSecond': hz,
              'interpretation': {
                  'noNewMeasurement': True,
                  'schedstat': 'Runtime is a stored scheduler sum_exec_runtime snapshot, not a forced fresh CPU read. Host proc envelopes bracket the IO, not necessarily the effective accounting time. Runtime difference is a broad diagnostic, not CPU inside the marker windows or a strict physical upper-bound test.',
                  'processor': 'stat field39 is the last CPU observed for the task, not a complete CPU-migration log. Different bookends imply different recorded last CPU values; equal bookends do not prove no migration.',
                  'state': 'stat state is recorded as context only; S does not establish guaranteed quiescence or fresh scheduler accounting.',
                  'independence': 'proc read bypasses the Perfetto serialization/export path but shares scheduler CPU accounting. It is not an independent physical CPU clock.',
                  'statTicks': 'utime/stime ticks are coarse supporting counters; no sub-tick timing or per-marker attribution.',
                  'performancePass': False},
              'checks': {'sourceComplete': True, 'visits': len(visits), 'procEndpoints': 2 * len(rows),
                         'formalActions': len(formal), 'warmupActions': len(warm), 'preflightActions': 1,
                         'allIdentitiesMatched': True, 'allMarkerHostContainmentChecksPassed': True,
                         'allCountersMonotonic': all(r['countersMonotonic'] for r in rows)},
              'formal': describe(formal), 'warmup': describe(warm),
              'preflight': describe([r for r in rows if r['preflight']]),
              'formalByBranch': {branch: describe([r for r in formal if r['branch'] == branch]) for branch in ('dp', 'legacy')},
              'visits': visits, 'actions': rows}
    with output_path.open('x') as file: file.write(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'checks': result['checks'], 'formal': result['formal'], 'warmup': result['warmup'],
                      'preflight': result['preflight']}, ensure_ascii=False))


if __name__ == '__main__': main()
