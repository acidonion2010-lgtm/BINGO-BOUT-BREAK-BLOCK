# Verification 6

The production HTML is byte-identical to frozen stage5. This round adds
verification and reports, not game changes. Use existing Python Playwright,
Chromium and Node. Browser jobs must run sequentially without other CPU jobs.
Commands below run from the unpacked `bingo-refactor` directory.

```bash
python3 validation/stage6/selector_performance.py index.before.html index.html validation/stage6/selector-performance.json --port 8007
python3 validation/stage6/secret_independence.py index.before.html index.html validation/stage6/secret-independence.json --port 8010
python3 validation/stage6/selector_control.py index.before.html validation/stage6/selector-control.json --port 8011
python3 validation/stage6/phase_strata.py validation/stage5/raf-phase-response.json validation/stage6/phase-strata-existing.json
python3 validation/stage6/phase_input_probe.py index.before.html index.html validation/stage6/phase-input-response.json --runs 4 --trials 16
python3 validation/stage6/phase_strata.py validation/stage6/phase-input-response.json validation/stage6/phase-strata-input.json
python3 validation/stage5/analyse_raf.py validation/stage6/phase-input-response.json validation/stage6/phase-input-decomposition.json
```

The selector matrix extends the original 64 conditions to 104, adding both HARD
fallback mixture paths and one-closed NORMAL/HARD legacy contracts. Each of two
independent browser runs compares two visible normally loaded HTML realms, reversing
creation, placement and first sampling order. Zero process exit means measurement
and functional checks completed. The separate strict non-regression flag is false.
The binomial median intervals assume independent exchangeable batches, which is
not established for within-process timings; pooled intervals are conditional and
not simultaneous guarantees. No noise-derived allowance is introduced.

The focused selector A/A control is exploratory: its five cases were chosen from
pooled-positive A/B cases. Its unconfirmed intervals do not cancel A/B differences.
The shared benchmark's stdout labels all skip messages "terminal skip". In the
focused control, JSON skipReason distinguishes explicit focus exclusions from
terminal policy exclusions.

The secret-BREAK check keeps public marks, layouts and turns fixed, restores history
for each secret, then makes four BLOCK calls with fixed public result-memory updates.
This checks function contracts and RNG/history invariants rather than simulating a
complete match. Terminal full-DP fixtures are excluded with reasons. Every secret
trace, exclusion and cross-version comparison remains in the JSON.

The CDP input experiment is a separate condition from locator.click. It retains
actual mouse pressed/released events, actionability and hit checks, trusted accepted
play, sound, BGM, animations and fixed public fixture. Four requested timer delays
are merely cues; actual capture phase is recorded and no missed target is retried or
removed. All 256 measured clicks and 16 warmups remain. Fixed 1 ms phase bands were
chosen before this added collection and retain every sample, including out-of-range
records. Residual phase, callback execution and visit-support differences remain.
No phase-adjusted speed, A/A subtraction, latency PASS, physical presentation claim
or causal inference from the shared-timestamp correlation is made.

See `追加検証6結果.md` and `summary.json` for results and unfinished items.
Earlier full-DP/Worker/gameplay checks remain applicable because the HTML hash is
unchanged. All previous reports and source snapshots are preserved.
