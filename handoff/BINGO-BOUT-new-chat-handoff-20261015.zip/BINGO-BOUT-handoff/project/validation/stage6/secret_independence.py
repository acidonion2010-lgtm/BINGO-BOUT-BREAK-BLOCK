#!/usr/bin/env python3
"""Verify BLOCK choices are independent of the current secret BREAK.

Load both complete game HTML files normally, in sequence in one foreground
page. Real Blob Workers prepare both first-player orders. This is functional
verification of fixed public selector fixtures, not an input-latency benchmark.
No production source, selector, renderer, sound, or animation is replaced.
"""
import argparse
import functools
import hashlib
import http.server
import importlib.util
import json
from pathlib import Path
import threading
from urllib.parse import quote

from playwright.sync_api import sync_playwright


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
FRAME_PATH = HERE.parent / 'stage3' / 'frame_performance.py'
module_spec = importlib.util.spec_from_file_location('secret_frame_fixture', FRAME_PATH)
frame_fixture = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(frame_fixture)
INSTALL_BENCH = frame_fixture.INSTALL_BENCH
LAYOUTS = frame_fixture.LAYOUTS
SCENARIOS = frame_fixture.SCENARIOS
PATHS = [
    {'name': 'normal-legacy', 'difficulty': 'normal', 'engine': 'ready', 'roll': 0.8},
    {'name': 'hard-legacy', 'difficulty': 'hard', 'engine': 'ready', 'roll': 0.3},
    {'name': 'hard-full', 'difficulty': 'hard', 'engine': 'ready', 'roll': 0.8},
    {'name': 'hard-fallback-low', 'difficulty': 'hard', 'engine': 'fallback', 'roll': 0.3},
    {'name': 'hard-fallback-high', 'difficulty': 'hard', 'engine': 'fallback', 'roll': 0.8},
    {'name': 'master-ready', 'difficulty': 'master', 'engine': 'ready', 'roll': 0.8},
    {'name': 'master-fallback', 'difficulty': 'master', 'engine': 'fallback', 'roll': 0.8},
]
HISTORIES = [
    {'name': f'cooldown-{cooldown}-{position}', 'cooldown': cooldown,
     'position': position, 'streak': 2}
    for cooldown in [0, 2] for position in ['inside', 'outside']
]
SECRETS = [None, *range(9)]


INSTALL_SECRET_CHECK = r'''() => {
  const memory = () => ({breakCell:state.cpuBlockedBreakCell,
    breakStreak:state.cpuBlockedBreakStreak,breakCooldown:state.cpuBlockedCooldown,
    blockCell:state.cpuSuccessfulBlockCell,blockStreak:state.cpuSuccessfulBlockStreak,
    blockCooldown:state.cpuSuccessfulBlockCooldown});
  const counters = () => ({whole:cpuWholeDecisions,fallback:cpuWholeLegacyDecisions,
    hardLegacy:hardLegacyDecisions,hardFull:hardDpDecisions});
  const publicState = () => ({p1Marks:state.p1Marks.slice(),p2Marks:state.p2Marks.slice(),
    p1Layout:state.p1NumberLayout.slice(),p2Layout:state.p2NumberLayout.slice(),
    p1TurnsTaken:state.p1TurnsTaken,p2TurnsTaken:state.p2TurnsTaken,
    firstPlayer:state.firstPlayer,difficulty:state.cpuDifficulty,phase:state.phase,
    isStarting:state.isStarting,gameMode:state.gameMode,gameEnded:state.gameEnded});
  const streams = [[0.11,0.73,0.99,0.02], [0.85,0.02,0.3,0.99],
    [0.01,0.95,0.61,0.5], [0.699999,0.7,0.999999,0.42]];
  window.__secretBlockCheck = ({spec,history,secret}) => {
    // configure/analyze are outside the recorded random-consumption interval.
    const decision = window.__frameCpuBench.configure(spec);
    if (decision.skip) return {decision,skipped:true,reason:decision.skipReason};
    const insideCell = state.p1Marks.findIndex(opened => !opened);
    const openedCell = state.p1Marks.findIndex(opened => opened);
    const outsideCell = openedCell < 0 ? null : openedCell;
    const rememberedCell = history.position === 'inside' ? insideCell : outsideCell;
    Object.assign(state,{selectedBreakCell:secret,cpuSuccessfulBlockCell:rememberedCell,
      cpuSuccessfulBlockStreak:history.streak,cpuSuccessfulBlockCooldown:history.cooldown});
    const expectedPublic = JSON.stringify(publicState());
    const initialMemory = memory();
    const draws = [], choices = [];
    const savedRandom = Math.random;
    let currentStream = [], cursor = 0;
    Math.random = () => {
      if (cursor >= currentStream.length) throw new Error('Unexpected extra random draw');
      const value = currentStream[cursor++]; draws.push(value); return value;
    };
    try {
      for (let step=0; step<4; step++) {
        currentStream = spec.difficulty === 'hard'
          ? [spec.roll,...streams[step]] : streams[step];
        cursor = 0;
        const startDraw = draws.length;
        const beforeMemory = memory();
        const cell = selectCpuBlockCell(state.p1Marks,state.p1NumberLayout);
        if (!Number.isInteger(cell) || cell < 0 || cell > 8 || state.p1Marks[cell]) {
          throw new Error('Illegal BLOCK choice: ' + cell);
        }
        if (state.selectedBreakCell !== secret) throw new Error('Selector changed secret BREAK');
        if (cpuWholeStatus !== spec.engine) throw new Error('Unexpected engine status change');
        const afterSelection = memory();
        if (afterSelection.blockCooldown !== Math.max(0,beforeMemory.blockCooldown-1)) {
          throw new Error('BLOCK cooldown was not consumed exactly once');
        }
        const afterCounters = counters();
        const expected = {whole:0,fallback:0,hardLegacy:0,hardFull:0};
        if (spec.name === 'hard-full') expected.whole = expected.hardFull = step+1;
        else if (spec.difficulty === 'hard') expected.hardLegacy = step+1;
        else if (spec.name === 'master-ready') expected.whole = step+1;
        else if (spec.name === 'master-fallback') expected.fallback = step+1;
        if (JSON.stringify(afterCounters) !== JSON.stringify(expected)) {
          throw new Error('Unexpected selector dispatch counters: ' + JSON.stringify(afterCounters));
        }
        const blocked = [true,false,true,false][step];
        rememberCpuBlockResult(cell,blocked);
        if (state.selectedBreakCell !== secret) throw new Error('History update changed secret BREAK');
        if (JSON.stringify(publicState()) !== expectedPublic) throw new Error('Public selector fixture changed');
        choices.push({step:step+1,cell,blocked,draws:draws.slice(startDraw),
          randomCalls:draws.length-startDraw,beforeMemory,afterSelection,
          afterResult:memory(),counters:afterCounters,status:cpuWholeStatus});
      }
      return {skipped:false,decision,historyFixture:{...history,rememberedCell,
        outsideRepresentation:openedCell < 0 ? 'No opened cell; null means no remembered cell' : 'Opened cell'},
        trace:{publicState:publicState(),initialMemory,draws,randomCalls:draws.length,
          choices,status:cpuWholeStatus,counters:counters(),finalMemory:memory()},secretPreserved:true};
    } finally {
      Math.random = savedRandom;
    }
  };
}'''


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(',', ':')).encode()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('before', type=Path)
    parser.add_argument('after', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--port', type=int, default=8010)
    args = parser.parse_args()
    paths = {key: getattr(args, key).resolve() for key in ['before', 'after']}
    for path in paths.values():
        if not path.is_file():
            parser.error(f'Missing HTML: {path}')
        try:
            path.relative_to(ROOT)
        except ValueError:
            parser.error('Both HTML files must be under the bingo-refactor directory')
    result = {
        'sources': {key: {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                    for key, path in paths.items()},
        'conditions': {
            'browserExecutable': '/usr/bin/chromium', 'viewport': [1280, 900],
            'pageModel': 'One foreground page; before and after HTML loaded sequentially',
            'layouts': LAYOUTS, 'firstPlayers': [1, 2], 'scenarios': SCENARIOS,
            'paths': PATHS, 'histories': HISTORIES, 'secretValues': SECRETS,
            'selectionCallsPerSecret': 4, 'historyResults': [True, False, True, False],
            'publicFixture': 'Identical marks/layouts/turns and history restored before each secret',
            'randomFixture': 'Same per-decision stream; HARD starts with its path mix roll',
            'randomScope': 'Only BLOCK selection; setup, real Worker preparation, configure/analyze excluded',
            'historyLimitations': 'Selector fixtures keep public marks/turns fixed; result memory advances. Opening has no opened cell, so candidate-outside history is null.',
            'notMeasured': ['performance', 'physical input-to-presentation latency', 'invalid ready-to-fallback transitions'],
        },
        'versions': {}, 'records': [], 'excluded': [], 'completed': False,
        'secretIndependent': None, 'versionEquivalent': None,
        'counts': {'plannedConfigurationsPerVersion': 2*len(SCENARIOS)*len(PATHS)*len(HISTORIES),
                   'testedVersionConfigurations': 0, 'testedSecretTraces': 0,
                   'selectionCalls': 0, 'crossVersionConfigurationsCompared': 0},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)

    def save():
        args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2))

    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *unused):
            pass

    server = http.server.ThreadingHTTPServer(('127.0.0.1', args.port),
        functools.partial(Handler, directory=str(ROOT)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    save()
    failed = False
    baseline = {}
    excluded_baseline = {}
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(executable_path='/usr/bin/chromium', headless=True,
                args=['--no-sandbox', '--disable-dev-shm-usage'])
            result['conditions']['browserVersion'] = browser.version
            try:
                page = browser.new_page(viewport={'width': 1280, 'height': 900})
                for version, path in paths.items():
                    version_record = {'selfTests': None, 'pageErrors': [], 'preparations': []}
                    result['versions'][version] = version_record
                    listener = lambda error, record=version_record: record['pageErrors'].append(str(error))
                    page.on('pageerror', listener)
                    try:
                        url = f'http://127.0.0.1:{args.port}/' + quote(str(path.relative_to(ROOT)), safe='/')
                        page.goto(url, wait_until='load', timeout=60000)
                        page.bring_to_front()
                        if page.evaluate('document.visibilityState') != 'visible':
                            raise RuntimeError('Verification page is not foreground-visible')
                        tests = json.loads(page.locator('#rule-test-results').text_content())
                        version_record['selfTests'] = tests
                        if tests['passed'] != tests['total'] or tests.get('failures'):
                            raise RuntimeError(f'{version}: automatic self tests failed')
                        version_record['setup'] = page.evaluate(INSTALL_BENCH, LAYOUTS)
                        page.evaluate(INSTALL_SECRET_CHECK)
                        for first_player in [1, 2]:
                            preparation = page.evaluate('first => window.__frameCpuBench.prepare(first)', first_player)
                            version_record['preparations'].append({'firstPlayer': first_player, **preparation})
                            for scenario in SCENARIOS:
                                for path_spec in PATHS:
                                    spec = {**scenario, **path_spec, 'role': 'block'}
                                    for history in HISTORIES:
                                        key = (first_player, scenario['name'], path_spec['name'], history['name'])
                                        record = {'version': version, 'firstPlayer': first_player,
                                                  'scenario': scenario['name'], 'path': path_spec['name'],
                                                  'history': history, 'secretChecks': [], 'completed': False}
                                        result['records'].append(record)
                                        base_trace = None
                                        for secret in SECRETS:
                                            record['activeSecret'] = secret
                                            answer = page.evaluate('args => window.__secretBlockCheck(args)',
                                                {'spec': spec, 'history': history, 'secret': secret})
                                            record.pop('activeSecret', None)
                                            if answer['skipped']:
                                                excluded = {**{k: record[k] for k in ['version', 'firstPlayer', 'scenario', 'path', 'history']},
                                                            'decision': answer['decision'], 'reason': answer['reason']}
                                                result['excluded'].append(excluded)
                                                record.update({'excluded': True, 'reason': answer['reason'],
                                                               'decision': answer['decision'], 'completed': True})
                                                if version == 'before':
                                                    excluded_baseline[key] = answer
                                                elif excluded_baseline.get(key) != answer:
                                                    result['versionEquivalent'] = False
                                                    raise RuntimeError('Cross-version terminal exclusion differs: ' + str(key))
                                                break
                                            trace = answer['trace']
                                            result['counts']['testedSecretTraces'] += 1
                                            result['counts']['selectionCalls'] += len(trace['choices'])
                                            check = {'secret': secret, 'secretPreserved': answer['secretPreserved'],
                                                     'traceSha256': digest(trace), 'randomCalls': trace['randomCalls'],
                                                     'choices': [entry['cell'] for entry in trace['choices']]}
                                            record['secretChecks'].append(check)
                                            if base_trace is None:
                                                base_trace = trace
                                                record.update({'decision': answer['decision'],
                                                    'historyFixture': answer['historyFixture'], 'trace': trace})
                                            elif trace != base_trace:
                                                result['secretIndependent'] = False
                                                record['mismatchingTrace'] = trace
                                                raise RuntimeError('Secret BREAK affects BLOCK: ' + str(key) + ', secret=' + str(secret))
                                        if base_trace is not None:
                                            record['completed'] = True
                                            result['counts']['testedVersionConfigurations'] += 1
                                            signature = {'decision': record['decision'], 'historyFixture': record['historyFixture'],
                                                         'trace': base_trace}
                                            if version == 'before':
                                                baseline[key] = signature
                                            elif baseline.get(key) != signature:
                                                result['versionEquivalent'] = False
                                                record['beforeSignature'] = baseline.get(key)
                                                raise RuntimeError('Cross-version BLOCK trace differs: ' + str(key))
                                            else:
                                                result['counts']['crossVersionConfigurationsCompared'] += 1
                            save()
                            print(f'{version} P{first_player}: secret BLOCK checks complete', flush=True)
                            page.evaluate('() => { releaseWholeGameCpu(); window.__frameCpuBench.dp=null; }')
                        page.evaluate('() => window.__frameCpuBench.cleanup()')
                        if version_record['pageErrors']:
                            raise RuntimeError(f'{version}: uncaught browser errors')
                    finally:
                        page.remove_listener('pageerror', listener)
                if result['counts']['crossVersionConfigurationsCompared'] != len(baseline):
                    raise RuntimeError('Not all baseline configurations were compared')
                result.update({'completed': True, 'secretIndependent': True, 'versionEquivalent': True})
                result['counts']['testedConfigurationsPerVersion'] = len(baseline)
                result['counts']['excludedConfigurationsPerVersion'] = len(excluded_baseline)
            finally:
                browser.close()
    except Exception as error:
        failed = True
        result['failure'] = f'{type(error).__name__}: {error}'
        print(result['failure'], flush=True)
    finally:
        server.shutdown()
        server.server_close()
        save()
    print(f'Results saved to {args.output}; completed={result["completed"]}', flush=True)
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
