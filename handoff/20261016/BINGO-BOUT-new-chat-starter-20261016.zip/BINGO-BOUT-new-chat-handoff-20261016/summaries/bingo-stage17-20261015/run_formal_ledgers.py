#!/usr/bin/env python3
"""After browser capture only, run the unchanged stage16 checker sequentially.

Preflight ledgers (run0/1) are produced by the collector's frozen-checker gate.
This script refuses existing formal outputs and does not launch any browser.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CHECKER = ROOT.parent / 'bingo-stage16-20261015/raw_counter_check.py'
CHECKER_SHA = '91762a94d1e1e05305c2a11fbb237dd4b42bffd3ebb5162f48c4cec42b038c23'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert len(sys.argv) <= 2, 'usage: run_formal_ledgers.py [completed-report.json]'
    assert sha(CHECKER) == CHECKER_SHA
    report_path = Path(sys.argv[1]) if len(sys.argv) == 2 else ROOT / 'report.json'
    report = json.loads(report_path.read_bytes())
    assert report['status'] == 'completed', 'browser collection must have completed first'
    visits = [v for v in report['visits'] if not v['preflight']]
    assert len(visits) == 8 and all(v.get('completed') for v in visits)
    assert [v['run'] for v in visits] == list(range(2, 10))
    assert all(not (ROOT / f'raw-counter-run{v["run"]}.json').exists() for v in visits)
    result = {'scriptSha256': sha(Path(__file__)), 'reportSha256': sha(report_path),
              'checkerPath': str(CHECKER), 'checkerSha256': CHECKER_SHA,
              'scope': 'Sequential unchanged raw decoder after all browser jobs; no additional measurements.', 'runs': []}
    for visit in visits:
        run = visit['run']
        source, output = ROOT / f'run{run}.pftrace', ROOT / f'raw-counter-run{run}.json'
        assert sha(CHECKER) == CHECKER_SHA
        command = [sys.executable, str(CHECKER), str(source), str(output)]
        completed = subprocess.run(command, capture_output=True, text=True, timeout=240)
        (ROOT / f'run{run}.raw-checker.stdout').write_text(completed.stdout)
        (ROOT / f'run{run}.raw-checker.stderr').write_text(completed.stderr)
        record = {'run': run, 'unit': visit['unit'], 'command': command, 'returncode': completed.returncode,
                  'inputSha256': sha(source), 'outputSha256': sha(output) if output.exists() else None}
        result['runs'].append(record)
        print(json.dumps(record), flush=True)
        if completed.returncode != 0:
            with (ROOT / 'raw-counter-execution.partial.json').open('x') as file:
                json.dump(result, file, indent=2)
            raise RuntimeError(('raw decoder failed; partial preserved', run, completed.returncode))
        ledger = json.loads(output.read_bytes())
        assert ledger['status'] == 'limited_scope_complete'
        assert ledger['script_sha256'] == CHECKER_SHA
        assert ledger['input']['sha256'] == record['inputSha256']
        del ledger
    with (ROOT / 'raw-counter-execution.json').open('x') as file:
        json.dump(result, file, indent=2)
        file.write('\n')


if __name__ == '__main__':
    main()
