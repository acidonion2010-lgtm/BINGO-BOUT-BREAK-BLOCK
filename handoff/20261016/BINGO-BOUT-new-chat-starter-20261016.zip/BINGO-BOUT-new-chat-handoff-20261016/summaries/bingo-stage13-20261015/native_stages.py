#!/usr/bin/env python3
"""Finite six-version, four-condition native fallback localization."""
import argparse
import hashlib
import http.server
import json
from pathlib import Path
import statistics
import sys
import threading
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parent
PROJECT=Path('/workspace/handoff/BINGO-BOUT-handoff/project')
sys.path.insert(0,str(PROJECT/'validation/stage3'))
import frame_performance as shared

FILES={'original':PROJECT/'index.before.html',
 'stage1':PROJECT/'stages/index.stage1.html','stage2':PROJECT/'stages/index.stage2.final.html',
 'stage3':PROJECT/'stages/index.stage3.final.html','stage4':PROJECT/'stages/index.stage4.html',
 'stage5':PROJECT/'stages/index.stage5.html'}
EXPECTED={'original':'e872443dc9764f3b9647f4797d1411ca98f865b9c2f69c6e694529e2685cd3a9',
 'stage1':'00bbb9add62e8bdd3847fc58e93a02a543784e3d91d2da4a4fa18d52531bfaf5',
 'stage2':'a6ffdab2b7cdfd491c4d78afecb610af8f6257ad37f57368586031bab1d0f662',
 'stage3':'11bbe3d0653ca64a07756079125078b86c0abd5ed3927ff664f43ca4e4186275',
 'stage4':'9f7a071e7dc3aa7ac3d2545578d42b92401563ba73229090c6602f0928cddc97',
 'stage5':'fea09e995bfc1036515b92771925bd7968f3c453425ea5517b7a5b480293be64'}
KEYS=list(FILES)
WILLIAMS_BASE=[0,1,5,2,4,3]
ORDERS=[[KEYS[(n+shift)%6] for n in WILLIAMS_BASE] for shift in range(6)]
# Every version occupies every position once, and every distinct directed
# adjacency occurs once across the six orders. The same six orders repeat twice
# within every condition; they are not selected using the run's placement.
assert all(sorted(order)==sorted(KEYS) for order in ORDERS)
assert all(len({order[pos] for order in ORDERS})==6 for pos in range(6))
assert len({(a,b) for order in ORDERS for a,b in zip(order,order[1:])})==30
COMPARISONS=list(zip(KEYS,KEYS[1:]))+[('original','stage5')]
DIAGNOSTIC_COMPARISONS=[('original',key) for key in KEYS[2:5]]
HOST=b'<!doctype html><meta charset="utf-8"><style>html,body{margin:0;width:7680px;height:900px;overflow:hidden}body{display:flex}iframe{border:0;display:block;width:1280px;height:900px;flex:0 0 1280px}</style><body></body>'
CALLS=100000
PAIRS=12
PARENT_TEMPLATE_SHA256='fc995ca404240aa8e100b5268a3221ec20c2d60789079d0c191a139f04301be6'

EXTEND=r'''() => {
 const b=__frameCpuBench, fixedRandom=Math.random;
 let refs,stable,history;
 const counters=()=>({whole:cpuWholeDecisions,fallback:cpuWholeLegacyDecisions,hardLegacy:hardLegacyDecisions,hardFull:hardDpDecisions});
 const memory=()=>({breakCell:state.cpuBlockedBreakCell,breakStreak:state.cpuBlockedBreakStreak,breakCooldown:state.cpuBlockedCooldown,
  blockCell:state.cpuSuccessfulBlockCell,blockStreak:state.cpuSuccessfulBlockStreak,blockCooldown:state.cpuSuccessfulBlockCooldown});
 const publicState=()=>({p1Marks:state.p1Marks.slice(),p2Marks:state.p2Marks.slice(),p1Layout:state.p1NumberLayout.slice(),p2Layout:state.p2NumberLayout.slice(),
  p1Turns:state.p1TurnsTaken,p2Turns:state.p2TurnsTaken,first:state.firstPlayer,phase:state.phase,difficulty:state.cpuDifficulty,gameMode:state.gameMode,
  isStarting:state.isStarting,gameEnded:state.gameEnded,isProcessing:state.isProcessing,selectedBreakCell:state.selectedBreakCell});
 const rowBits=()=>{
  const role=b.spec.role,turns=role==='break'?state.p2TurnsTaken:state.p1TurnsTaken;
  const marks=role==='break'?state.p2Marks:state.p1Marks, table=role==='break'?cpuEqBundle.p2:cpuEqBundle.p1;
  const r=9-turns,mask=marks.reduce((v,x,i)=>v|(x?(1<<i):0),0);
  const values=[table.values[r][mask],...table.breakProbs[r][mask],...table.blockProbs[r][mask]];
  const buf=new ArrayBuffer(values.length*8),view=new DataView(buf);
  values.forEach((v,i)=>view.setFloat64(i*8,v,false));
  return {r,mask,hex:Array.from(new Uint8Array(buf),v=>v.toString(16).padStart(2,'0')).join('')};
 };
 b.resetCounters=()=>{cpuWholeDecisions=cpuWholeLegacyDecisions=hardLegacyDecisions=hardDpDecisions=0;};
 b.verifyContract=(answer,count)=>{
  b.verify(answer,count);
  if(cpuWholeDp!==null || cpuWholeStatus!=='fallback' || Math.random!==fixedRandom)throw Error('Fallback/RNG reference changed');
  if(cpuWholeDecisions!==0 || cpuWholeLegacyDecisions!==count || hardLegacyDecisions!==0 || hardDpDecisions!==0)throw Error('Wrong fallback dispatch counter');
  if(cpuEqBundle!==refs.bundle || cpuEqBundle.p1!==refs.p1 || cpuEqBundle.p2!==refs.p2 ||
   state.p1Marks!==refs.m1 || state.p2Marks!==refs.m2 || state.p1NumberLayout!==refs.l1 || state.p2NumberLayout!==refs.l2 ||
   b.available!==refs.available || b.dp!==refs.dp ||
   refs.table.values[refs.r]!==refs.valueRow || refs.table.breakProbs[refs.r][refs.mask]!==refs.breakRow || refs.table.blockProbs[refs.r][refs.mask]!==refs.blockRow ||
   JSON.stringify(publicState())!==stable || JSON.stringify(memory())!==history || JSON.stringify(rowBits())!==refs.bits ||
   JSON.stringify(b.available)!==refs.availableValues)throw Error('Input/history/table identity or contents changed');
 };
 b.audit=()=>{
  const role=b.spec.role,table=role==='break'?cpuEqBundle.p2:cpuEqBundle.p1;
  const bits=rowBits();
  refs={bundle:cpuEqBundle,p1:cpuEqBundle.p1,p2:cpuEqBundle.p2,m1:state.p1Marks,m2:state.p2Marks,l1:state.p1NumberLayout,l2:state.p2NumberLayout,
   available:b.available,availableValues:JSON.stringify(b.available),dp:b.dp,table,r:bits.r,mask:bits.mask,
   valueRow:table.values[bits.r],breakRow:table.breakProbs[bits.r][bits.mask],blockRow:table.blockProbs[bits.r][bits.mask],bits:JSON.stringify(bits)};
  stable=JSON.stringify(publicState());history=JSON.stringify(memory());
  const audits=[];
  for(const roll of [0,0.05,0.2,0.5,0.8,0.999999]){
   b.resetCounters();const draws=[];Math.random=()=>{draws.push(roll);return roll};
   let answer;
   try {answer=b.loop(1)} finally {Math.random=fixedRandom}
   const marks=role==='break'?state.p2Marks:state.p1Marks;
   if(draws.length!==1 || !Number.isInteger(answer.lastCell) || marks[answer.lastCell])throw Error('Selector RNG/legality audit failed');
   if(cpuWholeLegacyDecisions!==1 || cpuWholeDecisions || hardLegacyDecisions || hardDpDecisions)throw Error('Audit dispatch failed');
   audits.push({roll,draws,...answer,counters:counters(),memory:memory()});
  }
  b.resetCounters();const probe=b.probe();b.verifyContract(probe,1);b.resetCounters();
  return {audits,bits,probe,publicState:JSON.parse(stable)};
 };
 b.warmChecked=count=>{
  b.resetCounters();const a=b.loop(count);b.verifyContract(a,count);return a;
 };
 b.sampleChecked=count=>{
  b.resetCounters();
  const startMs=performance.now();const answer=b.loop(count);const endMs=performance.now();
  const startNs=Math.round(startMs*1e6),endNs=Math.round(endMs*1e6);
  if(!Number.isSafeInteger(startNs)||!Number.isSafeInteger(endNs)||endNs<startNs)throw Error('Invalid clock endpoints');
  b.verifyContract(answer,count);
  return {...answer,count,startMs,endMs,startNs,endNs,elapsedMs:endMs-startMs,durationNs:endNs-startNs,
   status:cpuWholeStatus,counters:counters(),memory:memory()};
 };
 return {visibility:document.visibilityState,scalarLoop:b.loop.toString(),rng:fixedRandom.toString()};
}'''
SAMPLE=r'''({order,count})=>{
 const result={};
 for(const key of order){const b=document.getElementById('bench-'+key).contentWindow.__frameCpuBench;
  b.warmChecked(2000);result[key]=b.sampleChecked(count);}
 return result;
}'''


def sha(data):return hashlib.sha256(data).hexdigest()


def write(path,data):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2));tmp.replace(path)


def summary(samples,before,after):
    a=[r['measurements'][before]['durationNs'] for r in samples]
    b=[r['measurements'][after]['durationNs'] for r in samples]
    diffs=[(y-x)/CALLS/1000 for x,y in zip(a,b)]
    return {'beforeMedianUs':statistics.median(a)/CALLS/1000,'afterMedianUs':statistics.median(b)/CALLS/1000,
            'pairedDeltasUs':diffs,'pairedMedianDeltaUs':statistics.median(diffs),'interval':shared.median_interval(diffs)}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();assert not args.output.exists(),'Refuse overwrite'
    assert sha(Path(shared.__file__).read_bytes())=='238e31ab7695f7b80b7c59d05270e054124c13774f731d412f630eb253195cf7','Reviewed shared helper changed'
    args.output.parent.mkdir(parents=True,exist_ok=True)
    raw={k:p.read_bytes() for k,p in FILES.items()}
    for k,v in raw.items():assert sha(v)==EXPECTED[k],k+' input hash mismatch'
    result={'status':'running','scriptSha256':sha(Path(__file__).read_bytes()),'planSha256':sha((ROOT/'PLAN.md').read_bytes()),
        'sharedSource':{'path':shared.__file__,'sha256':sha(Path(shared.__file__).read_bytes())},'inputs':EXPECTED,
        'parentTemplateSha256':PARENT_TEMPLATE_SHA256,
        'primaryComparisons':COMPARISONS,'diagnosticComparisons':DIAGNOSTIC_COMPARISONS,
        'conditions':{'runs':6,'callsPerBatch':CALLS,'batchesPerCondition':PAIRS,'timedChoicesPlanned':172800000,
            'initialWarmup':50000,'batchWarmup':2000,'frameViewport':[1280,900],'topLevelViewport':[7680,900],
            'sourceOrder':ORDERS,'placementOrders':ORDERS,'measurementOrderIndex':'(batch + 2*(firstPlayer-1) + roleIsBlock) % 6; independent of run placement','endpointArithmetic':'Encode exposed ms as integer ns; no extra timer accuracy',
            'comparisonScope':'new six-realm diagnostic; not identical to stage12 three-realm history and not pooled with it or historical104-condition records',
            'noConcurrentBrowserJobs':True,'productionSelectorReferencesReplaced':False,'nativeCounterReset':'before each warmup and measured batch, outside timing'},
        'runs':[],'rows':[]}
    write(args.output,result)

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            key=self.path.strip('/');body=HOST if key=='host' else raw.get(key)
            if body is None:self.send_error(404);return
            self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)))
            self.end_headers();self.wfile.write(body)
        def log_message(self,*unused):pass

    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
    threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        with sync_playwright() as p:
            for run,placement in enumerate(ORDERS):
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
                rec={'run':run+1,'placement':placement,'selfTests':{},'setup':{},'preparations':[],'pageErrors':[]};result['runs'].append(rec)
                try:
                    page=browser.new_page(viewport={'width':7680,'height':900})
                    result['conditions']['browserVersion']=browser.version
                    page.on('pageerror',lambda error,rec=rec:rec['pageErrors'].append(str(error)))
                    origin=f'http://127.0.0.1:{server.server_port}'
                    page.goto(origin+'/host',wait_until='load',timeout=60000);frames={}
                    for key in placement:
                        page.evaluate('''async ({key,url})=>{const frame=document.createElement('iframe');frame.id='bench-'+key;frame.name=frame.id;
                         const loaded=new Promise((r,j)=>{const timer=setTimeout(()=>j(Error('Frame load exceeded60s')),60000);frame.onload=()=>{clearTimeout(timer);r()};frame.onerror=()=>{clearTimeout(timer);j(Error('Frame failed'))}});frame.src=url;document.body.appendChild(frame);await loaded}''',{'key':key,'url':origin+'/'+key})
                        frame=page.frame(name='bench-'+key);assert frame is not None
                        frames[key]=frame;tests=json.loads(frame.locator('#rule-test-results').text_content())
                        assert tests=={'passed':322,'total':322,'failures':[]},tests
                        rec['selfTests'][key]=tests
                        rec['setup'][key]=frame.evaluate(shared.INSTALL_BENCH,shared.LAYOUTS)
                        rec['setup'][key]['checks']=frame.evaluate(EXTEND)
                        assert rec['setup'][key]['checks']['visibility']=='visible'
                        assert rec['setup'][key]['innerWidth']==1280 and rec['setup'][key]['innerHeight']==900
                    assert page.evaluate('document.visibilityState')=='visible'
                    assert not rec['pageErrors'],rec['pageErrors']
                    for first in ([1,2] if run%2==0 else [2,1]):
                        preps={key:frames[key].evaluate('first=>__frameCpuBench.prepare(first)',first) for key in placement}
                        assert all(value['stats']==preps['original']['stats'] for value in preps.values()),'Worker stats differ'
                        assert not rec['pageErrors'],rec['pageErrors']
                        rec['preparations'].append({'firstPlayer':first,**preps})
                        cases=[(s,role) for s in shared.SCENARIOS[:1] for role in ['break','block']]
                        if run%2:cases.reverse()
                        for case_number,(scenario,role) in enumerate(cases):
                            spec={**scenario,'name':'master-fallback','difficulty':'master','engine':'fallback','roll':0.8,'role':role}
                            row={'run':run+1,'firstPlayer':first,'scenario':scenario['name'],'role':role,'samples':[],'audits':{}}
                            result['currentRow']=row;write(args.output,result)
                            decisions={key:frames[key].evaluate('spec=>__frameCpuBench.configure(spec)',spec) for key in placement}
                            assert all(value==decisions['original'] for value in decisions.values()),'Decision fixture differs'
                            row['decision']=decisions['original']
                            for key in placement:row['audits'][key]=frames[key].evaluate('()=>__frameCpuBench.audit()')
                            assert all(value==row['audits']['original'] for value in row['audits'].values()),'Functional/policy/RNG mismatch'
                            for key in placement:frames[key].evaluate('()=>__frameCpuBench.warmChecked(50000)')
                            for batch in range(PAIRS):
                                order=ORDERS[(batch+2*(first-1)+int(role=='block'))%6]
                                measured=page.evaluate(SAMPLE,{'order':order,'count':CALLS})
                                assert not rec['pageErrors'],rec['pageErrors']
                                fields=['checksum','lastCell','count','status','counters','memory']
                                contracts=[{k:measured[arm][k] for k in fields} for arm in FILES]
                                assert all(value==contracts[0] for value in contracts),'Timed contract differs'
                                row['samples'].append({'batch':batch+1,'order':order,'measurements':measured})
                            row['comparisons']={f'{a}-to-{b}':summary(row['samples'],a,b) for a,b in COMPARISONS+DIAGNOSTIC_COMPARISONS}
                            result['rows'].append(row);result.pop('currentRow',None);write(args.output,result)
                            focus=row['comparisons']['original-to-stage5']
                            print(f'run{run+1} P{first} {scenario["name"]} {role}: original→5 {focus["pairedMedianDeltaUs"]:+.4f}us {focus["interval"]["classification"]}',flush=True)
                        for frame in frames.values():frame.evaluate('()=>{releaseWholeGameCpu();__frameCpuBench.dp=null}')
                    for frame in frames.values():frame.evaluate('()=>__frameCpuBench.cleanup()')
                    assert not rec['pageErrors'],rec['pageErrors']
                finally:browser.close()
        assert len(result['rows'])==24
        result['timedChoicesExecuted']=sum(len(r['samples'])*6*CALLS for r in result['rows'])
        assert result['timedChoicesExecuted']==172800000
        result['status']='completed';result['functionalEquivalence']=True
    except BaseException as error:result['status']='failed';result['error']=repr(error);raise
    finally:write(args.output,result);server.shutdown();server.server_close()


if __name__=='__main__':main()
