# 段階13の再現手順

対象は添付された `BINGO-BOUT-new-chat-handoff-20261015.zip` の展開済みHTML。リポジトリmainの旧HTMLではない。元ZIPの内容を `/workspace/handoff/BINGO-BOUT-handoff/` に保持した環境で実行する。

必要なものはPython 3、Python Playwright、および `/usr/bin/chromium`。今回の実行環境はChromium154.0.8037.57、4CPU相当のquota。初期セットアップ後のインストールやアプリソース変更は不要だった。

1. 他のブラウザー・DP・性能ジョブを停止した状態で実行する。計測ジョブを並列化しない。
2. 元の480ファイルの完全性を確認する。

```bash
python3 /workspace/handoff/BINGO-BOUT-handoff/verify_manifest.py
```

3. 別の出力先を使って、固定回数の計測と集計を順に実行する。既存出力への上書きは拒否する。

```bash
cd /workspace/bingo-stage13-20261015
mkdir -p reproduction
python3 native_stages.py --output reproduction/native.json
python3 summarize_stages.py reproduction/native.json --output reproduction/summary.json
```

`native_stages.py` 内のPROJECTパスと、原本・5中間版、凍結済み共通helperのSHA-256を実行前に照合する。計画・計測script・helperの実行時hashがnative.jsonへ残る。計測scriptはPLAN.mdと同じディレクトリに置く。段階12scriptは由来を記録するためのhashであり、実行時依存ではない。

期待する完了形は `status=completed`、6run、24条件行、各12batch・各6版、計172,800,000計時判断。36通常読込がそれぞれ322/322、72実Worker準備、144版別の機能監査が全6版で一致する。エラーや不一致は失敗として保存される。

標本には機器・生成・実行履歴の影響が残る。出力が保存済み結果と同じ時間・符号になることを期待条件にしない。結果が異なっても既存データを削除せず、事後の許容差やA/A補正を追加しない。

`summary.json` は各条件・9比較の全run中央値と区間、増加/減少/未確定の件数を保持する。主要比較は隣接5差と原本→5、残り3差は診断用。元の104条件や段階12とプールせず、厳密な全経路非悪化とは扱わない。

同名のCSVも自動出力する（保存済み結果はsummary.csv、216データ行）。JSONとCSVの両方で既存出力への上書きを拒否する。

同梱index.htmlは利用中の段階9を無変更で保存したもので、今回の6版の一つではない。計測対象の6版と共通helperは元の引き継ぎZIPを展開して用意する。本ZIPは元ZIPの置き換えではない。
