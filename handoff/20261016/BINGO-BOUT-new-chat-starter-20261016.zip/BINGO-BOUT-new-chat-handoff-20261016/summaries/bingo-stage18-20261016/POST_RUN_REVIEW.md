# 段階18 保存データの独立最終レビュー

2026-10-16 JST。段階17の実効1ns・正式run3/4/7/8の保存SQL/JSON/限定raw ledgerを別のコードで再集計した。新しいブラウザー、DP、CPU負荷、性能実測、公式変換、protobuf decoderは実行していない。過去stageのファイルを変更せず、本段階の既存censusスクリプトもimport/実行していない。主要数値と保存された対応関係に不一致は見つからなかった。

## 計画・入力・ソース

PLANは4runの既存データだけを対象とし、PLAN_ADDITIONは既知のJSON正例2件だけを選ばず全192marker区間を調べる追加だった。どちらも新しい計測、閾値変更、サンプル除外や旧分類の更新を求めていない。各censusの現物スクリプトhash、元report hash、PLAN hash、marker helper hashを記録値へ照合した。

保存endpointソース23原本・933,974 bytesをsource-endpoint-auditのhash/bytesへ照合し、precisionソースmanifestの4ファイルも照合した。producer固定版と実行済み公式binaryの申告revisionに対応するexport_json.ccは、66,822 bytesの全文が同一だった。これは該当原文の同一性であり、任意のbinary全体や配布Chromiumの無改変buildを保証するものではない。失敗したソース取得の履歴とLICENSEも保持されている。

通常イベントのwall→TLS/reset/packet準備→CPUという経路、明示UserTimingと通常console stampの違い、4名称のcallsite、条件付き境界の導出を静的点検した。実効1nsで差分除算の剰余が0になることと、端点読取の同時性・時計の物理的妥当性は別の問題として扱われている。

## SQL残差と同一対象の精度差

| 指標 | 独立再集計 |
| --- | ---: |
| 完了SQL / CPU付き / CPU欠測 | 85,434 / 83,817 / 1,617 |
| CPU付きの負 / ゼロ / 正 | 49,070 / 6,868 / 27,879 |
| 正の差のnearest-rank p50 / p95 / p99 | 30 / 960 / 1,788 ns |
| 正の最大差 | 129,988 ns |
| CPU付きdur=0 instant / うちstrict正 | 2,752 / 0 |
| CPU付きdur>0 / 同一対象JSON X | 81,065 / 81,065 |

正の値の記述binも一致した。0超〜100nsが22,295、100ns超〜1µsが4,230、1µs超〜10µsが1,299、10µs超〜100µsが54、100µs超〜1msが1、1ms超は0。全108イベント名称のpositive件数も別集計と一致した。これらは許容差や合否の閾値ではない。

SQLの正duration・CPU付き81,065件とJSON Xのtupleを、出現数を含む多重集合で全数一致確認した。この同一母集団でduration同士を別々に整数µs化すると、次の符号遷移になる。

| ns差の符号 | µs差が負 | µs差がゼロ | µs差が正 |
| --- | ---: | ---: | ---: |
| 負 | 4,481 | 44,589 | 0 |
| ゼロ | 0 | 4,116 | 0 |
| 正 | 0 | 24,739 | 3,140 |

したがって今回はstrict件数差24,739件を同じduration母集団の整数µs化で全て説明できる。SQL側だけのCPU付きinstantはstrict0なので、この差への寄与は0だった。段階17では未分解だった点を既存データで追加分類したもので、過去値を変更していない。

durationを単調なfloorで比較する場合、正負の反転はなく、非ゼロが0になる。34件の複数候補を個別IDへ一意対応したとはせず、全体の多重集合一致と区別した。開始値とdurationを別々にfloorした派生終点のcarryも再集計し、wall/CPUとも0が23,877、wall0/CPU1が18,412、双方1が19,366、wall1/CPU0が19,410件で保存結果に一致した。

## raw境界と次の保存点

限定ledgerから同一sequence/trackのB/Eスタックを別に作り、全strict正27,879 SQL idが重複・欠落なく一意raw pairへ対応することを確認した。各begin/end CPU値と、UUID/CPU値から一意に引ける公式counter wall値はSQL sliceの端点と一致した。

same-threadのCPU付き保存raw点164,882件は全て公式counter wallへ一意対応した。保存点のpacket順とwall順は一致し、全隣接wall/CPU差は正。未対応END/未閉鎖BEGINもなかった。ただしCPUなしの一部TrackEventを保持しない限定ledgerであり、全実行命令・全イベント列を復元した結果ではない。

正のsliceのうち27,876件には次の保存点があり、3件はrun末尾で次点なしだった。次点ありの全件でwall gapが当該sliceの超過以上、両端のpacket clockは省略・default64・legacy timestampなし。次点をclock種別で飛ばしていない。slice内部clearは2件、same epochは27,877件だった。3欠測を必要条件適合へ加算していない。

この比較の必要条件は、正しく復元した同一threadの通常wall/CPU端点、wallの先行取得、CPU取得後に次wallを読む実行順、理想CPU増分がwall増分以下、という仮定を要する。packet順・default64のmetadataだけで実際のclock取得順を観測したわけではない。必要な時間の余地があることから、全残差がCPU終端読取遅延で生じたと結論しない。

## 全marker区間のnsとJSON端点差

全192区間（正式144・暖機48）を、保存raw点・公式counter wall・report marker・同じprotoのJSONへ独立に照合した。全端点が一意で、CPU/wall端点のns//1000はJSON tts/tsに一致した。

| 保存nsの符号→JSON端点差の符号 | 区間数 |
| --- | ---: |
| 負→負 | 178 |
| 負→ゼロ | 11 |
| 負→正 | 1 |
| 正→ゼロ | 1 |
| 正→正 | 1 |

保存nsは負190・正2、JSONは負178・ゼロ12・正2だった。特殊な3例の値も独立計算と一致した。

| capture→handler-end | 保存ns超過 | JSON µs超過 |
| --- | ---: | ---: |
| run7 legacy trial1 stamp | +25 ns | 0 µs |
| run7 legacy trial3 mark | +1,116 ns | +1 µs |
| run8 DP trial1 stamp | −139 ns | +1 µs |

markerは4つの端点値をfloorしてからCPU区間長とwall区間長を差し引くため、前節の「2つのdurationを別々にfloorする比較」と異なり正負反転が起こりうる。run8の1件を分類しても、保存nsで正の2件を解消したことにはならない。これらのns値も同時取得した物理CPU真値とは呼ばない。

SOURCE_ENDPOINT_REVIEWのduration丸め表現は、レビュー指摘後に正負反転なし・0化のみ、marker端点差とは別と明確化された。変更は説明のみで、式・ソース原本・実装・計測値は変わっていない。

## 適用範囲と成果物

新しい実測や構成対照を追加しなくても、今回の保存データ分類と必要条件の検査は完了している。未確定原因を都合のよい時計誤差や計測遅延へ一括帰属せず、旧62/104条件、過去stage14/15、全経路の厳密非退行・CPU会計の完全妥当性は未確認のまま維持する。

独立コードは`review_saved_censuses.py`、結果は`independent-census-review.json`。入力とスクリプトのhashを保存し、既存出力を上書きしない。過去stage・元handoff・repoの保全監査と最終ZIP監査はrootの別担当範囲。

最終RESULTS.mdとREPRODUCE.mdも読んで照合した。主要な分母・分布・duration整数化の差24,739件、marker3例、次点あり27,876/なし3、条件付き必要条件と原因未確定という範囲は本レビューと矛盾しない。新実測/新構成対照0を明示し、空の別フォルダーでの再計算として原本の上書きや移動を避けている。公開を妨げる問題は見つからなかった。

| 入力・独立結果 | SHA-256 |
| --- | --- |
| residual-census.json | `bafc77efc263a03dd542a1505b7d2c7bcb488c44a09bd9500b728c93a2a83345` |
| precision-census.json | `e7f3c55ad812f4dd017e909509b6d8a6fd303d1bf772476a0e4205e0c5cf1bcb` |
| boundary-census.json | `80e80a59bc2807bfa6d95abe903e4c8e3097abc94ecc81242e2966d1ebe51f7d` |
| marker-ns-census.json | `a207b3f2baccc593a36fa5614ac7ebcc91f6133b6e71e1817e00545d044a34ce` |
| independent-census-review.json | `5d3e878c973d4e75e1e68c87eb6422704f54c04c49c1c5123ff318a15d6e74bb` |
