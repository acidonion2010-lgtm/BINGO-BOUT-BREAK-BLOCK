#!/usr/bin/env python3
"""Cross-check declared fixture expectations against official and raw outputs."""
from pathlib import Path
from decimal import Decimal
import csv
import io
import json
import sys

ROOT = Path(__file__).resolve().parent
ledger_path = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "raw_ledger_clock_mapped.json"
output_path = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / "verification.json"
expected = json.loads((ROOT / "expected_clock_mapped.json").read_text())
ledger = json.loads(ledger_path.read_text())
official = json.loads((ROOT / "official_clock_mapped.json").read_text())
slices = list(csv.DictReader(io.StringIO((ROOT / "mapped_slice_query.stdout.txt").read_text())))
counters = list(csv.DictReader(io.StringIO((ROOT / "mapped_counter_query.stdout.txt").read_text())))
health = list(csv.DictReader(io.StringIO((ROOT / "mapped_health_query.stdout.txt").read_text())))
checks = []


def require(name, actual, wanted):
    assert actual == wanted, f"{name}: {actual!r} != {wanted!r}"
    checks.append({"check": name, "actual": actual, "expected": wanted, "passed": True})


require("packet_count", ledger["packets_seen"], expected["packet_count"])
require("event_count", ledger["events_seen"], expected["track_event_count"])
require("official_error_or_data_loss_rows", health, [])
for marker in expected["markers"]:
    matching = [row for row in ledger["ledger"] if row["sequence_id"] == marker["seq"]
                and row["name"] == marker["name"] and row["type"] == marker["type"]]
    require("unique_raw_marker:" + str(marker["name"]), len(matching), 1)
    require("raw_cpu_ns:" + str(marker["name"]), matching[0]["cpu_ns"], marker["cpu_ns"])
    name = marker.get("matching_begin_name", marker["name"])
    official_row = [row for row in slices if row["name"] == name]
    require("unique_official_slice:" + str(name), len(official_row), 1)
    row = official_row[0]
    official_cpu = int(row["thread_ts"])
    official_wall = int(row["ts"])
    if marker["type"] == 2:
        official_cpu += int(row["thread_dur"])
        official_wall += int(row["dur"])
    require("official_cpu_ns:" + str(marker["name"]), official_cpu, marker["cpu_ns"])
    require("official_wall_ns:" + str(marker["name"]), official_wall, marker["wall_ns"])

require("noise_rows_in_raw_order", [row["cpu_ns"] for row in ledger["ledger"] if row["name"] == "fixture_noise"],
        expected["nonmarker_cpu_ns"])
require("all_counter_values_raw_vs_official", sorted(row["cpu_ns"] for row in ledger["ledger"]),
        sorted(int(Decimal(row["value"])) for row in counters))
span = [row for row in slices if row["name"] == "S16_fixture_s1_span"][0]
require("official_thread_duration_ns", int(span["thread_dur"]), expected["expected_slice_thread_duration_ns"])
span_json = [row for row in official["traceEvents"] if row.get("name") == "S16_fixture_s1_span"][0]
require("official_json_tts_ns", int(Decimal(str(span_json["tts"])) * 1000), expected["expected_slice_cpu_ns"])
require("official_json_tdur_ns", int(Decimal(str(span_json["tdur"])) * 1000), expected["expected_slice_thread_duration_ns"])

report = {"status": "passed", "ledger": str(ledger_path), "checker_script_sha256": ledger["script_sha256"],
          "marker_endpoints": len(expected["markers"]), "checks": checks,
          "ledger_scope_status": ledger["status"], "ledger_diagnostics": ledger["diagnostics"],
          "limit": "Finite synthetic happy-path arithmetic only; does not validate full importer parity or runtime CPU accounting."}
with output_path.open("x") as f:
    f.write(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": "passed", "checks": len(checks), "marker_endpoints": len(expected["markers"]), "output": str(output_path)}))
