# 段階14保存traceのCPU時計点検

2026-10-15。新しいブラウザー・DP・性能測定は実行せず、段階14の既存16traceを読み取った。733,556,300 bytes・2,929,898 eventsの全ファイルで元reportのSHA-256と一致した。元traceをコピーせず、各元hashと集計・少数の証拠例だけをこの段階へ保存した。段階14のraw・分析器・JSON・本体は変更していない。

**CPU>wallは3つのresponse区間に限らない。全16visitのrenderer-mainでms単位のfull-X不整合があり、応答外にもある。** 一方、CPU counterの後戻りや、跳躍後に値を減らす補償はexportされた時計点列に見つからなかった。取得時の実CPU時計、採取順、Perfetto packet/exportのどこが原因かは、JSONだけでは確定しない。

## PerformanceMarkとconsole TimeStamp

全1,280個の一意名について、PerformanceMarkと直後のconsole TimeStampを同じrenderer-main PID/TIDに結び付けた。

- console−markのwall差はすべて正で18〜2,154µs、CPU差もすべて正で17〜180µs。各visitの分布を`raw-clock-review.json`へ保持した。一定のoffsetではない。
- 3ペアでCPU差がwall差を超えた。run1原本legacy trial2 second-rafはwall49µs/CPU75µs、run1段階3 legacy trial7 second-rafは34/50µs、run2原本DP trial9 second-rafは38/58µs。超過は26/16/20µsで、元のms単位の3response不整合とは別のペアである。
- mark→stampのcounter後戻りや`tts`欠測は0件だった。mark側の特定イベントだけにCPU時計問題を限定できず、両方から同じ区間を作っても元の3response不整合は残る。

したがってmarkのJSON小数対応だけを原因としたり、固定mark overheadを引けば解消すると扱ったりしない。page/trace `startTime`のULP対応検査は、別の数値対応検査として維持する。

## 同じrenderer-mainのI/Xイベント

各visitの全I/X startを、wall `ts`昇順、同じ丸めwall時刻では元JSONのevent index順に並べた。`tts`をソートキーに使って後戻りを隠していない。

| 点検 | 全16traceの結果 |
|---|---:|
| I/X startの有限ts/tts点 | 640,623 |
| うちIだけの点 | 23,906 |
| I/X startのtts後戻り | 0 |
| Iだけのtts後戻り | 0 |
| 隣接I/X start間のCPU増分がwall増分を1ms超上回る箇所 | 82 |
| full Xのdur/tdur対応 | 616,717 |
| full Xでtdur>dur | 12,624 |

丸めwall時刻が同じ隣接点は別集計に残した。厳密な符号の件数と規模の件数を区別し、次のbinで除外・補正・許容差判定をしていない。

| full Xのtdur−dur | 件数 |
|---|---:|
| 0超〜1µs以下 | 10,239 |
| 1超〜10µs以下 | 1,827 |
| 10超〜100µs以下 | 377 |
| 100超〜1,000µs以下 | 12 |
| 1,000µs超 | 169 |

全12,624件中10,360件は、warmupも含む全response窓の外側だった。1ms超だけでも169件中151件が全response外、18件がresponseと交差した。1ms超は全16visitで観測された。ネストするXイベントに同じ時計の跳躍が含まれるので、169件を独立したCPU異常回数と数えたり、超過量を合計してCPU損失へ換算したりしない。

1ms超のイベント名は、RunTask43件、ProxyMain::BeginMainFrame31件、v8.callFunction21件、FunctionCall20件、FireAnimationFrame19件、UpdateLayoutTree12件、Receive mojo message6件などに分散した。ParseHTMLとLayoutも各2件、commit待ち1件、GCに該当するイベントも2件あった。特定ゲーム関数・DP分岐・DOMイベント名に限定されない。

例としてrun2原本ではRunTaskがwall6µs/CPU6,888µsでresponse外、run1段階5のReceive mojo messageは120/7,229µsでresponse外だった。run2段階5legacy trial1のcommit待ちは251/7,624µsでresponse内だった。元の3つの区間以外にも局所的な会計不整合があるため、区間全体のCPU≤wallだけでは内部時計の正常性を証明できない。

## 局所跳躍と前後の時計点

`raw-clock-jumps.json`は、全I/X startに加えて各Xの終端を`ts+dur`/`tts+tdur`として明示的に構成した。合計1,257,340点をwall順に調べても、異なるwall時刻の間でttsが後戻りする例は0だった。startだけでなくdurationから作るendでも単調なcounterの局所跳躍として現れ、後でcounter値を減らす補償は見つからない。通常のidleによるwall−CPUの変化を「補償」と再分類していない。

例えばrun1原本のresponse外では、UpdateLayoutTree startのts=7,069,998,660/tts=5,150,301から、次のLayout startのts=7,070,002,410/tts=5,162,032へ進む。wall3,750µsに対してCPU11,731µsで7,981µsの超過があり、その前後のstart counterは順に増えている。対応UpdateLayoutTreeのfull Xもwall3,670µs/CPU11,725µsだった。

rootが指定したrun3原本legacy trial3内のParseHTMLについては、次の点列を直接確認した。

| 時計点 | wall ts (µs) | CPU tts (µs) |
|---|---:|---:|
| ParseHTML start | 7,203,002,620 | 19,576,225 |
| 同Xの導出end | 7,203,002,752 | 19,581,644 |
| 次の記録ParseHTML start | 7,203,002,792 | 19,581,647 |

full Xはwall132µs/CPU5,419µs。次のI/X startは導出endからwall40µs後、CPU3µs後にあり、exportされた列にはCPU超過5,287µsに見合う5msのwall gapがない。全1ms超イベント169件すべてに次の同thread I/X startがあり、168件ではそのwall gapがCPU超過量より短かった。この具体例と全件のgap集計は`boundary-gap-review.json`へ保存した。

wall→内部処理→CPUの非同時採取は不等式が崩れる候補の一つだが、この例を単純な「end CPU readだけが5ms遅れた」で説明するには、次startのwall時刻も実採取時刻に対応するか等の追加条件を確認する必要がある。JSONのts/ttsだけでは、明示時刻引数・実clock read・packet reconstructionの各時点を復元できないため、採取遅延説を断定も排除もしない。

## metadataと帰属可能性

全traceはwall側`clock-domain=LINUX_CLOCK_MONOTONIC`、Linux6.18.44、x86_64、`cpu-running-in-vm=1`を記録する。ただしCPU clock ID、CPU clockのsampling interval、元のthread-clock snapshot/packet sequenceを明示するmetadataは、保存JSON内で見つからなかった。同じrenderer-mainにはclock/CPU/sampling/profile名の該当イベントもなかった。現ホストのclocksource等を読んだ別成果物は実行環境の文脈であり、過去イベントの元clock readを証明するものではない。

`trace_processor_stats`には`invalid_cpu_times=0`、clock同期失敗関連0があるが、これは局所ts/tts不整合を正常化する根拠にならない。`clock_sync_cache_miss`は295〜367で非0。`traced_chunks_discarded`は各fresh browserの最初visitでは0、後続visitで増え、`traced_data_sources_seen`も4→8→12→16と増える。一部後続visitでは`traced_patches_discarded=2/3`もある。これらはsession横断の累積値を含む可能性があり、保存streamの`dataLossOccurred=false`や個別bufferのloss0とは区別して保持した。CPU超過をこのcounterへ帰属させる直接の対応は得られていない。

元の3response不整合区間には記録されたGC Xとの交差が0件だった。応答外の大きい超過がGCイベント内に出る例もあるが、それだけでGCがCPU時計を変えたとは言えない。ゲームのDP・JS GC・renderer負荷・仮想化・Linux clocksource・Perfetto exportのいずれにも、今回の保存データだけから確定的な帰属はできない。

## 保存物と残件

- `raw_clock_review.py` / `raw-clock-review.json`: 全16trace、mark/stamp対応、I/X start単調性、full-X全件、metadata、元hash。
- `raw_clock_jumps.py` / `raw-clock-jumps.json`: ms超過の分類とresponse内外、局所start列、導出X endを含む単調性。
- `boundary_gap_review.py` / `boundary-gap-review.json`: ms超過イベントの次start gapと特定ParseHTMLの時計点。

負のwall−CPU、不都合なXイベント、正式試行を除外せず保存した。CPU寄与率や待機量を補正してPASSにしていない。段階14のwall/描画/入力の記録は保持し、CPU時計の原因特定はsource調査とrootの別途固定計画によるprobeに引き継ぐ。元のHARD差、過去62条件、全経路非回帰判定は変更しない。
