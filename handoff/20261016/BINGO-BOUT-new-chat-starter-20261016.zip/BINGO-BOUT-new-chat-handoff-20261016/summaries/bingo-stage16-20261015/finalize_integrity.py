#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(n):return json.loads((R/n).read_bytes())
def main():
 report=read('report.json');analysis=read('analysis.json');raw=read('raw-counter-official-check.json');model=read('cpu-quantization-model-check.json');sql=read('official-sql-summary.json');same=read('same-proto-sql-json-check.json');control=read('decoder-validation/source-quantization-control/result.json')
 assert report['status']=='completed' and report['formalClicks']==24 and report['warmupClicks']==8
 assert report['scriptSha256']==sha(R/'capture_proto.py') and report['planSha256']==sha(R/'PLAN.md')
 assert analysis['scriptSha256']==sha(R/'analyze_proto_json.py') and analysis['reportSha256']==sha(R/'report.json')
 assert raw['scriptSha256']==sha(R/'verify_raw_counters.py') and raw['checkerSha256']==sha(R/'raw_counter_check.py') and raw['sourceReportSha256']==sha(R/'report.json')
 assert model['scriptSha256']==sha(R/'verify_quantization_resets.py') and model['rawOfficialCheckSha256']==sha(R/'raw-counter-official-check.json')
 assert sql['scriptSha256']==sha(R/'extract_sql.py') and sql['reportSha256']==sha(R/'report.json') and sql['binarySha256']==sha(R/'trace_processor_shell')
 assert same['scriptSha256']==sha(R/'check_sql_json.py') and same['reportSha256']==sha(R/'report.json')
 assert raw['summary']['allMarkerCoverageExact'] and raw['summary']['allCounterMultisetsEqual']
 assert model['summary']['largeSlicesWithinFloorBound']==26
 for v in report['visits']:
  assert v['completed'] and v['selfTests']=={'passed':322,'total':322,'failures':[]}
  assert v['trace']['integrityChecksPassed'] and v['trace']['sha256']==sha(Path(v['trace']['path']))
  assert v['conversion']['sha256']==sha(Path(v['conversion']['path']))
 assert not report['pageErrors']
 assert control['status']=='passed' and control['official_conversion_count']==1 and all(control['checks'].values())
 assert 'Verified 480 files: all SHA-256 hashes match.' in (R/'original-preservation.log').read_text()
 for name,count in [('stage14-preservation.log',37),('stage15-preservation.log',106)]:
  lines=(R/name).read_text().splitlines();assert len(lines)==count and all(x.endswith(': OK') for x in lines)
 assert not (R/'repository-status.txt').read_text()
 assert sha(R/'index.original.html')=='e872443dc9764f3b9647f4797d1411ca98f865b9c2f69c6e694529e2685cd3a9'
 assert sha(R/'index.html')=='59fff4685ff3f36e18d73fe9fa524ee57d81a348352e7b2912db4b7ecc1bb513'
 assert (R/'FINAL_REVIEW.md').is_file()
 inventory=[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((R/'official-sources').rglob('*')) if p.is_file()]
 (R/'source-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
 out={'status':'completed','clientDate':'2026-10-15','stage':16,'freshBrowserProcesses':5,'preflightBrowsers':1,'formalBrowsers':4,'normalLoads':5,'selfTestsPassed':1610,'realWorkerPreparations':4,'formalClicks':24,'warmupClicks':8,'additionalRealMeasurementsAfterFixedBrowserBudget':0,'rawProtoFiles':5,'rawProtoBytes':sum(v['trace']['bytes'] for v in report['visits']),'sameProtoJsonBytes':sum(v['conversion']['bytes'] for v in report['visits']),'jsonEvents':338523,'mainXEventsTotal':78837,'mainXWithBothClocks':69376,'mainXMissingRequiredCpuFields':9461,'jsonMainXStrictCpuGreaterThanWall':1468,'sqlMainSliceStrictCpuGreaterThanWall':1478,'cpuExcessOver1ms':26,'largeCpuSlicesAcrossClear':26,'largeCpuSlicesWithinConditionalQuantizationBound':26,'rawThreadCpuSamplesMatched':167205,'markerEndpointsMatched':260,'formalMarkerWindows':144,'warmupMarkerWindows':48,'markerWindowCpuExcess':0,'cdpOuterBrackets':33,'outerThreadTimeCpuExcess':0,'independentPhysicalCpuClockValidated':False,'syntheticQuantizationControlFixtures':1,'syntheticQuantizationControlOfficialConversions':1,'syntheticControlPassed':True,'syntheticTrueCpuAndWallNs':1500,'syntheticRepresentedCpuUs':10001,'syntheticRepresentedWallUs':1,'quantizationCandidateCompatibleWithActualTrace':True,'actualTraceSoleCauseConfirmed':False,'strictChromiumCpuAccountingConfirmed':False,'originalManifestFilesUnchanged':480,'stage14ManifestFilesUnchanged':37,'stage15ManifestFilesUnchanged':106,'mainRepositoryWorkingTreeClean':True,'applicationChanged':False,'currentApplicationSha256':sha(R/'index.html'),'old104ConditionRecordsReclassified':False,'oldUnconfirmedConditions':62,'strictAllPathsNonRegressionConfirmed':False,'formalSamplesFilteredOrCorrected':False,'officialSourceInventoryFiles':len(inventory)}
 (R/'integrity.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
