# 段階18：1nsトレースに残った小さな超過の照合

**JSONの整数化による見え方と、元ns端点に残る差を分けて確認した。** 同じイベント集合で、SQLの正27,879件とJSONの正3,140件の差24,739件は全て整数µs化で0になる記録だった。markerには負→正の符号反転も1件あった。元nsの小さな正の差は残り、厳密なCPU会計を確認したとはしない。

今回は保存済み段階17の1ns正式run3/4/7/8だけを再解析した。新規ブラウザー、DP、native負荷、ゲーム性能計測は全て0。既存データと固定sourceで確認できたため、新たな構成対照も追加しなかった。元の符号・失敗・曖昧な対応を補正・除外せず保持した。

## 元nsの分布

SQL完了slice85,434件のうちCPUあり83,817件、欠測1,617件、未完0。CPUありの内訳は負49,070、ゼロ6,868、正27,879。正の差の中央値は30ns、95%点960ns、99%点1,788ns、最大129,988nsだった（nearest-rank、正だけの記述統計）。ns表記は物理時計が1ns正確であることを意味しない。

| 正の差の範囲（重複なし） | 件数 |
| --- | ---: |
| 0超〜100ns | 22,295 |
| 100ns超〜1µs | 4,230 |
| 1µs超〜10µs | 1,299 |
| 10µs超〜100µs | 54 |
| 100µs超〜1ms | 1 |
| 1ms超 | 0 |

この区切りは記述用であり、小さい差を合格とする許容幅ではない。全名前別分布と最大20件を[residual-census.json](residual-census.json)に保存した。入れ子sliceを独立した異常の回数として足し合わせない。

## 同じイベントをSQLとJSONで比較

CPU付き・正durationの81,065件について、SQLをµsへ整数化したtupleの多重集合と、JSON Xの多重集合が全数一致した。SQLのみのinstant2,752件はstrict超過0で、分母は変えるが正の件数差には寄与しなかった。

- nsでは正27,879件。そのうち24,739件は整数µsのduration表現で0、3,140件は正のまま。
- Xのduration同士に同じfloorを適用するので、正負が逆方向へ反転することはなく、0への圧縮が起きる。
- µs tupleが重なる34 JSON（17組）は全候補を保持。個々のJSONへ都合のよいSQL候補を選ばない。集団の一致と個別対応の一意性を区別する。
- `floor(start/1000)+floor(duration/1000)`はraw ENDのfloorより1µs小さくなり得る。今回はwall38,776件・CPU37,778件にcarryがあり、JSONの派生ENDを元のns ENDとして扱わなかった。

使用した公式binary commitとproducer固定revisionのexporter原文を別々に取得し、全文が同一であることも確認した。source根拠と実データの照合は[PRECISION_REVIEW.md](PRECISION_REVIEW.md)に保存した。

## 終端から次の記録まで

正27,879件すべてで、raw BEGIN/ENDのCPU両端とSQL sliceが一意に対応した。raw CPU値と公式counter.tsから得たwall端点もSQL sliceと完全一致した。次のsame-thread retained CPU-bearing raw pointがある27,876件では、全件で次のwall gapが元sliceの超過以上だった。末尾3件は次点なしとして残した。

最大例（run8 ThreadControllerImpl::RunTask）はwall1,701,211ns、CPU1,831,199ns、差129,988ns。raw ENDから次点までのwallは132,858ns、CPUは1,834nsだった。すなわち、見かけの超過に相当する時間が次のwall記録までに存在した。

全27,876件のend/nextはdefault clock64で、packet順とwall順の次点が一致した。明示timestampのpointを探索から除外した結果ではない。正のsliceのclear跨ぎは2件、end→nextのclear跨ぎ11件、loss0。全raw adjacent164,878組のwall/CPU差は正だった。詳しい端点・次点・clock fieldを全件[boundary-census.json](boundary-census.json)へ保存した。

固定sourceでは、通常TRACE_EVENTはwallを取得してからTLS/状態/packetを準備し、CPUを読む。開始と終了のwall/CPUは同じ実時点ではない。理想CPU増分が同じwall経過以下で、次の通常wall取得が終端CPU読取より後なら、終端読取の遅れだけで説明できるためには `excess ≤ next_wall − end_wall` が必要となる。今回、次点ありの記録にこの必要条件の反例はなかった。

**必要条件との整合性は、全件の原因が読取遅延だったという証明ではない。** raw packet順もclock読取実時点そのものではない。実際の読取遅れ・clock精度・変換をこの集計だけでは分離できない。指定した4名称の通常timestamp callsite、UserTimingの先行保存wall、TimeStamp、限定条件を[SOURCE_ENDPOINT_REVIEW.md](SOURCE_ENDPOINT_REVIEW.md)にまとめた。

## クリックmarkerの元ns端点

1ns条件の全192 windows（正式144・暖機48）で、raw CPUと公式counter wallのns端点が一意対応し、各端点をfloorした値がJSONと一致した。保存nsの符号は負190・ゼロ0・正2。JSONは負178・ゼロ12・正2だったが、正になる記録は同じではなかった。

| run / 条件 / capture→handler-end | 元wall ns | 元CPU ns | 元の差 ns | JSONの差 |
| --- | ---: | ---: | ---: | ---: |
| 7 / legacy trial1 / stamp | 3,150,681 | 3,150,706 | **+25** | 0µs |
| 7 / legacy trial3 / mark | 3,316,000 | 3,317,116 | **+1,116** | +1µs |
| 8 / DP trial1 / stamp | 3,424,705 | 3,424,566 | **−139** | **+1µs** |

Xのduration同士のfloorと異なり、markerはCPU/wallの開始・終了4端点を別々にfloorしてから引く。このため小さな正負が反転し得る。JSONの+1µsをそのまま真の超過と見なしたり、JSON0を厳密に差なしと判断したりできない。一方、元nsの正2件を解消済みとも扱わない。暖機48件は全て元nsで負だった。

これらは保存されたnsカウンター端点であり、同時に測った物理的なCPU真値ではない。全符号遷移と端点は[marker-ns-census.json](marker-ns-census.json)に保持した。

## 今回確定した範囲

整数化による件数差と、marker符号反転の1例は元データから説明できた。残る厳密差は通常timestampの非同時取得と整合するが、単独原因は未確定。このトレースだけで `wall = CPU + 待ち` の厳密分解は行わない。1ns設定でも表現精度と測定の正確さは別である。

ゲーム本体・元handoff480ファイル・段階17の262manifest対象・repo mainのclean状態は不変。過去stageの記録を今回の結果で補正しない。旧104条件の42反復非増加・62未確定、全経路の厳密非退行の未確認を維持する。

再計算は[REPRODUCE.md](REPRODUCE.md)、独立点検は[POST_RUN_REVIEW.md](POST_RUN_REVIEW.md)。全解析器・正残差27,879件の詳細・source/license・入力hashを保存した。raw proto/全ledgerの巨大な原本は不変の段階17一式を参照し、今回のZIPへ重複収録しない。
