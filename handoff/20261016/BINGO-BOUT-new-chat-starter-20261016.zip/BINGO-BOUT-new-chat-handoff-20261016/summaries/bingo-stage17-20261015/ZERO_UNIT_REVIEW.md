# preflight unit1 の停止理由: raw値と実効倍率の違い

段階17 collector は unit1000 の run0 を通過した後、unit1 の run1 で `actual CPU counter unit differs from requested unit` により停止した。保存データを変更せず、既存ledgerと固定ソースを読み取って確認した。

run1 対象 `CrRendererMain` (pid/tid `49906/49906`) の保存済み frozen raw ledger は、`thread_time` CPU counter 36件を `decoded`、`is_incremental=true`、`unit_multiplier=0` と記録している。raw gate はこの値の集合が要求値 `{1}` と等しいと要求したため停止した。

固定 Perfetto `5dbeaad4ceb91470a835426b52e0cb43a3e5ef10` の `src/tracing/track.cc:163–164` は、`unit_multiplier_ != 1` のときだけ CounterDescriptor の `unit_multiplier` field4 をserializeする。従って設定倍率1の場合、このfieldは省略される。

schema `counter_descriptor.proto:80–82` は optional int64 で明示defaultを持たず、未設定時のgenerated accessor値は0。frozen checker `raw_counter_check.py:195` も未設定時0を保存している。同 checker `:260–261` は倍率が正の場合だけ乗算するので、保存値0のときcounterの実効倍率は1である。

公式 importer `src/trace_processor/importers/proto/track_event_tracker.cc:641–642` も `unit_multiplier > 0` の場合だけ乗算する。これは frozen checker の数値復元と一致する。今回の停止は、raw descriptor表示値を設定要求値とそのまま比較した gate の誤りを示す。CPU復元値を0倍する処理ではなく、ゲームやクロックの失敗を示す証拠でもない。

gate 修正では、raw descriptor値を報告から消さず、`raw=0` と `effective=1` を分けて記録する必要がある。既存run1原protobufに対して、config echo・incremental clock64のunit1・公式importer health・対象CPUcounterincrementalを再照合すれば、同じcaptureを検証できる。検証のための追加browser計測は必要ない。過去の停止reportとログは保持する。

追加の公式固定ソース6ファイル (105,707 bytes) を `official-sources/config-zero-unit-source/` へ保存した。`MANIFEST.json` に固定URL、SHA256、byte数を記録している。適用ライセンスは同stageの `official-sources/config-review/perfetto/LICENSE` と各sourceのApache-2.0ヘッダを参照。

主な根拠:

- [CounterTrack serialization](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/src/tracing/track.cc#L163)
- [Official importer scaling](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/src/trace_processor/importers/proto/track_event_tracker.cc#L641)
- [CounterDescriptor schema](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/protos/perfetto/trace/track_event/counter_descriptor.proto#L80)
