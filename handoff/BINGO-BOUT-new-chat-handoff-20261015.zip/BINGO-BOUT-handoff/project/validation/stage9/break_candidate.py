#!/usr/bin/env python3
"""Finite same-realm BREAK candidate crossover; no production or speed PASS.

The baseline HTML loads normally, including its automatic tests and real Blob
Worker. Only four selector function references are exchanged outside timing.
Run browser/CPU diagnostics sequentially, without another benchmark active.
"""
import argparse
import functools
import hashlib
import http.server
import json
from pathlib import Path
import re
import statistics
import sys
import threading

from playwright.sync_api import sync_playwright


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'validation' / 'stage3'))
import frame_performance as shared


FUNCTION_NAMES = ['getCpuSelectionWeights', 'prepareCpuBreakCandidates',
                  'selectCpuLegacyCell', 'selectCpuBreakCell']
CASE_DEFINITIONS = [
    ('p2-middle-normal-break', 2, 'middle', 'break', 'normal-legacy'),
    ('p2-middle-hard-break', 2, 'middle', 'break', 'hard-legacy'),
    ('p2-middle-fallback-break', 2, 'middle', 'break', 'hard-fallback-legacy-roll'),
    ('p1-opening-normal-break', 1, 'opening', 'break', 'normal-legacy'),
    ('p1-late-hard-break', 1, 'late', 'break', 'hard-legacy'),
    ('p1-late-hard-block', 1, 'late', 'block', 'hard-legacy'),
    ('p2-middle-hard-block', 2, 'middle', 'block', 'hard-legacy'),
    ('p2-one-closed-fallback-block', 2, 'one-closed', 'block', 'hard-fallback-legacy-roll'),
    ('p2-middle-normal-block', 2, 'middle', 'block', 'normal-legacy'),
    ('p1-late-full-block', 1, 'late', 'block', 'hard-full'),
]
AA_CASES = {'p2-middle-hard-break', 'p2-one-closed-fallback-block',
            'p1-late-full-block'}


def function_sources(source):
    """Extract the four source declarations, preserving their exact bytes.

    These declarations use the repository's eight-space top-level indentation;
    nested closing braces have deeper indentation. Fail on a changed format.
    """
    found = {}
    spans = {}
    for name in FUNCTION_NAMES:
        pattern = re.compile(r'^        function ' + re.escape(name) + r'\(', re.M)
        matches = list(pattern.finditer(source))
        if len(matches) != 1:
            raise ValueError(f'Expected one declaration: {name}')
        start = matches[0].start()
        closing = re.search(r'^        }(?=\r?$)', source[matches[0].end():], re.M)
        if closing is None:
            raise ValueError(f'Missing declaration closing brace: {name}')
        end = matches[0].end() + closing.end()
        found[name] = source[start:end]
        spans[name] = (start, end)
    normalized = source
    for name, (start, end) in sorted(spans.items(), key=lambda item: item[1][0], reverse=True):
        normalized = normalized[:start] + f'/* stage9 function {name} */' + normalized[end:]
    return found, normalized


def cases():
    scenarios = {item['name']: item for item in shared.SCENARIOS}
    paths = {item['name']: item for item in shared.PATHS}
    paths['hard-fallback-legacy-roll'] = {'name': 'hard-fallback-legacy-roll',
        'difficulty': 'hard', 'engine': 'fallback', 'roll': 0.3}
    return [{'id': key, 'firstPlayer': first, 'scenario': scenario,
             'role': role, 'path': path,
             'spec': {**{k: v for k, v in scenarios[scenario].items() if k != 'fallbackOnly'},
                      **paths[path], 'role': role}}
            for key, first, scenario, role, path in CASE_DEFINITIONS]


INSTALL = r'''({baselineSources,candidateSources,functionNames,compilationOrder}) => {
  const bench = window.__frameCpuBench;
  const native = {getCpuSelectionWeights,prepareCpuBreakCandidates,
    selectCpuLegacyCell,selectCpuBreakCell};
  const nativeGetCellWeights = getCellWeights;
  const compile = sources => (new Function(
    functionNames.map(name=>sources[name]).join('\n') +
    '\nreturn {'+functionNames.join(',')+'};'))();
  const variants = {};
  for(const name of compilationOrder)
    variants[name]=compile(name==='baseline'?baselineSources:candidateSources);
  let fixedRoll=0.8;
  const fixedRandom=()=>fixedRoll;
  Math.random=fixedRandom;
  let fixture=null, refs=null, stable=null, expectedCell=null;
  function exact(a,b) {
    if(typeof a!==typeof b) return false;
    if(a===null || b===null) return a===b;
    if(typeof a!=='object') return Object.is(a,b);
    const keys=Object.keys(a);
    return keys.length===Object.keys(b).length &&
      keys.every(key=>Object.hasOwn(b,key)&&exact(a[key],b[key]));
  }
  function install(name) {
    if(!Object.hasOwn(variants,name)) throw new Error('Unknown variant '+name);
    const functions=variants[name];
    getCpuSelectionWeights=functions.getCpuSelectionWeights;
    prepareCpuBreakCandidates=functions.prepareCpuBreakCandidates;
    selectCpuLegacyCell=functions.selectCpuLegacyCell;
    selectCpuBreakCell=functions.selectCpuBreakCell;
  }
  function counters() {return {whole:cpuWholeDecisions,fallback:cpuWholeLegacyDecisions,
    hardLegacy:hardLegacyDecisions,hardFull:hardDpDecisions};}
  function memory() {return {breakCell:state.cpuBlockedBreakCell,
    breakStreak:state.cpuBlockedBreakStreak,breakCooldown:state.cpuBlockedCooldown,
    blockCell:state.cpuSuccessfulBlockCell,blockStreak:state.cpuSuccessfulBlockStreak,
    blockCooldown:state.cpuSuccessfulBlockCooldown};}
  function publicState() {return {p1Marks:state.p1Marks.slice(),p2Marks:state.p2Marks.slice(),
    p1Layout:state.p1NumberLayout.slice(),p2Layout:state.p2NumberLayout.slice(),
    p1Turns:state.p1TurnsTaken,p2Turns:state.p2TurnsTaken,first:state.firstPlayer,
    phase:state.phase,difficulty:state.cpuDifficulty,gameMode:state.gameMode,
    isStarting:state.isStarting,gameEnded:state.gameEnded,isProcessing:state.isProcessing,
    selectedBreakCell:state.selectedBreakCell};}
  function reset() {
    cpuWholeDecisions=cpuWholeLegacyDecisions=hardLegacyDecisions=hardDpDecisions=0;
    Object.assign(state,{cpuBlockedBreakCell:0,cpuBlockedBreakStreak:2,cpuBlockedCooldown:0,
      cpuSuccessfulBlockCell:0,cpuSuccessfulBlockStreak:2,cpuSuccessfulBlockCooldown:0});
    refs.dp.pay.fill(0);refs.dp.probP.fill(0);refs.dp.probQ.fill(0);refs.dp.order.fill(0);
    refs.dp.monotone=false;
  }
  function expectedCounters(count) {
    const hard=fixture.spec.difficulty==='hard';
    const full=hard && fixture.spec.engine==='ready' && fixture.spec.roll>=0.7;
    return {whole:full?count:0,fallback:0,hardLegacy:hard&&!full?count:0,
      hardFull:full?count:0};
  }
  function expectedDraws() {
    if(fixture.spec.difficulty==='normal') return 3;
    return fixture.spec.engine==='ready' && fixture.spec.roll>=0.7 ? 2 : 4;
  }
  function assertStable() {
    if(bench.dp!==refs.dp || cpuWholeDp!==(fixture.spec.engine==='ready'?refs.dp:null) ||
       refs.dp.pay!==refs.pay || refs.dp.probP!==refs.p || refs.dp.probQ!==refs.q ||
       refs.dp.order!==refs.order || refs.dp.layers!==refs.layers ||
       refs.dp.layers.some((layer,i)=>layer.values!==refs.values[i]) ||
       state.p1Marks!==refs.p1Marks || state.p2Marks!==refs.p2Marks ||
       state.p1NumberLayout!==refs.p1Layout || state.p2NumberLayout!==refs.p2Layout ||
       bench.available!==refs.available || !exact(refs.available,refs.availableValues) ||
       !exact(publicState(),stable))
      throw new Error('Input, public state, receiver, scratch or table reference changed');
    if(!exact(memory(),{breakCell:0,breakStreak:2,breakCooldown:0,
       blockCell:0,blockStreak:2,blockCooldown:0})) throw new Error('History changed');
    if(cpuWholeStatus!==fixture.spec.engine) throw new Error('Engine status changed');
  }
  function verify(answer,count) {
    if(answer.lastCell!==expectedCell || answer.checksum!==count*(expectedCell+1))
      throw new Error('Fixed selector checksum/last cell changed');
    if(!exact(counters(),expectedCounters(count))) throw new Error('Unexpected dispatch counts');
    assertStable();
  }
  function auditVariant(name) {
    install(name);reset();
    const draws=[],calls=[];
    Math.random=()=>{draws.push(fixedRoll);return fixedRoll;};
    try {
      for(let call=0;call<16;call++) {
        const before=draws.length;
        const answer=bench.loop(1);
        if(answer.lastCell!==expectedCell || answer.checksum!==expectedCell+1 ||
           draws.length-before!==expectedDraws()) throw new Error('Individual cell/RNG audit failed');
        if(!exact(counters(),expectedCounters(call+1))) throw new Error('Individual dispatch audit failed');
        assertStable();
        calls.push({...answer,rngCalls:draws.length-before,
          counters:counters(),memory:memory()});
      }
    } finally {Math.random=fixedRandom;}
    const drawAudit={draws,calls,publicState:publicState()};
    reset();
    let weightCalls=0;
    const weights=[];
    getCellWeights=(marks,layout)=>{
      weightCalls++;
      const result=nativeGetCellWeights(marks,layout);
      weights.push(result.slice());
      return result;
    };
    let answer;
    try {answer=bench.loop(1);verify(answer,1);}
    finally {getCellWeights=nativeGetCellWeights;}
    const full=fixture.spec.engine==='ready' && fixture.spec.difficulty==='hard' &&
      fixture.spec.roll>=0.7;
    const expected=full?0:fixture.role==='break'?(name==='baseline'?2:1):1;
    if(weightCalls!==expected) throw new Error('Wrong getCellWeights calls: '+name+' '+weightCalls);
    if(weights.length>1 && !weights.every(values=>exact(values,weights[0])))
      throw new Error('Repeated raw weights differ');
    return {name,drawAudit,weightCalls,weights,answer};
  }
  window.__stage9BreakCandidate={
    async prepare(firstPlayer) {
      install('baseline');
      return await bench.prepare(firstPlayer);
    },
    configure(nextFixture) {
      fixture=nextFixture;fixedRoll=fixture.spec.roll;
      install('baseline');
      const decision=bench.configure(fixture.spec);
      if(decision.skip) throw new Error('Selected diagnostic case is terminal');
      refs={dp:bench.dp,pay:bench.dp.pay,p:bench.dp.probP,q:bench.dp.probQ,
        order:bench.dp.order,layers:bench.dp.layers,values:bench.dp.layers.map(layer=>layer.values),
        p1Marks:state.p1Marks,p2Marks:state.p2Marks,
        p1Layout:state.p1NumberLayout,p2Layout:state.p2NumberLayout,
        available:bench.available,availableValues:bench.available.slice()};
      stable=publicState();reset();
      const probe=bench.probe();expectedCell=probe.lastCell;
      verify(probe,1);
      const baseline=auditVariant('baseline'),candidate=auditVariant('candidate');
      if(!exact(baseline.drawAudit,candidate.drawAudit) || !exact(baseline.answer,candidate.answer) ||
         !exact(baseline.weights[0],candidate.weights[0]))
        throw new Error('Baseline/candidate untimed contract mismatch');
      reset();
      return {decision,expectedCell,audits:{baseline,candidate},
        inputArraysReadOnly:true,dpReceiverAndTableReferencesStable:true};
    },
    warm({name,count}) {
      install(name);reset();
      const answer=bench.loop(count);verify(answer,count);
      return {...answer,counters:counters(),memory:memory()};
    },
    comparison({aName,bName,pairs,count,batchWarmup,run,sameReference}) {
      const same=functionNames.every(name=>variants[aName][name]===variants[bName][name]);
      if(same!==sameReference) throw new Error('Wrong same-reference comparison condition');
      const rows=[];
      for(let pair=0;pair<pairs;pair++) {
        const order=(pair+run)%2?['b','a']:['a','b'];
        const sampled={};
        for(const key of order) {
          const name=key==='a'?aName:bName;
          install(name);reset();
          const warm=bench.loop(batchWarmup);verify(warm,batchWarmup);
          reset();
          if(Math.random!==fixedRandom || getCellWeights!==nativeGetCellWeights)
            throw new Error('Untimed instrumentation remained installed');
          const startMs=performance.now();
          const answer=bench.loop(count);
          const endMs=performance.now();
          const startNs=Math.round(startMs*1e6),endNs=Math.round(endMs*1e6);
          if(!Number.isSafeInteger(startNs)||!Number.isSafeInteger(endNs)||endMs<startMs)
            throw new Error('Invalid exposed-clock endpoint');
          const elapsedMs=endMs-startMs;
          verify(answer,count);
          sampled[key]={name,count,startMs,endMs,startNs,endNs,elapsedMs,
            endpointElapsedNs:endNs-startNs,usPerCall:elapsedMs*1000/count,
            endpointUsPerCall:(endNs-startNs)/1000/count,
            ...answer,status:cpuWholeStatus,counters:counters(),memory:memory()};
        }
        if(!exact(sampled.a.checksum,sampled.b.checksum)||
           !exact(sampled.a.counters,sampled.b.counters)||
           !exact(sampled.a.memory,sampled.b.memory)) throw new Error('Pair contract mismatch');
        rows.push({pair:pair+1,order,a:sampled.a,b:sampled.b});
      }
      return {sameFunctionReferences:same,pairs:rows};
    },
    release() {releaseWholeGameCpu();bench.dp=null;refs=null;},
    cleanup() {
      getCpuSelectionWeights=native.getCpuSelectionWeights;
      prepareCpuBreakCandidates=native.prepareCpuBreakCandidates;
      selectCpuLegacyCell=native.selectCpuLegacyCell;
      selectCpuBreakCell=native.selectCpuBreakCell;
      getCellWeights=nativeGetCellWeights;
      bench.cleanup();
    }
  };
  const clockIncrements=[];
  let previous=performance.now(),clockReads=1;
  for(;clockReads<10000 && clockIncrements.length<16;clockReads++) {
    const now=performance.now();
    if(now>previous) clockIncrements.push(now-previous);
    previous=now;
  }
  return {functionNames,variants:Object.keys(variants),compilationOrder,visibility:document.visibilityState,
    crossOriginIsolated,timeOrigin:performance.timeOrigin,
    clockObservation:{reads:clockReads,positiveIncrementsMs:clockIncrements,
      interpretation:'Observed exposed-clock increments in a finite untimed loop; not proof of timer accuracy/resolution'},
    compilation:'Both four-function bundles compiled with new Function inside this loaded realm',
    scalarLoop:'Unchanged shared bench.loop actual BREAK/BLOCK selector plus integer checksum',
    reset:'Counters/history and DP scratch reset before each warmup and measured batch; input refs unchanged'};
}'''


def summarize(pairs):
    raw = [(pair['b']['elapsedMs'] - pair['a']['elapsedMs']) * 1000 / pair['a']['count']
           for pair in pairs]
    endpoint_ns = [pair['b']['endpointElapsedNs'] - pair['a']['endpointElapsedNs']
                   for pair in pairs]
    return {'aMedianUs': statistics.median(pair['a']['usPerCall'] for pair in pairs),
        'bMedianUs': statistics.median(pair['b']['usPerCall'] for pair in pairs),
        'rawClockPairedDeltasUs': raw,
        'rawClockPairedMedianDeltaUs': statistics.median(raw),
        'rawClockPairedRangeDeltaUs': [min(raw), max(raw)],
        'rawClockPositivePairs': sum(value > 0 for value in raw),
        'rawClockNegativePairs': sum(value < 0 for value in raw),
        'rawClockZeroPairs': sum(value == 0 for value in raw),
        'integerEndpointPairedDurationDeltasNs': endpoint_ns,
        'integerEndpointPairedMedianDurationDeltaNs': statistics.median(endpoint_ns),
        'integerEndpointPositivePairs': sum(value > 0 for value in endpoint_ns),
        'integerEndpointNegativePairs': sum(value < 0 for value in endpoint_ns),
        'integerEndpointZeroPairs': sum(value == 0 for value in endpoint_ns)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, default=ROOT / 'index.html')
    parser.add_argument('--candidate', type=Path, default=ROOT / 'stages' / 'index.stage9.candidate.html')
    parser.add_argument('--output', type=Path, default=ROOT / 'validation' / 'stage9' / 'break-candidate.json')
    parser.add_argument('--runs', type=int, default=2)
    parser.add_argument('--pairs', type=int, default=9)
    parser.add_argument('--calls', type=int, default=20000)
    parser.add_argument('--warmup', type=int, default=20000)
    parser.add_argument('--batch-warmup', type=int, default=2000)
    parser.add_argument('--cases', help='Comma-separated explicit case IDs; default all ten')
    parser.add_argument('--no-aa', action='store_true', help='Omit the three declared same-reference controls')
    args = parser.parse_args()
    if min(args.runs,args.pairs,args.calls,args.warmup,args.batch_warmup) <= 0:
        parser.error('All measurement counts must be positive')
    paths = {'baseline': args.baseline.resolve(), 'candidate': args.candidate.resolve()}
    texts = {key:path.read_text() for key,path in paths.items()}
    extracted = {key:function_sources(text) for key,text in texts.items()}
    if extracted['baseline'][1] != extracted['candidate'][1]:
        parser.error('Sources differ outside the four permitted function declarations')
    if any(extracted['baseline'][0][name] == extracted['candidate'][0][name] for name in FUNCTION_NAMES):
        parser.error('Expected all four candidate function declarations to differ')
    paths['baseline'].relative_to(ROOT)
    selected = cases()
    if args.cases:
        requested = args.cases.split(',')
        known = {case['id'] for case in selected}
        if len(requested) != len(set(requested)) or set(requested)-known:
            parser.error('Unknown/duplicate case IDs; choose from '+', '.join(sorted(known)))
        selected = [case for case in selected if case['id'] in requested]
    aa_ids = set() if args.no_aa else AA_CASES & {case['id'] for case in selected}
    comparisons_per_run = len(selected)+len(aa_ids)
    timed_choices = args.runs*comparisons_per_run*args.pairs*2*args.calls
    result = {'sources': {key:{'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                    'bytes':path.stat().st_size} for key,path in paths.items()},
        'sourceIntegrity': {'onlyFourFunctionsDiffer':True,
            'functions': {name:{key:hashlib.sha256(extracted[key][0][name].encode()).hexdigest()
                               for key in paths} for name in FUNCTION_NAMES}},
        'conditions': {'productionModified':False,'loadedHtml':'baseline only; candidate declarations compiled locally',
            'executable':'/usr/bin/chromium','pageModel':'one visible foreground 1280x900 realm per fresh browser',
            'transport':'ordinary HTTP without COOP/COEP or fine-clock enhancement',
            'worker':'real production Blob Worker, once for each required first player per run',
            'runs':args.runs,'pairedBatchesPerComparison':args.pairs,'callsPerBatch':args.calls,
            'initialWarmupPerVariant':args.warmup,'batchWarmupPerArm':args.batch_warmup,
            'cases':selected,'sameReferenceControlCases':sorted(aa_ids),
            'timedChoicesPlanned':timed_choices,
            'warmupChoicesPlanned':args.runs*(len(selected)*2*args.warmup+
                comparisons_per_run*args.pairs*2*args.batch_warmup),
            'expectedAutomaticSelfTests':322,
            'run2Reverses':['bundle compilation order','first-player groups','case order','initial variant warmup order',
                            'comparison order','first paired arm order'],
            'timing':'Raw performance.now endpoints/duration plus separately rounded integer endpoints',
            'integerEndpointRepresentation':'Math.round(exposed performance.now milliseconds * 1e6); 1 ns representation of an exposed timestamp, not nanosecond accuracy or resolution',
            'timeOrigin':'Recorded per loaded realm; start/end milliseconds are absolute within its performance time origin',
            'state':'Fixed public inputs and same arrays/DP receiver; counters/history/scratch reset outside each arm',
            'rng':'One fixed Math.random function object for all timed arms; per-call draw/value trace audited untimed',
            'verification':'16 individual calls per variant per fixture plus separate untimed getCellWeights instrumentation',
            'inference':'Descriptive raw and integer-endpoint differences only; no performance PASS, tolerance, interval subtraction, or revised historical result',
            'limitations':['Hot selector fixture; not native RNG/cold latency/match progression/trusted clicks',
                'Compiled own bundle identities and repeated swaps can alter JIT history',
                'Within-process batches are not independent browser replicates',
                'Readonly marks/layout/available contents and DP/table references checked; value-table contents are not scanned each batch',
                'No trace or forced GC; allocation/GC cadence remains part of this diagnostic']},
        'runs':[],'combined':[],'completed':False,'functionalEquivalence':False}

    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*unused):
            pass

    server = http.server.ThreadingHTTPServer(('127.0.0.1',0),
        functools.partial(Handler,directory=str(ROOT)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    failed = False
    try:
        # Keep the shared benchmark installation, adding a finite readiness deadline.
        poll_anchor = '        const poll = () => {\n'
        assert shared.INSTALL_BENCH.count(poll_anchor) == 1
        frame_install = shared.INSTALL_BENCH.replace(poll_anchor,
            '        const deadline=performance.now()+45000;\n'+poll_anchor+
            "          if(performance.now()>deadline) return reject(new Error('Worker ready timeout'));\n",1)
        with sync_playwright() as playwright:
            for run in range(args.runs):
                browser = playwright.chromium.launch(executable_path='/usr/bin/chromium',
                    headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
                record = {'run':run+1,'browserVersion':browser.version,'pageErrors':[],
                          'preparations':[],'rows':[]}
                result['runs'].append(record)
                try:
                    page = browser.new_page(viewport={'width':1280,'height':900})
                    page.on('pageerror',lambda error,rec=record:rec['pageErrors'].append(str(error)))
                    url=f'http://127.0.0.1:{server.server_port}/{paths["baseline"].relative_to(ROOT).as_posix()}'
                    page.goto(url,wait_until='load');page.bring_to_front()
                    tests=json.loads(page.locator('#rule-test-results').text_content())
                    record['selfTests']=tests
                    if tests['total']!=322 or tests['passed']!=tests['total'] or tests.get('failures'):
                        raise RuntimeError('Automatic baseline self-tests failed')
                    record['frameSetup']=page.evaluate(frame_install,shared.LAYOUTS)
                    record['setup']=page.evaluate(INSTALL,{
                        'baselineSources':extracted['baseline'][0],
                        'candidateSources':extracted['candidate'][0],'functionNames':FUNCTION_NAMES,
                        'compilationOrder':['baseline','candidate'] if run%2==0 else ['candidate','baseline']})
                    if record['setup']['visibility']!='visible' or record['setup']['crossOriginIsolated']:
                        raise RuntimeError('Unexpected visibility or cross-origin clock isolation')
                    first_players=sorted({case['firstPlayer'] for case in selected},reverse=bool(run%2))
                    record['firstPlayerOrder']=first_players
                    for first_player in first_players:
                        preparation=page.evaluate('first=>__stage9BreakCandidate.prepare(first)',first_player)
                        record['preparations'].append({'firstPlayer':first_player,**preparation})
                        first_cases=[case for case in selected if case['firstPlayer']==first_player]
                        if run%2:first_cases.reverse()
                        for case in first_cases:
                            configured=page.evaluate('fixture=>__stage9BreakCandidate.configure(fixture)',case)
                            warm_order=['baseline','candidate'] if run%2==0 else ['candidate','baseline']
                            for name in warm_order:
                                page.evaluate('config=>__stage9BreakCandidate.warm(config)',
                                              {'name':name,'count':args.warmup})
                            comparisons=[('baseline_to_candidate','baseline','candidate',False)]
                            if case['id'] in aa_ids:
                                comparisons.append(('baseline_same_reference_AA','baseline','baseline',True))
                            if run%2:comparisons.reverse()
                            for comparison,a_name,b_name,same in comparisons:
                                sampled=page.evaluate('config=>__stage9BreakCandidate.comparison(config)',{
                                    'aName':a_name,'bName':b_name,'sameReference':same,'run':run,
                                    'pairs':args.pairs,'count':args.calls,'batchWarmup':args.batch_warmup})
                                row={'case':case,'comparison':comparison,'aName':a_name,'bName':b_name,
                                     'configured':configured,'initialWarmOrder':warm_order,
                                     **sampled,'summary':summarize(sampled['pairs'])}
                                record['rows'].append(row)
                                print(f'run {run+1} {case["id"]} {comparison}: '
                                      f'{row["summary"]["aMedianUs"]:.6f} -> '
                                      f'{row["summary"]["bMedianUs"]:.6f} us; raw paired '
                                      f'{row["summary"]["rawClockPairedMedianDeltaUs"]:+.6f} us',flush=True)
                        page.evaluate('__stage9BreakCandidate.release()')
                    page.evaluate('__stage9BreakCandidate.cleanup()')
                    if record['pageErrors']:raise RuntimeError(f'Browser errors: {record["pageErrors"]}')
                finally:
                    browser.close()
        for case in selected:
            names=['baseline_to_candidate']
            if case['id'] in aa_ids:names.append('baseline_same_reference_AA')
            for name in names:
                matching=[(run['run'],row) for run in result['runs'] for row in run['rows']
                          if row['case']['id']==case['id'] and row['comparison']==name]
                pairs=[pair for _,row in matching for pair in row['pairs']]
                result['combined'].append({'caseId':case['id'],'comparison':name,
                    'runSummaries':[{'run':run,**row['summary']} for run,row in matching],
                    'pooledConditionalDescriptiveSummary':summarize(pairs)})
        result['timedChoicesCompleted']=sum(len(row['pairs'])*2*args.calls
            for run in result['runs'] for row in run['rows'])
        if result['timedChoicesCompleted']!=timed_choices:
            raise RuntimeError('Finite workload count differs from declaration')
        result['completed']=True;result['functionalEquivalence']=True
    except Exception as error:
        failed=True;result['failure']=f'{type(error).__name__}: {error}'
        print(result['failure'],flush=True)
    finally:
        server.shutdown();server.server_close()
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(f'Results saved to {args.output}',flush=True)
    return 1 if failed else 0


if __name__=='__main__':
    raise SystemExit(main())
