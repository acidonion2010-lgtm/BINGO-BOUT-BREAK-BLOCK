#!/usr/bin/env python3
"""Save official SQL for stage17 same-proto comparisons; no browser work."""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
TOOL = ROOT.parent / 'bingo-stage16-20261015' / 'trace_processor_shell'
TOOL_SHA = '58042408e6cc861fb1a731c26bb082dc222285561eaa4e12a48a8b2b90dca7b9'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    report_path = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'report.json'
    assert len(sys.argv) <= 2, 'usage: extract_sql.py [report.json]'
    assert sha(TOOL) == TOOL_SHA
    report = json.loads(report_path.read_bytes())
    dest = ROOT / 'official-sql'
    dest.mkdir(exist_ok=False)
    summary = {'scriptSha256': sha(Path(__file__)), 'reportSha256': sha(report_path),
               'toolPath': str(TOOL), 'toolSha256': TOOL_SHA, 'visits': []}
    for visit in report['visits']:
        run = visit['run']
        if not visit.get('completed'):
            summary['visits'].append({'run': run, 'unit': visit['unit'], 'status': 'incomplete_visit_no_sql'})
            continue
        pid, tid = visit['conversion']['rendererPidTid']
        assert isinstance(pid, int) and isinstance(tid, int)
        trace = ROOT / f'run{run}.pftrace'
        queries = {
            'slices': f'SELECT s.id,s.ts,s.dur,s.thread_ts,s.thread_dur,s.name,s.depth,s.parent_id FROM slice s JOIN thread_track tt ON s.track_id=tt.id JOIN thread t ON tt.utid=t.utid JOIN process p ON t.upid=p.upid WHERE p.pid={pid} AND t.tid={tid} ORDER BY s.id',
            'counters': f"SELECT c.id,c.ts,c.value,ct.id AS track_id,ct.name,(SELECT int_value FROM args WHERE arg_set_id=ct.source_arg_set_id AND key='trace_id') AS uuid FROM counter c JOIN thread_counter_track ct ON c.track_id=ct.id JOIN thread t ON ct.utid=t.utid JOIN process p ON t.upid=p.upid WHERE p.pid={pid} AND t.tid={tid} ORDER BY c.id",
            'stats': 'SELECT name,idx,severity,source,value FROM stats WHERE value != 0 ORDER BY name,idx',
        }
        record = {'run': run, 'unit': visit['unit'], 'preflight': visit['preflight'], 'protoSha256': sha(trace), 'outputs': {}}
        summary['visits'].append(record)
        for name, query in queries.items():
            prefix = dest / f'run{run}-{name}'
            prefix.with_suffix('.sql').write_text(query + ';\n')
            completed = subprocess.run([str(TOOL), 'query', str(trace), query], capture_output=True, text=True, timeout=180)
            prefix.with_suffix('.csv').write_text(completed.stdout)
            prefix.with_suffix('.stderr').write_text(completed.stderr)
            record['outputs'][name] = {'returncode': completed.returncode, 'sha256': sha(prefix.with_suffix('.csv')),
                                       'rows': len(list(csv.DictReader(completed.stdout.splitlines())))}
            if completed.returncode != 0:
                record['status'] = 'query_failed'
                with (ROOT / 'official-sql-summary.partial.json').open('x') as file:
                    json.dump(summary, file, indent=2)
                raise RuntimeError((run, name, completed.returncode))
        record['status'] = 'completed'
        print(json.dumps({'run': run, 'unit': visit['unit'], 'rows': {k: v['rows'] for k, v in record['outputs'].items()}}), flush=True)
    with (ROOT / 'official-sql-summary.json').open('x') as file:
        json.dump(summary, file, indent=2)
        file.write('\n')


if __name__ == '__main__':
    main()
