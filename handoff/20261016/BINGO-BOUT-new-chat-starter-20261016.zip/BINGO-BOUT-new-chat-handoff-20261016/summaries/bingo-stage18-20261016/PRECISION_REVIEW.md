# 保存SQLとJSONの分母・精度差の検算

段階17の実効1ns・正式run3/4/7/8だけを読み直した。**SQLのstrict 27,879件とJSONのstrict 3,140件の差24,739件は、同じ正duration・CPU付き81,065件のdurationをnsから整数µsへ変換すると0になる記録で全て説明できた。** SQLの分母にだけ含まれるCPU付きinstant 2,752件はstrict 0件なので、今回のstrict件数差への寄与は0だった。新しい計測、browser、DP処理、アプリ変更はない。

## 同じ対象の照合

保存公式SQLの`name, ts//1000, dur//1000, thread_ts//1000, thread_dur//1000`と、同一proto由来JSONの`name, ts, dur, tts, tdur`を多重集合として照合した。全4runで、正duration・CPU付きSQLとrenderer mainのCPU付きJSON Xが、要素と出現数の両方で完全一致した。値の一致から個々の重複要素のIDを一意に決めてはいない。

| 対象 | run3 | run4 | run7 | run8 | 合計 |
| --- | ---: | ---: | ---: | ---: | ---: |
| CPU付き完了SQL | 21,384 | 21,103 | 20,268 | 21,062 | 83,817 |
| うちdur=0のinstant | 603 | 646 | 727 | 776 | 2,752 |
| うちdur>0＝CPU付きJSON X | 20,781 | 20,457 | 19,541 | 20,286 | 81,065 |
| SQL strict（ns） | 8,309 | 6,937 | 6,165 | 6,468 | 27,879 |
| JSON strict（µs） | 863 | 719 | 748 | 810 | 3,140 |
| 正→0となる記録 | 7,446 | 6,218 | 5,417 | 5,658 | 24,739 |
| 複数SQL候補を持つJSON | 2 | 2 | 2 | 28 | 34 |

CPU欠測SQL 1,617件（dur>0が1,200、instantが417）は、両方ともCPU付き比較の外に置いた。SQL未完sliceは0。今回のJSON main Xは全81,065件がCPU付きで、CPU付きinstantとJSON Xのtuple衝突も0だった。これらの分母の違いを、記録欠落やCPU値の正確さの証明へ置き換えない。

## durationの整数µs化で何が変わるか

各記録で`ns差 = thread_dur − dur`、`µs差 = floor(thread_dur/1000) − floor(dur/1000)`を別々に求めた。対象値が全て非負であることも確認したため、C++整数除算はこのfloorと同じになる。

| 元ns差の符号 | µs差が負 | µs差が0 | µs差が正 |
| --- | ---: | ---: | ---: |
| 負 | 4,481 | 44,589 | 0 |
| 0 | 0 | 4,116 | 0 |
| 正 | 0 | 24,739 | 3,140 |

単調な除算なので、符号の逆転や元の非正値から新たな正値の出現は0である。整数µsにする前後の差は各durationの余りの差（−999〜999ns）に等しい。正のns差がJSONで0になっても、そのns差を許容・補正したわけではない。JSON値を1,000倍しても捨てたnsは回復しない。

## 固定exporter原文

producerがpinするPerfetto `5dbeaad4ceb91470a835426b52e0cb43a3e5ef10`の保存原文に加え、実行済み公式binary v58.2のversion commit `add693d8b338ba9599dbcbc3e300b1ab8c000897`から[export_json.cc](precision-sources/binary-revision-export_json.cc)を公式raw URL・既定TLSで取得した。両原文は66,822 bytes・SHA256 `dc3a3b53cc2df3cd66be8b331b805d31331c2a8dbcf42e3f58d6fe8a05377667`で全文同一。取得履歴・SHA・LICENSEは[manifest](precision-sources/MANIFEST.json)に保存した。最初のGitHub API照会403も履歴に残し、既知の固定commitを使ったraw URL取得で補完した。ソース同一性を任意のbuild全体の同一性とは主張しない。

原文800行は`ts = it.ts()/1000`、886〜900行はwall duration 0をinstantとして出力する。902〜914行は正wall durationをXとして、`dur = duration_ns/1000`、`tts = thread_ts_ns/1000`、`tdur = thread_duration_ns/1000`をそれぞれ整数化する。durationは「整数化した終点−整数化した始点」から算出していない。thread/rootとchild/asyncの分岐も別にある（880行以降・926行以降）。今回のSQL/JSONの対象同一性はソースの推測だけに頼らず、前述の多重集合で検算した。

`floor((start+duration)/1000)`と`floor(start/1000)+floor(duration/1000)`には0または1µsの差が出る。正duration・CPU付き81,065件ではwall側38,776件、CPU側37,778件で1µsの差が出る（両方19,366件、wallだけ19,410件、CPUだけ18,412件、両方0が23,877件）。したがってJSONの`ts+dur`や`tts+tdur`を、元ns終点を直接整数化した値と無条件に等置できない。このendpoint表現差は上のXの`tdur > dur`判定へ混ぜていない。

## 34件の複数候補を維持

17個のtupleにはJSONが各2件、SQL候補も各2件あり、合計34 JSON・34候補行。JSONはいずれも`dur=tdur=0`µsで差の符号は0である。全候補を[precision-census.json](precision-census.json)に保存し、各JSONの候補リストにも展開した。候補に勝手な対応順を付けず、符号が一致する候補を選ばない。

以下はtupleごとのSQL候補IDと元ns差（`thread_dur−dur`）。`=0`だけがJSONの差0と符号一致し、正・負は不一致である。JSON一件ごとの全候補を調べると68候補出現のうち一致12、不一致56。重複を除いた34 SQL候補行では一致6、不一致28だった。いずれの候補も整数µs化後の差0とは一致する。

| run | tuple ts（µs） | SQL候補IDとns差 |
| --- | ---: | --- |
| 3 | 44512610302 | 49412: 0、49414: −20 |
| 4 | 44520473767 | 251: +9、252: 0 |
| 7 | 44548521124 | 5295: 0、5296: +9 |
| 8 | 44558019320 | 5614: +10、5615: +31 |
| 8 | 44558019361 | 5635: +21、5636: +10 |
| 8 | 44558019366 | 5641: 0、5642: +11 |
| 8 | 44558019379 | 5646: 0、5647: +19 |
| 8 | 44558019383 | 5651: −1、5652: +11 |
| 8 | 44558019398 | 5659: +10、5660: +40 |
| 8 | 44558019401 | 5663: +10、5664: +9 |
| 8 | 44558019447 | 5691: +10、5692: +9 |
| 8 | 44558019476 | 5708: +20、5709: +31 |
| 8 | 44558019668 | 5731: +20、5732: +10 |
| 8 | 44558019691 | 5742: +20、5743: +10 |
| 8 | 44558019694 | 5746: +9、5747: +10 |
| 8 | 44558228661 | 15330: +19、15331: 0 |
| 8 | 44558228973 | 15343: −9、15344: −11 |

tuple名・duration・CPU端点・depth/parent_idを含む候補全文と、候補ごとのns符号一致/不一致はJSONに残る。全体の件数分解はtuple多重集合から一意に確定する一方、34 JSONの個別ID対応は未確定のままである。

## 再実行と限界

`precision_census.py`は入力report/各SQL/各JSON/queryのSHAを保存し、既存の出力を上書きしない。保存結果との一致確認は次の読み取り専用再計算で行う。

```sh
python3 /workspace/bingo-stage18-20261016/precision_census.py --verify-output /workspace/bingo-stage18-20261016/precision-census.json
```

入れ子sliceは独立事象ではない。この調査は保存SQLとJSONの分母・数値表現の違いを分類したもので、残る正ns差を物理的に妥当と認めたり、wall/CPU時計変換・読取端点の同時性・kernel CPU会計を検証済みとしたりしない。段階17原本は変更していない。
