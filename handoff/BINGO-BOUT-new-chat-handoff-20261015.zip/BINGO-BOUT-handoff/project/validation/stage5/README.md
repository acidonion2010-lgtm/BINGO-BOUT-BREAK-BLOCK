# Stage 5 validation

Production uses only `index.html`. These are development tools using existing
Node, Python Playwright and Chromium. Run browser jobs sequentially, and do not
run the constructor check while timing another job. Commands run from the
unpacked `bingo-refactor` directory.

```bash
node validation/stage5/layer_indices.cjs
python3 validation/capture.py index.html validation/stage5/after --repeats 1 --port 8004
python3 validation/compare.py validation/before validation/stage5/after --output validation/stage5/comparison.json
python3 validation/worker_lifecycle.py index.html --out validation/stage5/worker.json
python3 validation/performance.py index.before.html index.html validation/stage5/startup-performance.json --port 8004
python3 validation/gameplay_smoke.py --file index.html --out validation/stage5/gameplay-smoke.json
python3 validation/stage5/raf_phase_response.py index.before.html index.html validation/stage5/raf-phase-response.json --runs 5 --trials 9
python3 validation/stage5/analyse_raf.py validation/stage5/raf-phase-response.json validation/stage5/raf-phase-decomposition.json
```

Regenerate original DP binaries before compare when unpacking the ZIP:

```bash
python3 validation/capture.py index.before.html validation/before --repeats 1 --port 8004
```

`layer-indices.json` checks all 512 masks for all 19 layers of the actual
constructors across both first players, early termination settings, layouts and
allocation modes. It checks unreachable sentinel 65535, ascending mask order,
shared identity only within the same DP and upper bound, separate DP buffers,
receiver null values, and unchanged independent value-array dimensions/bytes.
No solve is performed by that check. `comparison.json` and the hash file cover
full DP values, policies, fixed-random choices, histories and normal self tests.

`startup-performance-initial.json` is retained exploratory evidence: an independent
498 ms constructor check overlapped that timing run. The fresh sequential result
in `startup-performance.json` is the formal before/current comparison; no sample
was silently removed. Startup includes existing automatic self tests.

`stage4-raf-decomposition.json` derives handler, first-RAF wait and between-RAF
intervals from preserved stage4 data. The new phase probe records the last RAF
callback/time stamp before a trusted click plus first/second callbacks. A/A
(original/original) and A/B (original/current) remain separate. It keeps the old
3RAF fixture, real sound/BGM/animations and reversed visit order. Animation and
hover descriptors are observed outside the click timer. The additional monitoring
RAF and scalar event observation are development instrumentation and can change
timing; they do not modify game source or establish physical presentation latency.
All samples, warmups and visit summaries are retained. A/A is never subtracted to
turn an A/B increase into a performance PASS.

See `段階5比較結果.md` and `summary.json` for implementation, measurements,
interpretable timing differences and unfinished checks. All-path/all-device
strict non-regression is not established by these finite measurements.
