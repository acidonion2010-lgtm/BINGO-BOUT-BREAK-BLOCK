﻿[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
$folder = Join-Path $env:USERPROFILE 'Downloads\BINGO-BOUT-completed'
$url = 'https://raw.githubusercontent.com/acidonion2010-lgtm/BINGO-BOUT-BREAK-BLOCK/f36f9188d26c104d48e11b26d57dd5f4737216a8/index.html'
$expected = 'fea09e995bfc1036515b92771925bd7968f3c453425ea5517b7a5b480293be64'
New-Item -ItemType Directory -Path $folder -Force -ErrorAction Stop | Out-Null
$out = Join-Path $folder 'index.html'
$tmp = Join-Path $folder ([guid]::NewGuid().ToString('N') + '.tmp')
try {
    Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing -ErrorAction Stop
    if ((Get-FileHash -LiteralPath $tmp -Algorithm SHA256).Hash -ne $expected) {
        throw 'ファイルの確認に失敗しました。'
    }
    Move-Item -LiteralPath $tmp -Destination $out -Force -ErrorAction Stop
    Write-Host "保存しました: $out"
} finally {
    Remove-Item -LiteralPath $tmp -ErrorAction SilentlyContinue
}
