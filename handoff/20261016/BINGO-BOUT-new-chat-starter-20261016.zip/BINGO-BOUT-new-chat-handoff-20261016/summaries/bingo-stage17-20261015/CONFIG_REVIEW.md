# 段階17: CDP Perfetto 設定の固定ソース確認

対象は Chromium `73c14f6228d7cd537c855007e8f88678969cc0eb`、同 Chromium が固定する Perfetto `5dbeaad4ceb91470a835426b52e0cb43a3e5ef10`。調査中に browser、DP、測定処理は実行していない。ゲームと段階15/16のファイルは変更していない。

## 結論

`Tracing.start` の `perfettoConfig` へ、serialized `perfetto.protos.TraceConfig` を Base64 文字列として渡す。両条件を同一設定から作り、`TrackEventConfig.timestamp_unit_multiplier` だけを明示的に `1000` / `1` にする方法は固定ソースに沿う。`enable_thread_time_sampling=true`、`thread_time_subsampling_ns=0`、incremental timestamps 有効、`clear_period_ms=500` を両条件で揃える。

**CDP の raw `perfettoConfig` 分岐は Linux で `AdaptPerfettoConfigForChrome()` を呼ばない。** したがって、同関数の「欠落時に CPU sampling=true / multiplier=1000 / clear=500 を補完する」実装はこの呼び出し経路の保証として使えない。buffers、builtin clock、incremental clear、categories、CPU sampling は raw 設定に明示する。

`timestamp_unit_multiplier` は CPU と wall の両 timestamp 単位を変える。CPU 記録だけの設定変更ではない。1 ns 条件は記録精度と trace のサイズ・負荷も変えるので、この診断の wall latency 差をゲームの速度差として扱わない。

## 呼び出し経路と上書き条件

1. `Tracing.pdl:127–130` は `perfettoConfig` を Base64-encoded serialized TraceConfig と定義し、指定時に `categories` / `options` / `traceConfig` が無視されると明記する。
2. `tracing_handler.cc:738–764` は raw config を parse し、data source がない場合は失敗する。raw config では proto が既定となるが、いずれかの `ChromeConfig.convert_to_legacy_json=true` があると proto ではなくなる。`transferMode=ReturnAsStream`、`streamFormat=proto`、`streamCompression=none` を明示し、全 ChromeConfig の convert フラグを false にする。
3. `ConvertToTrackEventConfigIfNeeded()` (`tracing_handler.cc:283–301`) は、data source のいずれかに **非空 `track_event_config`** があれば直ちに return する。したがって `name=track_event` と非空 TrackEventConfig を持つ今回の設定は、旧 `org.chromium.trace_event` / ChromeConfig からの変換を受けない。
4. 同 handler の `:765–772` は Windows 固有の ETW 処理だけを呼び、`AdaptPerfettoConfigForChrome()` の将来的な使用を TODO にしている。通常の `categories` / `options` 分岐の `GetDefaultPerfettoConfig()` も raw 分岐では通らない。
5. `PerfettoTracingSession::EnableTracing()` (`tracing_handler.cc:320–359`) は受け取った config を `NewTrace(backend)->Setup(config)` / `Start()` に渡す。`tracingBackend=chrome` を明示すれば Chrome 内蔵 custom backend を選ぶ (`:260–280`)。

## 必要な field 番号

すべて proto2。uint/bool は wire type 0、string/message は wire type 2。

| message.field | field number | 今回の値 |
|---|---:|---|
| TraceConfig.buffers | 1 | 下記の2 buffers |
| TraceConfig.data_sources | 2 | 下記の2 sources |
| TraceConfig.builtin_data_sources | 20 | primary clock を指定 |
| TraceConfig.incremental_state_config | 21 | clear period を指定 |
| BufferConfig.size_kb | 1 | 204800 / 256 |
| BufferConfig.fill_policy | 4 | DISCARD=2 |
| DataSource.config | 1 | DataSourceConfig |
| DataSourceConfig.name | 1 | track_event / org.chromium.trace_metadata2 |
| DataSourceConfig.target_buffer | 2 | 0 / 1 |
| DataSourceConfig.chrome_config | 101 | 同じ false フラグ |
| DataSourceConfig.track_event_config | 113 | track_event source だけ |
| BuiltinDataSource.primary_trace_clock | 5 | BUILTIN_CLOCK_MONOTONIC=3 |
| IncrementalStateConfig.clear_period_ms | 1 | 500 |
| TrackEventConfig.disabled_categories | 1 | `*` |
| TrackEventConfig.enabled_categories | 2 | 旧8項目と `__metadata` |
| TrackEventConfig.disable_incremental_timestamps | 5 | false |
| TrackEventConfig.timestamp_unit_multiplier | 6 | **1000 / 1** |
| TrackEventConfig.filter_debug_annotations | 7 | false |
| TrackEventConfig.enable_thread_time_sampling | 8 | true |
| TrackEventConfig.filter_dynamic_event_names | 9 | false |
| TrackEventConfig.thread_time_subsampling_ns | 10 | 0 |
| ChromeConfig.privacy_filtering_enabled | 2 | false |
| ChromeConfig.convert_to_legacy_json | 3 | false |
| ChromeConfig.event_package_name_filter_enabled | 6 | false |

`chrome_config.trace_config` (field 1) は省略する。通常の Chromium builder も track_event / trace_metadata2 では空文字を渡しており、空文字の場合はこの field をセットしない (`perfetto_config.cc:41–64, :93–100, :123–129`)。categories の JSON をここへ重ねて追加する必要はない。

## 比較用設定の等価性

通常の `options=record-until-full` の config では、GetDefaultPerfettoConfig が 200 MiB の main buffer (`204800 KiB`) を DISCARD とし、別に metadata buffer `256 KiB` を DISCARD にする (`perfetto_config.cc:266–309`, `perfetto_config.h:24`)。main source は `track_event` / target 0、metadata source は `org.chromium.trace_metadata2` / target 1 (`perfetto_config.cc:93–100, :123–129`)。

通常の TraceConfig からの TrackEventConfig 変換は、明示カテゴリだけを有効にするとき `disabled_categories=*`、included category 各項目、常時 `__metadata`、CPU sampling=true、multiplier=1000 を書く (`trace_config.cc:801–834`)。段階14/16と揃える8項目は次の通り。

```
toplevel
cc
viz
devtools.timeline
blink.user_timing
renderer.scheduler
v8
disabled-by-default-devtools.timeline.frame
```

TrackEventConfig のカテゴリ判定は exact enabled categories が disabled glob より先に評価される (`track_event_config.proto:24–36`)。従って `disabled_categories=*` と上記 enabled リストは矛盾しない。`__metadata` は trace 上の thread/process 記述などの確認にも必要。CPU counter を各 event に出す `enable_thread_time_sampling` と `org.chromium.sampler_profiler` によるスタックサンプリングは別であり、この比較に sampler profiler source を追加する必要はない。

`BuiltinDataSource.primary_trace_clock=3` は Linux Chromium の trace clock と同じ CLOCK_MONOTONIC (`trace_time.h:16–19`, `builtin_clock.proto:44–45`)。builtin clock snapshots/config/system info/service events は止めず、2条件で同一にする。

`clear_period_ms=500` は eligible data source へ incremental state clear を要求する間隔で、event が必ずちょうど500 msごとに reset packet を出すという保証ではない (`trace_config.proto:474–488`)。実 trace の reset packet 数・timestamp を別途読む。

## SDK 側の確認と採否条件

固定 Perfetto の `TrackEventTlsState` は config から sampling / subsampling / multiplier を読み、incremental timestamps 有効なら multiplier によらず incremental clock を使用する (`track_event_internal.h:403–426`)。`ResetIncrementalStateIfRequired()` は CPU counter に `set_is_incremental(true)` と `set_unit_multiplier(multiplier)` を付ける (`track_event_internal.cc:431–446`)。通常イベントの CPU sample は `GetThreadCPUTimeNs()` から得て multiplier で整数除算する (`:598–610`)。multiplier=1 ではこの除算による ns の端数損失はない。

formal capture の前に、1000 / 1 の実 proto で次を確認する必要がある。

- echoed TraceConfig の categories・buffers・clock・clear・CPU sampling が意図通りであり、比較対象間の意味上の差が multiplier のみである。
- 対象 renderer main thread の CPU CounterDescriptor に `is_incremental=true`、それぞれ `unit_multiplier=1000` / `1` が実際にある。config を送信した事実だけで成功としない。
- incremental wall clock の ClockSnapshot / packet defaults の unit も確認する。1 ns / 1000 ns を混同して raw field を比較しない。
- marker を同一 pid/tid に同定し、data loss / full buffer / importer error がない。失敗した記録は保存し、formal件数に代入しない。

## 保存した根拠

`official-sources/config-review/MANIFEST.json` に全21ファイルの固定 commit URL・SHA256・byte 数を保存。合計266,189 bytes。Chromium の BSD-style `LICENSE`、Perfetto の `LICENSE` (Apache-2.0中心の upstream license text) をそれぞれ同梱した。オンラインの最新版ではなく上記固定 revision を使用した。

## 独立設定検算器

`make_configs.py` の field encoder を直接流用せず、独立の wire reader を `check_effective_config.py` に保存した。CLI は次の通り。

```
python3 check_effective_config.py TRACE --config trace-config.unit1000.pb --output CHECK.json
```

対象 unit に合わせて `--config` を変更する。入力は読み取り専用、出力が既存なら拒否する。終了0には、echoed TraceConfig の既知設定が全て要求値と一致し、primary trace clock が3で、incremental clock64の全 snapshots が要求unitかつincremental=true、TracePacketDefaults の全timestamp clockが64であること、これら記録がそれぞれ存在することを要求する。未知fieldはreportにfield番号・値または長さ/hashを保存する。未知fieldを理解したと主張せず、比較は明示した既知設定の範囲で行う。

TracePacket.trace_config=33、clock_snapshot=6、trace_packet_defaults=59、trusted_packet_sequence_id=10、TracePacketDefaults.timestamp_clock_id=58 を固定schemaで確認した。履歴の段階16 `run0.pftrace` を今回のunit1000要求に照合した全gateが通り、1893 packets、clock64 snapshots13、clock65 snapshots13、全primaryclock3を得た (`checker-historical-unit1000.json`)。これは検算器の既存保存データでの確認であり、新規 browser 計測ではない。

設定generatorの全fieldをこの独立readerでもdecodeし、意味上の差がunitだけであることを確認した (`config-source-audit.json`)。実CPU CounterDescriptorのincremental属性、各eventへの適用、importer errorsはこの検算器の対象外であり、frozen raw counter checkerと公式変換器側のgateを併用する。

unit1 preflightがraw descriptor値0を理由に停止した点は、[ZERO_UNIT_REVIEW.md](ZERO_UNIT_REVIEW.md) に追加確認を保存した。固定PerfettoのCounterTrack serializerは倍率1を省略し、公式importerとfrozen checkerは未設定accessor値0を実効倍率1として扱う。`zero-unit-evidence.json` は既存run1の対象CounterDescriptorにfield4が実際に存在しないことを直接確認している。追加公式ソース6ファイル (105,707 bytes) と別manifestを `official-sources/config-zero-unit-source/` に保存した。元の停止report・capture・checkerは保持する。

主なオンライン根拠:

- [Chromium CDP handler](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/content/browser/devtools/protocol/tracing_handler.cc)
- [Chromium Tracing.pdl](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/third_party/blink/public/devtools_protocol/domains/Tracing.pdl)
- [Chromium Perfetto config builder/adaptation](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/services/tracing/public/cpp/perfetto/perfetto_config.cc)
- [Perfetto TrackEventConfig schema](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/protos/perfetto/config/track_event/track_event_config.proto)
- [Perfetto TraceConfig schema](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/protos/perfetto/config/trace_config.proto)
