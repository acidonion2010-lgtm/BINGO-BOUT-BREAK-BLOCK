#!/usr/bin/env python3
"""Independent arithmetic review of saved native-load.json; starts no native job."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics
import sys


def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    root = Path(__file__).resolve().parent
    output = root / 'native-independent-review.json'
    assert not output.exists(), 'Refuse overwrite'
    data_path = root / 'native-load.json'; data = json.loads(data_path.read_text())
    assert data['status'] == 'completed'
    hashes = {}
    for key, name in [('scriptSha256', 'check_clock_load.py'), ('sourceSha256', 'native_clock_load.c'),
                      ('planSha256', 'NATIVE_PLAN.md'), ('binarySha256', 'native-load-build/native-clock-load')]:
        hashes[name] = digest(root / name)
        assert data[key] == hashes[name], (key, name)
    assert data['compiler'] == {'returnCode': 0, 'stdout': '', 'stderr': ''}
    assert data['compileCommand'] == ['cc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-pthread',
                                      str(root / 'native_clock_load.c'), '-o', str(root / 'native-load-build/native-clock-load')]
    expected = [(run, count) for run in range(1, 5) for count in ([1, 8] if run % 2 else [8, 1])]
    assert [(p['run'], p['threads']) for p in data['processes']] == expected
    processes, all_rows, all_tids = [], [], []
    for process in data['processes']:
        assert process['returnCode'] == 0 and process['stderr'] == ''
        captured = json.loads(process['stdout']); result = process['result']; count = process['threads']
        assert captured['threads'] == result['threads'] == count
        assert len(captured['workers']) == len(result['workers']) == count
        assert [w['index'] for w in result['workers']] == list(range(count))
        tids = [w['tid'] for w in result['workers']]
        assert len(set(tids)) == count and all(tid > 0 for tid in tids)
        all_tids.extend(tids)
        rows = []
        switches = Counter()
        for worker, original in zip(result['workers'], captured['workers']):
            assert {k: v for k, v in worker.items() if k != 'samples'} == {k: v for k, v in original.items() if k != 'samples'}
            assert len(worker['samples']) == len(original['samples']) == 128
            for field in ('voluntary', 'involuntary'):
                delta = worker[field + 'After'] - worker[field + 'Before']; assert delta >= 0
                switches[field] += delta
            previous = None
            for index, (sample, raw) in enumerate(zip(worker['samples'], original['samples'])):
                assert all(sample[key] == value for key, value in raw.items())
                assert sample['sample'] == index and sample['scenario'] == (index + worker['index']) % 4
                assert sample['wall0Ns'] <= sample['wall1Ns'] <= sample['wall2Ns'] <= sample['wall3Ns']
                assert sample['cpu0Ns'] <= sample['cpu1Ns']
                assert sample['core0'] >= 0 and sample['core1'] >= 0
                if previous:
                    assert previous['wall3Ns'] <= sample['wall0Ns'] and previous['cpu1Ns'] <= sample['cpu0Ns']
                cpu = sample['cpu1Ns'] - sample['cpu0Ns']
                outer = sample['wall3Ns'] - sample['wall0Ns']
                non = sample['wall2Ns'] - sample['wall0Ns']
                assert sample['cpuDeltaNs'] == cpu and sample['outerWallNs'] == outer
                assert sample['nonSimultaneousWallNs'] == non
                assert sample['outerExcessNs'] == cpu - outer and sample['nonSimultaneousExcessNs'] == cpu - non
                assert 0 <= cpu <= outer
                rows.append(sample); previous = sample
            assert Counter(s['scenario'] for s in worker['samples']) == {0: 32, 1: 32, 2: 32, 3: 32}
        cg = {key: process['cpuStatAfter'][key] - process['cpuStatBefore'][key] for key in process['cpuStatBefore']}
        assert all(value >= 0 for value in cg.values())
        processes.append({'run': process['run'], 'threads': count, 'workers': len(tids), 'samples': len(rows),
                          'contextSwitchDeltas': dict(switches), 'sharedCgroupDeltas': cg,
                          'outerCpuExcessCount': sum(s['outerExcessNs'] > 0 for s in rows),
                          'delayedNonSimultaneousExcessCount': sum(s['scenario'] == 3 and s['nonSimultaneousExcessNs'] > 0 for s in rows),
                          'recordedStartEndCoreDifferentCount': sum(s['core0'] != s['core1'] for s in rows)})
        all_rows.extend(rows)
    assert len(all_rows) == data['samples'] == 4608 and len(set(all_tids)) == len(all_tids) == 36
    assert Counter(s['scenario'] for s in all_rows) == {0: 1152, 1: 1152, 2: 1152, 3: 1152}
    assert data['outerCpuExcessCount'] == sum(s['outerExcessNs'] > 0 for s in all_rows) == 0
    assert data['delayedControlNonSimultaneousExcessCount'] == sum(s['scenario'] == 3 and s['nonSimultaneousExcessNs'] > 0 for s in all_rows) == 1151
    assert data['chromiumCpuAccountingConfirmed'] is False
    scenarios = []
    for scenario in range(4):
        selected = [s for s in all_rows if s['scenario'] == scenario]
        scenarios.append({'scenario': scenario, 'samples': len(selected),
                          'nonSimultaneousExcessCount': sum(s['nonSimultaneousExcessNs'] > 0 for s in selected),
                          'nonSimultaneousExcessOver1us': sum(s['nonSimultaneousExcessNs'] > 1000 for s in selected),
                          'outerExcessNsRange': [min(s['outerExcessNs'] for s in selected), max(s['outerExcessNs'] for s in selected)],
                          'cpuDeltaNsRange': [min(s['cpuDeltaNs'] for s in selected), max(s['cpuDeltaNs'] for s in selected)],
                          'wall2ToCpuEndOuterGapNsRange': [min(s['wall3Ns'] - s['wall2Ns'] for s in selected), max(s['wall3Ns'] - s['wall2Ns'] for s in selected)]})
    result = {'status': 'completed', 'reviewScriptSha256': digest(Path(__file__)),
              'sourceDataSha256': digest(data_path), 'inputHashesMatched': hashes,
              'review': 'Read-only arithmetic and source inspection; no compiler, binary or measurement was run.',
              'processes': processes, 'scenarios': scenarios,
              'checks': {'all4608EndpointsAndDerivedFieldsMatched': True,
                         'capturedStdoutMatchesRecordedBaseEndpoints': True,
                         'allOuterCpuIntervalsWithinWallBrackets': True,
                         'all36TidsUnique': True, 'plansSourcesRunnerBinaryHashesMatched': True,
                         'chromiumCpuAccountingConfirmed': False}}
    with output.open('x') as file: file.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'checks': result['checks'], 'scenarios': scenarios}, ensure_ascii=False))


if __name__ == '__main__': main()
