#!/usr/bin/env python3
"""Fixed-budget stage5/stage9 investigation. Does not alter the supplied HTML."""
import argparse
import hashlib
import http.server
import json
import platform
import re
import statistics
import threading
import time
from pathlib import Path
from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
PROJECT = Path('/workspace/handoff/BINGO-BOUT-handoff/project')
FILES = {'stage5': PROJECT/'stages/index.handoff-20261015.html',
         'stage9': PROJECT/'index.html', 'original': PROJECT/'index.before.html'}
EXPECTED = {'stage5': 'fea09e995bfc1036515b92771925bd7968f3c453425ea5517b7a5b480293be64',
            'stage9': '59fff4685ff3f36e18d73fe9fa524ee57d81a348352e7b2912db4b7ecc1bb513',
            'original': 'e872443dc9764f3b9647f4797d1411ca98f865b9c2f69c6e694529e2685cd3a9'}
ANCHOR = '''        mountStaticUiIcons();
        runRuleSelfTests();
        resetGame(false);
        syncAudioButtons();'''

INIT_PROBE = '''
window.__probe = {scriptStart:performance.now(), phases:{}, dpSolves:[], raf:[], worker:null};
const __nativeRaf = window.requestAnimationFrame.bind(window);
window.requestAnimationFrame = function(cb) {
  const row={scheduled:performance.now()}; __probe.raf.push(row);
  return __nativeRaf(function(t) {
    row.start=performance.now();
    try {return cb(t)} finally {row.end=performance.now()}
  });
};
'''
BOOTSTRAP_PROBE = '''
__probe.bootstrapStart=performance.now();
const __originalSolve = WholeGameDP.prototype.solve;
WholeGameDP.prototype.solve = function(...args) {
  const start=performance.now();
  try {return __originalSolve.apply(this,args)}
  finally {__probe.dpSolves.push({start,end:performance.now()})}
};
function __phase(name,fn) {
  const start=performance.now();
  try {return fn()} finally {__probe.phases[name]={start,end:performance.now()}}
}
__phase('icons',()=>mountStaticUiIcons());
__phase('selfTests',()=>runRuleSelfTests());
__phase('reset',()=>resetGame(false));
__phase('audioButtons',()=>syncAudioButtons());
WholeGameDP.prototype.solve=__originalSolve;
__probe.bootstrapEnd=performance.now();
'''

# Only diagnostic documents use the following preparation instrumentation.
# Worker-local durations are subtracted within that realm. No clocks are mixed.
INSTALL_PREP_PROBE = '''() => {
 const originalSource=wholeGameWorkerSource;
 wholeGameWorkerSource=function() {
  let source=originalSource();
  const oldCtor='const dp = new WholeGameDP(data.config);';
  const oldSolve='const stats = dp.solve();';
  const oldMessage='self.postMessage({ type: "ready",';
  for(const anchor of [oldCtor,oldSolve,oldMessage]) {
   if(source.split(anchor).length!==2)throw Error('Worker instrumentation anchor mismatch');
  }
  source=source.replace(oldCtor,'const __wp={origin:performance.timeOrigin,ctorStart:performance.now()}; '+oldCtor+' __wp.ctorEnd=performance.now();');
  source=source.replace(oldSolve,'__wp.solveStart=performance.now(); '+oldSolve+' __wp.solveEnd=performance.now();');
  source=source.replace(oldMessage,'__wp.postStart=performance.now(); self.postMessage({ __probe:__wp, type: "ready",');
  return source;
 };
 const NativeWorker=window.Worker;
 window.Worker=class extends NativeWorker {
  constructor(...args) {
   const row=__probe.worker={createStart:performance.now()};
   super(...args); row.createEnd=performance.now();
   this.addEventListener('message',event=> {
    row.receive=performance.now(); row.worker=event.data.__probe;
   });
  }
  postMessage(...args) {
   __probe.worker.postStart=performance.now();
   const value=super.postMessage(...args);
   __probe.worker.postEnd=performance.now(); return value;
  }
  set onmessage(callback) {
   super.onmessage=event=> {
    __probe.worker.handlerStart=performance.now();
    try {return callback.call(this,event)}
    finally {__probe.worker.handlerEnd=performance.now(); __probe.worker.status=cpuWholeStatus}
   };
  }
  get onmessage() {return super.onmessage}
 };
}'''

PREPARE = '''async diagnostic => {
 Object.assign(state,{gameMode:'cpu',cpuDifficulty:'master',seatChosen:true,isStarting:true,
  gameEnded:false,firstPlayer:1,p1NumberLayout:[8,1,6,3,5,7,4,9,2],p2NumberLayout:[5,9,1,7,2,6,3,8,4]});
 const start=performance.now();
 startWholeGameCpu(); const startReturned=performance.now();
 await new Promise((resolve,reject)=> {
  const poll=()=> {
   if(cpuWholeStatus==='ready')return resolve();
   if(cpuWholeStatus==='fallback')return reject(Error(cpuWholeFailure));
   if(performance.now()-start>30000)return reject(Error('probe 30s preparation timeout'));
   setTimeout(poll,5);
  }; poll();
 });
 const end=performance.now();
 const result={start,end,elapsedMs:end-start,startReturned,
  initialValue:cpuWholeStats.initialValue,maxGap:cpuWholeStats.maxGap,valueTableBytes:cpuWholeStats.valueTableBytes};
 if(diagnostic)result.probe=JSON.parse(JSON.stringify(__probe));
 releaseWholeGameCpu(); return result;
}'''


def digest(data):
    return hashlib.sha256(data).hexdigest()


def extract_function(text, name):
    start = text.index('        function '+name+'(')
    end = text.index('\n        }', start) + len('\n        }')
    return text[start:end]


def atomic_json(path, data):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2))
    tmp.replace(path)


def read_inputs():
    raw = {name: path.read_bytes() for name, path in FILES.items()}
    for name in raw:
        assert digest(raw[name]) == EXPECTED[name], name+' input hash mismatch'
    text = {name: value.decode() for name, value in raw.items()}
    stripped = {}
    names = ['getCpuSelectionWeights','prepareCpuBreakCandidates','selectCpuLegacyCell','selectCpuBreakCell']
    for name in ['stage5','stage9']:
        value = text[name]
        for function in names:
            value = value.replace(extract_function(value, function), '<CHANGED '+function+'>')
        stripped[name] = value
    assert stripped['stage5'] == stripped['stage9'], 'Unexpected source difference'
    diagnostic = {}
    for name in ['stage5','stage9']:
        value = text[name]
        assert value.count(ANCHOR) == 1
        assert value.count('    <script>') == 1
        diagnostic[name] = value.replace('    <script>', '    <script>\n'+INIT_PROBE, 1).replace(ANCHOR, BOOTSTRAP_PROBE).encode()
    return raw, diagnostic


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['native','diagnostic','original-check'])
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists(), 'Refusing to overwrite an existing result'
    raw, diagnostic = read_inputs()
    data = {'mode':args.mode, 'planSha256':digest((HERE/'PLAN.md').read_bytes()),
            'scriptSha256':digest(Path(__file__).read_bytes()), 'status':'running',
            'inputs':{name:{'path':str(FILES[name]), 'sha256':digest(value), 'bytes':len(value)} for name,value in raw.items()},
            'diagnosticSha256':{name:digest(value) for name,value in diagnostic.items()},
            'conditions':{'viewport':[1280,900], 'platform':platform.platform(),
                          'cpuMax':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),
                          'noConcurrentBrowserJobs':True, 'clockNote':'Worker-local and main-local durations only; performance.now has finite browser resolution'},
            'samples':[], 'workerSourceSha256':{}}

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            name=self.path.strip('/').split('?')[0]
            arm=name.split('.')[0]
            body=diagnostic.get(arm) if name.endswith('.diagnostic') else raw.get(arm)
            if body is None:
                self.send_error(404);return
            self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)))
            self.end_headers();self.wfile.write(body)
        def log_message(self,*unused): pass

    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
    threading.Thread(target=server.serve_forever,daemon=True).start()
    atomic_json(args.output,data)
    try:
        with sync_playwright() as p:
            for run in range(2 if args.mode != 'original-check' else 1):
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,
                    args=['--no-sandbox','--disable-dev-shm-usage'])
                data['conditions']['browserVersion']=browser.version
                page=browser.new_page(viewport={'width':1280,'height':900})
                errors=[];page.on('pageerror', lambda error:errors.append(str(error)))
                if args.mode=='native':
                    orders=[['stage5','stage9'] if (run+r)%2==0 else ['stage9','stage5'] for r in range(6)]
                elif args.mode=='diagnostic':
                    # Balanced Williams square: each arm occurs once at each position.
                    conditions=['stage5/immediate','stage9/immediate','stage5/settled','stage9/settled']
                    square=[[0,1,3,2],[1,2,0,3],[2,3,1,0],[3,0,2,1]]
                    orders=[[conditions[n] for n in (row if run==0 else list(reversed(row)))] for row in square]
                else: orders=[['original']]
                for round_number,order in enumerate(orders,1):
                    for position,condition in enumerate(order,1):
                        arm=condition.split('/')[0]
                        suffix='.diagnostic' if args.mode=='diagnostic' else ''
                        start=time.perf_counter()
                        response=page.goto(f'http://127.0.0.1:{server.server_port}/{arm}{suffix}',wait_until='load',timeout=60000)
                        startup=(time.perf_counter()-start)*1000
                        assert response.status==200
                        tests=json.loads(page.locator('#rule-test-results').text_content())
                        assert tests['passed']==tests['total']==322 and not tests['failures'], tests
                        if arm not in data['workerSourceSha256']:
                            source=page.evaluate('wholeGameWorkerSource()')
                            data['workerSourceSha256'][arm]=digest(source.encode())
                        if args.mode=='diagnostic':
                            page.evaluate(INSTALL_PREP_PROBE)
                            if condition.endswith('/settled'):
                                page.evaluate('''async()=>{for(let i=0;i<4;i++)await new Promise(resolve=>requestAnimationFrame(resolve));}''')
                        prep=page.evaluate(PREPARE,args.mode=='diagnostic')
                        assert prep['valueTableBytes']==18324976 and prep['maxGap']<=1e-5
                        assert prep['initialValue']==-119.69864675486676
                        assert not errors, errors
                        if args.mode=='diagnostic':
                            probe=prep['probe']; assert probe['worker']['status']=='ready'
                            assert probe['worker']['worker']['solveEnd']>=probe['worker']['worker']['solveStart']
                            assert probe['dpSolves'], 'No startup DP solves recorded'
                        sample={'run':run+1,'round':round_number,'position':position,'condition':condition,
                                'firstNavigationInProcess':round_number==1 and position==1,
                                'startupMs':startup,'selfTests':tests,'preparation':prep,
                                'navigation':page.evaluate('performance.getEntriesByType("navigation")[0].toJSON()')}
                        data['samples'].append(sample); atomic_json(args.output,data)
                        print(f'{args.mode} run{run+1} r{round_number} {condition}: load {startup:.2f} ms; prepare {prep["elapsedMs"]:.2f} ms',flush=True)
                browser.close()
        if args.mode!='original-check':
            assert data['workerSourceSha256']['stage5']==data['workerSourceSha256']['stage9'], 'Worker source differs'
        data['status']='completed'
    except BaseException as error:
        data['status']='failed';data['error']=repr(error)
        raise
    finally:
        atomic_json(args.output,data)
        server.shutdown();server.server_close()


if __name__=='__main__':
    main()
