# 段階14 実行前の独立静的レビュー

2026-10-15。`capture_clicks.py`、`PLAN.md`、凍結済みstage3/5/6/7 helperを読み、
入力hash・順序・予算・分岐契約を独立照合した。ブラウザー、DP、性能ジョブは起動していない。
修正後の収集器について、予定された診断の実行を止める欠陥は見つからず、実行可と判断する。
別担当の全trace解析器の完全な監査を、このレビューが代替するものではない。

## 設計・コードの照合

- 原本、stage3.final、stage5、stage9の4実HTML hashがEXPECTEDと一致。
  stage3/ui_response.py、stage5/raf_phase_response.py、stage6/phase_input_probe.py、
  stage7/trace_response.pyの4helperもHELPERSの固定SHA-256と一致した。
- Williams基底[0,1,3,2]の4配置は各版×visit位置を各1回、有向隣接12組を各1回満たす。
  `(run+position)%2`で分岐順を変える実装では、各版のDP先行/legacy先行がそれぞれ2回。
  4freshブラウザー、16visit、16自己テスト/実Worker準備、2分岐×各warmup1/正式9で
  288正式クリック＋32warmup。全320sample×4mark=1,280markerという計数に一致する。
- 入力は通常のlocator.clickで、forceやCDP cueを追加していない。
  FIXTUREの差は引数をdifficulty/rollにする箇所と固定乱数をrollへ変える箇所のみ。
  P1先攻・中盤の人間BREAK→CPU BLOCKという過去fixtureを保持する。
- DPは既存assert_sample('hard')を使い、whole1/DP1/legacy0を要求する。
  legacyは共通の非DP契約をassert_sample('normal')から再利用してwhole0を要求し、
  さらにDP0/legacy1を明示する。これはHARDをNORMALで計測する操作ではなく、
  fixtureはHARD、乱数0.3、engineはreadyのまま。表示・受理・音/BGM等の共通assertも維持する。
- native selector監査は各分岐で1回だけ計時前に行い、乱数列・選択合法性・counter・
  公開入力/履歴の不変を検査する。修正版では取得直後にも既存版との一致を検査する。
  WorkerのinitialValue/maxGap/bytes/statusも全版で照合する。
- ゲームの7関数の参照を保存し、各trial前とvisit後に不変を検査する。
  ゲームhandler/CPU selector/描画・演出関数をwrapperへ交換する箇所はない。
  監査時だけMath.randomを計数し、クリックには非計数の固定乱数を使う。

## traceと失敗保存

- stage7のcapture/bubble/RAF callback内の4markを保持し、name prefixだけstage14へ変更する。
  run/version/branch/trialを含むtokenは各sampleで一意になる。
  mark/console.timeStamp/RAF monitor等の計装は追加され、無計装時間とは区別されている。
- 各visitを1本の連続traceとして収集し、fixture、監査、warmupも含む。
  collectorはstream EOF、SHA、bytes、dataLossOccurred=false、buffer未充満、最終trialの4markを検査。
  それだけで全trialのmarker完全性を証明したとは扱わず、全1,280markerは別解析器で照合する。
- 修正版はgetCategoriesの列挙をrun別に保存する。空列挙はunknownであり、
  要求カテゴリをfilterしたり空文字へ変えたりしない。
  明示したカテゴリと実際のmarker/timeline/task/frameの可用性は生traceで別途確認する。
- 各recordを処理前に登録し、例外時にはvisitのfailure、進行中record、可能なraw traceを保存する。
  traceの終了・回収はfinallyで行い、主処理失敗時に二次trace失敗があっても元の失敗を保持する。
  出力report・trace directoryの既存内容を上書きしない。

## 解釈の制約

原本→3のhandlerと原本→5の2RAFは、過去の対象HTMLに対応する新しい同時記録となる。
stage4そのものを含めないため、過去の原本→4の+0.50msを直接再測定する構成ではない。
過去は無traceで、stage3ではHARD前にNORMALクリック履歴もあった。
今回の連続trace、追加監査、4版visit、分岐順・RAF monitorは異なる実行contextであり、
過去の+0.45/+0.50/+0.80msを今回の値で消したり原因確定したりしない。

計時前のnative監査はCPU BLOCK選択を比較するが、各実クリックのlocalなCPU BLOCK値を
直接保存するものではない。クリック中wrapperを入れない設計上の制約として保持する。
9trialを同時の版間対標本とは扱わず、visit中央値差を4runで記述し、狭いpaired CIを作らない。
位相補正、A/A減算、後付け許容差、旧62条件の自動更新、物理提示/音声latencyの主張をしない
というPLANの範囲は妥当である。

レビュー時SHA-256:

- capture_clicks.py: `df0c5fa77905d13ce492882e14338a5684e6670e1c5f0694f44b20d696092c77`
- PLAN.md: `9729a74246156911addeebbe98e693d20fc841ef077b454c1ea4c6d333a8ceb7`
