#!/usr/bin/env python3
"""Focused original/original control for five pooled-positive selector cases."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import selector_performance as extended


FOCUS = [
    {'firstPlayer': 1, 'scenario': 'late', 'role': 'block', 'path': 'hard-legacy'},
    {'firstPlayer': 1, 'scenario': 'late', 'role': 'block', 'path': 'hard-full'},
    {'firstPlayer': 2, 'scenario': 'middle', 'role': 'break', 'path': 'hard-fallback-legacy-roll'},
    {'firstPlayer': 2, 'scenario': 'middle', 'role': 'block', 'path': 'hard-legacy'},
    {'firstPlayer': 2, 'scenario': 'one-closed', 'role': 'block', 'path': 'hard-fallback-legacy-roll'},
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--port', type=int, default=8011)
    args = parser.parse_args()
    bench = extended.benchmark
    anchor = '      this.spec = spec;\n'
    assert bench.INSTALL_BENCH.count(anchor) == 1
    check = '\n      const focused = ' + json.dumps(FOCUS) + r''';
      if (!focused.some(item => item.firstPlayer === this.firstPlayer &&
          item.scenario === spec.nameScenario && item.role === spec.role &&
          item.path === spec.name)) {
        return {skip:true,skipReason:'Outside the five focused A/A control cases'};
      }
'''
    # Scenarios and paths both use `name`; preserve the scenario name explicitly.
    bench.SCENARIOS = [{**scenario, 'nameScenario': scenario['name']}
                       for scenario in bench.SCENARIOS]
    bench.INSTALL_BENCH = bench.INSTALL_BENCH.replace(anchor, anchor + check, 1)
    previous_argv = sys.argv
    sys.argv = [str(Path(extended.__file__)), str(args.original), str(args.original),
                str(args.output), '--port', str(args.port)]
    try:
        status = extended.main()
    finally:
        sys.argv = previous_argv
    if args.output.exists():
        data = json.loads(args.output.read_text())
        data['conditions']['comparison'] = 'A/A; same original HTML in both realms'
        data['conditions']['focusedCases'] = FOCUS
        data['conditions']['focusSelection'] = 'Five pooled-positive cases from the prior A/B run; exploratory control, no performance PASS or subtraction'
        data['conditions']['notTargetedSkips'] = 'Other conditions are excluded by the explicit focus list, independently of terminal classification'
        args.output.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    return status


if __name__ == '__main__':
    raise SystemExit(main())
