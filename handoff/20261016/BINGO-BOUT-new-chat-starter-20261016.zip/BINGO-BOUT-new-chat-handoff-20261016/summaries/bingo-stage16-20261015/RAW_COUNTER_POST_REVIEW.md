# 段階16 保存proto原CPU counterの独立照合

**同じ保存protoから、独自wire decoderと公式Perfetto processorが同じthread CPU値を得ることを確認した。** 対象rendererの167,205 counter samplesは(UUID,value)の多重集合が全て一致し、260markerのCPU端点と、1msを超えてCPU>wallとなる26sliceのCPU begin/endも一致した。これはCPU値の復元・転記を確かめる結果であり、時計の物理的妥当性や超過原因の確定ではない。

ブラウザー・DP・性能ジョブは追加していない。rootが収集を完了したrun0–4のproto、同protoJSON、公式SQLを読み、段階16内に解析結果のみ保存した。元proto/JSON/HTML/PLAN/collector、過去成果物は変更していない。

## 手段と根拠

- [raw_counter_check.py](/workspace/bingo-stage16-20261015/raw_counter_check.py) をSHA256 `91762a94d1e1e05305c2a11fbb237dd4b42bffd3ebb5162f48c4cec42b038c23`で凍結。符号付きvarint、UUID/defaults、counter multiplier、sequence/resetをpacket順に復元する。wall変換は行わない。
- source/schema/限界は [PROTO_DECODE_REVIEW.md](/workspace/bingo-stage16-20261015/PROTO_DECODE_REVIEW.md)、[COUNTER_SCHEMA_REVIEW.md](/workspace/bingo-stage16-20261015/COUNTER_SCHEMA_REVIEW.md)、[RAW_COUNTER_CHECK_REVIEW.md](/workspace/bingo-stage16-20261015/RAW_COUNTER_CHECK_REVIEW.md)。固定公式ソースのURL/hash/LICENSEを保存済み。
- 公式processorは `trace_processor_shell` v58.2-add693d8b、SHA256 `58042408e6cc861fb1a731c26bb082dc222285561eaa4e12a48a8b2b90dca7b9`。rootの同一protoからの公式SQL/JSONを使用した。
- syntax/独立静的レビューに加え、[合成回帰30項目](/workspace/bingo-stage16-20261015/RAW_COUNTER_SYNTHETIC_CHECKS_v2.json)、別担当による[公式SQL/JSONとの合成照合48項目](/workspace/bingo-stage16-20261015/decoder-validation/verification_final.json)が成功。後者は8端点・11counter値、非marker増分、2sequence、reset、倍率1000、BEGIN/END/INSTANTを含む。
- 実行command、decoder hash、入力/出力hashと診断は [raw-counter-execution.json](/workspace/bingo-stage16-20261015/raw-counter-execution.json)。独立照合の実装は [verify_raw_counters.py](/workspace/bingo-stage16-20261015/verify_raw_counters.py)、結果と26件の元packet証拠は [raw-counter-official-check.json](/workspace/bingo-stage16-20261015/raw-counter-official-check.json)。

## 全counterとmarkerの結果

reportのrenderer PID/TID、counterのparent thread、UUIDを照合し、同じrendererの `thread_time` counterを選んだ。UUIDはunsigned64へ正規化してSQLと比較した。counterの比較は値の出現数まで含む多重集合であり、wall timestampで1点ずつ並べた比較ではない。markerはPerformanceMark名、またはTimeStampの `data.message` の完全一致で、各系列1件を要求した。

| run | 原thread_time samples | 公式SQL samples | counter多重集合 | marker端点一致 | CPU超過>1msのSQL slice | raw CPU packet対への一意対応 |
|---|---:|---:|---|---:|---:|---:|
| 0（preflight） | 36 | 36 | 一致 | 4/4 | 0 | 0 |
| 1 | 39,874 | 39,874 | 一致 | 64/64 | 12 | 12 |
| 2 | 41,974 | 41,974 | 一致 | 64/64 | 6 | 6 |
| 3 | 41,480 | 41,480 | 一致 | 64/64 | 3 | 3 |
| 4 | 43,841 | 43,841 | 一致 | 64/64 | 5 | 5 |
| 合計 | **167,205** | **167,205** | **全run一致** | **260/260** | **26** | **26** |

markerの260件はpreflightの2名称×2系列=4件、正式4visitの各32名称×2系列=256件である。名称には暖機trial0も含む。対象markerは全てledgerに保持され、CPUなし/重複/JSON側欠落は0。raw CPU nsの整数us化（正値のns/1000切捨て）はJSON ttsと全件一致した。

## 26sliceのraw CPU端点

renderer thread trackの保持済みCPU付きBEGIN/ENDをpacket順のstackで対応付けた。各runのraw pair数は16 / 19,638 / 20,681 / 20,415 / 21,594、unmatched ENDとunclosed BEGINはいずれも0だった。

公式SQLの `thread_dur−dur>1,000,000ns` を満たすsliceについて、**name・CPU begin ns・CPU end ns** が一致するraw BEGIN/END対を探した。26件全てで候補は1件だった。対応の根拠にはsequence、thread track UUID、counter UUID、begin/end packet indexとfile offset、各endpointでのraw delta/multiplier/累積値を保存した。原CPU値はSQLのns値そのものと一致し、JSONの丸め値だけを照合したものではない。

例としてrun1 SQL slice15928、`ThreadControllerImpl::RunTask` は、raw packet33321→38311、CPU `3,983,293,000→4,022,130,000ns`。差分 `38,837,000ns` はSQL thread_durと一致する。SQL wallは `36,439,627ns`、差は `2,397,373ns`。この結果は、export後JSONだけでCPUの数値が増えたとする説明を必要としない。

このraw対の対応はwallの独自復元ではない。stackは保持されたaccepted-CPUのBEGIN/ENDに限定し、任意の旧phase/async slice、欠測CPU、全track形式を復元するものではない。今回の対応は全stack閉鎖・候補一意・元counter値一致まで確認できたが、wall clock mappingや取得点の同時性を検証したとは扱わない。

## 残る制限と解釈

各ledgerには `legacy_nested_annotation_unsupported` 診断が残る（run0–4: 22 / 2,161 / 2,199 / 2,306 / 2,270件）。古いannotationの一部は解釈対象外であり、`limited_scope_supported=false` を保持した。対象markerの必要な `data.message` は解決でき、全counter/marker端点の上記照合も成立したが、decoder全形式対応PASSには読み替えない。失敗診断を削除・許容差化していない。

CPU counter値の独自復元と公式結果が一致したことで、今回の26件に「JSON exporterがCPUを補間・別値へ変えたこと」を原因として持ち込む必要はなくなった。**CPU APIの正確さ、producerの採取点、wall取得、ClockSnapshot、wall clock変換、VM/kernel会計等の原因候補は残る。** 本補助decoderはwallを変換していないので、原因をproto生成前へ限定しない。

また、26件は今回の小規模診断の保存traceであり、段階14の169件を直接復元した結果ではない。段階14には元protoがなく、この一致をそのまま全過去traceへ適用しない。CPU≤wallへのclamp、超過sliceの除外、段階14の修正、性能の非劣化・過去原因の断定は行っていない。

追加のsource/既存ledger照合では、SDKがCPU差分のns→us切捨て余りを毎回失い、clear後にその累積損失が回復し得ることを確認した。26/26件がclearを跨ぎ、各begin epochの更新回数から求めたfloor損失上限と整合した。CPU値のraw一致はこのproducer側効果を除外しない。式・全件証拠・境界の保留例は [CPU_QUANTIZATION_REVIEW.md](/workspace/bingo-stage16-20261015/CPU_QUANTIZATION_REVIEW.md) に記録した。
