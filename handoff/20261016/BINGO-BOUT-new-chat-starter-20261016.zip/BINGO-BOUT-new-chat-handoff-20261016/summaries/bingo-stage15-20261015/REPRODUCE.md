# 段階15の再現

新しいゲーム計測はなく、段階14の16traceを再解析した。元データは`BINGO-BOUT-stage14-20261015.zip`に含まれる。本ZIPにはその約734MBの生traceを重複収録せず、元hashとcompact証拠を保存する。

## 保存traceの読み取り再解析

Python3標準ライブラリだけを使う。ブラウザー・Playwright・ネットワークは不要。段階14を`/workspace/bingo-stage14-20261015/`に展開し、report.jsonの隣にtraces/を保持する。新しい出力先を使い、次を順に実行する。

```bash
cd /workspace/bingo-stage15-20261015
mkdir -p reproduction
python3 raw_clock_review.py /workspace/bingo-stage14-20261015/report.json --output reproduction/raw-clock-review.json
python3 raw_clock_jumps.py /workspace/bingo-stage14-20261015/report.json reproduction/raw-clock-jumps.json
python3 boundary_gap_review.py /workspace/bingo-stage14-20261015/report.json reproduction/boundary-gap-review.json
```

各scriptは元reportとtraceのSHA-256を照合し、既存出力を拒否する。いずれも全16traceを読むため、合計では数GBの読み取りになる。新しい試行を収集せず、元データの時刻を変更しない。169件は入れ子を含む完了Xの件数であり、独立の異常回数ではない。

保存JSONの再計算値はSOURCE_CLOCK_REVIEW.mdの別実装集計とも照合済み。公式source原文とLICENSEはofficial-sources/、各manifestにcommit固定URL・サイズ・hashを保存した。原文を読むためのネットワーク取得は再現に必要ない。fetch scriptの再実行は保存済み原文の検証に不要。

## 新しくOS時計診断をする場合

Python3、Linux、pthreadとCLOCK_THREAD_CPUTIME_ID、ccが必要。今回はDebian cc14.2.0を使用。NATIVE_PLAN.mdの固定8process・4,608区間を一度だけ実行する。別のブラウザー・DP・性能ジョブと重ねない。

```bash
python3 check_clock_load.py --output reproduction/native-load.json
```

出力と隣のnative-load-buildディレクトリが既存なら拒否する。新しい出力先を用意する。helperは1thread/8thread、busy/yield/sleep/意図的末尾CPU読取り遅延の対照を持つ。意図的な非同時wall超過を実trace原因の再現と解釈しない。時計結果の有無で回数を増やさず、全端点を保存する。

実施済みの独立再計算はreview_native.pyとnative-independent-review.jsonに保存した。review_native.pyは当時の固定パス・固定出力名を使う検査記録で、既存review出力への上書きを拒否する。追加compileやnative実行を行うscriptではない。検査したbinaryもnative-load-build/へそのまま収録し、SHA-256を記録した。新規の時計診断では上のreproduction/出力を使い、同梱binaryを再利用しない。

## 判定と未確定範囲

元traceの169件、隣接制約168件、counter後戻り0、native外側bracket成立4,608件という結果を別々の観測として扱う。外側bracket成立はChromiumのCPU会計を承認しない。元の負の残差をclampせず、試行を除かず、A/A補正・事後許容差・旧62条件の再分類をしない。

同梱index.htmlは従来の段階9を無変更で保存した参考本体で、今回新たに測定したHTMLではない。リポジトリmainや元引き継ぎZIPの変更もない。
