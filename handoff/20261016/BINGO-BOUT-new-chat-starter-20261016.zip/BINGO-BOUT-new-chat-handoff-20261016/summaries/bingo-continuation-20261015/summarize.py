#!/usr/bin/env python3
"""Summarize all retained pairs without trimming, correction or tolerance."""
import argparse
import json
import statistics
from pathlib import Path


def stats(values):
    return {'n':len(values),'median':statistics.median(values),
            'mean':statistics.mean(values),'min':min(values),'max':max(values),
            'positive':sum(x>0 for x in values),'negative':sum(x<0 for x in values),
            'zero':sum(x==0 for x in values),'raw':values}


def metrics(row):
    prep=row['preparation']
    output={'startupMs':row['startupMs'],'preparationMs':prep['elapsedMs']}
    if 'probe' not in prep: return output
    probe=prep['probe'];w=probe['worker'];local=w['worker']
    selftests=probe['phases']['selfTests']
    output.update({
        'selfTestsMs':selftests['end']-selftests['start'],
        'startupDpSolvesMs':sum(p['end']-p['start'] for p in probe['dpSolves']),
        'startupDpSolveCount':len(probe['dpSolves']),
        'iconsMs':probe['phases']['icons']['end']-probe['phases']['icons']['start'],
        'resetMs':probe['phases']['reset']['end']-probe['phases']['reset']['start'],
        'workerCtorMs':local['ctorEnd']-local['ctorStart'],
        'workerSolveMs':local['solveEnd']-local['solveStart'],
        'mainBeforePostMs':w['postStart']-prep['start'],
        'mainPostToReceiveMs':w['receive']-w['postStart'],
        'receiveToHandlerMs':w['handlerStart']-w['receive'],
        'handlerMs':w['handlerEnd']-w['handlerStart'],
        'pollTailMs':prep['end']-w['handlerEnd'],
        'syncStartMs':prep['startReturned']-prep['start'],
    })
    output['selfTestsOutsideDpSolveMs']=output['selfTestsMs']-output['startupDpSolvesMs']
    output['workerTransportCompileQueueOtherMs']=(output['mainPostToReceiveMs']-output['workerCtorMs']-output['workerSolveMs'])
    raf=[r for r in probe['raf'] if 'end' in r and r['end']>prep['start'] and r['start']<prep['end']]
    output['rafDuringPreparationCount']=len(raf)
    output['rafDuringPreparationMs']=sum(min(r['end'],prep['end'])-max(r['start'],prep['start']) for r in raf)
    return output


def summarize(data):
    assert data['status']=='completed'
    rows=data['samples']; result={'sampleCount':len(rows),'runs':{}}
    for run in sorted(set(r['run'] for r in rows)):
        selected=[r for r in rows if r['run']==run]
        runout={'conditions':{},'versionPairs':{}}
        for condition in sorted(set(r['condition'] for r in selected)):
            values=[metrics(r) for r in selected if r['condition']==condition]
            runout['conditions'][condition]={key:stats([r[key] for r in values]) for key in values[0]}
        for mode in (['immediate','settled'] if data['mode']=='diagnostic' else ['native']):
            s5='stage5'+('/'+mode if mode!='native' else '')
            s9='stage9'+('/'+mode if mode!='native' else '')
            paired=[]
            for round_number in sorted(set(r['round'] for r in selected)):
                arms={r['condition']:metrics(r) for r in selected if r['round']==round_number}
                a=arms[s5];b=arms[s9]
                paired.append({key:b[key]-a[key] for key in a})
            runout['versionPairs'][mode]={key:stats([r[key] for r in paired]) for key in paired[0]}
            runout['versionPairs'][mode]['ratioOfMediansPercent']={
                key:(runout['conditions'][s9][key]['median']/runout['conditions'][s5][key]['median']-1)*100
                for key in ['startupMs','preparationMs']}
        if data['mode']=='diagnostic':
            runout['settledMinusImmediate']={}
            for arm in ['stage5','stage9']:
                paired=[]
                for round_number in sorted(set(r['round'] for r in selected)):
                    arms={r['condition']:metrics(r) for r in selected if r['round']==round_number}
                    a=arms[arm+'/immediate'];b=arms[arm+'/settled']
                    paired.append({key:b[key]-a[key] for key in a})
                runout['settledMinusImmediate'][arm]={key:stats([r[key] for r in paired]) for key in paired[0]}
        result['runs'][str(run)]=runout
    return result


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('directory',type=Path)
    args=parser.parse_args()
    output={name:summarize(json.loads((args.directory/(name+'.json')).read_text())) for name in ['native','diagnostic']}
    (args.directory/'summary.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
    for name,data in output.items():
        print(name)
        for run,rows in data['runs'].items():
            for mode,pairs in rows['versionPairs'].items():
                print('run',run,mode,'ratio of medians %',pairs['ratioOfMediansPercent'])
                for key in ['startupMs','preparationMs','selfTestsMs','startupDpSolvesMs','workerSolveMs','mainPostToReceiveMs','handlerMs','pollTailMs','rafDuringPreparationMs']:
                    if key in pairs:
                        stat=pairs[key]
                        print(key,'paired median',round(stat['median'],3),'range',[round(stat['min'],3),round(stat['max'],3)],'positive',stat['positive'],'negative',stat['negative'])


if __name__=='__main__': main()
