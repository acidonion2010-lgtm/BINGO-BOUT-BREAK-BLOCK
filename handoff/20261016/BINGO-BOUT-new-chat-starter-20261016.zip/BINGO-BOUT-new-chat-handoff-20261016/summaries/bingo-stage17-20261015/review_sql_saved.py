#!/usr/bin/env python3
"""Independent read-only SQL/JSON counts; consumes saved official query output."""
import csv, hashlib, json
from collections import Counter
from decimal import Decimal
from pathlib import Path
R=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):
    with p.open(newline='') as stream:return list(csv.DictReader(stream))
def main():
    out=R/'post-run-independent-sql.json';assert not out.exists()
    report=json.loads((R/'report.json').read_text()); results=[]
    for v in report['visits']:
        run=v['run']; base=R/'official-sql'; sp=base/f'run{run}-slices.csv'
        cp=base/f'run{run}-counters.csv'; hp=base/f'run{run}-stats.csv'
        slices=rows(sp); complete=[s for s in slices if int(s['dur'])>=0]
        cpu=[s for s in complete if s['thread_ts']!='[NULL]' and s['thread_dur']!='[NULL]']
        positive=[s for s in cpu if int(s['thread_dur'])>int(s['dur'])]
        large=[s for s in positive if int(s['thread_dur'])-int(s['dur'])>1000000]
        tuples=Counter((s['name'],int(s['ts'])//1000,int(s['dur'])//1000,int(s['thread_ts'])//1000,int(s['thread_dur'])//1000) for s in cpu)
        json_data=json.loads((R/f'run{run}.json').read_text(),parse_float=Decimal)
        pid,tid=v['conversion']['rendererPidTid']
        x=[e for e in json_data['traceEvents'] if e.get('ph')=='X' and (e.get('pid'),e.get('tid'))==(pid,tid) and all(k in e for k in ['dur','tts','tdur'])]
        json_tuples=Counter((e['name'],e['ts'],e['dur'],e['tts'],e['tdur']) for e in x)
        missing=json_tuples-tuples;assert not missing,(run,missing)
        counters=rows(cp);stats=rows(hp)
        errors=[s for s in stats if s['severity'] in ['error','data_loss'] and int(s['value'])!=0]
        assert not errors,(run,errors)
        results.append({'run':run,'unit':v['unit'],'preflight':v['preflight'],
            'sqlSlices':len(slices),'sqlComplete':len(complete),'sqlCompleteWithCpu':len(cpu),
            'sqlCompleteCpuMissing':len(complete)-len(cpu),'sqlStrictPositive':len(positive),'sqlOver1ms':len(large),
            'sqlNegativeCpu':sum(int(s['thread_dur'])<0 for s in cpu),
            'sqlZeroCpu':sum(int(s['thread_dur'])==0 for s in cpu),
            'jsonWithCpu':len(x),'jsonSqlTupleMissing':sum(missing.values()),
            'threadTimeCounters':sum(c['name']=='thread_time' for c in counters),
            'nonzeroErrorOrDataLossStats':errors,
            'slicesSha256':sha(sp),'countersSha256':sha(cp),'statsSha256':sha(hp)})
    result={'status':'completed','scriptSha256':sha(Path(__file__)),'reportSha256':sha(R/'report.json'),
        'scope':'Reads saved official SQL CSV and JSON only; no tool, decoder, browser or new measurement execution.',
        'runs':results,'formalByUnit':{str(u):{k:sum(v[k] for v in results if v['unit']==u and not v['preflight']) for k in ['sqlSlices','sqlComplete','sqlCompleteWithCpu','sqlCompleteCpuMissing','sqlStrictPositive','sqlOver1ms','sqlNegativeCpu','sqlZeroCpu','jsonWithCpu','jsonSqlTupleMissing','threadTimeCounters']} for u in [1000,1]}}
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result['formalByUnit']))
if __name__=='__main__':main()
