#!/usr/bin/env python3
"""Describe predeclared C/E contrasts across independent diagnostic processes."""
import argparse
import csv
import json
from pathlib import Path
import statistics


def describe(values):
    return {'raw':values,'median':statistics.median(values),'range':[min(values),max(values)],
            'positive':sum(v>0 for v in values),'negative':sum(v<0 for v in values),'zero':values.count(0)}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('input',type=Path);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();assert not args.output.exists(),'Refuse overwrite'
    data=json.loads(args.input.read_text());assert data['status']=='completed' and len(data['runs'])==8
    assert data['timedChoicesCompleted']==57600000
    result={'completed':True,'timedChoices':data['timedChoicesCompleted'],'comparisons':{},
        'interpretation':'Run-level paired medians; factor contrasts are descriptive differences across separate browsers. No A/A correction or universal non-regression inference.'}
    comparisons=[item[0] for item in data['conditions']['comparisons']]
    csv_rows=[]
    for comparison in comparisons:
        entries=[];indexed={}
        for run in data['runs']:
            assert len(run['fixtures'])==1
            row=next(row for row in run['rows'] if row['comparison']==comparison)
            f=run['factors'];key=(f['construction'],f['executionReverse'],f['replicate'])
            assert key not in indexed
            median=row['summary']['pairedMedianDeltaUs'];indexed[key]={'run':run['run'],'median':median}
            entry={'run':run['run'],**f,'pairedMedianDeltaUs':median,'interval':row['summary']['interval95']}
            entries.append(entry)
            csv_rows.append([comparison,run['run'],*key,median,*entry['interval']['boundsUs'],entry['interval']['classification']])
        assert set(indexed)=={(c,e,r) for c in [0,1] for e in [0,1] for r in [1,2]}
        construction=[];execution=[]
        for rep in [1,2]:
            for e in [0,1]:
                a=indexed[(0,e,rep)];b=indexed[(1,e,rep)]
                construction.append({'replicate':rep,'executionReverse':e,'beforeRun':a['run'],'afterRun':b['run'],'deltaUs':b['median']-a['median']})
            for c in [0,1]:
                a=indexed[(c,0,rep)];b=indexed[(c,1,rep)]
                execution.append({'replicate':rep,'construction':c,'beforeRun':a['run'],'afterRun':b['run'],'deltaUs':b['median']-a['median']})
        result['comparisons'][comparison]={'runs':entries,'constructionC1MinusC0':construction,'executionE1MinusE0':execution,
            'constructionContrastSummary':describe([v['deltaUs'] for v in construction]),
            'executionContrastSummary':describe([v['deltaUs'] for v in execution])}
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    with args.output.with_suffix('.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['comparison','run','construction','executionReverse','replicate','pairedMedianDeltaUs','intervalLowerUs','intervalUpperUs','classification']);writer.writerows(csv_rows)
    for c,r in result['comparisons'].items():
        print(c,'per-run medians',[e['pairedMedianDeltaUs'] for e in r['runs']])
        print('C1−C0',r['constructionContrastSummary'],'E1−E0',r['executionContrastSummary'])


if __name__=='__main__':main()
