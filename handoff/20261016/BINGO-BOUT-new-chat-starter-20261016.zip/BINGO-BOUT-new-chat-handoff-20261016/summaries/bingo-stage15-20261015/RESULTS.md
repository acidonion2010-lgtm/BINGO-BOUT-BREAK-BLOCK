# 段階15：CPU時計の不整合を全traceと実装から確認

**CPU時間の超過は、前回の3つのマーカー区間だけではなかった。** 保存された全16traceのrenderer-mainで、完了XイベントのCPU時間が経過時間を1ms超上回るものを169件確認した。151件は操作応答の外側にもあり、特定のゲーム選択処理に限らない。入れ子のイベントが同じ時計増分を含むため、169件を独立した異常回数とは数えない。

公式の固定revisionソースでは、wallとCPUを別時点で採取し、CPUをOS APIから直接読む経路を確認した。実際のJSON exporterにwallからCPUを補間・推定する処理は見つからなかった。一方、単純な取得遅延だけでは説明に情報が足りない隣接イベントもあり、**実traceの原因とCPU寄与率は未確定**である。

新しいゲーム/ブラウザー計測は行わず、元の733,556,300 bytesをhash検証付きで再解析した。別の固定native診断4,608区間はCPUを包む外側wallに全件収まった。本体・原本480ファイル・段階14の記録と分析器は変更していない。

## 全16traceで見つかった範囲

| 点検 | 結果 |
| --- | ---: |
| 元trace | 16本、2,929,898 events |
| renderer-mainのdur/tdurを持つ完了X | 616,717件 |
| tdur > durの完了X | 12,624件 |
| 超過0より大〜1µs以下 | 10,239件 |
| 超過1より大〜10µs以下 | 1,827件 |
| 超過10より大〜100µs以下 | 377件 |
| 超過100より大〜1,000µs以下 | 12件 |
| 超過1,000µsより大 | 169件、全16visitに分布 |
| うち全responseの外側 | 151件 |
| I/X start間で1ms超の過大CPU増分 | 82箇所 |
| startと導出X endを含む時計点 | 1,257,340点 |
| 異なるwall時刻間でのtts後戻り | 0件 |

上のbinは大きさの記述で、許容差やPASS基準ではない。小さい値も除外・補正していない。1ms超はRunTask、main frame、FunctionCall、RAF、Style/Layout、ParseHTML、commit待ち等に分布する。超過を合計してCPU損失や処理費用へ換算しない。

全1,280組のPerformanceMarkとconsole TimeStampも照合した。mark→stampのwall差は18〜2,154µs、CPU差は17〜180µsで、一定のoffsetではない。3組でCPU差がwall差を16〜26µs超えたが、これは前回のms単位の3response区間とは別の組である。固定マーカー費用を差し引く補正はしない。

詳細・元hash・metadataはRAW_CLOCK_REVIEW.md、raw-clock-review.json、raw-clock-jumps.json。

## ソースから確定した取得経路

対象ブラウザー申告revisionはChromium `73c14f6228d7cd537c855007e8f88678969cc0eb`（154.0.8037.57）。そのDEPSが固定するPerfettoは`5dbeaad4ceb91470a835426b52e0cb43a3e5ef10`。公式原文とURL・hash・LICENSEを保存した。配布binary全体と無改変upstreamビルドの同一性を検証したわけではない。

- PerformanceMarkはoptionsなしでも先に保存したwall timestampをtraceへ渡し、CPUは後で読む。
- console TimeStampと通常ParseHTML BEGIN/ENDは明示timestampを渡さない。それでも標準経路はwall取得→incremental state/packet準備→CPU取得という別時点のsnapshot。
- modern producerは`CLOCK_THREAD_CPUTIME_ID`を直接読む。古いChromium TraceLog/ThreadTicks経路と混同しない。標準wallは`CLOCK_MONOTONIC`。
- JSON経路はcounterを復元し、B/E端点差を計算して整数単位へ変換する。調査した経路にCPU補間・wallによる上限補正はない。
- CPUの差分符号化・µs単位への量子化もあるが、数msの超過を丸めだけで説明したとはしない。

取得時点がずれればCPU差とwall差は同じ境界の物理会計ではなくなる。ただし、この一般的な可能性だけで実データのms超過を説明したとは言えない。

## 単純な末尾取得遅延説に対する制約

原本run3・従来trial3のParseHTMLは、wall132µs、CPU5,419µs。その導出endの40µs後に、次の同thread ParseHTML startがあり、CPUは3µsだけ進んでいる。ParseHTMLのBEGIN/END双方に明示timestampはなく、通常取得経路を使う。

1ms超の169イベントすべてに次の同thread I/X startがあり、168件ではend→次startのwall gapがCPU超過より短い。この関係は別実装の再集計でも一致した。従って、単に「endのCPU readが約5ms遅れた」とだけ説明するには、後続wall時刻と整合する追加根拠が必要になる。

導出endはJSONのts+dur/tts+tdurであり、次startもexportされた時刻である。元の個別clock read・protobuf packet・counter resetを復元できていないため、取得ずれ説を断定も排除もしない。boundary-gap-review.jsonとindependent-boundary-source-check.jsonに式と証拠を保存した。

## 同じOS APIの固定native診断

実行前にNATIVE_PLAN.mdを保存し、4runそれぞれ1thread/8threadの順を反転して8fresh processを直列実行した。各thread128区間、計4,608。busy、yield、sleepと、既知の末尾CPU読取り遅延を加えた対照を使った。affinity・優先度・kernel設定は変更していない。

共通読取りはwall0→CPU0→wall1→work→wall2→（対照だけ追加work）→CPU1→wall3。CPU差を外側wall3−wall0で包み、別途、非同時wall2−wall0との差も保存した。

| 条件 | 区間数 | 外側wallを超えるCPU差 |
| --- | ---: | ---: |
| 1thread | 512 | 0 |
| 8thread | 4,096 | 0 |
| 合計 | 4,608 | 0 |

既知の約1ms目標の末尾遅延対照では、非同時wallに対して1,151/1,152区間でCPU差が上回った。意図的遅延なしの条件にも数µsの非同時超過があり、最大3,493nsだった。外側bracketは全件成立した。閾値でこれらを消していない。

8threadでは区間前後のcore番号差が計61件あり、context switchや共有cgroup throttle増分も記録された。これは負荷条件の観測で、共有値を各threadやゲームへ配賦しない。busyはwall期限であり、固定量のCPU仕事ではない。

この結果は「非同時取得だけでも形式上のCPU>wallを作れる」という対照であり、元の169件の原因を特定しない。別process・負荷・実装でのOS API診断が整合しても、Chromiumのtts/tdurを承認する根拠にはしない。全端点、元stdout、source/plan/script/binary hashと導出値を独立照合した。NATIVE_REVIEW.mdとnative-independent-review.json参照。

## 何を引き継ぐか

今回確定したのは、全traceに広がる局所的なCPU会計の問題、取得経路、export経路、単純な説明への隣接制約、別native API診断の結果である。CPU時計の根本原因、kernel/VM、producer/processorの個別問題やそれぞれの寄与は未確定。

段階14のwall・入力・描画イベントの記録は保持するが、CPU差による厳密な処理/待機量の配分は保留する。次に原因を絞るには、元protobufのcounter/sequence/resetと独立したthread CPU記録を同時に取る等の追加証拠が必要。今回は新しいブラウザー試行を増やしていない。

過去のHARD増加原因、未確定62条件、段階8のraster/GPU寄与、全経路の厳密な非悪化の判定は更新しない。再現はREPRODUCE.md、実装レビューはSOURCE_CLOCK_REVIEW.md、全raw点検はRAW_CLOCK_REVIEW.md。
