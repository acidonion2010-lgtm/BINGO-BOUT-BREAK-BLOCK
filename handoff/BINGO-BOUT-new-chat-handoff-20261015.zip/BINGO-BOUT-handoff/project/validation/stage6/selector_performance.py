#!/usr/bin/env python3
"""Extend the existing real-HTML selector comparison to HARD fallback paths."""
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'stage3'))
import frame_performance as benchmark


def main():
    benchmark.ROOT = Path(__file__).resolve().parents[2]
    benchmark.PATHS = [*benchmark.PATHS,
        {'name': 'hard-fallback-legacy-roll', 'difficulty': 'hard',
         'engine': 'fallback', 'roll': 0.3},
        {'name': 'hard-fallback-dp-roll', 'difficulty': 'hard',
         'engine': 'fallback', 'roll': 0.8},
    ]
    # Keep terminal full-DP exclusions, but include the legal one-candidate
    # NORMAL/HARD legacy selector contracts as well as fallback contracts.
    benchmark.SCENARIOS = [{key: value for key, value in scenario.items()
                            if key != 'fallbackOnly'}
                           for scenario in benchmark.SCENARIOS]
    anchor = '      this.expectedCell = cell;\n'
    assert benchmark.INSTALL_BENCH.count(anchor) == 1
    benchmark.INSTALL_BENCH = benchmark.INSTALL_BENCH.replace(anchor, anchor + r'''
      const seen = counters();
      const hard = this.spec.difficulty === 'hard';
      const full = this.spec.engine === 'ready' &&
        (this.spec.difficulty === 'master' || (hard && this.spec.roll >= 0.7));
      const expected = {whole:full ? 1 : 0,
        fallback:this.spec.difficulty === 'master' && this.spec.engine === 'fallback' ? 1 : 0,
        hardLegacy:hard && !full ? 1 : 0, hardFull:hard && full ? 1 : 0};
      for (const key of Object.keys(expected)) {
        if (seen[key] !== expected[key]) throw new Error('Unexpected selector dispatch: '+key);
      }
''', 1)
    status = benchmark.main()
    # The shared CLI accepts before, after, output and an optional --port.
    output = Path(sys.argv[3])
    if output.exists():
        result = json.loads(output.read_text())
        result['conditions']['verification'] = 'stage6; production remains stage5'
        result['conditions']['addedCoverage'] = [
            'HARD fallback with both mixture rolls, both first players and roles',
            'NORMAL/HARD legacy with one closed cell',
            'Probe dispatch counters checked against intended branch',
        ]
        result['conditions']['oneClosedLimit'] = (
            'Legal selector contract checks; terminal full-DP states are excluded. '
            'These are not timings of user interactions after match termination.')
        result['conditions']['productionModified'] = False
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    return status


if __name__ == '__main__':
    raise SystemExit(main())
