#!/usr/bin/env python3
"""Fixed-budget, same-realm MASTER fallback wrapper diagnostic (experiment C)."""
from __future__ import annotations

import argparse
import ast
import functools
import hashlib
import http.server
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import statistics
import sys
import tempfile
import threading

# Importing the frozen shared harness must not create or update its pycache.
sys.dont_write_bytecode = True
from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
WORKSPACE = Path('/workspace')
PROJECT = WORKSPACE / 'handoff/BINGO-BOUT-handoff/project'
PARENT_PATH = HERE / 'wrapper_crossover.py'
PARENT_HASH = '1744417f1f556a073dd2082505b1a9b6199eb5b01f5e1cba54b3a1359af5d291'
SHARED_PATH = PROJECT / 'validation/stage3/frame_performance.py'
SHARED_HASH = '238e31ab7695f7b80b7c59d05270e054124c13774f731d412f630eb253195cf7'
SOURCES = {'stage5': PROJECT / 'stages/index.handoff-20261015.html',
           'stage9': PROJECT / 'index.html'}
EXPECTED = {'stage5': 'fea09e995bfc1036515b92771925bd7968f3c453425ea5517b7a5b480293be64',
            'stage9': '59fff4685ff3f36e18d73fe9fa524ee57d81a348352e7b2912db4b7ecc1bb513'}
WORKER_HASH = '9d54c0c06f6f80320d3f3e07284b75d39a9ebbe3163321ca964ca685aeecb722'
POLICY_HASH = '84d2383a7ba73a9b1e057be396f2a867b675580b6e77961b4c1b5eeb23696008'
CHANGED = ['getCpuSelectionWeights', 'prepareCpuBreakCandidates',
           'selectCpuLegacyCell', 'selectCpuBreakCell']
RUNS, PAIRS, COUNT, WARMUP, BATCH_WARMUP = 8, 9, 100_000, 50_000, 2_000
RUN_SPECS = [(0, 0), (1, 0), (1, 1), (0, 1), (0, 1), (1, 1), (1, 0), (0, 0)]
COMPARISONS = [('oldA_to_new', 'oldA', 'new'), ('distinct_old_AA', 'oldA', 'oldB'),
               ('native_to_oldA', 'nativeOld', 'oldA'), ('same_reference_AA', 'oldA', 'oldA')]
CASES = [{'id': 'p2-opening-master-fallback-break', 'firstPlayer': 2}]

INSTALL = r'''({oldSource,newSource,constructionOrder}) => {
  const bench=window.__frameCpuBench;
  const nativeOld=selectCpuBreakCell;
  const variants={nativeOld};
  for(const name of constructionOrder) {
    const source=name==='new'?newSource:oldSource;
    variants[name]=(new Function(source+'\nreturn selectCpuBreakCell;'))();
  }
  if(variants.oldA===variants.oldB || variants.oldA===variants.new || nativeOld===variants.oldA)
    throw Error('Expected distinct native/clone function references');
  let fixedRoll=0.8;
  const fixedRandom=()=>fixedRoll;
  Math.random=fixedRandom;
  const exact=(a,b)=> {
    if(typeof a!==typeof b)return false;
    if(a===null||b===null||typeof a!=='object')return Object.is(a,b);
    const keys=Object.keys(a);
    return keys.length===Object.keys(b).length && keys.every(k=>Object.hasOwn(b,k)&&exact(a[k],b[k]));
  };
  const counters=()=>({whole:cpuWholeDecisions,fallback:cpuWholeLegacyDecisions,
    hardLegacy:hardLegacyDecisions,hardFull:hardDpDecisions});
  const history=()=>({breakCell:state.cpuBlockedBreakCell,breakStreak:state.cpuBlockedBreakStreak,
    breakCooldown:state.cpuBlockedCooldown,blockCell:state.cpuSuccessfulBlockCell,
    blockStreak:state.cpuSuccessfulBlockStreak,blockCooldown:state.cpuSuccessfulBlockCooldown});
  const publicState=()=>({gameMode:state.gameMode,difficulty:state.cpuDifficulty,seatChosen:state.seatChosen,
    isStarting:state.isStarting,gameEnded:state.gameEnded,isProcessing:state.isProcessing,
    phase:state.phase,firstPlayer:state.firstPlayer,inning:state.inning,turnRole:state.turnRole,
    selectedBreakCell:state.selectedBreakCell,p1Turns:state.p1TurnsTaken,p2Turns:state.p2TurnsTaken,
    p1Marks:state.p1Marks.slice(),p2Marks:state.p2Marks.slice(),
    p1Layout:state.p1NumberLayout.slice(),p2Layout:state.p2NumberLayout.slice()});
  const slots=[
    ['getCpuSelectionWeights',()=>getCpuSelectionWeights,v=>{getCpuSelectionWeights=v}],
    ['prepareCpuBreakCandidates',()=>prepareCpuBreakCandidates,v=>{prepareCpuBreakCandidates=v}],
    ['selectCpuLegacyCell',()=>selectCpuLegacyCell,v=>{selectCpuLegacyCell=v}],
    ['getCellWeights',()=>getCellWeights,v=>{getCellWeights=v}],
    ['selectWholeGameCpuCell',()=>selectWholeGameCpuCell,v=>{selectWholeGameCpuCell=v}],
    ['selectHardMixedCell',()=>selectHardMixedCell,v=>{selectHardMixedCell=v}],
    ['selectHardLegacyCell',()=>selectHardLegacyCell,v=>{selectHardLegacyCell=v}],
    ['WholeGameDP.solve',()=>WholeGameDP.prototype.solve,v=>{WholeGameDP.prototype.solve=v}],
    ['WholeGameDP.analyze',()=>WholeGameDP.prototype.analyze,v=>{WholeGameDP.prototype.analyze=v}],
    ['CpuEquilibriumSolver.equilibrium',()=>CpuEquilibriumSolver.prototype.equilibrium,v=>{CpuEquilibriumSolver.prototype.equilibrium=v}],
    ['CpuEquilibriumSolver.strategyGap',()=>CpuEquilibriumSolver.prototype.strategyGap,v=>{CpuEquilibriumSolver.prototype.strategyGap=v}],
  ].map(([name,get,set])=>({name,get,set,original:get()}));
  const equilibriumRef=selectCpuEquilibriumCell;
  const bundleRef=cpuEqBundle;
  let numericElements=0,arrayNodes=0;
  function captureArray(ref) {
    if(!Array.isArray(ref)&&!ArrayBuffer.isView(ref))throw Error('Unexpected table array');
    arrayNodes++;
    const present=Array.from({length:ref.length},(_,i)=>Object.hasOwn(ref,i));
    const values=Array.from(ref);
    const children=[];
    for(let i=0;i<values.length;i++) {
      if(typeof values[i]==='number')numericElements++;
      if(Array.isArray(values[i])||ArrayBuffer.isView(values[i]))children.push([i,captureArray(values[i])]);
    }
    return {ref,length:ref.length,present,values,children};
  }
  const tableSnapshots=['p1','p2'].map(player=> {
    const ref=bundleRef[player];
    return {player,ref,arrays:['layout','values','breakProbs','blockProbs'].map(key=>[key,captureArray(ref[key])])};
  });
  function checkArray(snap) {
    if(snap.ref.length!==snap.length)throw Error('Table array length changed');
    for(let i=0;i<snap.length;i++) {
      if(Object.hasOwn(snap.ref,i)!==snap.present[i] || !Object.is(snap.ref[i],snap.values[i]))
        throw Error('Table array reference/numeric value changed');
    }
    for(const [,child] of snap.children)checkArray(child);
  }
  function checkTables() {
    if(cpuEqBundle!==bundleRef)throw Error('Fallback bundle reference changed');
    for(const table of tableSnapshots) {
      if(cpuEqBundle[table.player]!==table.ref)throw Error('Fallback table reference changed');
      for(const [key,snap] of table.arrays) {
        if(table.ref[key]!==snap.ref)throw Error('Fallback table root array changed');
        checkArray(snap);
      }
    }
  }
  let refs=null,stable=null,expectedHistory=null,fixture=null;
  function install(name) {
    if(!Object.hasOwn(variants,name))throw Error('Unknown wrapper variant');
    selectCpuBreakCell=variants[name];
  }
  function reset() {
    cpuWholeDecisions=cpuWholeLegacyDecisions=hardLegacyDecisions=hardDpDecisions=0;
    Object.assign(state,{cpuBlockedBreakCell:0,cpuBlockedBreakStreak:2,cpuBlockedCooldown:0,
      cpuSuccessfulBlockCell:0,cpuSuccessfulBlockStreak:2,cpuSuccessfulBlockCooldown:0});
  }
  function assertStable(auditing=false) {
    if(!refs || bench.dp!==refs.dp || bench.dp.layers!==refs.layers ||
       refs.layers.some((layer,i)=>layer.values!==refs.dpValues[i]) ||
       cpuWholeDp!==null || cpuWholeStatus!=='fallback' ||
       state.p1Marks!==refs.p1Marks || state.p2Marks!==refs.p2Marks ||
       state.p1NumberLayout!==refs.p1Layout || state.p2NumberLayout!==refs.p2Layout ||
       bench.available!==refs.available || !exact(bench.available,refs.availableValues) ||
       !exact(publicState(),stable) || !exact(history(),expectedHistory))
      throw Error('Fixture/input/history/receiver/table-reference changed');
    if(selectCpuEquilibriumCell!==equilibriumRef)throw Error('Equilibrium selector changed');
    if(!auditing && slots.some(slot=>slot.get()!==slot.original))throw Error('Audit hook or helper change remained');
    checkTables();
  }
  function verify(answer,count,expectedCell=7,auditing=false) {
    if(answer.lastCell!==expectedCell || answer.checksum!==count*(expectedCell+1))
      throw Error('Selector checksum/cell changed');
    if(!exact(counters(),{whole:0,fallback:count,hardLegacy:0,hardFull:0}))
      throw Error('Unexpected dispatch counter delta');
    assertStable(auditing);
  }
  function audit(name) {
    install(name);
    const forbidden=Object.fromEntries(slots.map(slot=>[slot.name,0]));
    const draws=[];
    Math.random=()=>{draws.push(fixedRoll);return fixedRoll};
    for(const slot of slots)slot.set(function(){forbidden[slot.name]++;throw Error('Forbidden audit path: '+slot.name)});
    const calls=[],rollChecks=[];
    try {
      for(let i=0;i<16;i++) {
        fixedRoll=0.8;reset();const before=draws.length;
        const answer=bench.loop(1);verify(answer,1,7,true);
        const consumed=draws.slice(before);
        if(!exact(consumed,[0.8]))throw Error('Expected exactly one fixed RNG draw');
        calls.push({answer,draws:consumed,counters:counters(),history:history()});
      }
      for(const roll of [0,0.1,0.3,0.5,0.8,0.999999999999]) {
        fixedRoll=roll;reset();const before=draws.length;
        const expected=drawCpuEqDistribution(refs.policy,0,roll);
        const answer=bench.loop(1);verify(answer,1,expected,true);
        if(!exact(draws.slice(before),[roll]))throw Error('Multi-roll RNG audit failed');
        reset();const suppliedBefore=draws.length;
        const cell=selectCpuBreakCell(refs.available,{sample:roll});
        verify({lastCell:cell,checksum:cell+1},1,expected,true);
        if(draws.length!==suppliedBefore)throw Error('Supplied sample unexpectedly drew RNG');
        rollChecks.push({roll,cell,draws:[roll],suppliedSampleCell:cell,suppliedSampleDraws:0});
      }
    } finally {
      for(const slot of slots)slot.set(slot.original);
      fixedRoll=0.8;Math.random=fixedRandom;reset();
    }
    if(Object.values(forbidden).some(value=>value!==0))throw Error('Forbidden audit calls recorded');
    assertStable();
    return {name,calls,rollChecks,forbiddenCalls:forbidden};
  }
  window.__wrapperCrossover={
    async prepare(first) {
      refs=stable=null;install('nativeOld');fixedRoll=0.8;Math.random=fixedRandom;
      const prepared=await bench.prepare(first);
      if(cpuWholeStatus!=='ready'||!bench.dp)throw Error('Real Worker did not prepare DP');
      checkTables();return prepared;
    },
    async configure(nextFixture) {
      fixture=nextFixture;install('nativeOld');fixedRoll=0.8;Math.random=fixedRandom;
      const decision=bench.configure({name:'master-fallback',difficulty:'master',engine:'fallback',roll:0.8,
        role:'break',maskP1:0,maskP2:0,baseT:0});
      if(decision.skip || decision.remaining!==9 || state.p2TurnsTaken!==0)throw Error('Wrong opening fixture');
      refs={dp:bench.dp,layers:bench.dp.layers,dpValues:bench.dp.layers.map(layer=>layer.values),
        p1Marks:state.p1Marks,p2Marks:state.p2Marks,p1Layout:state.p1NumberLayout,p2Layout:state.p2NumberLayout,
        available:bench.available,availableValues:bench.available.slice(),policy:cpuEqBundle.p2.breakProbs[9][0]};
      stable=publicState();reset();expectedHistory=history();assertStable();
      const audits=[];
      for(const name of ['nativeOld','oldA','oldB','new'])audits.push(audit(name));
      for(const other of audits.slice(1)) {
        if(!exact(audits[0].calls,other.calls)||!exact(audits[0].rollChecks,other.rollChecks))
          throw Error('Wrapper audit contract differs');
      }
      const policyRow={value:cpuEqBundle.p2.values[9][0],break:Array.from(refs.policy),
        block:Array.from(cpuEqBundle.p2.blockProbs[9][0])};
      const values=[policyRow.value,...policyRow.break,...policyRow.block];
      const bytes=new ArrayBuffer(values.length*8),view=new DataView(bytes);
      values.forEach((value,i)=>view.setFloat64(i*8,value,false));
      const digest=await crypto.subtle.digest('SHA-256',bytes);
      const policyRowSha256=Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join('');
      assertStable();
      return {fixture,decision,policyRow,policyRowSha256,audits,stablePublicState:stable,
        numericElementsVerifiedPerTableScan:numericElements,arrayNodesVerifiedPerTableScan:arrayNodes};
    },
    warm({name,count}) {
      install(name);fixedRoll=0.8;reset();assertStable();
      const answer=bench.loop(count);verify(answer,count);
      return {name,count,...answer,counters:counters()};
    },
    sample({name,count,batchWarmup}) {
      install(name);fixedRoll=0.8;reset();assertStable();
      if(Math.random!==fixedRandom)throw Error('Timed RNG reference changed');
      const warm=bench.loop(batchWarmup);verify(warm,batchWarmup);
      reset();assertStable();
      const startMs=performance.now();
      const answer=bench.loop(count);
      const endMs=performance.now();
      const startNs=Math.round(startMs*1e6),endNs=Math.round(endMs*1e6);
      if(!Number.isSafeInteger(startNs)||!Number.isSafeInteger(endNs)||endMs<startMs)
        throw Error('Invalid exposed-clock endpoints');
      verify(answer,count);
      if(Math.random!==fixedRandom)throw Error('Timed RNG reference changed after sample');
      return {name,count,batchWarmup,startMs,endMs,startNs,endNs,elapsedMs:endMs-startMs,
        endpointElapsedNs:endNs-startNs,...answer,counters:counters(),history:history(),status:cpuWholeStatus};
    },
    references(a,b) {return variants[a]===variants[b]},
    finishFixture() {assertStable();releaseWholeGameCpu();bench.dp=null;refs=stable=null;},
    cleanup() {selectCpuBreakCell=nativeOld;for(const slot of slots)slot.set(slot.original);bench.cleanup();},
  };
  return {constructionOrder,variantSources:Object.fromEntries(Object.entries(variants).map(([k,v])=>[k,v.toString()])),
    distinctOldReferences:variants.oldA!==variants.oldB,visibility:document.visibilityState,
    crossOriginIsolated,timeOrigin:performance.timeOrigin,
    compilation:'Only exact selectCpuBreakCell declarations cloned with new Function; other helpers retain native references.',
    tableVerification:'All fallback table array references, holes and numeric elements (Object.is, including NaN/signed zero) checked outside every arm.',
    timing:'One RPC per arm; all variants use unchanged shared bench.loop; JSON writes occur only after complete pairs.'};
}'''


def sha(data):
    return hashlib.sha256(data).hexdigest()


def validate_parent():
    raw = PARENT_PATH.read_bytes()
    if sha(raw) != PARENT_HASH:
        raise ValueError('Frozen B parent script hash mismatch')
    module = ast.parse(raw.decode())
    assignments = [node.value for node in module.body if isinstance(node, ast.Assign)
                   and any(isinstance(target, ast.Name) and target.id == 'INSTALL' for target in node.targets)]
    if len(assignments) != 1:
        raise ValueError('Expected one frozen B INSTALL assignment')
    parent_install = ast.literal_eval(assignments[0])
    parent_anchor = "for(const name of ['nativeOld',...constructionOrder])audits.push(audit(name));"
    fixed_anchor = "for(const name of ['nativeOld','oldA','oldB','new'])audits.push(audit(name));"
    if (parent_install.count(parent_anchor) != 1 or INSTALL.count(fixed_anchor) != 1
            or parent_install.count(fixed_anchor) != 0 or INSTALL.count(parent_anchor) != 0
            or INSTALL.replace(fixed_anchor, parent_anchor, 1) != parent_install):
        raise ValueError('C INSTALL differs from frozen B beyond the one fixed audit-order line')
    if len(RUN_SPECS) != RUNS or any(RUN_SPECS.count((c, e)) != 2 for c in (0, 1) for e in (0, 1)):
        raise ValueError('Invalid 2x2x2 independent-factor allocation')
    return {'path': str(PARENT_PATH), 'sha256': sha(raw),
            'parentInstallSha256': sha(parent_install.encode()), 'cInstallSha256': sha(INSTALL.encode()),
            'installMatchesFrozenBExceptFixedAuditOrder': True,
            'fixedAuditOrder': ['nativeOld', 'oldA', 'oldB', 'new'],
            'normalization': {'parentAnchor': parent_anchor, 'fixedAnchor': fixed_anchor, 'replacementCount': 1}}


def load_shared():
    if sha(SHARED_PATH.read_bytes()) != SHARED_HASH:
        raise ValueError('Shared harness source hash mismatch')
    spec = importlib.util.spec_from_file_location('stage12_shared_frame', SHARED_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def extract_functions(source):
    found, spans = {}, []
    for name in CHANGED:
        matches = list(re.finditer(r'^        function ' + re.escape(name) + r'\(', source, re.M))
        if len(matches) != 1:
            raise ValueError('Expected one declaration: ' + name)
        match = matches[0]
        closing = re.search(r'^        }(?=\r?$)', source[match.end():], re.M)
        if closing is None:
            raise ValueError('No closing brace: ' + name)
        end = match.end() + closing.end()
        found[name] = source[match.start():end]
        spans.append((match.start(), end, name))
    normalized = source
    for start, end, name in sorted(spans, reverse=True):
        normalized = normalized[:start] + '<CHANGED:' + name + '>' + normalized[end:]
    return found, normalized


def atomic_save(path, value):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', dir=path.parent, prefix=path.name+'.tmp.', delete=False) as handle:
            temporary = Path(handle.name)
            json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
            handle.write('\n')
        os.replace(temporary, path)
    finally:
        if temporary and temporary.exists():
            temporary.unlink()


def summarize(pairs, shared):
    if not pairs:
        return None
    integer = [pair['b']['endpointElapsedNs'] - pair['a']['endpointElapsedNs'] for pair in pairs]
    per_call = [value / COUNT / 1000 for value in integer]
    raw = [(pair['b']['elapsedMs'] - pair['a']['elapsedMs']) * 1000 / COUNT for pair in pairs]
    return {'pairedBatchCount': len(pairs),
            'aMedianUs': statistics.median(pair['a']['endpointElapsedNs'] / COUNT / 1000 for pair in pairs),
            'bMedianUs': statistics.median(pair['b']['endpointElapsedNs'] / COUNT / 1000 for pair in pairs),
            'pairedDurationDeltasNs': integer, 'pairedDeltasUs': per_call,
            'pairedMedianDeltaUs': statistics.median(per_call),
            'positivePairs': sum(value > 0 for value in integer),
            'negativePairs': sum(value < 0 for value in integer), 'zeroPairs': integer.count(0),
            'interval95': shared.median_interval(per_call),
            'rawFloatPairedDeltasUs': raw, 'rawFloatPairedMedianDeltaUs': statistics.median(raw)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError('Refusing to overwrite '+str(args.output))
    parent = validate_parent()
    shared = load_shared()
    source_bytes = {name: path.read_bytes() for name, path in SOURCES.items()}
    for name, contents in source_bytes.items():
        if sha(contents) != EXPECTED[name]:
            raise ValueError(name+' input hash mismatch')
    extracted = {name: extract_functions(contents.decode()) for name, contents in source_bytes.items()}
    if extracted['stage5'][1] != extracted['stage9'][1]:
        raise ValueError('Unexpected changes outside four stage9 functions')
    if any(extracted['stage5'][0][name] == extracted['stage9'][0][name] for name in CHANGED):
        raise ValueError('Expected four changed function declarations')
    old_source = extracted['stage5'][0]['selectCpuBreakCell']
    new_source = extracted['stage9'][0]['selectCpuBreakCell']
    result = {'status': 'running', 'experiment': 'C: independent construction/execution-factor wrapper crossover',
              'scriptSha256': sha(Path(__file__).read_bytes()), 'planSha256': sha((HERE/'ORDER_PLAN.md').read_bytes()),
              'planPath': str(HERE/'ORDER_PLAN.md'), 'parentExperimentB': parent,
              'sharedHarness': {'path': str(SHARED_PATH), 'sha256': sha(SHARED_PATH.read_bytes()),
                                'installSha256': sha(shared.INSTALL_BENCH.encode())},
              'inputs': {name: {'path': str(SOURCES[name]), 'sha256': sha(contents), 'bytes': len(contents)}
                         for name, contents in source_bytes.items()},
              'sourceIntegrity': {'onlyFourFunctionsDiffer': True, 'onlyWrapperSwappedInTimedWork': True,
                                  'oldWrapperSha256': sha(old_source.encode()), 'newWrapperSha256': sha(new_source.encode())},
              'conditions': {'runs': RUNS, 'runSpecs': [{'constructionFactor': c, 'executionFactor': e} for c, e in RUN_SPECS],
                             'factorMeaning': {'C0': 'oldA/oldB/new construction', 'C1': 'new/oldB/oldA construction',
                                               'E0': 'forward warm/comparison/initial-arm orders', 'E1': 'reversed warm/comparison/initial-arm orders'},
                             'fixedAuditOrder': ['nativeOld', 'oldA', 'oldB', 'new'],
                             'cases': CASES, 'comparisons': COMPARISONS, 'pairedBatches': PAIRS,
                             'callsPerBatch': COUNT, 'initialWarmupEachVariant': WARMUP, 'armWarmup': BATCH_WARMUP,
                             'timedChoicesPlanned': RUNS*len(CASES)*len(COMPARISONS)*PAIRS*2*COUNT,
                             'warmupChoicesPlanned': RUNS*len(CASES)*(4*WARMUP+len(COMPARISONS)*PAIRS*2*BATCH_WARMUP),
                             'viewport': [1280, 900], 'executable': '/usr/bin/chromium',
                             'layouts': shared.LAYOUTS, 'rng': 'Same uncounted fixedRandom object in all timed arms, value 0.8; rolls argument omitted.',
                             'partialSave': 'Atomic JSON after every complete paired batch; failed current operation is identified.',
                             'verification': '16 fixed RNG calls plus six native-RNG-branch fixed rolls and six supplied-roll checks per variant/fixture; audit hooks removed before all warmups.',
                             'limitations': ['New Function identities may share V8 compilation metadata.',
                                             'Swapping functions and native/clone ownership alter JIT/caller feedback.',
                                             'Full fallback numeric scans and protocol gaps outside timing affect runtime history.',
                                             'Within-process batches are dependent; intervals are conditional descriptions.',
                                             'Not native RNG cost, VM-cold calls, whole-game latency or universal non-regression.']},
              'runs': [], 'combined': [], 'currentOperation': None}
    # Reserve the output name exclusively before writing any partial results.
    with args.output.open('x') as handle:
        json.dump(result, handle, ensure_ascii=False, allow_nan=False)

    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *unused):
            pass

    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0),
                 functools.partial(Handler, directory=str(WORKSPACE)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        with sync_playwright() as playwright:
            for run, (construction_factor, execution_factor) in enumerate(RUN_SPECS):
                replicate = RUN_SPECS[:run+1].count((construction_factor, execution_factor))
                record = {'run': run+1, 'constructionFactor': construction_factor, 'executionFactor': execution_factor,
                          'factorReplicate': replicate,
                          'factors': {'construction': construction_factor, 'executionReverse': execution_factor,
                                      'replicate': replicate},
                          'pageErrors': [], 'fixtures': [], 'rows': []}
                result['runs'].append(record)
                result['currentOperation'] = {'run': run+1, 'phase': 'load'}
                atomic_save(args.output, result)
                browser = playwright.chromium.launch(executable_path='/usr/bin/chromium', headless=True,
                            args=['--no-sandbox', '--disable-dev-shm-usage'])
                try:
                    record['browserVersion'] = browser.version
                    page = browser.new_page(viewport={'width': 1280, 'height': 900})
                    page.set_default_navigation_timeout(60_000)
                    page.on('pageerror', lambda error, rec=record: rec['pageErrors'].append(str(error)))
                    path = SOURCES['stage5'].relative_to(WORKSPACE).as_posix()
                    response = page.goto(f'http://127.0.0.1:{server.server_port}/{path}', wait_until='load')
                    if response.status != 200:
                        raise RuntimeError('Unexpected HTTP response')
                    page.bring_to_front()
                    tests = json.loads(page.locator('#rule-test-results').text_content())
                    record['selfTests'] = tests
                    if tests['passed'] != 322 or tests['total'] != 322 or tests['failures']:
                        raise RuntimeError('Automatic self-tests failed')
                    if record['pageErrors']:
                        raise RuntimeError('Browser page errors during load')
                    record['benchSetup'] = page.evaluate(shared.INSTALL_BENCH, shared.LAYOUTS)
                    construction_order = ['oldA', 'oldB', 'new'] if construction_factor == 0 else ['new', 'oldB', 'oldA']
                    setup = page.evaluate(INSTALL, {'oldSource': old_source, 'newSource': new_source,
                                                  'constructionOrder': construction_order})
                    # Store source hashes without repeating long declarations in output.
                    variant_sources = setup.pop('variantSources')
                    setup['variantSourceSha256'] = {name: sha(value.encode()) for name, value in variant_sources.items()}
                    for name, value in variant_sources.items():
                        expected = new_source.lstrip() if name == 'new' else old_source.lstrip()
                        if value != expected:
                            raise RuntimeError('Native/clone source differs: '+name)
                    record['setup'] = setup
                    if setup['visibility'] != 'visible' or setup['crossOriginIsolated']:
                        raise RuntimeError('Unexpected visibility/clock isolation')
                    if record['pageErrors']:
                        raise RuntimeError('Browser page errors during setup')
                    cases = CASES if execution_factor == 0 else list(reversed(CASES))
                    comparisons = COMPARISONS if execution_factor == 0 else list(reversed(COMPARISONS))
                    warm_order = ['nativeOld', 'oldA', 'oldB', 'new']
                    if execution_factor:
                        warm_order.reverse()
                    record['caseOrder'] = [case['id'] for case in cases]
                    record['comparisonOrder'] = [item[0] for item in comparisons]
                    record['initialWarmOrder'] = warm_order
                    for case in cases:
                        result['currentOperation'] = {'run': run+1, 'case': case['id'], 'phase': 'prepare/configure'}
                        atomic_save(args.output, result)
                        preparation = page.evaluate('first=>__wrapperCrossover.prepare(first)', case['firstPlayer'])
                        worker_source = page.evaluate('wholeGameWorkerSource()')
                        if sha(worker_source.encode()) != WORKER_HASH:
                            raise RuntimeError('Real Worker source hash changed')
                        stats = preparation['stats']
                        if not (stats['valueTableBytes'] == 18_324_976 and 0 <= stats['maxGap'] <= 1e-5
                                and math.isfinite(stats['initialValue'])):
                            raise RuntimeError('Worker DP stats mismatch')
                        configured = page.evaluate('fixture=>__wrapperCrossover.configure(fixture)', case)
                        if configured['policyRowSha256'] != POLICY_HASH:
                            raise RuntimeError('Target policy row binary hash mismatch')
                        if record['pageErrors']:
                            raise RuntimeError('Browser page errors during prepare/audit')
                        fixture_record = {'case': case, 'preparation': preparation,
                                          'workerSourceSha256': sha(worker_source.encode()), 'configured': configured,
                                          'warmups': []}
                        record['fixtures'].append(fixture_record)
                        for name in warm_order:
                            fixture_record['warmups'].append(page.evaluate('config=>__wrapperCrossover.warm(config)',
                                                                          {'name': name, 'count': WARMUP}))
                        for comparison, a_name, b_name in comparisons:
                            same = page.evaluate('names=>__wrapperCrossover.references(...names)', [a_name, b_name])
                            if same != (comparison == 'same_reference_AA'):
                                raise RuntimeError('Wrong same-reference comparison')
                            row = {'caseId': case['id'], 'comparison': comparison, 'aName': a_name,
                                   'bName': b_name, 'sameFunctionReferences': same, 'pairs': []}
                            record['rows'].append(row)
                            for pair in range(PAIRS):
                                order = ['a', 'b'] if (pair+execution_factor) % 2 == 0 else ['b', 'a']
                                sampled = {}
                                row['incompletePair'] = {'pair': pair+1, 'order': order, 'samples': sampled}
                                for side in order:
                                    name = a_name if side == 'a' else b_name
                                    result['currentOperation'] = {'run': run+1, 'case': case['id'],
                                        'comparison': comparison, 'pair': pair+1, 'arm': side, 'variant': name}
                                    sampled[side] = page.evaluate('config=>__wrapperCrossover.sample(config)',
                                        {'name': name, 'count': COUNT, 'batchWarmup': BATCH_WARMUP})
                                    if record['pageErrors']:
                                        raise RuntimeError('Browser page error')
                                for key in ('checksum', 'lastCell', 'counters', 'history', 'status'):
                                    if sampled['a'][key] != sampled['b'][key]:
                                        raise RuntimeError('Paired contract differs: '+key)
                                row['pairs'].append({'pair': pair+1, 'order': order, **sampled})
                                del row['incompletePair']
                                row['summary'] = summarize(row['pairs'], shared)
                                atomic_save(args.output, result)
                            print(f'C run{run+1} C{construction_factor}E{execution_factor} {case["id"]} {comparison}: '
                                  f'{row["summary"]["pairedMedianDeltaUs"]:+.6f} us/choice', flush=True)
                        page.evaluate('__wrapperCrossover.finishFixture()')
                    page.evaluate('__wrapperCrossover.cleanup()')
                    if record['pageErrors']:
                        raise RuntimeError('Browser page errors recorded')
                finally:
                    browser.close()
        for case in CASES:
            for comparison, _, _ in COMPARISONS:
                matching = [(record['run'], row) for record in result['runs'] for row in record['rows']
                            if row['caseId'] == case['id'] and row['comparison'] == comparison]
                classifications = [row['summary']['interval95']['classification'] for _, row in matching]
                repeated = classifications[0] if len(set(classifications)) == 1 else 'unconfirmed'
                result['combined'].append({'caseId': case['id'], 'comparison': comparison,
                    'runSummaries': [{'run': run, **row['summary']} for run, row in matching],
                    'repeatedClassification': repeated,
                    'pooledConditionalDescription': summarize([pair for _, row in matching for pair in row['pairs']], shared)})
        result['timedChoicesCompleted'] = sum(len(row['pairs'])*2*COUNT for record in result['runs'] for row in record['rows'])
        if result['timedChoicesCompleted'] != result['conditions']['timedChoicesPlanned']:
            raise RuntimeError('Fixed timed-choice budget mismatch')
        result['functionalEquivalence'] = True
        result['status'] = 'completed'
        result['currentOperation'] = None
    except BaseException as error:
        result['status'] = 'failed'
        result['error'] = repr(error)
        raise
    finally:
        atomic_save(args.output, result)
        server.shutdown()
        server.server_close()


if __name__ == '__main__':
    main()
