# CPU時計の追加診断（実行前固定）

クリック計測完了後、保存traceの3区間で同一thread CPU差がwallを2.283〜6.720ms上回った。TimeStampでも同様で、単純なmark startTimeのserializationだけでは説明できない。元report・trace・analysis・分析器を保持し、再計測・標本除外・残差の0補正をしない。

1. 保存データだけからaudit_clocks.pyで該当3区間、両marker時計、同じ応答と交差する完了Xのdur/tdur、近傍イベントをclock-audit.jsonへ保存する。完了Xの全区間CPU>wallも記録するが、clipped CPUへの線形配賦はしない。
2. Linux CLOCK_MONOTONICとCLOCK_THREAD_CPUTIME_IDの短区間を独立のnative helperで検証する。ブラウザー/アプリを追加起動しない。
3. cc -std=c11 -O2 -Wall -Wextra -Werrorでhelperをコンパイルし、4fresh process×128sample=512区間を1回だけ実行する。各processで、busy1ms、busy4ms、busy1ms+sleep2ms、busy4ms+sleep2msの4条件を32回ずつ、この順に反復する。全標本を保存しwarmup除外なし。
4. wall0→CPU0→wall1→busy/sleep→wall2→CPU1→wall3の順で読取り、CPU区間を外側wallで包む。各ns端点とCPU coreを保存し、0<=CPU1−CPU0<=wall3−wall0を確認する。絶対原点を異なる時計間で減算しない。
5. native helperで整合してもChromium traceのCPU会計を承認しない。異なるprocess・取得法・負荷/移動/仮想化履歴であり、OS全般や元traceの直接原因を証明しない。trace実装/OS会計/時計source等を切り分ける限定的な診断とする。

追加処理は別script/JSONと本計画へ保存し、正式クリック288+warmup32の測定予算を増やさない。結果の符号/異常の有無で追加sampleを増やさず、helperのバグやclock API失敗は失敗として保持する。
