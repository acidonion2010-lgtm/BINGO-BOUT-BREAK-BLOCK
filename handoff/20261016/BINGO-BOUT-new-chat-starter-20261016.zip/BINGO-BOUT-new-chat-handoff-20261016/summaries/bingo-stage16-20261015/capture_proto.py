#!/usr/bin/env python3
"""Fixed-budget original-protobuf diagnostic; never retry or overwrite a capture."""
import base64,hashlib,http.server,json,math,subprocess,sys,threading,time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/bingo-stage14-20261015')
import capture_clicks as old
phase=old.phase

def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,o):
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(o,ensure_ascii=False,indent=2,allow_nan=False)+'\n');t.replace(p)
def snap(session,browser_session):
 out={'hostStartMonotonicNs':time.monotonic_ns()}
 out['metricSendMonotonicNs']=time.monotonic_ns();out['metrics']=session.send('Performance.getMetrics');out['metricReturnMonotonicNs']=time.monotonic_ns()
 out['processInfo']=browser_session.send('SystemInfo.getProcessInfo')
 out['renderers']=[]
 for item in out['processInfo']['processInfo']:
  if item['type']!='renderer':continue
  pid=int(item['id']);p=Path(f'/proc/{pid}/task/{pid}');r={'pid':pid,'tid':pid,'hostBeforeReadNs':time.monotonic_ns()}
  try:
   r.update(comm=(p/'comm').read_text().strip(),stat=(p/'stat').read_text().strip(),schedstat=(p/'schedstat').read_text().strip())
  except OSError as e:r['readError']=repr(e)
  r['hostAfterReadNs']=time.monotonic_ns();out['renderers'].append(r)
 out['hostEndMonotonicNs']=time.monotonic_ns();return out

class Proto:
 def __init__(self,session,page,path):
  self.session=session;self.page=page;self.path=path;self.complete=None;self.active=False;self.usage=[]
  self.done=lambda e:setattr(self,'complete',e);self.used=lambda e:self.usage.append(e)
  session.on('Tracing.tracingComplete',self.done);session.on('Tracing.bufferUsage',self.used)
  self.summary={'path':str(path),'started':False,'integrityChecksPassed':False}
 def start(self):
  self.session.send('Tracing.start',{'categories':','.join(old.CATEGORIES),'options':'record-until-full','bufferUsageReportingInterval':100,'transferMode':'ReturnAsStream','streamFormat':'proto','streamCompression':'none'})
  self.active=True;self.summary['started']=True
 def finish(self):
  try:
   self.session.send('Tracing.end');self.active=False
   deadline=time.monotonic()+30
   while self.complete is None and time.monotonic()<deadline:self.page.wait_for_timeout(20)
   assert self.complete is not None,'missing tracingComplete'
   self.summary.update(tracingComplete=self.complete,bufferUsage=self.usage)
   handle=self.complete['stream'];calls=0
   try:
    with self.path.open('xb') as f:
     while True:
      chunk=self.session.send('IO.read',{'handle':handle,'size':65536});data=chunk.get('data','')
      f.write(base64.b64decode(data,validate=True) if chunk.get('base64Encoded') else data.encode('utf8'));calls+=1
      if chunk.get('eof'):break
      assert calls<10000,'unbounded stream'
   finally:self.session.send('IO.close',{'handle':handle})
   b=self.path.read_bytes();self.summary.update(bytes=len(b),sha256=sha(b),streamReadCalls=calls,streamEOF=True)
   assert b and self.complete.get('dataLossOccurred') is False
   assert not any(u.get('percentFull',0)>=1 for u in self.usage)
   self.summary['integrityChecksPassed']=True
  finally:
   self.session.remove_listener('Tracing.tracingComplete',self.done);self.session.remove_listener('Tracing.bufferUsage',self.used)

def convert(path,markers):
 target=path.with_suffix('.json');assert not target.exists()
 log={}
 try:
  p=subprocess.run([str(ROOT/'trace_processor_shell'),'convert','json',str(path),str(target)],capture_output=True,text=True,timeout=120)
  log.update(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr);assert p.returncode==0
 except BaseException as e:
  log['failure']=repr(e)
  if isinstance(e,subprocess.TimeoutExpired):
   log.update(stdout=(e.stdout or b'').decode('utf8',errors='replace'),stderr=(e.stderr or b'').decode('utf8',errors='replace'),timeoutSeconds=e.timeout)
  raise
 finally:
  if target.exists():log.update(outputBytes=target.stat().st_size,outputSha256=sha(target.read_bytes()))
  write(path.with_suffix('.convert-log.json'),log)
 trace=json.loads(target.read_bytes());events=trace['traceEvents'];found=[]
 for marker in markers:
  n=marker['name'];m=[e for e in events if e.get('name')==n];c=[e for e in events if e.get('name')=='TimeStamp' and e.get('args',{}).get('data',{}).get('message')==n]
  assert len(m)==len(c)==1,(n,len(m),len(c));found.append({'name':n,'mark':m[0],'stamp':c[0]})
 ids={(e[k]['pid'],e[k]['tid']) for e in found for k in ('mark','stamp')};assert len(ids)==1,ids
 return {'path':str(target),'sha256':sha(target.read_bytes()),'bytes':target.stat().st_size,'events':len(events),'markers':found,'rendererPidTid':list(ids.pop())}

def main():
 report=ROOT/'report.json';assert not report.exists(),'refuse overwrite'
 raw=old.FILES['original'].read_bytes();assert sha(raw)==old.EXPECTED['original']
 assert sha(Path(old.__file__).read_bytes())=='df0c5fa77905d13ce492882e14338a5684e6670e1c5f0694f44b20d696092c77'
 for n,h in old.HELPERS.items():assert sha((old.PROJECT/'validation'/n).read_bytes())==h
 assert sha((ROOT/'trace_processor_shell').read_bytes())=='58042408e6cc861fb1a731c26bb082dc222285561eaa4e12a48a8b2b90dca7b9'
 result={'status':'running','scriptSha256':sha(Path(__file__).read_bytes()),'planSha256':sha((ROOT/'PLAN.md').read_bytes()),'helperCollectorSha256':sha(Path(old.__file__).read_bytes()),'htmlSha256':sha(raw),'visits':[],'pageErrors':[]}
 write(report,result)
 class Handler(http.server.BaseHTTPRequestHandler):
  def do_GET(self):
   if self.path!='/original':self.send_error(404);return
   self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  def log_message(self,*a):pass
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
 try:
  with sync_playwright() as p:
   for run in range(5):
    visit={'run':run,'preflight':run==0,'samples':[]};result['visits'].append(visit);write(report,result)
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    try:
     page=browser.new_page(viewport={'width':1280,'height':900});page.on('pageerror',lambda e:result['pageErrors'].append(str(e)))
     session=page.context.new_cdp_session(page);bs=browser.new_browser_cdp_session()
     visit['browserVersion']=browser.version;visit['categoryDiscovery']=session.send('Tracing.getCategories')
     page.goto(f'http://127.0.0.1:{server.server_port}/original',wait_until='load',timeout=60000)
     visit['selfTests']=json.loads(page.locator('#rule-test-results').text_content());assert visit['selfTests']=={'passed':322,'total':322,'failures':[]}
     session.send('Performance.enable',{'timeDomain':'threadTicks'})
     page.evaluate(old.INSTALL_MARKER.replace('bingo.stage14.','bingo.stage16.'))
     if run:
      visit['prepare']=page.evaluate(phase.PREPARE);assert visit['prepare']['status']=='ready'
      page.evaluate(old.stage7.TRACE_INSTRUMENT);page.evaluate(phase.INSTALL_MONITOR);visit['nativeFunctionSources']=page.evaluate(old.NATIVE_REFS)
     path=ROOT/f'run{run}.pftrace';trace=Proto(session,page,path);markers=[];error=None
     try:
      trace.start()
      if not run:
       visit['before']=snap(session,bs)
       markers=page.evaluate('''()=>{traceResponseState.enabled=true;traceResponseState.token='preflight';traceResponseMark('begin',performance.now());const start=performance.now();while(performance.now()-start<8){}traceResponseMark('end',performance.now());return traceResponseState.markers}''')
       visit['after']=snap(session,bs)
      else:
       branches=['dp','legacy'] if run%2 else ['legacy','dp'];visit['branchOrder']=branches;visit['audits']={}
       for branch in branches:
        fixture={'difficulty':'hard','roll':old.BRANCHES[branch]};page.evaluate(old.FIXTURE,fixture)
        audit=page.evaluate(old.AUDIT,old.BRANCHES[branch]);visit['audits'][branch]=audit
        assert audit['draws'] and all(v==old.BRANCHES[branch] for v in audit['draws'])
        prior=[v['audits'][branch] for v in result['visits'] if v is not visit and branch in v.get('audits',{})]
        if prior:assert audit==prior[0],'untimed fixture/RNG/choice audit changed'
        assert audit['status']=='ready' and audit['counters']==({'whole':1,'legacy':0,'dp':1} if branch=='dp' else {'whole':0,'legacy':1,'dp':0})
        for trial in range(4):
         record={'branch':branch,'trial':trial,'warmup':trial==0,'outcome':'preparing'};visit['samples'].append(record);write(report,result)
         page.evaluate(old.FIXTURE,fixture);record['descriptor']=page.evaluate(phase.DESCRIBE)
         assert record['descriptor']['visibility']=='visible' and not record['descriptor']['crossOriginIsolated']
         assert page.evaluate('()=>stage14CheckNativeRefs()')
         token=f'run{run}.{branch}.trial{trial}'
         page.evaluate('''token=>{traceResponseState.enabled=true;traceResponseState.token=token;traceResponseState.markers=[]}''',token)
         record['before']=snap(session,bs)
         page.locator('#board1 .cell:not([disabled])').first.click(timeout=10000)
         page.wait_for_function('uiResponseProbe.result !== null',timeout=10000)
         record['after']=snap(session,bs)
         sample=page.evaluate('uiResponseProbe.result');old.assert_sample(sample,branch)
         current=page.evaluate('traceResponseState.markers');assert [m['label'] for m in current]==list(old.stage7.LABELS)
         record.update(sample=sample,markers=current,outcome='accepted');markers.extend(current)
         assert not result['pageErrors'];write(report,result)
       assert page.evaluate('()=>stage14CheckNativeRefs()')
     except BaseException as e:error=e;visit['failure']=repr(e);raise
     finally:
      try:
       if trace.active:trace.finish()
      except BaseException as e:
       visit['traceFailure']=repr(e)
       if error is None:raise
      finally:visit['trace']=trace.summary;write(report,result)
     visit['conversion']=convert(path,markers)
     pid,tid=visit['conversion']['rendererPidTid'];assert pid==tid
     snapshots=([visit['before'],visit['after']] if not run else [s[k] for s in visit['samples'] for k in ['before','after']])
     identities=[];metric_values=[]
     for s in snapshots:
      target=next(r for r in s['renderers'] if r['pid']==pid and r['tid']==tid)
      fields=target['stat'][target['stat'].rfind(')')+2:].split()
      identities.append((target['comm'],fields[19])) # /proc stat field22 starttime
      assert sum(r['pid']==pid and r['tid']==tid and 'readError' not in r for r in s['renderers'])==1
      values={m['name']:m['value'] for m in s['metrics']['metrics']}
      assert all(k in values and isinstance(values[k],(int,float)) and math.isfinite(values[k]) for k in ['ThreadTime','Timestamp']),'finite metrics missing'
      metric_values.append(values['ThreadTime'])
     assert len(set(identities))==1,'renderer identity changed across snapshots'
     visit['metricMonotonic']=all(b>=a for a,b in zip(metric_values,metric_values[1:]));assert visit['metricMonotonic']
     if not run:assert metric_values[-1]>metric_values[0],'preflight ThreadTime did not increase'
     marker_lookup={m['name']:m for m in visit['conversion']['markers']}
     groups=[{'markers':markers,'before':visit['before'],'after':visit['after']}] if not run else visit['samples']
     visit['hostMarkerContainmentChecked']=True
     for group in groups:
      lo=group['before']['metricSendMonotonicNs'];hi=group['after']['metricReturnMonotonicNs']
      for marker in group['markers']:
       for kind in ['mark','stamp']:assert lo<=marker_lookup[marker['name']][kind]['ts']*1000<=hi,'marker and host clocks not contained'
     assert not result['pageErrors'],result['pageErrors']
     visit['rendererIdentity']={'comm':identities[0][0],'starttimeTicks':identities[0][1]}
     thread_names=[e.get('args',{}).get('name') for e in json.loads(path.with_suffix('.json').read_bytes())['traceEvents'] if e.get('ph')=='M' and e.get('name')=='thread_name' and (e.get('pid'),e.get('tid'))==(pid,tid)]
     visit['traceThreadNames']=thread_names;assert 'CrRendererMain' in thread_names
     visit['completed']=True;write(report,result);print(f'run{run}: proto + same-input JSON verified, markers={len(markers)}',flush=True)
     if run:page.evaluate('()=>{rafPhaseMonitor.running=false;cancelAnimationFrame(rafPhaseMonitor.handle);releaseWholeGameCpu()}')
    finally:browser.close()
  assert len(result['visits'])==5 and all(v.get('completed') for v in result['visits'])
  samples=[s for v in result['visits'] for s in v['samples']];assert len(samples)==32 and sum(not s['warmup'] for s in samples)==24
  result.update(status='completed',formalClicks=24,warmupClicks=8)
 except BaseException as e:result.update(status='failed',failure=repr(e));raise
 finally:write(report,result);server.shutdown();server.server_close()
if __name__=='__main__':main()
