# 現在地と引き継ぎ記録

## 対象版

対象はユーザーが最初に添付した約501KBのHTMLを基準にしたCPU整理です。添付ロードマップは `project/CPU重複削減計画.txt`、原本は `project/index.before.html`。リポジトリmainの旧版は実装基準にしていません。

| 版 | bytes / 行数 | SHA-256 |
| --- | --- | --- |
| 添付原本 | 501,003 / 9,034 | `e872443dc9764f3b9647f4797d1411ca98f865b9c2f69c6e694529e2685cd3a9` |
| ユーザー受領済み段階5 | 499,401 / 9,005 | `fea09e995bfc1036515b92771925bd7968f3c453425ea5517b7a5b480293be64` |
| 現在の段階9 | 499,212 / 8,998 | `59fff4685ff3f36e18d73fe9fa524ee57d81a348352e7b2912db4b7ecc1bb513` |

現在の `project/index.html`、`project/stages/index.stage9.html`、`project/stages/index.stage9.candidate.html` は同一です。受領済み版は `project/stages/index.handoff-20261015.html` に保存されています。`project/changes.patch` は原本→現在版、`project/validation/stage9/changes-from-handoff.patch` は段階5→現在版です。

現在版の固定URL:
https://raw.githubusercontent.com/acidonion2010-lgtm/BINGO-BOUT-BREAK-BLOCK/73c394af9deb3823ef31d79bf287db348c60522a/index.html

リポジトリ: `acidonion2010-lgtm/BINGO-BOUT-BREAK-BLOCK`

受け渡しブランチ: `handoff/completed-index-20261015-fea09e99`

段階5のHTMLコミット: `f36f9188d26c104d48e11b26d57dd5f4737216a8`

段階9のHTMLコミット: `73c394af9deb3823ef31d79bf287db348c60522a`

前チャットでは完成HTMLのGitHub受け渡しと、今回の引き継ぎ資料・プロンプト・ZIPのGitHub配置をユーザーが許可しています。mainへの反映、PRのmerge、サイトのdeployは行っていません。ZIP掲載のコミットは別途渡すダウンロードURLで固定されます。HTMLの内容は上記段階9と同じです。

## 段階ごとの到達点

| 段階 | 内容 |
| --- | --- |
| 0 | 添付原本、テスト、固定配置・乱数、性能基準を保存 |
| 1 | Worker受信側の値配列二重確保を除去。18,324,976Bの不要な確保を削減。数値検証とURL解放の不具合も修正 |
| 2 | `CpuEquilibriumSolver` を共通化。`WholeGameDP` が継承し、盤面単体先読みも共通solverを使用 |
| 3 | monotone判定の局所化、不要なmaxPay削除、対角形strategyGapの整理 |
| 4 | `buildMaxScores` の漸化式化で一時配列を削減 |
| 5 | reverse mapを共有し、DPのindex表38枚→10枚、38,912B→10,240B |
| 6〜8 | 選択経路と実入力・描画待ちの追加調査。本体は段階5のまま |
| 9 | 従来方式BREAK内でraw weightsを再利用し2計算→1計算。NORMAL入口の重複を既存legacy処理へ統合。現在採用済み |

段階9は4つのCPU関数だけを変更しています: `getCpuSelectionWeights`、`prepareCpuBreakCandidates`、`selectCpuLegacyCell`、`selectCpuBreakCell`。その他のHTMLは段階5とバイト一致。raw weightsは判断1回限りで、次の手や試合へ持ち越しません。

UI・音・演出・ルール・対戦形式と通常起動時の自己テスト実行は維持しています。HTMLに外部ライブラリ・通信先・追加ファイル依存を足していません。

## 機能の検証済み範囲

`project/validation/stage9/validated-summary.json` と `project/段階9比較結果.md` が最新の入口です。

- 全体DP: 固定の両盤面配置、両先攻の計4,581,244 Float64値が原本とバイト一致。`table-binary-integrity.json` にhashを保存。
- 盤面単体5,632状態、代表政策36件、ルール・終端・レイヤーの比較は最大差0。
- 固定乱数416ケース×4選択は、選択・乱数順序/回数・履歴更新が一致。
- 段階5との追加36,672組: 全512マスク・16配置、履歴/クールダウン/閾値、入口/補助関数を照合。これはlegacy/NORMAL/HARD代替の検証であり、MASTER均衡入口や全体solverは別のブラウザー検証。
- 均衡境界・符号付き4,617件が原本と一致し全件gap≤1e-5。
- 自己テスト322/322、Worker45/45、実操作7/7。

全DP照合は固定配置組に対する全値で、全配置組の総当たりではありません。大きな `.bin` をZIPへ同梱していないため、再実行には原本と対象版をそれぞれcaptureしてください。保存されたhash・照合結果と、新環境での再実行結果を区別してください。

## 最新の性能結果と限界

段階9だけのsame-realm診断では、選んだ5つのBREAK条件が全90/90対で短縮し、中央値比で約39〜48%短縮。関数設置/コンパイル履歴が通常読込と異なる診断で、物理操作応答の短縮率ではありません。

原本対段階9の通常HTML比較は104条件、2独立ブラウザー、74,880,000判断。84非終端条件＋20個の未開放1個のselector契約です。8個の終端全体DP条件は2run合計16行を除外。終了後のゲーム操作を再現するものではありません。

| 分類 | 2run反復 | 集約の記述的区間 |
| --- | ---: | ---: |
| 非増加側（区間上端≤0） | 42 | 58 |
| 未確定 | 62 | 45 |
| 増加側 | 0 | 1 |

32のlegacy BREAK条件は全て2runで短縮側。MASTER代替のP2先攻/序盤/BREAKは集約中央値+0.025µs、区間[+0.005,+0.040]µsで残ります（run1未確定/run2増加）。時計の浮動小数点残差ではありません。今回の入口関数は通るものの、重み再利用の3補助関数は通らず、計時中に均衡solverも走りません。表は原本・段階5・段階9で一致します。JITや準備・割当履歴の影響まで特定できていません。

段階5→9のsame-realm BLOCK対照にも微小差が残り、P2未開放1個代替BLOCKは両run中央値が微増。原本対段階9のrun2ではP2序盤BLOCKのHARD legacy/失敗時DP-rollに増加区間があり、集約・反復では確定しません。詳細は `project/validation/stage9/final-measurement-review.md` を確認してください。

正式起動比較は各版5回、交互・順序反転で実施:

| 比較 | 起動中央値ms | MASTER準備中央値ms |
| --- | ---: | ---: |
| 原本→段階9 | 2963.99→2431.17（−17.98%） | 640.10→527.60（−17.58%） |
| 段階5→段階9 | 2351.34→2367.67（+0.69%） | 499.30→511.80（+2.50%） |

別の計測列をまたいで同一版の値を直接引き算しないでください。Workerと準備処理自体は段階9で変えていませんが、観測された増加を無視した非悪化PASSはしていません。全経路の厳密な非悪化は未確定です。

## 残件と続きの進め方

1. 62条件の反復非悪化と、MASTER代替/対照の微小差の直接原因。
2. 段階5比の起動+0.69%・準備+2.50%の原因と非悪化。
3. 以前のHARD同期handler+0.45ms、2RAF+0.5/+0.8msなど、同時記録のない試行の直接原因。
4. 段階8のcommit完了待ちに対する個々のraster/GPU準備/通知の寄与。
5. cold latency、実端末の物理入力→画面提示/音声出力、全配置・全端末・全ブラウザー。

最初は1または2を選び、既存記録/ソースから検証可能な仮説を立ててください。計測対象・SHA・有限回数・停止条件を先に記録し、結果の符号に応じて都合よく追加しないでください。ブラウザー・DP・性能ジョブは直列で実行します。文書レビューは並行可能です。

同一条件での数値/選択照合と時間差を別判定にし、A/A差し引き・後付け性能許容差・未確定のPASS化は行っていません。段階9の整数timestamp表現は丸め誤差の符号問題を避ける方法で、ns精度の時計にはなりません。以前の記録と分類は書き換えていません。

## 段階8の描画待ちについて

保存された正式32クリックとpilot8クリックでは全件受理成功。原本と段階5の両方で長い `WaitForCommitCompletion` が記録され、大部分が当該main threadのoff-CPUと重なりました。旧pending treeがある間commitを保留するChromiumの条件と、旧tree activation直後の次commitが整合しています。

各raster/GPU/通知の時間配分までは確定していません。この記録を、同時のtraceがない過去の試行、今回のselector差、起動・準備差の原因へ遡って当てはめないでください。RAF callbackは物理画面への提示完了ではなく、headlessの音声も実スピーカーで確認していません。

## 履歴の読み違いを避ける

`project/比較結果.md` は段階2時点の本文、`未完了検証8結果.md` の「本体は受領版」「98条件未確定」「以前のPowerShellが最新」も当時の記録です。現在の基準は段階9とこの引き継ぎです。古い関数のbyte一致は、その報告で比較した版の範囲で有効です。段階9では4つのCPU関数を変更しています。段階9のレビュー内にある「At review timeは段階5」等も、候補採用前の時点の記録です。

`project/github-handoff.json` と `download-index.ps1` は段階9のHTMLを指します。`*.stage5.json` と `download-index.received-stage5.ps1` は段階5保存用です。GitHub上のZIP受取コードはこのHTML用コードとは別です。

作成日: 2026-10-15（Asia/Tokyo）
