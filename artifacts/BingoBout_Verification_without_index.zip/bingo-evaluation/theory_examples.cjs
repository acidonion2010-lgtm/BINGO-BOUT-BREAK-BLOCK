#!/usr/bin/env node
'use strict';
// Analytical illustrations; these are NOT observations from sampled matches.
const fs=require('node:fs'),path=require('node:path');
const {loadAudit}=require('./audit_cases.cjs');
const {WholeGameDP,cpuBreakSelectionWeights,sourceSha256}=loadAudit();
const dp=new WholeGameDP({layoutP1:[1,2,3,4,5,6,7,8,9],layoutP2:[9,8,7,6,5,4,3,2,1]});
const pay=[1005,0],stay=-1005,e=dp.equilibrium(2,pay,stay);
const p=Array.from(dp.probP.slice(0,2)),q=Array.from(dp.probQ.slice(0,2));
const actual=Array.from(cpuBreakSelectionWeights({legalActions:[0,1],breakStrategy:p,actionValues:pay,stayValue:stay},1000).slice(0,2));
function columns(dist){return [dist[0]*stay+dist[1]*pay[1],dist[0]*pay[0]+dist[1]*stay]}
const originalColumns=columns(p),actualColumns=columns(actual);
const result={sourceSha256,kind:'Synthetic analytical example; not a sampled board position',pay,stay,nashValue:e.value,p,q,pActual:actual,nashColumnUtilities:originalColumns,actualColumnUtilities:actualColumns,actualWorst:Math.min(...actualColumns),nashWorst:Math.min(...originalColumns),localUtilityLoss:Math.min(...originalColumns)-Math.min(...actualColumns),actualVsNashBlock:actualColumns.reduce((s,v,j)=>s+q[j]*v,0),
  expectedUtilityObjectiveCounterexample:{kind:'Conceptual outcome lotteries; attainability from a shared board state is not asserted',lotteryA:{pWin:.51,pLoss:.49,pDraw:0,winMargin:1,lossMargin:-1,expectedUtility:1000*(.51-.49)+.51-.49},lotteryB:{pWin:.5,pLoss:.5,pDraw:0,winMargin:44,lossMargin:-1,expectedUtility:1000*(.5-.5)+.5*44-.5}}};
const outdir=process.argv[2]||path.join(__dirname,'results');fs.writeFileSync(path.join(outdir,'theory_examples.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
