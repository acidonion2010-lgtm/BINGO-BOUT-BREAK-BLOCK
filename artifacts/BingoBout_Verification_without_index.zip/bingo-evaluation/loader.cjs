'use strict';
// Evaluate the supplied script verbatim up to its UI event-registration tail.
// No rule/CPU function is rewritten. Window is only used for exported QA hooks.
const fs = require('node:fs');
const vm = require('node:vm');
const crypto = require('node:crypto');
const path = require('node:path');
const SOURCE = path.join(__dirname, 'source.html');
function load(file = SOURCE) {
  const html = fs.readFileSync(file, 'utf8');
  const scripts = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)];
  if (scripts.length !== 1) throw new Error('Expected one inline script');
  const script = scripts[0][1];
  const boundary = "        document.getElementById('score-gain-callout').addEventListener";
  const end = script.lastIndexOf(boundary);
  if (end < 0) throw new Error('UI tail boundary missing');
  const math = Object.create(Math);
  math.random = () => { throw new Error('Random generator not installed'); };
  const context = vm.createContext({Math: math, window: {}, console});
  const exports = `;globalThis.api={state, CONFIG, CPU_DIFFICULTY, WholeGameDP,
    calculateScore, calculateHighestReachableScore, evaluateEndState,
    getCellWeights, getCpuSelectionWeights, getCpuChoicePool,
    getCpuBreakCandidatePool, getCpuBlockCandidatePool,
    selectCpuBreakCell, selectCpuBlockCell, resetCpuBreakMemory, resetCpuBlockMemory,
    rememberCpuBreakResult, rememberCpuBlockResult, createIndividualNumberLayouts,
    cpuBreakSelectionWeights, sampleCpuEqDistribution, buildCpuEqTable,
    getCurrentPlayer,
    setRandom(fn){Math.random=fn},
    setDp(dp){cpuWholeDp=dp;cpuWholeStatus=dp?'ready':'inactive';
      cpuWholeDecisions=0;hardLegacyDecisions=0;hardDpDecisions=0},
    counters(){return {whole:cpuWholeDecisions,legacy:hardLegacyDecisions,dp:hardDpDecisions}},
    dpStatus(){return cpuWholeStatus}
  };`;
  vm.runInContext(script.slice(0, end) + exports, context, {filename: file});
  return {api:context.api, sha256:crypto.createHash('sha256').update(html).digest('hex')};
}
// Mulberry32. uint32 output divided by 2^32; no Date or host randomness.
function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function seed(...parts) {
  return crypto.createHash('sha256').update(parts.join('|')).digest().readUInt32LE(0);
}
module.exports = {load,rng,seed,SOURCE};
