#!/usr/bin/env python3
"""Observe trusted HARD clicks and RAF phase in separate A/A and A/B visits.

The game keeps its ordinary HTTP headers, real Blob Worker, sound, BGM, CSS
animations, and three-RAF fixture. A/A is reported as a control, never subtracted
from A/B to manufacture a pass. RAF callbacks do not measure physical display
presentation. This script adds an observation loop and scalar probe fields only.
"""

import argparse
import functools
import hashlib
import http.server
import json
import math
import os
from pathlib import Path
import statistics
import sys
import threading
from urllib.parse import quote

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'stage3'))
from ui_response import PREPARE, FIXTURE, INSTRUMENT, assert_sample
from playwright.sync_api import sync_playwright


def extend_instrument(source):
    """Keep the existing click probe and add timestamps to its same callbacks."""
    replacements = [
        (
            '            handlerMs: ended - pending.started,\n',
            '            handlerMs: ended - pending.started,\n'
            '            clickCaptureNowMs: pending.started,\n'
            '            eventTimestampMs: pending.eventTimestampMs,\n'
            '            previousRafTimestampMs: pending.previousRafTimestampMs,\n'
            '            previousRafCallbackNowMs: pending.previousRafCallbackNowMs,\n'
            '            previousRafSequence: pending.previousRafSequence,\n'
            '            phaseObserverNowMs: pending.phaseObserverNowMs,\n',
        ),
        (
            '        requestAnimationFrame(() => {\n'
            '            sample.firstRafMs = performance.now() - pending.started;\n',
            '        requestAnimationFrame(firstTimestamp => {\n'
            '            const firstCallbackNow = performance.now();\n'
            '            sample.firstRafTimestampMs = firstTimestamp;\n'
            '            sample.firstRafCallbackNowMs = firstCallbackNow;\n'
            '            sample.firstRafMs = firstCallbackNow - pending.started;\n',
        ),
        (
            '            requestAnimationFrame(() => {\n'
            '                sample.twoRafMs = performance.now() - pending.started;\n',
            '            requestAnimationFrame(secondTimestamp => {\n'
            '                const secondCallbackNow = performance.now();\n'
            '                sample.secondRafTimestampMs = secondTimestamp;\n'
            '                sample.secondRafCallbackNowMs = secondCallbackNow;\n'
            '                sample.twoRafMs = secondCallbackNow - pending.started;\n',
        ),
    ]
    for old, new in replacements:
        if source.count(old) != 1:
            raise ValueError('The shared INSTRUMENT changed; review the RAF extension')
        source = source.replace(old, new, 1)
    return source


PHASE_INSTRUMENT = extend_instrument(INSTRUMENT)

INSTALL_MONITOR = r"""() => {
    window.rafPhaseMonitor = {
        running: true, handle: null, sequence: 0,
        timestampMs: null, callbackNowMs: null
    };
    const monitor = rafPhaseMonitor;
    const observeFrame = timestamp => {
        monitor.timestampMs = timestamp;
        monitor.callbackNowMs = performance.now();
        monitor.sequence++;
        if (monitor.running) monitor.handle = requestAnimationFrame(observeFrame);
    };
    monitor.handle = requestAnimationFrame(observeFrame);
    document.addEventListener('click', event => {
        // The preceding shared capture observer consumed armed and set pending.
        // Record scalars only: no DOM, animation, style, or layout queries here.
        const pending = uiResponseProbe.pending;
        if (!pending) return;
        pending.eventTimestampMs = event.timeStamp;
        pending.previousRafTimestampMs = monitor.timestampMs;
        pending.previousRafCallbackNowMs = monitor.callbackNowMs;
        pending.previousRafSequence = monitor.sequence;
        pending.phaseObserverNowMs = performance.now();
    }, true);
}"""

DESCRIBE = r"""() => {
    const cell = getCellButton(1, 2);
    return {
        observedNowMs: performance.now(),
        hover: Boolean(cell && cell.matches(':hover')),
        visibility: document.visibilityState,
        fontStatus: document.fonts.status,
        crossOriginIsolated,
        audioState: audioCtx ? audioCtx.state : 'uninitialized',
        audioTime: audioCtx ? audioCtx.currentTime : null,
        bgmStep, soundMuted: state.isMuted, bgmOff: state.isBgmOff,
        animations: document.getAnimations().map(animation => {
            const timing = animation.effect?.getComputedTiming();
            const target = animation.effect?.target;
            const targetName = target?.id ||
                (typeof target?.className === 'string' ? target.className : target?.tagName);
            return {
                type: animation.constructor.name,
                name: animation.animationName || animation.transitionProperty || '',
                target: targetName || null,
                playState: animation.playState, pending: animation.pending,
                currentTime: animation.currentTime,
                duration: timing?.duration, iterations: timing?.iterations,
                endTime: timing?.endTime
            };
        })
    };
}"""

METRICS = (
    'handlerMs', 'firstRafMs', 'twoRafMs', 'clickPhaseMs',
    'clickPhaseAfterCallbackMs', 'firstWaitAfterHandlerMs',
    'rafIntervalMs', 'rafCallbackIntervalMs',
    'previousRafCallbackLagMs', 'firstRafCallbackLagMs',
    'secondRafCallbackLagMs', 'rafCallbackLagChangeMs',
)


def decompose(sample):
    required = (
        'clickCaptureNowMs', 'eventTimestampMs', 'previousRafTimestampMs',
        'previousRafCallbackNowMs', 'phaseObserverNowMs',
        'firstRafTimestampMs', 'firstRafCallbackNowMs',
        'secondRafTimestampMs', 'secondRafCallbackNowMs',
    )
    assert all(isinstance(sample.get(key), (int, float)) and
               math.isfinite(sample[key]) for key in required), sample
    assert sample['previousRafSequence'] > 0, sample
    assert sample['secondRafTimestampMs'] >= sample['firstRafTimestampMs'], sample
    sample.update({
        'clickPhaseMs': sample['clickCaptureNowMs'] - sample['previousRafTimestampMs'],
        'clickPhaseAfterCallbackMs': sample['clickCaptureNowMs'] - sample['previousRafCallbackNowMs'],
        'firstWaitAfterHandlerMs': sample['firstRafMs'] - sample['handlerMs'],
        'rafIntervalMs': sample['secondRafTimestampMs'] - sample['firstRafTimestampMs'],
        'rafCallbackIntervalMs': sample['secondRafCallbackNowMs'] - sample['firstRafCallbackNowMs'],
        'previousRafCallbackLagMs': sample['previousRafCallbackNowMs'] - sample['previousRafTimestampMs'],
        'firstRafCallbackLagMs': sample['firstRafCallbackNowMs'] - sample['firstRafTimestampMs'],
        'secondRafCallbackLagMs': sample['secondRafCallbackNowMs'] - sample['secondRafTimestampMs'],
    })
    sample['rafCallbackLagChangeMs'] = sample['secondRafCallbackLagMs'] - sample['firstRafCallbackLagMs']
    assert all(math.isfinite(sample[key]) for key in METRICS), sample
    return sample


def click_trial(page):
    page.evaluate(FIXTURE, 'hard')
    # Descriptor collection is outside click capture and its elapsed timers.
    # Its overhead can affect input phase; it is identical in all four arms.
    descriptor = page.evaluate(DESCRIBE)
    assert not descriptor['crossOriginIsolated'], descriptor
    page.locator('#board1 .cell:not([disabled])').first.click(timeout=10000)
    page.wait_for_function('uiResponseProbe.result !== null', timeout=10000)
    sample = page.evaluate('uiResponseProbe.result')
    assert_sample(sample, 'hard')
    decompose(sample)
    sample['preClickDescriptor'] = descriptor
    return sample


def comparisons(rows, runs):
    output = []
    for kind in ('aa', 'ab'):
        paired_visits = []
        for run in range(1, runs + 1):
            pair = {row['version']: row for row in rows
                    if row['kind'] == kind and row['round'] == run}
            assert set(pair) == {'before', 'after'}, pair
            paired_visits.append({
                'round': run,
                'beforeVisitMediansMs': pair['before']['mediansMs'],
                'afterVisitMediansMs': pair['after']['mediansMs'],
                'medianDeltaMs': {key: pair['after']['mediansMs'][key] -
                                  pair['before']['mediansMs'][key] for key in METRICS},
            })
        pooled = {}
        for version in ('before', 'after'):
            samples = [sample for row in rows
                       if row['kind'] == kind and row['version'] == version
                       for sample in row['samples']]
            pooled[version] = {key: statistics.median(s[key] for s in samples)
                               for key in METRICS}
        output.append({
            'kind': kind, 'pooledMediansMs': pooled,
            'pooledMedianDeltaMs': {key: pooled['after'][key] - pooled['before'][key]
                                    for key in METRICS},
            'pairedVisits': paired_visits,
            'pairedVisitMedianDeltaMs': {
                key: statistics.median(p['medianDeltaMs'][key] for p in paired_visits)
                for key in METRICS},
        })
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('before', type=Path)
    parser.add_argument('after', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--runs', type=int, default=5)
    parser.add_argument('--trials', type=int, default=9)
    args = parser.parse_args()
    if args.runs < 1 or args.trials < 1:
        parser.error('Use positive run and trial counts')
    paths = {version: getattr(args, version).resolve(strict=True)
             for version in ('before', 'after')}
    serve_root = Path(os.path.commonpath([str(path.parent) for path in paths.values()]))

    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *unused):
            pass

    server = http.server.ThreadingHTTPServer(
        ('127.0.0.1', 0), functools.partial(Handler, directory=str(serve_root)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    result = {
        'conditions': {
            'executable': '/usr/bin/chromium', 'viewport': [1280, 900],
            'foregroundPages': 1, 'runsPerComparison': args.runs,
            'trialsPerVersionRun': args.trials,
            'warmupTrustedClicksPerVersionRun': 1,
            'comparisons': {'aa': 'original/original', 'ab': 'original/current'},
            'sampleOrder': 'A/A visit pairs, then A/B visit pairs; odd rounds before/after, even rounds after/before',
            'pageLoadsPerComparison': args.runs * 2,
            'realBlobWorkerPreparationsPerVisit': 1,
            'sources': {version: {'path': str(path),
                        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                        for version, path in paths.items()},
            'difficulty': 'hard', 'fixedRandom': 0.8,
            'hardBranch': 'whole-game DP (0.8 >= 0.7)',
            'firstPlayer': 1,
            'layouts': {'p1': [8, 1, 6, 3, 5, 7, 4, 9, 2],
                        'p2': [5, 9, 1, 7, 2, 6, 3, 8, 4]},
            'fixture': {'maskP1': 3, 'maskP2': 24, 't': 8, 'inning': 5, 'turnRole': 0},
            'fixtureWait': 'Shared FIXTURE: three RAF callbacks; no animation settling, finishing, or cancellation added.',
            'httpHeaders': 'Ordinary HTTP; no COOP or COEP; normal performance.now clock precision.',
            'observers': 'Continuous scalar RAF monitor and a capture observer after the shared click probe; no DOM reads in capture observer.',
            'timestamps': 'RAF timestamp arguments and performance.now use the page time origin; RAF timestamps are not display-presentation timestamps.',
            'metrics': {
                'handlerMs': 'document click capture through document bubble after the game handler',
                'clickPhaseMs': 'click capture performance.now minus most recently observed RAF timestamp; unwrapped, not modulo an assumed frame interval',
                'clickPhaseAfterCallbackMs': 'click capture performance.now minus previous RAF monitor callback execution time',
                'firstWaitAfterHandlerMs': 'first RAF callback execution minus handler-end observation',
                'rafIntervalMs': 'second RAF timestamp argument minus first RAF timestamp argument',
                'rafCallbackIntervalMs': 'second RAF callback execution time minus first RAF callback execution time',
                'firstRafCallbackLagMs': 'first callback performance.now minus its RAF timestamp argument',
                'secondRafCallbackLagMs': 'second callback performance.now minus its RAF timestamp argument',
                'rafCallbackLagChangeMs': 'second callback lag minus first callback lag',
            },
            'descriptors': 'Animation, hover, and BGM observations before click and outside elapsed timers; this observation overhead may influence input phase equally in each arm.',
            'limits': 'One legal P1 BREAK state and HARD DP branch; sound/animation retained; callback observations are not physical presentation or input-device latency. Monitor overhead exists in all arms. A/A and A/B are separate observations; no subtraction, correction, or latency pass threshold.',
        },
        'visits': [], 'rows': [], 'pageErrors': [],
        'behaviorChecksPassed': False, 'latencyPassAssessed': False,
    }
    current_visit = {}
    current_trial = {}

    def save_report():
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2,
                                          allow_nan=False) + '\n')

    save_report()
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(
                executable_path='/usr/bin/chromium', headless=True,
                args=['--no-sandbox', '--disable-dev-shm-usage'])
            result['conditions']['browserVersion'] = browser.version
            page = browser.new_page(viewport={'width': 1280, 'height': 900})
            page.on('pageerror', lambda error: result['pageErrors'].append(
                {**current_visit, 'error': str(error)}))
            try:
                for kind in ('aa', 'ab'):
                    for run in range(args.runs):
                        order = ('before', 'after') if run % 2 == 0 else ('after', 'before')
                        for version in order:
                            current_visit.clear()
                            current_visit.update({'kind': kind, 'round': run + 1, 'version': version})
                            current_trial.clear()
                            source_version = 'before' if kind == 'aa' else version
                            source = paths[source_version]
                            relative = quote(source.relative_to(serve_root).as_posix())
                            page.goto(f'http://127.0.0.1:{server.server_port}/{relative}',
                                      wait_until='load', timeout=60000)
                            page.bring_to_front()
                            tests = json.loads(page.locator('#rule-test-results').text_content())
                            assert tests['total'] == 322 and tests['passed'] == 322, tests
                            preparation = page.evaluate(PREPARE)
                            page.evaluate(PHASE_INSTRUMENT)
                            page.evaluate(INSTALL_MONITOR)
                            result['visits'].append({**current_visit, 'sourceVersion': source_version,
                                                     'selfTests': tests, 'preparation': preparation})
                            row = {**current_visit, 'sourceVersion': source_version,
                                   'difficulty': 'hard', 'samples': []}
                            result['rows'].append(row)
                            current_trial.update({'kind': 'warmup', 'trial': 0})
                            row['warmup'] = click_trial(page)
                            for trial in range(args.trials):
                                current_trial.update({'kind': 'measured', 'trial': trial + 1})
                                row['samples'].append(click_trial(page))
                            row['mediansMs'] = {
                                key: statistics.median(s[key] for s in row['samples'])
                                for key in METRICS}
                            save_report()
                            print(f"{kind} round {run + 1} {version}: "
                                  f"handler {row['mediansMs']['handlerMs']:.3f} ms, "
                                  f"two RAF {row['mediansMs']['twoRafMs']:.3f} ms, "
                                  f"phase {row['mediansMs']['clickPhaseMs']:.3f} ms, "
                                  f"{len(row['samples'])} trusted clicks passed", flush=True)
                            page.evaluate('''() => {
                                state.turnToken++;
                                discardThinkTimer();
                                releaseWholeGameCpu();
                                rafPhaseMonitor.running = false;
                                cancelAnimationFrame(rafPhaseMonitor.handle);
                            }''')
                assert not result['pageErrors'], result['pageErrors']
                result['comparisons'] = comparisons(result['rows'], args.runs)
                result['behaviorChecksPassed'] = True
            finally:
                browser.close()
    except Exception as error:
        result['failure'] = {'visit': dict(current_visit), 'trial': dict(current_trial),
                             'type': type(error).__name__, 'detail': str(error)}
        save_report()
        raise
    finally:
        server.shutdown()
        server.server_close()
        save_report()


if __name__ == '__main__':
    main()
