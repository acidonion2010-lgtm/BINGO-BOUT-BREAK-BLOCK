#!/usr/bin/env python3
"""Copy required unchanged stage15/17 upstream snapshots with hash validation."""
import hashlib
import json
import pathlib
import shutil

ROOT = pathlib.Path(__file__).resolve().parent
BASE15 = pathlib.Path('/workspace/bingo-stage15-20261015')
BASE17 = pathlib.Path('/workspace/bingo-stage17-20261015')
DEST = ROOT/'official-sources'/'endpoint-review'
CR = '73c14f6228d7cd537c855007e8f88678969cc0eb'
PR = '5dbeaad4ceb91470a835426b52e0cb43a3e5ef10'
copies = []

def add(base, origin, repository, revision, source):
    copies.append((base, origin, repository, revision, source))

for path in ['include/perfetto/base/time.h',
             'include/perfetto/tracing/track_event.h',
             'include/perfetto/tracing/track_event_legacy.h',
             'include/perfetto/tracing/internal/track_event_data_source.h',
             'src/tracing/internal/track_event_internal.cc']:
    add(BASE15, 'official-sources/linux-threadticks-review/perfetto/'+path,
        'google/perfetto', PR, path)
for path in ['src/trace_processor/export_json.cc',
             'src/trace_processor/importers/proto/track_event_event_importer.h']:
    add(BASE15, 'official-sources/perfetto-review/'+path.replace('/', '__'),
        'google/perfetto', PR, path)
for path in ['third_party/blink/renderer/core/timing/performance_mark.cc',
             'third_party/blink/renderer/core/timing/performance_user_timing.cc',
             'third_party/blink/renderer/core/inspector/thread_debugger_common_impl.cc',
             'third_party/blink/renderer/core/inspector/inspector_trace_events.h',
             'third_party/blink/renderer/core/inspector/inspector_trace_events.cc']:
    add(BASE15, 'official-sources/chromium/'+path, 'chromium/chromium', CR, path)
add(BASE15, 'official-sources/linux-threadticks-review/base/time/time_now_posix.cc',
    'chromium/chromium', CR, 'base/time/time_now_posix.cc')
add(BASE17, 'official-sources/config-review/perfetto/include/perfetto/tracing/internal/track_event_internal.h',
    'google/perfetto', PR, 'include/perfetto/tracing/internal/track_event_internal.h')
add(BASE15, 'official-sources/licenses/chromium/LICENSE', 'chromium/chromium', CR, 'LICENSE')
add(BASE15, 'official-sources/licenses/perfetto/LICENSE', 'google/perfetto', PR, 'LICENSE')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def checksums(base):
    result = {}
    for line in (base/'SHA256SUMS').read_text().splitlines():
        expected, name = line.split('  ', 1)
        result[name.removeprefix('./')] = expected
    return result

def main():
    prior = {BASE15: checksums(BASE15), BASE17: checksums(BASE17)}
    records = []
    for base, origin, repository, revision, source in copies:
        path = base/origin
        digest = sha(path)
        assert prior[base][origin] == digest, origin
        family = 'chromium' if repository == 'chromium/chromium' else 'perfetto'
        target = DEST/family/source
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as output:
            output.write(path.read_bytes())
        assert sha(target) == digest
        records.append(dict(copyFrom=str(path), previousManifest=str(base/'SHA256SUMS'),
            previousManifestSha256=sha(base/'SHA256SUMS'), repository=repository,
            revision=revision, sourcePath=source,
            url=f'https://raw.githubusercontent.com/{repository}/{revision}/{source}',
            savedPath=str(target.relative_to(ROOT)), bytes=target.stat().st_size,
            sha256=digest, lineCount=len(target.read_bytes().splitlines()), passed=True))
    (DEST/'copied-source-manifest.json').write_text(json.dumps(records, indent=2)+'\n')
    print(json.dumps(dict(copied=len(records), priorSnapshotHashesVerified=True)))

if __name__ == '__main__':
    main()
