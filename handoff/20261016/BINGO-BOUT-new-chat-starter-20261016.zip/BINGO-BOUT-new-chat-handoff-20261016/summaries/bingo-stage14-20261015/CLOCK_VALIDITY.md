# CPU時計差を物理的なCPU会計と認定しない理由

生traceと元のanalysis.jsonを変更せず、audit_clocks.pyが3つの矛盾する区間を再点検した。全markerの名前・thread・startTime対応や算術が一致しても、そのCPU差が物理的な会計として正しいことは別である。

| run・版・分岐・trial | 区間 | PerformanceMark wall / tts差（ms） | TimeStamp wall / tts差（ms） |
| --- | --- | ---: | ---: |
| 1 原本 legacy 9 | handler→1RAF | 7.347 / 9.630 | 7.348 / 9.632 |
| 3 原本 legacy 3 | handler | 3.416 / 8.583 | 3.396 / 8.566 |
| 4 段階5 DP 3 | handler | 3.128 / 9.848 | 3.116 / 9.837 |

全て正式試行で、CPU差の超過は2.283〜6.720ms。ULPやµs単位の丸めと同一視しない。同じ症状がconsole TimeStampにもあるため、pageのstartTimeをJSONへserializeした対応だけの問題とは扱えない。これらの応答と重なる完了Xのうち、イベント全体のtdurがdurを超えるものも各3・8・7件あった。イベントは入れ子を含み、独立した20件の原因とは数えない。各marker・周辺イベント・元traceのhashはclock-audit.json。

analysis.jsonのallMarkerHashesClocksThreadsAndBranchesPassedは、名前・有限/単調な端点・同じthread・page値対応等の検証が通ったという意味であり、CPU時計の物理的整合性PASSではない。同じ出力にcpuExceedsWallWindowCountWithoutTolerance=3と各区間のfalseフラグが残る。これを消したり、負の残差を0に変えたり、試行を除外したりしていない。

問題の時計増分を含む長い親区間がCPU<=wallに収まっていても、そのCPU会計が正しいことを証明しない。今回の全結果について、記録tts差を厳密なCPU寄与率へ使わず、wall−tts差を待機量へ換算しない。残る区間の範囲内という観測だけでも全時計の妥当性を保証しない。

## 別のOS時計診断

追加計測前にCLOCK_PLAN.mdを固定し、native_clocks.cをccで警告なしにコンパイルした。4fresh process×128=512区間を一度だけ実行。busy1/4msとそれぞれsleep2ms追加の4条件を各processで32回ずつ使い、全標本を保存した。

CLOCK_MONOTONICの外側読取りでCLOCK_THREAD_CPUTIME_IDの区間を包み、全512件で0<=CPU差<=外側wall差だった。区間前後のCPU core番号に差があった標本は0件。ただし途中の移動まで網羅して観測したものではない。元の端点・全stdout・コンパイラ結果・source/plan/script/binary hashはnative-clocks.json。

これは別process・別取得法・別負荷での限定した確認である。Chromiumの実際のtts取得経路がこの直接APIと同一だったこと、仮想化/OS会計/移動/trace実装のどれが原因か、環境全体の時計が常に正しいことを証明しない。Chromium側の3不整合とCPU会計の未確認を保持する。ブラウザークリックの追加・再試行は行っていない。

wallのUserTiming/frame対応やclipしたLayout/Paint/commitイベントは、CPU差と分けて記述できる。ただしtrace・mark自体が動作を変えること、これらが過去の無trace試行の直接原因や物理提示を示さないことも維持する。
