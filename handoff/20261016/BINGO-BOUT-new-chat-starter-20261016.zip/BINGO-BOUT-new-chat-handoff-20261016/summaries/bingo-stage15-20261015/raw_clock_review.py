#!/usr/bin/env python3
"""Finite read-only review of all sixteen existing stage14 JSON traces."""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import statistics


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def finite(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def record(e, index=None):
    result = {key: e[key] for key in ('name', 'cat', 'ph', 'pid', 'tid', 'ts', 'tts', 'dur', 'tdur') if key in e}
    if index is not None:
        result['rawEventIndex'] = index
    return result


def stats(values):
    return {'count': len(values), 'min': min(values) if values else None,
            'median': statistics.median(values) if values else None,
            'max': max(values) if values else None,
            'negative': sum(v < 0 for v in values), 'zero': sum(v == 0 for v in values),
            'positive': sum(v > 0 for v in values)}


def bins(values):
    limits = (0, 1, 10, 100, 1000)
    return {'0<excess<=1us': sum(0 < v <= 1 for v in values),
            '1<excess<=10us': sum(1 < v <= 10 for v in values),
            '10<excess<=100us': sum(10 < v <= 100 for v in values),
            '100<excess<=1000us': sum(100 < v <= 1000 for v in values),
            'excess>1000us': sum(v > 1000 for v in values)}


def sequence(entries):
    """Sort starts by wall ts, retaining export order for tied wall microseconds."""
    entries = sorted(entries, key=lambda pair: (pair[1]['ts'], pair[0]))
    backward, excessive, equal_wall = [], [], []
    for (ai, a), (bi, b) in zip(entries, entries[1:]):
        wall, cpu = b['ts'] - a['ts'], b['tts'] - a['tts']
        item = {'wallDeltaUs': wall, 'ttsDeltaUs': cpu, 'excessUs': cpu - wall,
                'before': record(a, ai), 'after': record(b, bi)}
        if cpu < 0:
            backward.append(item)
        if cpu > wall:
            excessive.append(item)
            if wall == 0:
                equal_wall.append(item)
    positive_wall = [r for r in excessive if r['wallDeltaUs'] > 0]
    return {'entries': len(entries), 'ordering': 'Ascending start ts, raw JSON index breaks ties; no tts sort.',
            'backwardTtsCount': len(backward),
            'backwardTtsAtDistinctWallCount': sum(r['wallDeltaUs'] > 0 for r in backward),
            'largestBackwardTts': sorted(backward, key=lambda r: r['ttsDeltaUs'])[:4],
            'ttsDeltaExceedsWallCount': len(excessive),
            'ttsDeltaExceedsWallAtSameRoundedWallTimestamp': len(equal_wall),
            'positiveWallExcessDistribution': bins([r['excessUs'] for r in positive_wall]),
            'largestTtsDeltaExceedsWall': sorted(excessive, key=lambda r: r['excessUs'], reverse=True)[:4]}


def overlaps(e, windows):
    end = e['ts'] + max(e.get('dur', 0), 0)
    return [w['id'] for w in windows if e['ts'] < w['endUs'] and end > w['startUs']]


def review(report_path):
    report_raw = report_path.read_bytes()
    report = json.loads(report_raw)
    require(report['status'] == 'completed' and len(report['visits']) == 16, 'Incomplete source report')
    result = {'sourceReport': str(report_path.resolve()),
              'sourceReportSha256': hashlib.sha256(report_raw).hexdigest(),
              'reviewScriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'interpretation': {
                  'noNewMeasurement': True, 'noSourceTraceCopies': True,
                  'scope': 'Same renderer-main PID/TID per visit; all sixteen existing trace hashes verified. I/X start snapshots and complete X durations are assessed independently. PerformanceMark and console TimeStamp exact-name pairs retain original timestamps.',
                  'precision': 'Strict counts use no tolerance. Excess bins describe scale only and never remove, clamp or correct anomalies. Tied rounded wall microseconds are identified separately. Nested full-X excesses are not summed as independent CPU.',
                  'metadata': 'JSON trace_processor_stats describe that export/import pass. Zero loss/invalid_cpu_times counters do not override locally contradictory exported ts/tts. JSON lacks original protobuf packet sequence/clock snapshot records needed to assign an export-stage cause.',
                  'performancePass': False}, 'traces': []}
    for visit in report['visits']:
        meta = visit['trace']
        path = Path(meta['path'])
        path = path if path.is_absolute() else report_path.parent / path
        if not path.is_file():
            path = report_path.parent / 'traces' / Path(meta['path']).name
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == meta['sha256'], 'Trace hash mismatch')
        trace = json.loads(raw)
        events = trace['traceEvents']
        marks, stamps = {}, {}
        for index, event in enumerate(events):
            name = event.get('name', '')
            if name.startswith('bingo.stage14.'):
                marks.setdefault(name, []).append((index, event))
            if name == 'TimeStamp':
                message = event.get('args', {}).get('data', {}).get('message', '')
                if message.startswith('bingo.stage14.'):
                    stamps.setdefault(message, []).append((index, event))
        marker_pairs, response_windows, marker_windows = [], [], []
        for sample in visit['samples']:
            same = {}
            for marker in sample['markers']:
                name = marker['name']
                require(len(marks[name]) == len(stamps[name]) == 1, 'Marker pairing is not unique')
                mi, m = marks[name][0]; si, s = stamps[name][0]
                require((m['pid'], m['tid']) == (s['pid'], s['tid']), 'Marker clock thread mismatch')
                same[marker['label']] = (m, s)
                wall = s['ts'] - m['ts']
                cpu = s['tts'] - m['tts'] if finite(m.get('tts')) and finite(s.get('tts')) else None
                marker_pairs.append({'name': name, 'wallDeltaUs': wall, 'ttsDeltaUs': cpu,
                                     'excessUs': cpu - wall if cpu is not None else None,
                                     'performanceMark': record(m, mi), 'consoleTimeStamp': record(s, si)})
            sample_id = f"run{visit['run']}.{visit['version']}.{sample['branch']}.trial{sample['trial']:02d}"
            response_windows.append({'id': sample_id, 'warmup': sample['warmup'],
                                     'startUs': same['capture'][0]['ts'], 'endUs': same['second-raf'][0]['ts']})
            for name, a, b in (('handler', 'capture', 'handler-end'),
                               ('handlerToFirstRaf', 'handler-end', 'first-raf'),
                               ('firstToSecondRaf', 'first-raf', 'second-raf'),
                               ('captureToSecondRaf', 'capture', 'second-raf')):
                entry = {'id': sample_id, 'window': name, 'warmup': sample['warmup']}
                for kind, ix in (('performanceMark', 0), ('consoleTimeStamp', 1)):
                    start, end = same[a][ix], same[b][ix]
                    wall, cpu = end['ts'] - start['ts'], end['tts'] - start['tts']
                    entry[kind] = {'wallUs': wall, 'ttsDifferenceUs': cpu, 'excessUs': cpu - wall,
                                   'start': record(start), 'end': record(end)}
                marker_windows.append(entry)
        pid, tid = marker_pairs[0]['performanceMark']['pid'], marker_pairs[0]['performanceMark']['tid']
        main = [(i, e) for i, e in enumerate(events) if (e.get('pid'), e.get('tid')) == (pid, tid)]
        start_ix = [(i, e) for i, e in main if e.get('ph') in ('I', 'X')
                    and finite(e.get('ts')) and finite(e.get('tts'))]
        instant = [(i, e) for i, e in start_ix if e['ph'] == 'I']
        complete = [(i, e) for i, e in main if e.get('ph') == 'X'
                    and finite(e.get('dur')) and finite(e.get('tdur'))]
        violations = []
        by_name = Counter()
        for index, event in complete:
            if event['tdur'] > event['dur']:
                matches = overlaps(event, response_windows)
                violations.append({'event': record(event, index),
                                   'excessUs': event['tdur'] - event['dur'],
                                   'overlappingResponseSamples': matches})
                by_name[event['name']] += 1
        original_cpu_metadata = {key: value for key, value in trace['metadata'].items()
                                 if any(token in key.lower() for token in ('clock', 'cpu-', 'os-kernel', 'revision'))}
        proc_stats = trace['metadata'].get('trace_processor_stats', {})
        relevant_stats = {key: value for key, value in proc_stats.items()
                          if any(token in key for token in ('clock', 'thread', 'cpu', 'incremental', 'timestamp', 'packet', 'sequence'))
                          and not isinstance(value, (dict, list))}
        nonzero_stats = {key: value for key, value in proc_stats.items()
                         if isinstance(value, (int, float)) and value != 0}
        anomaly_names = Counter(e['name'] for _, e in main
                                if any(token in e.get('name', '').lower() for token in ('clock', 'cpu', 'sampling', 'profile')))
        matching_metadata_paths = []
        def find_clock_info(value, prefix='metadata'):
            if isinstance(value, dict):
                for key, sub in value.items():
                    path_key = prefix + '.' + key
                    if key in ('cpu_clock', 'cpu_clock_id', 'thread_clock', 'thread_clock_id',
                               'sampling_interval', 'sampling_frequency', 'thread_time_multiplier'):
                        matching_metadata_paths.append({'path': path_key, 'value': sub})
                    find_clock_info(sub, path_key)
            elif isinstance(value, list):
                for i, sub in enumerate(value):
                    find_clock_info(sub, prefix + f'[{i}]')
        find_clock_info(trace['metadata'])
        bad_windows = [entry for entry in marker_windows
                       if entry['performanceMark']['excessUs'] > 0]
        bad_tts_pair = [entry for entry in marker_pairs
                        if entry['ttsDeltaUs'] is not None and (entry['ttsDeltaUs'] < 0 or entry['excessUs'] > 0)]
        x_outside = [v for v in violations if not v['overlappingResponseSamples']]
        gc_events = [(i, e) for i, e in main if e.get('ph') == 'X'
                     and ('GC' in e.get('name', '') or 'garbagecollection' in e.get('name', '').lower())]
        gc_overlap_by_bad = []
        for entry in bad_windows:
            bounds = entry['performanceMark']
            lo, hi = bounds['start']['ts'], bounds['end']['ts']
            matching = [record(e, i) for i, e in gc_events if e['ts'] < hi and e['ts'] + e.get('dur', 0) > lo]
            gc_overlap_by_bad.append({'id': entry['id'], 'window': entry['window'],
                                      'intersectingRecordedGcXCount': len(matching), 'examples': matching[:3]})
        output = {'run': visit['run'], 'version': visit['version'], 'sourceTrace': str(path.resolve()),
                  'sourceSha256': meta['sha256'], 'bytes': len(raw), 'eventCount': len(events),
                  'rendererMainThread': {'pid': pid, 'tid': tid},
                  'mainThreadEventCount': len(main),
                  'mainThreadPhaseCounts': dict(Counter(e.get('ph') for _, e in main)),
                  'markerPairs': {'count': len(marker_pairs),
                                  'consoleMinusPerformanceMarkWallUs': stats([e['wallDeltaUs'] for e in marker_pairs]),
                                  'consoleMinusPerformanceMarkTtsUs': stats([e['ttsDeltaUs'] for e in marker_pairs if e['ttsDeltaUs'] is not None]),
                                  'missingTtsPairs': sum(e['ttsDeltaUs'] is None for e in marker_pairs),
                                  'backwardTtsPairs': sum(e['ttsDeltaUs'] is not None and e['ttsDeltaUs'] < 0 for e in marker_pairs),
                                  'ttsDeltaExceedsWallPairs': sum(e['excessUs'] is not None and e['excessUs'] > 0 for e in marker_pairs),
                                  'largestProblemExamples': sorted(bad_tts_pair, key=lambda e: abs(e['excessUs']), reverse=True)[:4]},
                  'responseClockWindows': {'total': len(marker_windows),
                                           'cpuExceedsWall': bad_windows},
                  'ixStartSequence': sequence(start_ix),
                  'instantStartSequence': sequence(instant),
                  'fullX': {'countWithDurAndTdur': len(complete),
                            'missingTdurCount': sum(e.get('ph') == 'X' and not finite(e.get('tdur')) for _, e in main),
                            'strictCpuExceedsWallCount': len(violations),
                            'excessDistribution': bins([v['excessUs'] for v in violations]),
                            'names': dict(by_name.most_common()),
                            'intersectingResponseCount': len(violations) - len(x_outside),
                            'entirelyOutsideResponseCount': len(x_outside),
                            'largestExamples': sorted(violations, key=lambda v: v['excessUs'], reverse=True)[:5],
                            'largestOutsideResponseExamples': sorted(x_outside, key=lambda v: v['excessUs'], reverse=True)[:3]},
                  'recordedGcIntersectionWithBadClockWindows': gc_overlap_by_bad,
                  'metadata': {'selected': original_cpu_metadata,
                               'relevantTraceProcessorStats': relevant_stats,
                               'allNonzeroScalarTraceProcessorStats': nonzero_stats,
                               'bufferStats': proc_stats.get('traced_buf'),
                               'specificCpuClockOrSamplingMetadata': matching_metadata_paths,
                               'mainThreadClockCpuSamplingEventNameCounts': dict(anomaly_names)}}
        result['traces'].append(output)
        print(json.dumps({'run': visit['run'], 'version': visit['version'],
                          'fullXStrictCpuExceedsWall': len(violations),
                          'over1ms': sum(v['excessUs'] > 1000 for v in violations),
                          'backwardIxTts': output['ixStartSequence']['backwardTtsCount']}), flush=True)
        del trace, events, main
    traces = result['traces']
    names = Counter()
    for t in traces:
        names.update(t['fullX']['names'])
    result['summary'] = {
        'sourceTraces': len(traces), 'sourceTraceBytes': sum(t['bytes'] for t in traces),
        'sourceEvents': sum(t['eventCount'] for t in traces),
        'markerPairs': sum(t['markerPairs']['count'] for t in traces),
        'markerPairsWithBackwardTts': sum(t['markerPairs']['backwardTtsPairs'] for t in traces),
        'markerPairsWithTtsDeltaExceedingWall': sum(t['markerPairs']['ttsDeltaExceedsWallPairs'] for t in traces),
        'responseClockWindowsWithCpuExceedingWall': sum(len(t['responseClockWindows']['cpuExceedsWall']) for t in traces),
        'fullXWithDurAndTdur': sum(t['fullX']['countWithDurAndTdur'] for t in traces),
        'fullXWithCpuExceedingWall': sum(t['fullX']['strictCpuExceedsWallCount'] for t in traces),
        'fullXCpuExcessDistribution': {key: sum(t['fullX']['excessDistribution'][key] for t in traces)
                                      for key in traces[0]['fullX']['excessDistribution']},
        'fullXCpuExceedsWallEntirelyOutsideResponses': sum(t['fullX']['entirelyOutsideResponseCount'] for t in traces),
        'fullXNamesWithCpuExceedingWall': dict(names.most_common()),
        'ixTtsBackwardStarts': sum(t['ixStartSequence']['backwardTtsCount'] for t in traces),
        'ixTtsBackwardStartsAtDistinctWallTimes': sum(t['ixStartSequence']['backwardTtsAtDistinctWallCount'] for t in traces),
        'instantTtsBackwardStarts': sum(t['instantStartSequence']['backwardTtsCount'] for t in traces),
        'instantTtsBackwardStartsAtDistinctWallTimes': sum(t['instantStartSequence']['backwardTtsAtDistinctWallCount'] for t in traces),
        'allSourceHashesVerified': True,
        'rawCpuClockCauseEstablished': False}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('report', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), 'Refuse to overwrite output')
    result = review(args.report)
    with args.output.open('x') as file:
        file.write(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    print(json.dumps(result['summary'], ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
