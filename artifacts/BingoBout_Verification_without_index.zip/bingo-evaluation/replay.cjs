'use strict';
// Replay any one raw result row with the complete action history.
const {load,rng,seed}=require('./loader.cjs');
const {game}=require('./simulate.cjs');
const design=require('./design.json');
const [pairArg,swapArg,firstArg,difficulty,opponent,repArg]=process.argv.slice(2);
if(repArg===undefined){console.error('Usage: node replay.cjs pair swap firstPlayer difficulty opponent replicate');process.exit(2);}
const pair=Number(pairArg),swap=Number(swapArg),firstPlayer=Number(firstArg),rep=Number(repArg);
if(!Number.isInteger(pair)||pair<0||pair>=design.layout_pairs||![0,1].includes(swap)||
 ![1,2].includes(firstPlayer)||!design.difficulties.includes(difficulty)||
 !design.opponents.includes(opponent)||!Number.isInteger(rep)||rep<0||rep>=design.replicates_per_cell)
 throw new Error('Arguments must identify a fixed-design game');
const {api,sha256}=load();if(sha256!==design.source_sha256)throw new Error('Source SHA mismatch');
api.setRandom(rng(seed('bingo-v1','layout',pair)));
const layouts=api.createIndividualNumberLayouts(),p1=Array.from(swap?layouts.p2:layouts.p1),p2=Array.from(swap?layouts.p1:layouts.p2);
const dp=new api.WholeGameDP({layoutP1:p1,layoutP2:p2,firstPlayer});dp.solve();
const tables=[api.buildCpuEqTable(p1),api.buildCpuEqTable(p2)];
console.log(JSON.stringify({sourceSha256:sha256,p1,p2,result:game(api,dp,tables,{pair,swap,firstPlayer,p1,p2},difficulty,opponent,rep,true)},null,2));
