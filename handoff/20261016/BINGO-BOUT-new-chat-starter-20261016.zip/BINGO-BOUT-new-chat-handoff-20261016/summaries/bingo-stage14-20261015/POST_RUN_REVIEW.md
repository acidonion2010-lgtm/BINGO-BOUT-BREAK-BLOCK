# 段階14 保存記録の独立事後レビュー

2026-10-15。report、全16生trace、analysis JSON/CSV、収集器・解析器・PLANを読み、
別実装でmarker・区間和・frame対応・中央値差を再計算した。ブラウザー・DP・性能計測を
追加実行せず、HTML・過去成果物・凍結済みscript/PLAN/raw/analysisは変更していない。

**記録の完全性と計算の照合は通過した。一方、thread CPUがwallを上回る3区間があり、
CPU会計の物理的整合性は未検証である。marker対応の成功をCPU時計の妥当性PASSとは扱わない。**

## 完全性と機能

- 4freshブラウザー、指定Williams4順序の16visit。各版×visit位置を各1回、有向隣接12組を各1回。
  各版のDP先行/legacy先行は2回ずつで、保存された分岐順・trial順がPLANに一致する。
- 16読込すべて322/322自己テスト成功、16実Worker準備がready。
  initialValue/maxGap/valueTableBytes/statusが全visitで一致した。
- 全320recordがaccepted、正式288と別warmup32。各visit・分岐にtrial0のwarmup1、正式trial1～9。
  page errorなし、全visit completed、計画外の追加試行なし。
- 全sampleでtrusted、受理cell2、selectedBreakCell2、REVEAL表示、可視性、disabled、処理状態、
  audio running、音/BGMフラグ、engine ready、turns=[4,4]を照合した。
  DPはwhole1/DP1/legacy0、従来はwhole0/DP0/legacy1で全件一致。
- 計時前の32native CPU BLOCK監査は全版・全runで一致。
  DPはcell7、乱数列[0.8,0.8]、従来はcell2、[0.3,0.3,0.3,0.3]。
  固定公開入力・履歴・合法性・counterも一致する。
  **これは別監査の選択同値であり、各実クリック内部のlocalなCPU BLOCK値を観測した意味ではない。**
- 保存された7関数×16visitのsource文字列を実HTMLの該当宣言と照合した。
  native参照をtrial前/visit後に検査する収集器も確認した。JSONから参照同一性そのものを
  再現することはできないため、その部分は実行コードの検査にも基づく。
- 4入力HTML、4helper、capture script、PLANの実hashがreportと一致し、収集器/PLANは
  事前レビュー時のdigestとも一致。analysisのreportSha256とanalyzerSha256も実ファイルに一致した。

## 全markerとtrace

- 全16traceのbytes・SHA-256・eventCountが収集記録と一致。
  EOF回収記録、dataLossOccurred=false、buffer未充満を確認。
  最大buffer使用率は約9.412%。trace wall clock-domainは全てLINUX_CLOCK_MONOTONIC。
- 明示要求した8カテゴリは全16traceの実カテゴリに存在する。
  getCategoriesは4runとも空だったがunknownとして保存され、要求リストをfilterしていない。
  実カテゴリ・分類内の観測数があることと、すべての作業が網羅されたことは別である。
- 全320sampleの4個、計1,280個のPerformanceMarkは名前が一意で、各1個だけ存在。
  対応するconsole TimeStampも各1個。同じsampleの全markerが同じpid/tidへ結び付き、
  CrRendererMainのmetadataと一致する。各visitで対象threadは1つ。
- page観測時刻、PerformanceMark startTime、trace内startTimeの対応と順序を照合。
  ULPによるserialization対応の確認は性能許容差として使っていない。
  全visitの対象main threadに同期B/Eイベントはなく、境界scopeの見落としはなかった。

## wall・CPU・category・frameの独立再計算

全sampleについてcapture→handler-end、handler-end→1RAF、1RAF→2RAF、capture→2RAFの
1,280区間を生ts/ttsから再計算し、保存されたwall、CPU差、wall−CPU差と一致した。
console TimeStampの区間も別に照合した。tts欠測は今回0件。

同じthreadの完了Xイベントを境界でclipし、9分類の区間和と全X区間和を別実装で再計算した。
taskの被覆/非被覆、分類unionも全区間で一致。分類は相互に重なるため合計しない。
「記録taskで覆われない時間」はidleやrunqueue待ちの証明ではなく、分類の0は
該当する記録X区間がないという意味に限定する。背景threadの時間をmainへ配賦していない。

全640callbackについて、rawのmain_frame_id→SendBeginMainFrame→Scheduler sequence→
該当Viz tickを独立に再対応付けした。今回すべて一意に対応し、保存されたframe時刻差も一致。
この対応はframe pipelineの記述で、物理画面提示やGPU待ちの直接原因を確定するものではない。

## CPU時計の3件の不整合

以下はすべて正式sampleで、単位ms。値は削除・0 clamp・事後許容差化せず保持した。

| run・版・分岐・trial | 区間 | PerformanceMark wall / CPU | 残差wall−CPU | TimeStamp wall / CPU |
|---|---|---:|---:|---:|
| 1・原本・legacy・9 | handler→1RAF | 7.347 / 9.630 | -2.283 | 7.348 / 9.632 |
| 3・原本・legacy・3 | handler | 3.416 / 8.583 | -5.167 | 3.396 / 8.566 |
| 4・段階5・DP・3 | handler | 3.128 / 9.848 | -6.720 | 3.116 / 9.837 |

数msの逸脱なので、小さな浮動小数点丸めだけで説明したとは扱わない。
console TimeStampでも同じ逸脱があり、PerformanceMark startTimeの対応だけの問題とも断定できない。
解析器のcpuExceedsWallWindowCountWithoutTolerance=3は独立集計と一致する。
raw CPUと残差を保存した計算が正しいことと、値を厳密なCPU寄与へ使えることは別である。
CPU寄与率や厳密な待機内訳を確定する結論は支持しない。

PerformanceMark→console TimeStampの最大間隔も2.154ms（run4・段階5・DP・trial9・2RAF）だった。
計装/割込み等を含む診断contextであり、この間隔の直接原因も特定していない。

## visit中央値・版間差・CSV

生traceから再計算した全84metricについて、32visit-branchの9正式sampleの中央値・範囲・
利用件数、計2,688要約を照合した。warmupは事前指定のtrial0だけを除く。
DP/従来×4比較×4run×84metricの2,688個のvisit中央値差と、run別差の記述統計も一致。
CSV320行は一意なrun/version/branch/trialに対応し、全metricが再計算値と一致した。
演算順による最大再計算差は約3.55e-15msで、性能の許容差には使っていない。

主要焦点のDP分岐について、page時計のvisit中央値差をrun1～4順に示す（ms、表示は丸め）。
各欄は別々の中央値差であり、成分同士の加法性を仮定しない。

| 比較 | handler差 | 2RAF差 |
|---|---|---|
| 原本→3.final | -0.3, -0.1, +0.3, 0.0 | +1.1, +0.3, -1.0, -0.7 |
| 原本→5 | -0.6, -0.1, +0.5, -0.3 | +1.1, -0.5, -0.5, +0.2 |
| 5→9 | +0.2, +0.2, -0.2, +0.2 | -0.2, -0.3, 0.0, 0.0 |
| 原本→9 | -0.4, +0.1, +0.3, -0.1 | +0.9, -0.8, -0.5, +0.2 |

従来分岐の4比較も含め、保存された数値と全差が一致した。
これらは同時・同位相のクリック対ではないため、trial番号を独立対標本とした狭いCIを付けない。
phase補正、A/A減算、後付け許容差、旧62条件の更新は行われていない。

今回の観測と、旧+0.45ms handler/+0.50ms・+0.80ms 2RAFの直接原因は別の問いである。
旧試行に同時traceがなく、今回には追加監査・連続trace・marker・RAF monitor・分岐履歴がある。
旧観測を消したり、今回だけで過去の原因を確定したりしない扱いが妥当。
完全性/機能/計算の照合結果は支持するが、CPU会計、過去原因、全経路の厳密非悪化、
無計装の製品latency、物理入力/提示/音声latencyの保証は未確定のままである。
