"""Same realm/state counterfactual: swap only equilibrium, leave all callers fixed."""
import argparse
import functools
import http.server
import json
from pathlib import Path
import statistics
import threading
from playwright.sync_api import sync_playwright

ROOT = Path('/workspace/bingo-refactor')
BEFORE = ROOT / 'index.before.html'
STAGE2 = ROOT / 'stages/index.stage2.final.html'

def class_source(path, name):
    source = path.read_text()
    start = source.index('        class ' + name)
    end = source.index('        function wholeGameWorkerSource()', start)
    return source[start:end]

def summarize(samples):
    deltas = [sample['afterUs'] - sample['beforeUs'] for sample in samples]
    # Distribution-free paired median interval. Order statistics are deliberately
    # used instead of treating millions of repeated calls as independent trials.
    ordered = sorted(deltas)
    return {'beforeMedianUs': statistics.median(s['beforeUs'] for s in samples),
            'afterMedianUs': statistics.median(s['afterUs'] for s in samples),
            'pairedMedianDeltaUs': statistics.median(deltas),
            'pairedDeltaRangeUs': [min(deltas), max(deltas)],
            'positivePairs': sum(delta > 0 for delta in deltas),
            'samples': samples}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=ROOT/'validation/stage3/solver-isolate.json')
    parser.add_argument('--batches', type=int, default=11)
    parser.add_argument('--count', type=int, default=50000)
    parser.add_argument('--candidates', default='stage2,local,argument')
    args = parser.parse_args()
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *unused): pass
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(Handler, directory=str(ROOT)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    result = {'conditions': {'page': 'single foreground Chromium page; one DP/workspace per first-player setting',
                             'batches': args.batches, 'callsPerBatch': args.count,
                             'warmupCalls': args.count, 'swappedCode': 'equilibrium; split candidates also swap strategyGap',
                             'switchWarmupCalls': 1000,
                             'checksum': 'all function results consumed and equality asserted'}, 'rows': []}
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            page = browser.new_page(viewport={'width': 1280, 'height': 900})
            errors = []
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.goto(f'http://127.0.0.1:{server.server_port}/stages/index.stage2.final.html')
            page.bring_to_front()
            original = class_source(BEFORE, 'WholeGameDP')
            shared = class_source(STAGE2, 'CpuEquilibriumSolver')
            page.evaluate('''({original,shared}) => {
                window.isolatedEquilibrium = {};
                isolatedEquilibrium.original = (new Function(original + '\\nreturn WholeGameDP.prototype.equilibrium;'))();
                isolatedEquilibrium.stage2 = CpuEquilibriumSolver.prototype.equilibrium;
                const local = shared.replace('equilibrium(count, pay, stay) {',
                    'equilibrium(count, pay, stay) { const monotone = this.monotone;')
                    .replaceAll('this.monotone &&', 'monotone &&')
                    .replaceAll('!this.monotone', '!monotone')
                    .replaceAll('this.monotone ?', 'monotone ?')
                    .replaceAll('if (this.monotone)', 'if (monotone)');
                isolatedEquilibrium.local = (new Function(local + '\\nreturn CpuEquilibriumSolver.prototype.equilibrium;'))();
                const argument = shared.replace('equilibrium(count, pay, stay) {',
                    'equilibrium(count, pay, stay, monotone = false) {')
                    .replaceAll('this.monotone &&', 'monotone &&')
                    .replaceAll('!this.monotone', '!monotone')
                    .replaceAll('this.monotone ?', 'monotone ?')
                    .replaceAll('if (this.monotone)', 'if (monotone)');
                isolatedEquilibrium.argument = (new Function(argument + '\\nreturn CpuEquilibriumSolver.prototype.equilibrium;'))();
                isolatedEquilibrium.aa = isolatedEquilibrium.original;
                isolatedEquilibrium.split = isolatedEquilibrium.original;
                isolatedEquilibrium.local_split = isolatedEquilibrium.local;
                window.isolatedGaps = {original: CpuEquilibriumSolver.prototype.strategyGap};
                const split = shared.replace(`                    for (let row = 0; row < count; row++) {
                        expected += p[row] * (row === col ? stay : pay[row]);
                    }`, `                    for (let row = 0; row < col; row++) expected += p[row] * pay[row];
                    expected += p[col] * stay;
                    for (let row = col + 1; row < count; row++) expected += p[row] * pay[row];`);
                if (split === shared) throw new Error('gap split substitution failed');
                isolatedGaps.split = (new Function(split + '\\nreturn CpuEquilibriumSolver.prototype.strategyGap;'))();
            }''', {'original': original, 'shared': shared})
            # Check mathematical output before using a timing as evidence.
            equality = page.evaluate('''() => {
                const work = new CpuEquilibriumSolver();
                const cases = [[2,[7,5,3]], [2,[2,2,2]], [-2,[-5,-3,-4]],
                    [0,[4,-3,1]], [1,[5,5,5,2]], [1,[1+2e-12,1+2e-12,1]]];
                let count = 0;
                for (const [stay,pay] of cases) {
                    let baseline;
                    for (const [name,method] of Object.entries(isolatedEquilibrium)) {
                        work.strategyGap = name.includes('split') ? isolatedGaps.split : isolatedGaps.original;
                        const answer = method.call(work,pay.length,pay,stay);
                        const actual = JSON.stringify({answer,p:Array.from(work.probP.slice(0,pay.length)),q:Array.from(work.probQ.slice(0,pay.length))});
                        if (!baseline) baseline = actual;
                        if (baseline !== actual) throw new Error(name + ' mathematical mismatch');
                        count++;
                    }
                }
                return {cases: count, exactlyEqual: true};
            }''')
            result['candidateEquivalence'] = equality
            for first in (1, 2):
                page.evaluate('''async first => {
                    Object.assign(state,{gameMode:'cpu',cpuDifficulty:'master',seatChosen:true,isStarting:true,
                        gameEnded:false,firstPlayer:first,p1NumberLayout:[8,1,6,3,5,7,4,9,2],p2NumberLayout:[5,9,1,7,2,6,3,8,4]});
                    startWholeGameCpu();
                    await new Promise((resolve,reject) => { const poll=() => {
                        if (cpuWholeStatus === 'ready') return resolve();
                        if (cpuWholeStatus === 'fallback') return reject(new Error(cpuWholeFailure));
                        setTimeout(poll,5); }; poll(); });
                    window.isolateDp = cpuWholeDp;
                    isolateDp.equilibrium = isolatedEquilibrium.stage2;
                    const t = isolateDp.attacker[8] === 2 ? 8 : 9;
                    Object.assign(state,{p1Marks:Array.from({length:9},(_,i)=>Boolean(3&(1<<i))),
                        p2Marks:Array.from({length:9},(_,i)=>Boolean(24&(1<<i))),
                        p1TurnsTaken:first === 1 ? (t+1)>>1 : t>>1,
                        p2TurnsTaken:first === 2 ? (t+1)>>1 : t>>1,
                        cpuBlockedCooldown:0,cpuSuccessfulBlockCooldown:0});
                    Math.random = () => 0.8;
                }''', first)
                for role in ('break', 'block'):
                    for difficulty in ('normal', 'master'):
                        page.evaluate('''({first,role,difficulty}) => {
                            const t = isolateDp.attacker[8] === (role === 'break' ? 2 : 1) ? 8 : 9;
                            Object.assign(state,{cpuDifficulty:difficulty,
                                p1TurnsTaken:first===1?(t+1)>>1:t>>1,
                                p2TurnsTaken:first===2?(t+1)>>1:t>>1});
                        }''', {'first': first, 'role': role, 'difficulty': difficulty})
                        for candidate in args.candidates.split(','):
                            samples = page.evaluate('''({candidate,role,count,batches}) => {
                                const variants = {before: isolatedEquilibrium.original, after: isolatedEquilibrium[candidate]};
                                const available = [0,1,2,5,6,7,8];
                                const run = (method) => {
                                    isolateDp.equilibrium = method;
                                    // Warm the switched target outside the timed region.
                                    for (let i=0;i<1000;i++) {
                                        if (role==='break') selectCpuBreakCell(available);
                                        else selectCpuBlockCell(state.p1Marks,state.p1NumberLayout);
                                    }
                                    let checksum = 0;
                                    const started = performance.now();
                                    for (let i=0;i<count;i++) checksum += role==='break'
                                        ? selectCpuBreakCell(available)
                                        : selectCpuBlockCell(state.p1Marks,state.p1NumberLayout);
                                    return {us:(performance.now()-started)*1000/count,checksum};
                                };
                                isolateDp.strategyGap = isolatedGaps.original;
                                const warmBefore = run(variants.before);
                                isolateDp.strategyGap = candidate.includes('split') ? isolatedGaps.split : isolatedGaps.original;
                                const warmAfter = run(variants.after);
                                if (warmBefore.checksum !== warmAfter.checksum) throw new Error('warmup selection mismatch');
                                const samples = [];
                                for (let batch=0;batch<batches;batch++) {
                                    const order = batch % 2 ? ['after','before'] : ['before','after'];
                                    const pair = {};
                                    for (const name of order) {
                                        isolateDp.strategyGap = name === 'after' && candidate.includes('split') ? isolatedGaps.split : isolatedGaps.original;
                                        pair[name] = run(variants[name]);
                                    }
                                    if (pair.before.checksum !== pair.after.checksum) throw new Error('selection mismatch');
                                    samples.push({beforeUs:pair.before.us,afterUs:pair.after.us,checksum:pair.before.checksum});
                                }
                                return samples;
                            }''', {'candidate': candidate, 'role': role, 'count': args.count, 'batches': args.batches})
                            row = {'firstPlayer': first, 'role': role, 'difficulty': difficulty, 'candidate': candidate, **summarize(samples)}
                            result['rows'].append(row)
                            print(f'{first} {difficulty} {role} {candidate}: delta {row["pairedMedianDeltaUs"]:+.4f} us, positive {row["positivePairs"]}/{args.batches}', flush=True)
                page.evaluate('releaseWholeGameCpu()')
            result['browserErrors'] = errors
            assert not errors, errors
            browser.close()
    finally:
        server.shutdown(); server.server_close()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2)+'\n')

if __name__ == '__main__': main()
