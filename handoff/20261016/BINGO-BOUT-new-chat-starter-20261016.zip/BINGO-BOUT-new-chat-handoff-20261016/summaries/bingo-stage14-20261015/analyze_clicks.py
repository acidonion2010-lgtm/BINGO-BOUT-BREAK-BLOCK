#!/usr/bin/env python3
"""Read-only analysis of stage14 trusted HARD clicks and their simultaneous traces.

No browser is launched. Results describe this traced diagnostic condition only.
"""
import argparse
import ast
from collections import Counter
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics


VERSIONS = ('original', 'stage3', 'stage5', 'stage9')
BRANCHES = ('dp', 'legacy')
LABELS = ('capture', 'handler-end', 'first-raf', 'second-raf')
WINDOWS = (('handler', 'capture', 'handler-end'),
           ('handlerToFirstRaf', 'handler-end', 'first-raf'),
           ('firstToSecondRaf', 'first-raf', 'second-raf'),
           ('captureToSecondRaf', 'capture', 'second-raf'))
PAGE_METRICS = ('handlerMs', 'twoRafMs', 'clickPhaseMs',
                'firstRafCallbackLagMs', 'secondRafCallbackLagMs',
                'firstWaitAfterHandlerMs', 'rafIntervalMs', 'rafCallbackIntervalMs')
COMPARISONS = (('original', 'stage3'), ('original', 'stage5'),
               ('stage5', 'stage9'), ('original', 'stage9'))
FRAME_SOURCE = {
    'path': '/workspace/handoff/BINGO-BOUT-handoff/project/validation/stage8/analyse_tasks.py',
    'sha256': 'e22ecc319f79597c01773e9e8499830a6496b148b8ca506869803751ec04b9f2',
    'functionSha256': '400574d63c2b69f47b5ff0ff1302e33d4142e095d905a4422f360ff77c809ad9',
    'eventRecordSha256': 'eff7b54bf00df90a51d4bbb7e6e344c44d4b2a46b18810af032f50ffc5f8c7ff',
    'reuse': 'Exact source copies of frame_for_mark and event_record; no browser imports.'}


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def close_ulp(a, b):
    return finite(a) and finite(b) and abs(a - b) <= max(math.ulp(a), math.ulp(b))


def union_us(intervals, lo, hi):
    clipped = sorted((max(a, lo), min(b, hi)) for a, b in intervals if b > lo and a < hi)
    total, end = 0, lo
    for a, b in clipped:
        total += max(0, b - max(a, end))
        end = max(end, b)
    return total


def clock_window(start, end):
    require(start['pid'] == end['pid'] and start['tid'] == end['tid'], 'Clock thread mismatch')
    require(finite(start.get('ts')) and finite(end.get('ts')), 'Missing wall timestamp')
    wall = (end['ts'] - start['ts']) / 1000
    require(wall >= 0, 'Non-monotonic wall timestamps')
    available = finite(start.get('tts')) and finite(end.get('tts'))
    cpu = (end['tts'] - start['tts']) / 1000 if available else None
    require(cpu is None or cpu >= 0, 'Non-monotonic thread CPU timestamps')
    return {'traceWallMs': wall, 'rendererMainThreadCpuMs': cpu,
            'wallMinusThreadCpuMs': wall - cpu if available else None,
            'cpuAvailable': available,
            'cpuWithinWallWithoutTolerance': cpu <= wall if available else None,
            'cpuMissingReason': None if available else 'One or both matching markers lack finite tts; wall retained.'}


def boundary_scopes(events, windows):
    """Pair B/E scopes; an open/unknown side cannot be assumed outside a window."""
    records = [e for e in events if e.get('ph') in ('B', 'E')]
    stack, scopes = [], []
    for event in sorted(records, key=lambda e: e['ts']):
        if event['ph'] == 'B':
            stack.append(event)
        elif stack:
            begin = stack.pop()
            scopes.append({'begin': event_record(begin), 'end': event_record(event),
                           'startUs': begin['ts'], 'endUs': event['ts']})
        else:
            scopes.append({'begin': None, 'end': event_record(event),
                           'startUs': None, 'endUs': event['ts']})
    scopes.extend({'begin': event_record(e), 'end': None, 'startUs': e['ts'], 'endUs': None}
                  for e in stack)
    for scope in scopes:
        lo = scope['startUs'] if scope['startUs'] is not None else -math.inf
        hi = scope['endUs'] if scope['endUs'] is not None else math.inf
        require(not any(lo < end and hi > start for start, end in windows),
                {'unsupportedSynchronousBoundaryScopeIntersectsResponse': scope})
    return {'eventCount': len(records), 'scopeCount': len(scopes),
            'allOutsideResponseWindows': True, 'scopes': scopes}


def task_summary(events, lo, hi):
    tasks = [e for e in events if e['name'] in ('ThreadControllerImpl::RunTask', 'RunTask')
             and e['ts'] < hi and e['ts'] + e['dur'] > lo]
    intervals = sorted((max(lo, e['ts']), min(hi, e['ts'] + e['dur'])) for e in tasks)
    end, gaps = lo, []
    for a, b in intervals:
        if a > end:
            gaps.append({'startUs': end, 'endUs': a, 'wallMs': (a - end) / 1000})
        end = max(end, b)
    if end < hi:
        gaps.append({'startUs': end, 'endUs': hi, 'wallMs': (hi - end) / 1000})
    covered = union_us(intervals, lo, hi)
    require(covered + sum(g['endUs'] - g['startUs'] for g in gaps) == hi - lo,
            'Task gap partition mismatch')
    return {'recordedTopLevelTaskUnionMs': covered / 1000,
            'notCoveredByRecordedTasksMs': (hi - lo - covered) / 1000,
            'taskCountOverlappingWindow': len(tasks),
            'largestUncoveredIntervals': sorted(gaps, key=lambda g: g['wallMs'], reverse=True)[:5],
            'tasksAvailable': any(e['name'] in ('ThreadControllerImpl::RunTask', 'RunTask')
                                  for e in events)}


def category_groups(events):
    return {'styleLayout': {'UpdateLayoutTree', 'Layout'},
            'paintPreparation': {'PrePaint', 'Paint', 'Layerize'},
            'garbageCollection': {e['name'] for e in events
                                  if 'GC' in e['name'] or 'garbagecollection' in e['name'].lower()},
            'commitWait': {'LayerTreeHost::WaitForCommitCompletion'},
            'topLevelTask': {'ThreadControllerImpl::RunTask', 'RunTask'},
            'functionCall': {'FunctionCall'}, 'eventDispatch': {'EventDispatch'},
            'animationCallback': {'FireAnimationFrame'},
            'mainFrame': {'ProxyMain::BeginMainFrame'}}


def analyse_window(events, marks, stamps, start_label, end_label):
    lo, hi = marks[start_label]['ts'], marks[end_label]['ts']
    row = clock_window(marks[start_label], marks[end_label])
    row['consoleTimeStampClockWindow'] = clock_window(stamps[start_label], stamps[end_label])
    overlapping = [e for e in events if e['ts'] < hi and e['ts'] + e['dur'] > lo]
    covered = union_us([(e['ts'], e['ts'] + e['dur']) for e in overlapping], lo, hi)
    row.update({'startTraceUs': lo, 'endTraceUs': hi,
                'recordedXIntervalUnionMs': covered / 1000,
                'notCoveredByRecordedXIntervalsMs': (hi - lo - covered) / 1000,
                'intervalUnionByCategoryMs': {}, 'categoryObservation': {},
                'overlappingEventCount': len(overlapping),
                'overlappingEventsMissingThreadDuration': sum(not finite(e.get('tdur')) for e in overlapping)})
    for group, names in category_groups(events).items():
        row['intervalUnionByCategoryMs'][group] = union_us(
            [(e['ts'], e['ts'] + e['dur']) for e in overlapping if e['name'] in names], lo, hi) / 1000
        visit_count = sum(e['name'] in names for e in events)
        row['categoryObservation'][group] = {
            'matchingXEventsInVisit': visit_count,
            'matchingXEventsInWindow': sum(e['name'] in names for e in overlapping),
            'observedInVisit': bool(visit_count),
            'zeroUnionMeaning': 'Zero union means no matching recorded X interval; absence of the underlying work is not established.'}
    row['topLevelTasks'] = task_summary(events, lo, hi)
    row['functionCalls'] = [
        {'function': e.get('args', {}).get('data', {}),
         'clippedWallMs': (min(hi, e['ts'] + e['dur']) - max(lo, e['ts'])) / 1000,
         'fullEventWallMs': e['dur'] / 1000,
         'fullEventThreadCpuMs': e['tdur'] / 1000 if finite(e.get('tdur')) else None}
        for e in overlapping if e['name'] == 'FunctionCall']
    row['commitWaitEvents'] = [event_record(e) for e in overlapping
                              if e['name'] == 'LayerTreeHost::WaitForCommitCompletion']
    return row


def validate_page(sample, branch):
    require(sample['trusted'] is True, 'Untrusted click')
    for field in ('messageVisible', 'selectedCellAccepted', 'selectedCellDisabled',
                  'documentVisible', 'processingAtHandlerEnd', 'processingAtTwoRaf'):
        require(sample.get(field) is True, {'pageInvariant': field, 'sample': sample})
    require(sample.get('audioState') == 'running' and sample.get('soundMuted') is False
            and sample.get('bgmOff') is False, 'Audio/BGM inactive')
    require(sample.get('wholeDecisions') == (1 if branch == 'dp' else 0), 'Wrong full-DP decision counter')
    require(sample.get('clickedIndex') == 2 and sample.get('selectedBreakCell') == 2,
            'Expected accepted human BREAK cell2')
    require(sample.get('wholeStatus') == 'ready' and sample.get('turns') == [4, 4],
            'Wrong engine/turn fixture')
    require(sample.get('messageAtHandlerEnd') == 'REVEALING PICKS...'
            and sample.get('messageAtTwoRaf') == 'REVEALING PICKS...', 'Wrong reveal message')
    require(sample.get('hardDpDecisions') == (1 if branch == 'dp' else 0)
            and sample.get('hardLegacyDecisions') == (1 if branch == 'legacy' else 0),
            {'wrongHardBranch': branch, 'sample': sample})
    for metric in PAGE_METRICS:
        require(finite(sample.get(metric)), {'missingPageMetric': metric})


def validate_audits(visit, reference):
    audits = visit['audits']
    require(set(audits) == set(BRANCHES), 'Missing branch audit')
    expected_state = {
        'marks': [bool(3 & (1 << i)) for i in range(9)],
        'layout': [8, 1, 6, 3, 5, 7, 4, 9, 2],
        'otherMarks': [bool(24 & (1 << i)) for i in range(9)],
        'otherLayout': [5, 9, 1, 7, 2, 6, 3, 8, 4],
        'turns': [4, 4], 'phase': 'break', 'selected': None,
        'history': [0, 2, 0, 0, 2, 0]}
    for branch, audit in audits.items():
        require(audit['publicState'] == expected_state, 'Audit fixture differs from fixed public state')
        require(audit['status'] == 'ready', 'Audit engine not ready')
        require(audit['counters'] == ({'whole': 1, 'legacy': 0, 'dp': 1} if branch == 'dp'
                                     else {'whole': 0, 'legacy': 1, 'dp': 0}),
                'Audit branch counters mismatch')
        roll = 0.8 if branch == 'dp' else 0.3
        require(audit['draws'] and all(value == roll for value in audit['draws']),
                'Audit random sequence mismatch')
        cell = audit['cell']
        require(isinstance(cell, int) and not isinstance(cell, bool) and 0 <= cell <= 8
                and not audit['publicState']['marks'][cell], 'Audit chose invalid cell')
        if branch in reference:
            require(audit == reference[branch], 'Audit choice/random/counters/state differs across visits')
        else:
            reference[branch] = audit


def collect_sample(visit, sample, events, mark_index, stamp_index):
    run, version, branch, trial = visit['run'], visit['version'], sample['branch'], sample['trial']
    require(branch in BRANCHES and trial in range(10), 'Unexpected branch/trial')
    require(sample['warmup'] is (trial == 0), 'Warmup assignment mismatch')
    page = sample['sample']
    validate_page(page, branch)
    markers = sample['markers']
    require([m['label'] for m in markers] == list(LABELS), 'Marker labels/order mismatch')
    prefix = f'bingo.stage14.run{run}.{version}.{branch}.trial{trial:02d}.'
    marks, stamps = {}, {}
    observed_expected = {'capture': page['clickCaptureNowMs'],
                         'handler-end': page['clickCaptureNowMs'] + page['handlerMs'],
                         'first-raf': page['firstRafCallbackNowMs'],
                         'second-raf': page['secondRafCallbackNowMs']}
    for marker in markers:
        label, name = marker['label'], marker['name']
        require(name == prefix + label, {'unexpectedMarkerName': name, 'expectedPrefix': prefix})
        perf, stamp = mark_index.get(name, []), stamp_index.get(name, [])
        require(len(perf) == len(stamp) == 1, {'markerCountMismatch': name,
                                              'performance': len(perf), 'console': len(stamp)})
        event = perf[0]
        require(close_ulp(event.get('args', {}).get('data', {}).get('startTime'),
                          marker['performanceMarkStartTimeMs']), {'performanceStartTimeMismatch': name})
        require(close_ulp(marker['observedNowMs'], observed_expected[label]),
                {'phaseObservedTimeMismatch': name})
        require(marker['observedNowMs'] <= marker['performanceMarkStartTimeMs']
                <= marker['markerEndNowMs'], {'markerClockOrder': marker})
        marks[label], stamps[label] = event, stamp[0]
    threads = {(e['pid'], e['tid']) for e in (*marks.values(), *stamps.values())}
    require(len(threads) == 1, {'markerThreadsDiffer': sorted(threads)})
    pid, tid = next(iter(threads))
    require(any(e.get('name') == 'thread_name' and e.get('pid') == pid and e.get('tid') == tid
                and e.get('args', {}).get('name') == 'CrRendererMain' for e in events),
            'Missing CrRendererMain correspondence')
    require(all(marks[a]['ts'] <= marks[b]['ts'] and stamps[a]['ts'] <= stamps[b]['ts']
                for a, b in zip(LABELS, LABELS[1:])), 'Marker timestamp order mismatch')
    main = [e for e in events if e.get('pid') == pid and e.get('tid') == tid]
    complete = [e for e in main if e.get('ph') == 'X' and finite(e.get('dur')) and e['dur'] > 0]
    result = {'run': run, 'version': version, 'branch': branch, 'trial': trial,
              'warmup': sample['warmup'], 'rendererThread': {'pid': pid, 'tid': tid},
              'pageMetrics': {key: page[key] for key in PAGE_METRICS},
              'markerNames': [m['name'] for m in markers],
              'performanceMarkToConsoleTimeStampMs': {
                  label: (stamps[label]['ts'] - marks[label]['ts']) / 1000 for label in LABELS},
              'markerInstrumentationWallMs': {
                  m['label']: m['markerEndNowMs'] - m['observedNowMs'] for m in markers},
              'windows': {name: analyse_window(complete, marks, stamps, a, b)
                          for name, a, b in WINDOWS},
              'callbackFrame': {label: frame_for_mark(events, marks[label])
                                for label in ('first-raf', 'second-raf')}}
    return result, (pid, tid), (marks['capture']['ts'], marks['second-raf']['ts'])


def flatten_metrics(row):
    result = {'page.' + key: value for key, value in row['pageMetrics'].items()}
    for name, _, _ in WINDOWS:
        window = row['windows'][name]
        for key in ('traceWallMs', 'rendererMainThreadCpuMs', 'wallMinusThreadCpuMs',
                    'recordedXIntervalUnionMs', 'notCoveredByRecordedXIntervalsMs'):
            result[f'{name}.{key}'] = window[key]
        result.update({f'{name}.category.{key}': value
                       for key, value in window['intervalUnionByCategoryMs'].items()})
        result[f'{name}.recordedTopLevelTaskUnionMs'] = window['topLevelTasks']['recordedTopLevelTaskUnionMs']
        result[f'{name}.notCoveredByRecordedTasksMs'] = window['topLevelTasks']['notCoveredByRecordedTasksMs']
    for label, frame in row['callbackFrame'].items():
        for key in ('traceCallbackLagMs', 'frameTimeToSendMs', 'sendToMainStartMs',
                    'mainStartToCallbackMarkMs', 'vizTickLatenessMs', 'vizTickToSendMs'):
            result[f'{label}.{key}'] = frame.get(key)
    return result


def describe(rows):
    flattened = [flatten_metrics(row) for row in rows]
    result = {}
    for key in flattened[0]:
        values = [row[key] for row in flattened if finite(row[key])]
        result[key] = {'median': statistics.median(values) if values else None,
                       'min': min(values) if values else None, 'max': max(values) if values else None,
                       'availableSamples': len(values), 'totalSamples': len(rows)}
    return result


def analyse(path):
    report_bytes = path.read_bytes()
    report = json.loads(report_bytes)
    require(report['status'] == 'completed', 'Incomplete report')
    require(report.get('pageErrors') == [], 'Page errors were recorded')
    visits = report['visits']
    expected = [(run, VERSIONS[(offset + run - 1) % 4])
                for run in range(1, 5) for offset in (0, 1, 3, 2)]
    require([(v['run'], v['version']) for v in visits] == expected,
            'Visit schedule is not the preregistered four shifted Williams orders')
    rows, trace_reports, global_names, audit_reference = [], [], set(), {}
    prepare_reference = None
    for visit in visits:
        require(visit.get('completed') is True, 'Visit not completed')
        require(visit['selfTests'] == {'passed': 322, 'total': 322, 'failures': []},
                'Normal-load self-tests did not all pass')
        prepare = visit['prepare']
        require(prepare['status'] == 'ready', 'Real Worker not ready')
        current_prepare = {key: prepare[key] for key in ('initialValue', 'maxGap', 'valueTableBytes', 'status')}
        if prepare_reference is None:
            prepare_reference = current_prepare
        else:
            require(current_prepare == prepare_reference, 'Prepared Worker statistics differ across visits')
        validate_audits(visit, audit_reference)
        meta = visit['trace']
        require(meta['integrityChecksPassed'] is True, 'Trace capture integrity not passed')
        trace_path = Path(meta['path'])
        # Allow analysis of the downloaded bundle when its original absolute
        # workspace paths do not exist. The content hash is still mandatory.
        if not trace_path.is_file():
            trace_path = path.parent / 'traces' / trace_path.name
        raw = trace_path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == meta['sha256'], {'traceHashMismatch': str(trace_path)})
        trace = json.loads(raw)
        require(trace.get('metadata', {}).get('clock-domain') == 'LINUX_CLOCK_MONOTONIC',
                'Unexpected trace wall clock')
        events = trace['traceEvents']
        mark_index, stamp_index = {}, {}
        for event in events:
            if event.get('cat') == 'blink.user_timing':
                mark_index.setdefault(event.get('name'), []).append(event)
            if event.get('name') == 'TimeStamp':
                name = event.get('args', {}).get('data', {}).get('message')
                stamp_index.setdefault(name, []).append(event)
        samples = visit['samples']
        require(len(samples) == 20 and {(s['branch'], s['trial']) for s in samples}
                == {(branch, trial) for branch in BRANCHES for trial in range(10)},
                'Missing/duplicate branch trials')
        visit_rows, by_thread = [], {}
        for sample in samples:
            require(sample.get('outcome') == 'accepted', 'Sample not accepted')
            row, thread, window = collect_sample(visit, sample, events, mark_index, stamp_index)
            require(not (global_names & set(row['markerNames'])), 'Duplicate global marker names')
            global_names.update(row['markerNames'])
            by_thread.setdefault(thread, []).append(window)
            visit_rows.append(row)
        require(len(by_thread) == 1, 'Renderer main thread changed during visit')
        boundary = []
        for (pid, tid), windows in by_thread.items():
            main = [e for e in events if e.get('pid') == pid and e.get('tid') == tid]
            check = boundary_scopes(main, windows)
            boundary.append({'pid': pid, 'tid': tid, **check})
        prefix = f'bingo.stage14.run{visit["run"]}.{visit["version"]}.'
        require({name for name in mark_index if isinstance(name, str) and name.startswith(prefix)}
                == {name for row in visit_rows for name in row['markerNames']},
                'Unexpected/missing stage14 PerformanceMark name in trace')
        rows.extend(visit_rows)
        trace_reports.append({'run': visit['run'], 'version': visit['version'],
                              'path': str(trace_path), 'sha256': meta['sha256'],
                              'eventCount': len(events), 'rendererMainThread': dict(zip(('pid', 'tid'), next(iter(by_thread)))),
                              'categoryEventCounts': dict(Counter(e.get('cat', '') for e in events)),
                              'mainThreadXEventNames': dict(Counter(e.get('name', '') for e in events
                                  if e.get('ph') == 'X' and (e.get('pid'), e.get('tid')) in by_thread)),
                              'boundaryScopesOutsideResponseWindows': boundary,
                              'normalLoadSelfTests': visit.get('selfTests'),
                              'normalPrepare': visit.get('prepare'),
                              'selectorAudits': visit['audits']})
    formal = [row for row in rows if not row['warmup']]
    require(len(rows) == 320 and len(formal) == 288 and len(global_names) == 1280,
            'Global sample/marker count mismatch')
    visit_medians = []
    for run in range(1, 5):
        for version in VERSIONS:
            for branch in BRANCHES:
                selected = [r for r in formal if (r['run'], r['version'], r['branch']) == (run, version, branch)]
                require(len(selected) == 9, 'Wrong formal visit size')
                visit_medians.append({'run': run, 'version': version, 'branch': branch,
                                      'samples': 9, 'metrics': describe(selected)})
    differences = []
    for branch in BRANCHES:
        for old, new in COMPARISONS:
            per_run = []
            for run in range(1, 5):
                before = next(v for v in visit_medians if (v['run'], v['version'], v['branch']) == (run, old, branch))
                after = next(v for v in visit_medians if (v['run'], v['version'], v['branch']) == (run, new, branch))
                delta = {}
                for key in before['metrics']:
                    a, b = before['metrics'][key], after['metrics'][key]
                    # A missing CPU/frame measure is not replaced by a partial median in a contrast.
                    delta[key] = b['median'] - a['median'] if a['availableSamples'] == b['availableSamples'] == 9 else None
                per_run.append({'run': run, 'deltaOfVisitMediansMs': delta})
            summary = {}
            for key in per_run[0]['deltaOfVisitMediansMs']:
                values = [r['deltaOfVisitMediansMs'][key] for r in per_run
                          if finite(r['deltaOfVisitMediansMs'][key])]
                summary[key] = {'availableRuns': len(values),
                                'medianDeltaMs': statistics.median(values) if values else None,
                                'minDeltaMs': min(values) if values else None,
                                'maxDeltaMs': max(values) if values else None,
                                'increasedRuns': sum(v > 0 for v in values),
                                'decreasedRuns': sum(v < 0 for v in values),
                                'equalRuns': sum(v == 0 for v in values)}
            differences.append({'branch': branch, 'before': old, 'after': new,
                                'perRun': per_run, 'descriptiveAcrossFourRuns': summary})
    return {'status': 'completed', 'reportPath': str(path.resolve()),
            'reportSha256': hashlib.sha256(report_bytes).hexdigest(),
            'analyzerSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'frameFunctionProvenance': verified_frame_provenance(),
            'categoryDiscovery': report.get('conditions', {}).get('categoryDiscovery'),
            'explicitRequestedCategories': report.get('conditions', {}).get('categories'),
            'checks': {'traces': len(visits), 'totalSamples': len(rows), 'formalSamples': len(formal),
                       'warmupSamples': len(rows) - len(formal), 'uniqueMarkers': len(global_names),
                       'normalLoadSelfTestsPassed': len(visits) * 322,
                       'realWorkerPreparations': len(visits),
                       'selectorAuditsAcrossAllVisits': len(visits) * 2,
                       'selectorAuditChoiceRandomCountersAndFixedInputsAgree': True,
                       'allMarkerHashesClocksThreadsAndBranchesPassed': True,
                       'allBoundaryScopesOutsideResponseWindows': True,
                       'cpuUnavailableWindowCount': sum(not w['cpuAvailable'] for r in rows for w in r['windows'].values()),
                       'cpuExceedsWallWindowCountWithoutTolerance': sum(w['cpuWithinWallWithoutTolerance'] is False
                                                                          for r in rows for w in r['windows'].values()),
                       'callbackFramesAvailable': sum(f['available'] for r in rows for f in r['callbackFrame'].values()),
                       'callbackFrameCount': len(rows) * 2},
            'interpretation': {
                'condition': 'Simultaneously traced trusted locator clicks with scalar phase markers; trace/marker instrumentation perturbs execution. Formal trial 1..9 medians exclude the predeclared trial-0 warmup only.',
                'clocks': 'Same renderer-main-thread PerformanceMark ts differences are monotonic wall microseconds; tts differences are cumulative thread CPU microseconds. Console TimeStamp clocks are retained separately. Missing tts yields null CPU/residual; wall remains. Page/trace PerformanceMark startTime correspondence permits at most one floating-point ULP for serialization only.',
                'residual': 'Wall minus thread CPU includes frame pacing, blocking, idle and time not scheduled. It does not separate those causes. No negative residual is clamped or hidden.',
                'categories': 'Same-thread X durations are clipped and unioned independently within each named category. Categories overlap and must not be added. Every category records observed matching event counts for the visit and window; zero union is not proof that the underlying work was absent. An empty getCategories list means discovery unknown; explicit requested categories remain recorded without filtering. Full-event tdur is not apportioned linearly into a clipped interval. Uncovered task/X time is not proof of idle. commitWait is only the named observed event, not total GPU/OS wait.',
                'frames': 'The preserved stage8 frame matching uses recorded main-frame IDs and scheduler sequence numbers. Unavailable matches remain unavailable. Frame timing is not physical display presentation or ultimate causal attribution.',
                'comparisons': 'Descriptive differences of nine-sample visit medians for the same browser run. Four fresh runs are reported individually; no confidence interval, strict performance PASS, A/A correction, noise allowance or historical-sample causal reassignment is performed.',
                'performancePass': False,
                'historicalUnconfirmedConditionsChanged': False},
            'traces': trace_reports, 'visitMedians': visit_medians,
            'comparisons': differences, 'samples': rows,
            'largestFormalCallbackLag': sorted(formal, key=lambda r: r['pageMetrics']['secondRafCallbackLagMs'], reverse=True)[:8]}


def verified_frame_provenance():
    source = Path(__file__).read_text()
    functions = {node.name: ast.get_source_segment(source, node) for node in ast.parse(source).body
                 if isinstance(node, ast.FunctionDef)}
    for name, key in (('frame_for_mark', 'functionSha256'), ('event_record', 'eventRecordSha256')):
        require(hashlib.sha256(functions[name].encode()).hexdigest() == FRAME_SOURCE[key],
                'Copied stage8 frame helper changed')
    return FRAME_SOURCE


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('report', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    csv_path = args.output.with_suffix('.csv')
    require(not args.output.exists() and not csv_path.exists(), 'Refusing to replace existing JSON/CSV output')
    result = analyse(args.report)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive output creation also prevents an accidental race from replacing data.
    with args.output.open('x') as file:
        file.write(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    with csv_path.open('x', newline='') as file:
        writer = csv.writer(file)
        keys = list(flatten_metrics(result['samples'][0]))
        writer.writerow(['run', 'version', 'branch', 'trial', 'warmup', *keys])
        for row in result['samples']:
            writer.writerow([row[k] for k in ('run', 'version', 'branch', 'trial', 'warmup')]
                            + [flatten_metrics(row)[key] for key in keys])
    print(json.dumps({'output': str(args.output), 'csv': str(csv_path), 'checks': result['checks']}, ensure_ascii=False))


def event_record(event):
    return {key: event[key] for key in ('name', 'cat', 'pid', 'tid', 'ts', 'dur', 'tts', 'tdur', 'args')
            if key in event}

def frame_for_mark(events, mark):
    frames = [e for e in events if e.get('pid') == mark['pid'] and e.get('tid') == mark['tid']
              and e.get('name') == 'ProxyMain::BeginMainFrame' and e.get('ph') == 'X'
              and e['ts'] <= mark['ts'] <= e['ts'] + e.get('dur', 0)]
    result = {'containingMainFrames': len(frames), 'available': False}
    if len(frames) != 1:
        return result
    frame = frames[0]
    pipeline = frame.get('args', {}).get('main_frame_pipeline', {})
    main_id = pipeline.get('main_frame_id')
    sends = [e for e in events if e.get('name') == 'SendBeginMainFrame' and e.get('ph') == 'I'
             and e.get('pid') == mark['pid'] and main_id is not None
             and e.get('args', {}).get('main_frame_pipeline', {}).get('main_frame_id') == main_id]
    result.update({'mainFrame': event_record(frame), 'sendCandidates': len(sends)})
    if len(sends) != 1:
        return result
    send = sends[0]
    sequence = send['args']['main_frame_pipeline']['begin_frame_id']['sequence_number']
    schedulers = [e for e in events if e.get('name') == 'Scheduler::BeginFrame'
                  and e.get('pid') == send['pid'] and e.get('tid') == send['tid']
                  and e.get('ph') == 'X'
                  and e.get('args', {}).get('args', {}).get('sequence_number') == sequence
                  and e['ts'] <= send['ts']]
    result.update({'send': event_record(send), 'schedulerCandidates': len(schedulers)})
    if len(schedulers) != 1:
        return result
    scheduler = schedulers[0]
    frame_time = scheduler['args']['args']['frame_time_us']
    ticks = [e for e in events if e.get('name') == 'DelayBasedBeginFrameSource::OnTimerTick'
             and e.get('ph') == 'X' and e.get('args', {}).get('frame_time') == frame_time
             and e['ts'] <= send['ts']]
    result.update({'available': True, 'scheduler': event_record(scheduler),
                   'frameTimeUs': frame_time, 'frameIntervalUs': scheduler['args']['args']['interval_us'],
                   'matchingVizTicks': [event_record(e) for e in ticks],
                   'traceCallbackLagMs': (mark['ts'] - frame_time) / 1000,
                   'frameTimeToSendMs': (send['ts'] - frame_time) / 1000,
                   'sendToMainStartMs': (frame['ts'] - send['ts']) / 1000,
                   'mainStartToCallbackMarkMs': (mark['ts'] - frame['ts']) / 1000})
    # The three clock intervals telescope to callback lag, without phase fitting.
    assert abs(result['traceCallbackLagMs'] - sum(result[key] for key in
               ('frameTimeToSendMs', 'sendToMainStartMs', 'mainStartToCallbackMarkMs'))) < 1e-9
    if len(ticks) == 1:
        tick = ticks[0]
        result.update({'vizTickLatenessMs': (tick['ts'] - frame_time) / 1000,
                       'vizTickToSendMs': (send['ts'] - tick['ts']) / 1000})
    return result


if __name__ == '__main__':
    main()
