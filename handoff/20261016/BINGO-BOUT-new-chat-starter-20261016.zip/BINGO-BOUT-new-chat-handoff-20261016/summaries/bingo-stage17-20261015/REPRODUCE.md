# 段階17の実行履歴と保存データの再検算

原版HTML・ゲーム関数は変更せず、Python PlaywrightとChromium154.0.8037.57を使った。参照先stage14のfunctional harnessとstage16のfrozen stream/converter/snapshot、raw checker、公式Perfetto binaryは元の絶対パスを維持している。この一式だけで他マシンへ依存物を全配置するinstall scriptではない。元handoff/段階14/16が同じworkspaceにあることが前提で、原本と依存helperのhash gateがある。

採取済みファイルへ再実行しない。次は実行履歴であり、上書き・追加ブラウザーを勧める手順ではない。

```sh
python3 /workspace/bingo-stage17-20261015/make_configs.py
python3 /workspace/bingo-stage17-20261015/capture_units.py
python3 /workspace/bingo-stage17-20261015/resume_capture.py
```

最初の収集器は、unit1のCounterDescriptorが倍率fieldを省略する正当な形式(raw0/effective1)を誤判定して停止した。正式計測はまだ0回だった。`preflight-failed-report.json`、`capture-console.log`、`capture_units.py`、`PLAN.md`と両preflightのraw/JSON/ledgerをそのまま保存した。`PLAN_AMENDMENT.md`と`RESUME_PRE_RUN_REVIEW.md`で既存bytesの再判定を定め、`resume_capture.py`が未実施のunit1 config/clock/health確認を行って、当初予定の残り4browserだけを実行した。追加preflightも計測値の補正もない。

保存済みデータの再検算はブラウザーを必要としない。解析出力は新しいファイル名を選ぶ。

```sh
python3 /workspace/bingo-stage17-20261015/analyze_counter_units.py /workspace/bingo-stage17-20261015/report.json /tmp/stage17-unit-analysis-recheck.json
/workspace/bingo-stage17-20261015/tools/trace_processor_shell convert json /workspace/bingo-stage17-20261015/run3.pftrace /tmp/stage17-unit1-recheck.json
```

正式のraw ledger/SQL抽出は`run_formal_ledgers.py report.json`、`extract_sql.py report.json`で実施し、既存出力を拒否する。保存済み出力がある現在は重ねて実行しない。frozen checkerはstage16の実ファイルを呼び、結果をstage17へ保存する。元checkerはraw倍率を保持し、正の倍率だけを乗算する。修正した解析器は生値と実効値を別列で示す。最初の解析器snapshotと旧データのreplayも保持している。

`check_effective_config.py TRACE --config CONFIG --output NEW_JSON`は、echoed known設定・primary clock・incremental clock64単位・packet defaultsを独立に確認する。unit倍率以外のsemantic設定は同じだが、段階16のlegacy categories経路とraw perfettoConfig経路は区別する。時計の数値が物理的に正確だという判定には使わない。

CPU>wallのstrict符号と>1msの記述用binは別集計。JSONのµs値からns精度を復元せず、SQLのns値も保持する。入れ子の数を独立事象として数えず、CPU欠測・曖昧対応・最初の停止・zero/負値も残す。

同梱tools/trace_processor_shellは実行済み公式binaryと同一SHAで、保存protoの再変換に使える。reference/raw_counter_check.pyは凍結decoderの原文照合用copyであり、source_evidenceの元stage16配置を伴わず単独実行する手順ではない。保存済みledger/SQL/JSONからのanalyze_counter_units.py再集計はbrowserもstage16のdecoder再実行も不要。
