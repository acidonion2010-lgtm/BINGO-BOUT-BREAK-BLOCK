# 段階13：原本から段階5までのソースレビュー

対象は添付引き継ぎの保存版。ソース・既存報告・段階12の記録だけを読み、ブラウザー、solver、性能ジョブは実行していない。本体や過去の成果物は変更していない。目的は、段階12 AでP1序盤BREAKの原本→段階5に6/6の増加区間を観測した範囲を、変更箇所と初期化履歴へ分けること。直接原因を確定するレビューではない。

## 比較に使う保存版

基準ディレクトリは`/workspace/handoff/BINGO-BOUT-handoff/project/`。ファイル全体の実SHA-256を読み取りで計算した。

| 版 | 相対パス | bytes / 行数 | SHA-256 |
| --- | --- | ---: | --- |
| 原本 | `index.before.html` | 501,003 / 9,034 | `e872443dc9764f3b9647f4797d1411ca98f865b9c2f69c6e694529e2685cd3a9` |
| 段階1 | `stages/index.stage1.html` | 501,325 / 9,036 | `00bbb9add62e8bdd3847fc58e93a02a543784e3d91d2da4a4fa18d52531bfaf5` |
| 段階2 | `stages/index.stage2.final.html` | 499,834 / 9,016 | `a6ffdab2b7cdfd491c4d78afecb610af8f6257ad37f57368586031bab1d0f662` |
| 段階3 | `stages/index.stage3.final.html` | 500,010 / 9,018 | `11bbe3d0653ca64a07756079125078b86c0abd5ed3927ff664f43ca4e4186275` |
| 段階4 | `stages/index.stage4.html` | 499,303 / 9,004 | `9f7a071e7dc3aa7ac3d2545578d42b92401563ba73229090c6602f0928cddc97` |
| 段階5 | `stages/index.stage5.html` | 499,401 / 9,005 | `fea09e995bfc1036515b92771925bd7968f3c453425ea5517b7a5b480293be64` |

`index.stage2.html`と`index.stage2.final.html`、`index.stage3.html`と`index.stage3.final.html`は、それぞれバイト単位で同じ。段階5は受領済み`index.handoff-20261015.html`と同じ既知hashである。現在の`project/index.html`は段階9なので、段階5の代わりには使わない。

全6版で、`function getCellWeights`直前までと`function cpuTakeTurn`以後を残し、その間を同じ印へ置換した文字列は一致した。共通hashは`12259e844db976779253189cfc6d985c154f6ca775c4cff715acbbdf52b5cb60`。変更はこのCPU範囲内であり、外側のHTML・UI・自己テスト・bootstrap呼出しは同じ。CPU範囲は順に70,787、71,109、69,618、69,794、69,087、69,185 bytesだった。ソース位置やクラスの配置は変わるため、同じ本文が同じ生成コードになるとは限らない。

## MASTER fallbackで実行される経路

P1先攻opening BREAKの共有fixtureでは、CPUはP2、両markは0、P2の攻撃済み回数は0、残り機会r=9。P1先攻の全体DP上のtは1になるが、代替選択自体はfirstPlayerや全体DPを読まない。固定配置・乱数0.8なら、従来の検証対象はP2の`breakProbs[9][0]`からcell7を選ぶ経路である。

```text
selectCpuBreakCell(available)                 // NORMAL本体を飛ばす
  getCpuDifficultyId()
  selectCpuEquilibriumCell('break', undefined)
    cpuWholeLegacyDecisions++               // fallback状態
    assertCpuEqLayout(P2 layout, P2 table)
    assertCpuEqState(P2 marks, 9)
    getCpuDifficultyId()
    table.breakProbs[9][0], table.values[9][0]
    assertCpuEqDistribution(...)
    takeCpuEqSampleRoll(undefined) -> Math.random()
    drawCpuEqDistribution(...)
    consumeCpuEqCooldown('break')            // cooldown=0なら書込みなし
```

この9関数の宣言全体を同じ8スペースのトップレベル境界で抽出し、6版すべてで完全一致と確認した。

| 関数 | UTF-8 bytes | 共通SHA-256 |
| --- | ---: | --- |
| `getCpuDifficultyId` | 163 | `dbf96b274580c174c92d7712bec5b9a286cba3c05a21ebdd7aef9b93d0d6c725` |
| `selectCpuBreakCell` | 578 | `6a99baa5a282c2b11f84fedde95e8d4586e8c1ddaf2c95fcefb6c831ad5c7652` |
| `selectCpuEquilibriumCell` | 2,026 | `9efad0f8abe2ce6dd64c57cce0e8fa927934ab4988aa9625b46f31763134700a` |
| `assertCpuEqLayout` | 911 | `48dc6720a0ccf327fe64aa0e9c7b7874801136431011bcbb6f3c0bd712967a81` |
| `assertCpuEqState` | 754 | `8a512225699907346f98ab13a69a3267a116594ac565505e92735f51d0ee807c` |
| `takeCpuEqSampleRoll` | 390 | `edc779f5463ca64e557991e89f67a3da635f9a9d15b2879f0c57515de4a55a46` |
| `assertCpuEqDistribution` | 798 | `a878a7a1570b69e634358a5c99ca53fa6d9490d3f78542a99b89a2d2c6f4bf20` |
| `drawCpuEqDistribution` | 936 | `b06145066791f75cdfe99fd2864e2afd688f46f3c8ee46a08fd692f40c31d128` |
| `consumeCpuEqCooldown` | 297 | `0110e079c2047796041c0e2ecef5aa12d856c0d710c67098e02d53c4c31885ee` |

この経路で乱数は1回、持続する変更はfallback counterだけ。重み計算、従来方式、HARD混合、全体DPのanalyze/equilibrium/strategyGapは計時内に到達しない。ソース上の一時生成はlayout検証のseen配列、mark検証のopens配列と状態オブジェクト、サンプリングのpositive配列などで、6版の選択処理自体に追加された仕事は見つからない。ただしVMによる物理的な割当や機械語の一致を示したものではない。

## 隣接段階で変わった準備処理

トップレベル関数とクラスメソッドを別々に比較した。ここで「選択内」は上記の固定したMASTER fallback経路を指す。

| 区間 | 差分の実体 | 選択内との関係 |
| --- | --- | --- |
| 原本→1 | `WholeGameDP.constructor/buildLayer`へ`allocateValues`を追加。`startWholeGameCpu`のmain受信側を`new WholeGameDP(config,false)`へ変更 | 受信時に作って捨てていた約18.3 MBの値配列を省く。メタデータや補助表は引き続き構築。Workerと自己テストの既定値はtrueだが、そのconstructor/条件分岐の本文は変わる |
| 1→2 | `CpuEquilibriumSolver`を追加し、`WholeGameDP`が継承。均衡・正規化・gapの4メソッドを共有クラスへ移動。constructorは`super()`へ、`solveState`の未使用maxPay計算を削除。盤面表builderとWorker生成式も変更 | 表構築・全体DP・自己テストを変える。作業配列の確保位置とオブジェクトの初期化順も変わるが、代替選択中にsolverは呼ばれない |
| 2→3 | 共通`equilibrium`のmonotone読取りをローカル化。`strategyGap`で列の対角前・対角・対角後に分割し、元の加算順を維持 | board-only表は同じbuilder本文から変更済みequilibriumを呼ぶ。monotoneモードではstrategyGapを呼ばない。全体DP・自己テストではgapの変更も到達し得る |
| 3→4 | `WholeGameDP.buildMaxScores`を部分集合列挙から残り手番のDPへ変更 | 全体DPのconstructor、受信側の補助表、同期自己テストを変える。盤面表builderとその共通solverには新しい差分なし |
| 4→5 | `WholeGameDP.constructor/buildLayer`で逆引き索引を38本から10本へDPインスタンス内で共有 | 同じく全体DPの準備・自己テストの割当と参照関係を変える。代替選択中に索引表は使わない |

原本→1で変わるトップレベル関数は`startWholeGameCpu`だけ、1→2は`buildCpuEqTable`と`wholeGameWorkerSource`だけ。2→3、3→4、4→5はトップレベル関数に本文差がなく、上表のクラスメソッド差が中心である。

## 盤面単体の表構築

`buildCpuEqTable`の本文は原本/段階1で5,251 bytes、hashは`570c11727505f8109e830e597bc0e9f4315d5bdd49586ae5e24e9f1fafebb450`。段階2〜5では2,639 bytes、hashは`a7e26e7ba008b5e4193dfad618cdc3e5e0b04ccca45b4adaa06d2062309959c5`。

旧版は各状態で利得のitemsオブジェクト配列と支持集合を作り、sortして政策を計算する。段階2以後は`new CpuEquilibriumSolver(true)`、pay/probP/probQ/orderの作業領域、2本のraw政策配列を再利用して計算し、保存する各政策配列は別に作る。返す表のlayout/values/breakProbs/blockProbsという契約は維持される。計算結果の一致と割当・コンパイル履歴の一致は別である。

段階2→3はbuilder本文が同じでも依存するequilibriumが変わる。段階3→4→5は盤面表のbuilderとsolverが同じでも、その前後の全体DPや自己テストの処理が変わる。したがってbuilderのhashだけで準備全体を同じとは扱わない。原本と段階5の政策行bits一致は段階12 Aの保存記録で確認済みだが、中間版すべての値一致を今回の静的レビューだけから保証せず、新しい機能監査で照合する。

### 段階1→2の戻り表の構造と代入順

戻り値の観測可能な配列種別・穴・プロパティの作成順に、新しい相違は見つからない。両版とも`{layout: storedLayout, values, breakProbs, blockProbs}`という同じ順のplain objectを返す。layoutはsliceした通常Array、valuesは長さ10の通常Arrayと各長さ512のFloat64Arrayで、r>0の未到達値はNaNを入れる。政策の外側は長さ10の通常Arrayでindex0は未代入、r=1〜9の各行は長さ512の通常Arrayで、同じpopcount条件により未到達slotを穴のまま残す。

到達するslotに保存するBREAK/BLOCK政策は、両版とも未変更の`storeCpuEqDistribution`が毎回新しく作る長さ9のFloat64Array。段階2でraw作業配列を再利用しても、保存する政策をrawと共有したり、BREAKとBLOCKの保存配列を共用したりはしない。rとmaskの昇順、各rのvalues→break行→block行という確保順、各状態のvalue→BREAK政策→BLOCK政策という代入順も保たれる。旧版の1候補・一様分布・通常支持集合の3分岐も、この保存順を使う。

一方、保存配列の**前後に行う一時処理と割当の順序**は明確に変わる。段階2は最初のr行を作る前にsolverとその作業配列、2本のraw配列を確保する。旧版の状態ごとのitems/support/only/uniform/raw配列等を置き換え、共通equilibriumの`{value,gap}`結果も使う。したがって同じ保存配列種別・政策値でも、割当位置、周囲の生存オブジェクトやGC/コンパイル履歴は同一とは限らない。ただし、実際の内部Map/elements kind、メモリアドレス、policy読出しのJITが変わったことを静的ソースは確認できない。各HTMLの別realmという条件もある。戻り表の形状が変わって読出しが遅くなったと断定せず、準備に伴う配置・VM履歴という追加候補に留める。

## 自己テスト・bootstrap・fixtureの履歴

`runRuleSelfTests`本文は全6版で182,309 bytes、hashは`4af01bec0642bbbaad0894608149f6d36ffe41fddde39ca941ef4c80a8a18694`。静的な呼出し箇所は`new WholeGameDP`が6個、`dp.solve()`が5個である。自己テスト本文が同じでも、この6つのconstructorと5つの同期solveが呼ぶクラスは段階ごとに変わる。盤面表も自己テストの2回の直接構築とMASTERのrefresh検査で構築される。選択やソース文字列検査を含む先行履歴もあるため、「同じテスト件数なら同じVM履歴」とは言えない。

`resetGame`本文も全6版で3,015 bytes、hashは`cb265e6186b1805f85c34b8bdb8046b94604f430dfd635a3ba683567bae12664`。末尾の`mountStaticUiIcons → runRuleSelfTests → resetGame(false) → syncAudioButtons`も同じ。reset後のRAF予約などは残るが、予約元が同じことは実行時刻や他処理との重なりを保証しない。

共有frame benchmarkは計時前にP1/P2の盤面表を構築し、実Workerで全体DPを準備する。fallback条件でもDP receiverを保持し、configureでは全体DPのanalyzeを計時外に実行してから`cpuWholeDp=null/status=fallback`とする。この準備・scratch・保持メモリ・実行履歴は6版で同じ費用ではない。先に実行した条件、warmup、iframe作成と計測順、プロセスのGC/JIT/OS状態も未統制の差を残し得る。これらは候補であって原因として確定したものではない。

## Worker生成文字列の区別

`wholeGameWorkerSource`関数本文は原本/段階1で同じだが、`WholeGameDP.toString()`の内容が変わるため、生成されるWorker本文は異なる。段階2以後は共通solverクラスも連結する。以下はクラス宣言と固定handler文字列から、コードを実行せず再構成したUTF-8文字列のhashである。段階5は既存の実Worker記録のhashと一致する。他の版について実ブラウザーで生成したことを今回のレビューは意味しない。

| 版 | 再構成Worker bytes | SHA-256 |
| --- | ---: | --- |
| 原本 | 23,986 | `6d207f7fbc2946eecb26802735c0b55e2a7765b0fac7704669dd45268e9885c5` |
| 1 | 24,167 | `a3360a1aeb5d70547063044b210c7f1397bf6eda6d0b78219a7fc6866f76e59d` |
| 2 | 25,052 | `a66185c3998c771ff8901de7fd5bce25bfa73b67291d2c9c111e0595a4282d4e` |
| 3 | 25,228 | `c7e4139c712587928a01475ba5c841a65a2b07ec359d171f4c8667b6bf7dc511` |
| 4 | 24,521 | `fa161eeadb69a5cc2c9931362368020321119567d36091997a2138a766f51233` |
| 5 | 24,619 | `9d54c0c06f6f80320d3f3e07284b75d39a9ebbe3163321ca964ca685aeecb722` |

全中間版へ段階5のWorker hashを要求すると、正しい保存版まで失敗扱いになる。生成関数のhashと生成後の文字列のhashを分けて保存する必要がある。

## 次の切り分けで守る結論の範囲

1. 選択関数の直接の追加処理ではなく、変更した準備と、その前後のVM履歴を主な調査候補にできる。ただしソース同一性は性能同一性の証明ではない。
2. 原本→1、1→2、2→3、3→4、4→5を既存保存版で比較すれば、差が現れたソース区間を探索できる。1→2はboard-only表と全体DP共有化、3→4・4→5は全体DP側という区別がある。いずれかを先に直接原因と断定しない。
3. 性能差は非単調であり得る。段階順で単純な二分探索を行い「最初の悪化コミット」を確定するのではなく、原本と段階5の端点も同時に残す有限の比較として扱う。
4. 各保存版の通常自己テスト、固定政策行bits、乱数・分岐counter・入力不変性、実Workerの成功を新しい比較でも確認する。P1/P2の同政策入力やBLOCKの対照は保持し、対照の差を減算しない。
5. 増加が特定段階で再現しても、JIT・GC・配置やスケジューリングの直接原因まで自動で特定できるわけではない。過去の増加、未確定62条件、全経路の厳密な非悪化が未確認という記録を維持する。
