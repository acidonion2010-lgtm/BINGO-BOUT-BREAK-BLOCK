#!/usr/bin/env python3
"""Independent tiny Perfetto wire fixture; no decoder/checker code is imported.

Schema: google/perfetto at 5dbeaad4ceb91470a835426b52e0cb43a3e5ef10.
Exact upstream schema originals/provenance are saved in the adjacent stage16
official-sources/clock-schema-review and official-sources/counter-review trees.
Only unsigned/int64 protobuf varints and length-delimited messages are needed.
"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent


def varint(value):
    value &= (1 << 64) - 1
    out = bytearray()
    while value > 127:
        out.append((value & 127) | 128)
        value >>= 7
    out.append(value)
    return bytes(out)


def scalar(number, value):
    return varint(number << 3) + varint(value)


def message(number, value):
    if isinstance(value, str):
        value = value.encode()
    return varint((number << 3) | 2) + varint(len(value)) + value


NAMES = {
    1: "S16_fixture_s1_start",
    2: "S16_fixture_s1_span",
    3: "fixture_noise",
    4: "S16_fixture_s1_after",
    5: "S16_fixture_s2_start",
    6: "S16_fixture_s2_end",
    7: "S16_fixture_s1_reset_start",
    8: "S16_fixture_s1_reset_end",
}


def packet(seq, fields):
    return message(1, scalar(10, seq) + fields)


def clear_and_describe(seq, thread_uuid, counter_uuid, tid, wall_ns):
    # ClockSnapshot references are absolute. Clock64 uses microsecond units.
    clock3 = scalar(1, 3) + scalar(2, wall_ns)
    clock64 = (
        scalar(1, 64) + scalar(2, wall_ns // 1000)
        + scalar(3, 1) + scalar(4, 1000)
    )
    snapshot = message(1, clock3) + message(1, clock64) + scalar(2, 3)
    track_defaults = scalar(11, thread_uuid) + scalar(31, counter_uuid)
    defaults = scalar(58, 64) + message(11, track_defaults)
    interned = message(1, scalar(1, 1) + message(2, "fixture"))
    for iid, name in NAMES.items():
        interned += message(2, scalar(1, iid) + message(2, name))
    yield packet(
        seq,
        scalar(13, 1) + message(59, defaults) + message(12, interned)
        + message(6, snapshot),
    )
    thread = scalar(1, 4242) + scalar(2, tid) + message(5, f"FixtureThread{seq}")
    thread_track = scalar(1, thread_uuid) + message(4, thread)
    yield packet(seq, scalar(13, 2) + scalar(8, 0) + message(60, thread_track))
    # COUNTER_THREAD_TIME_NS=1; multiplier1000; incremental=true.
    counter = scalar(1, 1) + scalar(4, 1000) + scalar(5, 1)
    counter_track = (
        scalar(1, counter_uuid) + scalar(5, thread_uuid)
        + message(2, "thread_time") + message(8, counter)
    )
    yield packet(seq, scalar(13, 2) + scalar(8, 0) + message(60, counter_track))


def event(seq, name_iid, event_type, wall_delta_us, cpu_delta_us):
    track_event = scalar(9, event_type) + scalar(3, 1) + scalar(12, cpu_delta_us)
    if name_iid is not None:
        track_event += scalar(10, name_iid)
    return packet(
        seq, scalar(13, 2) + scalar(8, wall_delta_us) + message(11, track_event)
    )


def main():
    parts = []
    parts.extend(clear_and_describe(1, 101, 102, 101, 1_000_000_000))
    parts.extend(clear_and_describe(2, 201, 202, 202, 1_000_010_000))
    # Interleave sequences and place non-marker CPU increments between markers.
    parts.append(event(1, 1, 3, 0, 1000))
    parts.append(event(2, 5, 3, 0, 5000))
    parts.append(event(1, 2, 1, 100, 7))
    parts.append(event(2, 3, 3, 40, 17))
    parts.append(event(1, 3, 3, 25, 13))
    parts.append(event(2, 6, 3, 80, 3))
    parts.append(event(1, None, 2, 75, 11))
    parts.append(event(1, 4, 3, 30, 5))
    # Re-emit seq1 descriptors/defaults/interning. First CPU value is absolute
    # after clear, so 50000 must not be added to the old accumulated 1036.
    parts.extend(clear_and_describe(1, 101, 102, 101, 1_000_300_000))
    parts.append(event(1, 7, 3, 0, 50000))
    parts.append(event(1, 3, 3, 40, 19))
    parts.append(event(1, 8, 3, 60, 2))
    raw = b"".join(parts)
    fixture = ROOT / "counter_fixture.pftrace"
    fixture.write_bytes(raw)
    # These are independently stated arithmetic expectations, not decoded from
    # wire values and not obtained from the implementation under examination.
    expected = {
        "revision": "5dbeaad4ceb91470a835426b52e0cb43a3e5ef10",
        "scope": "two sequences, one reset, default incremental CPU counter",
        "packet_count": 20,
        "track_event_count": 11,
        "markers": [
            {"name": "S16_fixture_s1_start", "type": 3, "seq": 1, "wall_ns": 1000000000, "cpu_ns": 1000000},
            {"name": "S16_fixture_s2_start", "type": 3, "seq": 2, "wall_ns": 1000010000, "cpu_ns": 5000000},
            {"name": "S16_fixture_s1_span", "type": 1, "seq": 1, "wall_ns": 1000100000, "cpu_ns": 1007000},
            {"name": None, "matching_begin_name": "S16_fixture_s1_span", "type": 2, "seq": 1, "wall_ns": 1000200000, "cpu_ns": 1031000},
            {"name": "S16_fixture_s2_end", "type": 3, "seq": 2, "wall_ns": 1000130000, "cpu_ns": 5020000},
            {"name": "S16_fixture_s1_after", "type": 3, "seq": 1, "wall_ns": 1000230000, "cpu_ns": 1036000},
            {"name": "S16_fixture_s1_reset_start", "type": 3, "seq": 1, "wall_ns": 1000300000, "cpu_ns": 50000000},
            {"name": "S16_fixture_s1_reset_end", "type": 3, "seq": 1, "wall_ns": 1000400000, "cpu_ns": 50021000},
        ],
        "expected_slice_cpu_ns": 1007000,
        "expected_slice_thread_duration_ns": 24000,
        "nonmarker_cpu_ns": [5020000 - 3000, 1020000, 50019000],
    }
    (ROOT / "expected.json").write_text(json.dumps(expected, indent=2) + "\n")
    print(json.dumps({"fixture": str(fixture), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}))


if __name__ == "__main__":
    main()
