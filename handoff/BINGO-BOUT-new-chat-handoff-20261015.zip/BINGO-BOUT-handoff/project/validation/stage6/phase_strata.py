#!/usr/bin/env python3
"""Describe trusted-click observations in fixed input-phase bands.

This is exploratory analysis of an already collected dataset. Every measured
sample and every warmup record is retained. The output assigns no latency PASS,
applies no phase correction, and never subtracts A/A from A/B.
"""

import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics


BIN_START_MS = 0
BIN_END_MS = 20
BIN_WIDTH_MS = 1
METRICS = (
    'clickPhaseMs',
    'handlerMs',
    'firstRafMs',
    'twoRafMs',
    'firstWaitAfterHandlerMs',
    'rafIntervalMs',
    'previousRafCallbackLagMs',
    'firstRafCallbackLagMs',
    'secondRafCallbackLagMs',
    'rafCallbackLagChangeMs',
)


def summarize(records):
    """Summarize one arm without changing or discarding its records."""
    return {
        'sampleCount': len(records),
        'visitCount': len({record['sourceRow'] for record in records}),
        'supportedRounds': sorted({record['round'] for record in records}),
        'mediansMs': {
            metric: statistics.median(record['sample'][metric] for record in records)
            if records else None
            for metric in METRICS
        },
        'records': records,
    }


def describe_band(arms):
    summaries = {version: summarize(arms[version])
                 for version in ('before', 'after')}
    common_rounds = sorted(set(summaries['before']['supportedRounds'])
                           & set(summaries['after']['supportedRounds']))
    pairs = []
    for round_number in common_rounds:
        before = summarize([record for record in arms['before']
                            if record['round'] == round_number])
        after = summarize([record for record in arms['after']
                           if record['round'] == round_number])
        # A single sample is retained too; no sample-count or latency threshold
        # determines which supported rounds may appear in the description.
        pairs.append({
            'round': round_number,
            'beforeSampleCount': before['sampleCount'],
            'afterSampleCount': after['sampleCount'],
            'beforeVisitCount': before['visitCount'],
            'afterVisitCount': after['visitCount'],
            'beforeVisitMediansMs': before['mediansMs'],
            'afterVisitMediansMs': after['mediansMs'],
            'visitMedianDifferencesMs': {
                metric: after['mediansMs'][metric] - before['mediansMs'][metric]
                for metric in METRICS
            },
        })
    return {'arms': summaries, 'sameRoundPairs': pairs}


def analyse(data):
    if not data.get('behaviorChecksPassed') or data.get('pageErrors'):
        raise ValueError('Use completed input measurements without browser errors')
    groups = {kind: {version: [] for version in ('before', 'after')}
              for kind in ('aa', 'ab')}
    warmups = []
    for row_number, row in enumerate(data['rows'], 1):
        kind, version = row['kind'], row['version']
        if kind not in groups or version not in groups[kind]:
            raise ValueError(f'Unknown comparison arm in source row {row_number}')
        round_number = row['round']
        if not isinstance(round_number, int) or isinstance(round_number, bool) or round_number < 1:
            raise ValueError(f'Invalid round in source row {row_number}')
        for trial_number, sample in enumerate(row['samples'], 1):
            if sample.get('trusted') is not True:
                raise ValueError(f'Untrusted input in source row {row_number}, trial {trial_number}')
            for metric in METRICS:
                value = sample.get(metric)
                if (not isinstance(value, (int, float)) or isinstance(value, bool)
                        or not math.isfinite(value)):
                    raise ValueError(f'Invalid {metric} in source row {row_number}, trial {trial_number}')
            groups[kind][version].append({
                'sourceRow': row_number,
                'round': round_number,
                'trial': trial_number,
                'sourceVersion': row.get('sourceVersion'),
                'sample': sample,
            })
        if 'warmup' in row:
            warmups.append({
                'sourceRow': row_number,
                'kind': kind,
                'version': version,
                'round': round_number,
                'sourceVersion': row.get('sourceVersion'),
                'sample': row['warmup'],
            })

    comparisons = []
    for kind in ('aa', 'ab'):
        bands = []
        for lower in range(BIN_START_MS, BIN_END_MS, BIN_WIDTH_MS):
            upper = lower + BIN_WIDTH_MS
            arms = {
                version: [record for record in groups[kind][version]
                          if lower <= record['sample']['clickPhaseMs'] < upper]
                for version in ('before', 'after')
            }
            bands.append({
                'lowerInclusiveMs': lower,
                'upperExclusiveMs': upper,
                'label': f'[{lower},{upper}) ms',
                **describe_band(arms),
            })
        outside = {
            version: [record for record in groups[kind][version]
                      if not BIN_START_MS <= record['sample']['clickPhaseMs'] < BIN_END_MS]
            for version in ('before', 'after')
        }
        accounting = {}
        for version in ('before', 'after'):
            retained = sum(band['arms'][version]['sampleCount'] for band in bands)
            retained += len(outside[version])
            if retained != len(groups[kind][version]):
                raise AssertionError(f'Incomplete retention in {kind}/{version}')
            accounting[version] = {
                'sourceMeasuredSampleCount': len(groups[kind][version]),
                'retainedMeasuredSampleCount': retained,
                'outsideRangeSampleCount': len(outside[version]),
            }
        comparisons.append({
            'kind': kind,
            'description': 'original/original' if kind == 'aa' else 'original/current',
            'accounting': accounting,
            'bands': bands,
            'outsideRange': describe_band(outside),
        })

    return {
        'analysisNature': 'Exploratory description of an already collected dataset.',
        'phaseBands': {
            'startInclusiveMs': BIN_START_MS,
            'endExclusiveMs': BIN_END_MS,
            'widthMs': BIN_WIDTH_MS,
            'classification': 'Use unrounded clickPhaseMs; lower inclusive, upper exclusive.',
            'outsideRange': 'Retain every sample below 0 ms or at/above 20 ms separately.',
            'futureUse': 'The same bands can be fixed before additional collection; this script does not certify preregistration.',
        },
        'notes': [
            'All measured samples remain in exactly one band or the outside-range records; no latency-dependent exclusion is applied.',
            'Warmup records are retained separately and do not enter measured-sample summaries.',
            'Each same-round pair requires only one or more measured samples in both arms of that band; sparse support is reported, not treated as sufficient evidence.',
            'Band medians are descriptive. Residual phase differences, visit composition, callback execution, audio, and animation may still differ inside a band.',
            'No phase correction, A/A subtraction, latency decision threshold, statistical PASS, or non-inferiority assessment is applied.',
            'clickPhaseMs and twoRafMs share the same capture timestamp with opposite signs; their correlation is not independent causal evidence.',
            'RAF callbacks are not physical display presentation, input-device latency, or reveal-animation completion measurements.',
        ],
        'metrics': list(METRICS),
        'sourceBehaviorChecksRecorded': data['behaviorChecksPassed'],
        'sourceConditions': data.get('conditions', {}),
        'warmupRecords': warmups,
        'comparisons': comparisons,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    source_bytes = args.input.read_bytes()
    result = {
        'source': str(args.input),
        'sourceSha256': hashlib.sha256(source_bytes).hexdigest(),
        **analyse(json.loads(source_bytes)),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2,
                                      allow_nan=False) + '\n')
    print(json.dumps({
        'output': str(args.output),
        'measuredSampleAccounting': {
            comparison['kind']: comparison['accounting']
            for comparison in result['comparisons']
        },
        'retainedWarmupCount': len(result['warmupRecords']),
        'interpretation': 'Descriptive only; no latency PASS or correction.',
    }, ensure_ascii=False))


if __name__ == '__main__':
    main()
