# Stage16 proc CPU外側記録の独立点検

2026-10-15 JST。完成した`report.json`の保存snapshotだけを読み取り、対象renderer-mainのstat/schedstatを独立にparse・再計算した。ブラウザー・DP・性能ジョブは追加実行していない。CDP ThreadTimeそのものの評価は別レビューへ分離した。

**5visit・66個の対象proc endpointでidentityが対応し、runtime・runqueue・schedule-count差はすべて非負だった。** 今回の広いproc IO外側wallより保存runtime差が大きい例は0件。ただしschedstatの更新鮮度を保証できず、これを厳密CPU会計のPASSやmarker内部のCPU時間とは解釈しない。

## parserとidentity

再計算scriptは`review_cpu_outer.py`、全33actionの元endpoint対応・差・marker照合を`cpu-outer-review.json`へ保存した。source reportとscript、tick単位を確認したcapability JSONのSHA-256を記録している。

statはcomm内の空白/括弧を想定して最後の`)`からfield3以降を分け、field22=starttime、field39=processor、field14/15=utime/stimeを取り出した。全statは52fieldだった。schedstatはruntime ns、runqueue wait ns、schedule countの3整数を読み、collectorが作った派生値に依存せず差を算出した。

targetは各visitの変換済みUserTimingに対応するPID/TIDを使用し、SystemInfoの先頭rendererとは仮定しなかった。全5visitでPID=TID。各visit内の全snapshotでproc PID・comm・starttimeが同じで、collectorの保存identityと独立parse結果も一致した。

| visit | renderer PID/TID | proc comm | stat starttime ticks |
|---|---:|---|---:|
| preflight0 | 34855 | chromium | 2630760 |
| formal1 | 34990 | chromium | 2631229 |
| formal2 | 35200 | chromium | 2632160 |
| formal3 | 35373 | chromium | 2633104 |
| formal4 | 35560 | chromium | 2634055 |

proc commの`chromium`とtrace metadataの`CrRendererMain`は別の名前欄であり、名前だけで同一性を決めていない。保存statのPIDも対象TIDへ一致した。

## 外側差の再計算

正式24action、warmup8action、preflight1actionを混ぜずに集計した。単位ms、schedule countだけ回数。外側wallは「before対象procの最初のIO前→after対象procの最後のIO後」であり、thread CPU区間の実時刻を厳密に指定するものではない。

| 保存値の差・envelope | 正式24の最小 | 中央値 | 最大 |
|---|---:|---:|---:|
| schedstat runtime | 12.013 | 15.201 | 18.829 |
| schedstat runqueue wait | 0.000 | 0.307 | 4.674 |
| schedstat schedule count | 25 | 29 | 46 |
| proc IO外側wall | 58.338 | 72.398 | 81.411 |
| before IO完了→after IO開始 | 58.207 | 72.262 | 81.282 |

正式DP12件のruntime差中央値は16.237ms、legacy12件は15.071msだった。これはfixture・click protocol・待機・callback回収・metric command等を含む広い補助差で、selectorやhandlerのDP追加費用とは呼ばない。分岐間で差し引いて補正しない。

warmup8件のruntime差は14.377〜45.210ms、中央値29.103ms、外側wallは60.346〜150.212ms。preflightのruntime差は9.708ms、外側wallは17.536msだった。warmupを削除せず別記録として残している。

同じsnapshot内のhost順序も、snapshot開始→metric送信/受信→対象proc read開始/終了→snapshot終了へ整合した。対象proc IO全体の記録幅は66endpointで0.062〜0.249msだった。さらに各actionの全mark/stampが「before対象proc read完了〜after対象proc read開始」の数値envelope内にあることを、130名・260timestampsで確認した。これはIOとmarkerの順序対応を確認するもので、scheduler counterの鮮度を証明しない。

## core bookendと粗い補助値

stat field39のlast CPU値は0〜4だった。正式24件中2件で前後が違った。

| action | before last CPU | after last CPU | 保存runtime差ms | runqueue差ms |
|---|---:|---:|---:|---:|
| run1 DP trial1 | 1 | 3 | 18.001 | 4.674 |
| run1 DP trial2 | 3 | 4 | 17.758 | 2.730 |

これは両端で記録されたlast CPU値の変化であり、完全なCPU移動履歴ではない。前後が同じ残りのactionでも、途中の移動がなかったとは保証しない。この2件をCPU時計問題の原因へ帰属させない。

proc stateは66endpoint中64個がS、2個がRだった。stateはcontextとして保存し、Sを「確実に停止していてcounterがfresh」とは扱わない。`SC_CLK_TCK=100`に基づくutime/stimeの差は正式actionで10msまたは20msとなり、runtime差の数ms単位の検証には粗い。量子化した差をruntimeの補正に用いない。

## 制約と引継ぎ

Linux source上、schedstatは`task->se.sum_exec_runtime`の保存値を直接出し、read時に現在まで強制更新する`task_sched_runtime()`とは経路が異なる。before/afterのread時刻がmarkerを包んでも、実効的な会計時点がそのread時刻にあるとは保証できない。広いbracketでruntime差≤wallだった今回の観測から、短いmarker窓の`tts`/`tdur`を正しいと承認しない。

runqueue waitも全host bracket内の累積補助差であり、RAF待機・idle・blocked・GPU待ちをすべて表す値ではない。runtime/runqueue/その他intervalの中央値同士を足してwall差を再構成しない。proc読み取りはPerfetto serializationを迂回するがkernel CPU会計を共有するため、独立した物理CPU時計でもない。

保存差はclampや試行除外を行っていない。今回のidentity・算術・host包含にblockerは見つからないが、元CPU時計異常の原因やHARD非回帰の結論は、raw protobuf/同一入力変換・別CDPレビューと合わせても、その証拠の範囲で判断する必要がある。
