#!/usr/bin/env python3
"""Recheck all saved endpoint-review original bytes and immutable URL revisions."""
import hashlib
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent
BASE = ROOT/'official-sources'/'endpoint-review'
MANIFESTS = ['fetch-manifest.json', 'fetch-manifest-followup1.json',
             'fetch-manifest-followup2.json', 'copied-source-manifest.json']
REVS = {'chromium/chromium': '73c14f6228d7cd537c855007e8f88678969cc0eb',
        'google/perfetto': '5dbeaad4ceb91470a835426b52e0cb43a3e5ef10'}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    checked = []
    failures = []
    attempts = []
    saved = set()
    for name in MANIFESTS:
        manifest = BASE/name
        for row in json.loads(manifest.read_text()):
            assert row['revision'] == REVS[row['repository']]
            assert row['url'] == f"https://raw.githubusercontent.com/{row['repository']}/{row['revision']}/{row['sourcePath']}"
            if not row['passed']:
                attempts.append(row)
                continue
            path = ROOT/row['savedPath']
            assert path.is_relative_to(BASE)
            result = dict(path=row['savedPath'], sha256=sha(path), bytes=path.stat().st_size,
                          lines=len(path.read_bytes().splitlines()), sourceManifest=name)
            result['passed'] = (result['sha256'] == row['sha256'] and
                                result['bytes'] == row['bytes'] and result['lines'] == row['lineCount'])
            if not result['passed']:
                failures.append(result)
            assert path not in saved, path
            saved.add(path)
            checked.append(result)
    originals = {p for p in BASE.rglob('*') if p.is_file() and p.suffix != '.json'}
    assert originals == saved, sorted(map(str, originals ^ saved))
    result = dict(schema='stage18.endpoint-source-audit.v1', scriptSha256=sha(pathlib.Path(__file__)),
                  scope='Hash, length, line count, immutable revision URL and saved-original inventory checks; no browser or clock validation.',
                  manifestHashes={name: sha(BASE/name) for name in MANIFESTS},
                  savedOriginalCount=len(checked), savedOriginalBytes=sum(r['bytes'] for r in checked),
                  unsuccessfulFetches=attempts, checked=checked, failures=failures,
                  passed=not failures)
    (ROOT/'source-endpoint-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(dict(saved=len(checked), failedFetches=len(attempts), passed=result['passed'])))
    assert not failures

if __name__ == '__main__':
    main()
