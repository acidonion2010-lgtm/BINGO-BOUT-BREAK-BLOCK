# 段階15：OS時計を負荷下で包む追加診断（実行前固定）

保存trace全体でmainのXイベントに1ms超のCPU超過が169件あり、全16visitに分布する。ttsの後戻りは見つかっていない。公式sourceでPerfettoのCPU取得はCLOCK_THREAD_CPUTIME_ID、wallとCPUは別時点に読む実装と確認されたが、実データに生じたms規模の原因は未確定。

新しいブラウザーやゲームは起動せず、sourceと同じLinux APIをnative helperで診断する。元trace・段階14全記録・分析器・本体を変更しない。

- 4runそれぞれ1threadと8threadを1processずつ実行する。順序はrun1/3が1→8、run2/4が8→1。計8fresh processを直列実行。1threadではmain自身、8threadではmain＋7pthreadが同期開始する。
- 各thread128区間。scenario=(sample番号+thread番号)%4として、各条件32区間ずつ。総4×(1+8)×128=4,608区間。除外・warmup削除・追加再試行なし。
- 条件0: busy1ms。条件1: sched_yield後busy4ms。条件2: busy1ms後nanosleep2ms。条件3: busy1ms後wall2を読み、さらに意図的busy1msを挟んでCPU1を読む。条件3は既知の非同時取得対照であり、実traceで同じ遅延が生じたという証拠にはしない。
- 共通読取りはcore前→wall0→CPU0→wall1→work→wall2→（条件3の遅延）→CPU1→wall3→core後。全ns端点を保存し、0<=CPU1−CPU0<=wall3−wall0の外側bracketで整合性を見る。
- 併せてCPU差と非同時wall2−wall0を比較して保存する。条件3では意図した末尾CPU読取り遅延がある。外側wall整合と非同時wallの超過を区別する。1µs/1ms閾値は記録の大きさを分類するためだけで、性能許容差ではない。
- 各threadのTID、前後core、全区間前後のgetrusage(RUSAGE_THREAD) context switch数を記録する。process前後の共有cgroup cpu.statも保存し、共有値を個々のthreadやゲームへ配賦しない。affinity、優先度、kernel設定を変えない。
- cc -std=c11 -O2 -Wall -Wextra -Werror -pthreadでcompile。process上限60秒。compile/API失敗は停止しpartial結果を保持する。時計不整合そのものは調査対象として全件保存する。

外側bracketに全件収まっても、Chromiumのtts/tdurが正しいとは承認しない。単独native processとbrowserのcode/負荷/仮想化/CPU移動/trace経路は異なる。意図的遅延で非同時区間の超過を再現しても、実traceの原因を確定しない。現象の有無によるsample追加、元の負の残差の補正、旧62条件の再分類を行わない。
