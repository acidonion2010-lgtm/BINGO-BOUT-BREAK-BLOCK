"""Validate the unchanged uploaded HTML in Chromium, including its real Worker.

Run: python browser_validation.py
Requires installed Python Playwright and /usr/bin/chromium. No npm dependencies.
Starts a localhost-only temporary HTTP server on port 8001 and stops it at exit.
"""
import functools
import hashlib
import http.server
import json
import os
from pathlib import Path
import subprocess
import threading
import time

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
CONFIG = {
    "layoutP1": [8, 1, 6, 3, 5, 7, 4, 9, 2],
    "layoutP2": [2, 7, 6, 9, 5, 1, 4, 3, 8],
    "earlyTermination": True,
}
SEEDS = [0, 1, 2, 42, 73, 98765, 123456789, 4294967295]
STATE_MASKS = [(0, 0, 0), (1, 0, 0), (4, 3, 24), (5, 3, 24),
               (10, 11, 37), (11, 11, 37)]
RNG_JS = """seed => {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}"""


def fixtures():
    result = []
    for first in [1, 2]:
        for difficulty in ["normal", "hard", "master"]:
            for t, m1, m2 in STATE_MASKS:
                attacker = first if t % 2 == 0 else 3 - first
                role = "break" if attacker == 2 else "block"
                marks1 = [bool(m1 & (1 << i)) for i in range(9)]
                marks2 = [bool(m2 & (1 << i)) for i in range(9)]
                turns_first, turns_second = (t + 1) // 2, t // 2
                turns1, turns2 = ((turns_first, turns_second) if first == 1
                                  else (turns_second, turns_first))
                for ix, seed in enumerate(SEEDS):
                    memo = ix % 2 == 1
                    state = {
                        "gameMode": "cpu", "cpuDifficulty": difficulty,
                        "seatChosen": True, "firstPlayer": first,
                        "isStarting": True, "gameEnded": False,
                        "isMuted": True, "isBgmOff": True,
                        "p1NumberLayout": CONFIG["layoutP1"],
                        "p2NumberLayout": CONFIG["layoutP2"],
                        "p1Marks": marks1, "p2Marks": marks2,
                        "p1TurnsTaken": turns1, "p2TurnsTaken": turns2,
                        "inning": t // 2 + 1, "turnRole": t % 2,
                        "phase": "break", "selectedBreakCell": None,
                        "cpuBlockedBreakCell": marks2.index(False) if memo else None,
                        "cpuBlockedBreakStreak": 2 if memo else 0,
                        "cpuBlockedCooldown": 2 if memo else 0,
                        "cpuSuccessfulBlockCell": marks1.index(False) if memo else None,
                        "cpuSuccessfulBlockStreak": 2 if memo else 0,
                        "cpuSuccessfulBlockCooldown": 2 if memo else 0,
                    }
                    result.append({"id": f"{first}-{difficulty}-{t}-{seed}",
                                   "firstPlayer": first, "difficulty": difficulty,
                                   "role": role, "seed": seed, "state": state})
    return result


class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass


def main():
    os.chdir(ROOT)
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "logs").mkdir(exist_ok=True)
    spec = {"config": CONFIG, "fixtures": fixtures()}
    expected_proc = subprocess.run(
        ["node", str(ROOT / "browser_expected.cjs")], input=json.dumps(spec),
        capture_output=True, text=True, check=True)
    expected_data = json.loads(expected_proc.stdout)
    expected = {row["id"]: row for row in expected_data["rows"]}
    server = http.server.ThreadingHTTPServer(
        ("127.0.0.1", 8001), functools.partial(Handler, directory=str(ROOT)))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    console, errors, readiness, rows, ui_checks, http_failures = [], [], [], [], [], []
    started = time.monotonic()
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(executable_path="/usr/bin/chromium",
                                        headless=True, args=["--no-sandbox"])
            page = browser.new_page(reduced_motion="reduce")
            page.on("console", lambda msg: console.append({"type": msg.type, "text": msg.text}))
            page.on("pageerror", lambda error: errors.append(str(error)))
            page.on("response", lambda res: http_failures.append(
                {"url": res.url, "status": res.status}) if res.status >= 400 else None)
            page.add_init_script(f"Math.random = ({RNG_JS})(20261014);")
            response = page.goto("http://127.0.0.1:8001/source.html", wait_until="load")
            built_in = json.loads(page.locator("#rule-test-results").text_content())
            for first in [1, 2]:
                for difficulty in ["normal", "hard", "master"]:
                    subset = [x for x in spec["fixtures"]
                              if x["firstPlayer"] == first and x["difficulty"] == difficulty]
                    # Use the original Worker lifecycle. isStarting suppresses auto UI moves.
                    init = subset[0]["state"]
                    page.evaluate("s => {Object.assign(state, s); startWholeGameCpu();}", init)
                    if difficulty != "normal":
                        page.wait_for_function("cpuWholeStatus !== 'preparing'", timeout=40000)
                    status = page.evaluate("getWholeGameCpuStatus()")
                    readiness.append({"firstPlayer": first, "difficulty": difficulty,
                                      "status": status})
                    # Exercise the original UI dispatch paths as well as selectors.
                    ui_fixture = next(x for x in subset if x["id"] == f"{first}-{difficulty}-0-0")
                    page.evaluate(f"""f => {{
                      Object.assign(state, f.state, {{isStarting:false, isProcessing:false,
                        isHandoffPending:false,pickPressPending:false,
                        isHowToOpen:false,isQuitConfirmOpen:false}});
                      renderBoards();
                      Math.random = ({RNG_JS})(f.seed);
                      if (state.firstPlayer === 2) cpuTakeTurn();
                      else handleCellClick(1, 0, true);
                    }}""", ui_fixture)
                    if first == 1:
                        page.wait_for_function("state.p1TurnsTaken === 1", timeout=5000)
                        ui_cell = page.evaluate("""() => {
                          const cells=[...document.getElementById('board1').children];
                          const index=cells.findIndex(el=>el.classList.contains('shield-miss') ||
                            el.classList.contains('block-clash'));
                          state.turnToken++; return index;
                        }""")
                    else:
                        ui_cell = page.evaluate("state.selectedBreakCell")
                    expected_ui_cell = expected[ui_fixture["id"]]["cell"]
                    ui_checks.append({"firstPlayer": first, "difficulty": difficulty,
                                      "role": ui_fixture["role"], "cell": ui_cell,
                                      "expectedCell": expected_ui_cell,
                                      "match": ui_cell == expected_ui_cell})
                    for fixture in subset:
                        actual = page.evaluate(f"""f => {{
                          Object.assign(state, f.state);
                          Math.random = ({RNG_JS})(f.seed);
                          cpuWholeDecisions = 0; hardLegacyDecisions = 0; hardDpDecisions = 0;
                          const opens = state.p2Marks.flatMap((x,i) => x ? [] : [i]);
                          const cell = f.role === 'break' ? selectCpuBreakCell(opens)
                            : selectCpuBlockCell(state.p1Marks, state.p1NumberLayout);
                          return {{cell, counters: {{whole:cpuWholeDecisions,
                            legacy:hardLegacyDecisions, dp:hardDpDecisions}}, memory: {{
                            cpuBlockedCooldown:state.cpuBlockedCooldown,
                            cpuSuccessfulBlockCooldown:state.cpuSuccessfulBlockCooldown}}}};
                        }}""", fixture)
                        want = expected[fixture["id"]]
                        want_without_id = {key: value for key, value in want.items() if key != "id"}
                        rows.append({"id": fixture["id"], "role": fixture["role"],
                                     "match": actual == want_without_id,
                                     "actual": actual, "expected": want_without_id})
            browser_version = browser.version
            browser.close()
    finally:
        server.shutdown()
        server.server_close()
    data = {
        "sourceSha256": hashlib.sha256((ROOT / "source.html").read_bytes()).hexdigest(),
        "loaderSourceSha256": expected_data["sha256"],
        "browser": browser_version, "httpStatus": response.status,
        "httpFailures": http_failures,
        "elapsedSeconds": time.monotonic() - started,
        "builtInTests": built_in, "pageErrors": errors,
        "workerReadiness": readiness, "parityCases": len(rows),
        "parityMatches": sum(row["match"] for row in rows),
        "uiDispatchChecks": ui_checks,
        "rows": rows,
        "scope": "Exact production CPU selection with deterministic Math.random reset immediately before each decision; UI audiovisual RNG consumption excluded. Real Worker preparation tested separately from synchronous Node DP.",
    }
    (ROOT / "results" / "browser_validation.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    (ROOT / "logs" / "browser_console.json").write_text(
        json.dumps(console, ensure_ascii=False, indent=2) + "\n")
    summary = {"builtInTests": {k: built_in[k] for k in ["passed", "total", "failures"]},
               "workerStatuses": [{"difficulty": row["difficulty"],
                  "firstPlayer": row["firstPlayer"], "status": row["status"]["status"]}
                  for row in readiness], "pageErrors": errors,
               "parityCases": len(rows), "parityMatches": data["parityMatches"]}
    summary["uiDispatchChecks"] = ui_checks
    summary["httpFailures"] = http_failures
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if errors or built_in["failures"] or not all(row["match"] for row in rows + ui_checks):
        raise SystemExit(1)
    if any(row["status"]["status"] != ("inactive" if row["difficulty"] == "normal" else "ready")
           for row in readiness):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
