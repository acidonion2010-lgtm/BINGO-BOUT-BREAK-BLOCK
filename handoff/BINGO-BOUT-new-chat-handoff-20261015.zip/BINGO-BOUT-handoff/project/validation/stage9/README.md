# Stage9: reuse legacy BREAK raw weights

The candidate is `../../stages/index.stage9.candidate.html`, SHA-256
`59fff4685ff3f36e18d73fe9fa524ee57d81a348352e7b2912db4b7ecc1bb513`.
The received stage5 version remains frozen at
`../../stages/index.handoff-20261015.html` (SHA-256 `fea09e99...`).
The original upload remains `../../index.before.html` (SHA-256 `e872443d...`).

Only four CPU functions differ from the received version. Raw weights are shared
between candidate filtering and weighted selection within a single legacy BREAK
decision. NORMAL reuses that same legacy entry. No cache survives a decision.
Other HTML bytes, including UI, sound, rules and the Worker, match stage5 exactly.
The standalone HTML has no new dependency.

Run from `/workspace/bingo-refactor`, one browser/DP measurement job at a time:

```bash
node validation/stage9/legacy_equivalence.cjs
python3 validation/capture.py index.before.html validation/stage9/repro/before --repeats 1 --port 8014
python3 validation/capture.py stages/index.stage9.candidate.html validation/stage9/repro/after --repeats 1 --port 8014
python3 validation/compare.py validation/stage9/repro/before validation/stage9/repro/after --output validation/stage9/repro/comparison.json
python3 validation/stage9/break_candidate.py --baseline stages/index.handoff-20261015.html --candidate stages/index.stage9.candidate.html --output validation/stage9/break-candidate.json
python3 validation/stage9/selector_performance.py index.before.html stages/index.stage9.candidate.html validation/stage9/selector-performance.json --port 8015
python3 validation/worker_lifecycle.py stages/index.stage9.candidate.html --out validation/stage9/worker.json
python3 validation/gameplay_smoke.py --file stages/index.stage9.candidate.html --out validation/stage9/gameplay.json
python3 validation/performance.py index.before.html stages/index.stage9.candidate.html validation/stage9/startup-original.json --port 8016 --repeats 5
python3 validation/performance.py stages/index.handoff-20261015.html stages/index.stage9.candidate.html validation/stage9/startup-handoff.json --port 8016 --repeats 5
```

`legacy-equivalence.json` compares 36,672 paired contracts using all 512 masks,
16 layouts, history/cooldown/threshold cases, exact RNG traces and immutable
ordinary input arrays. It tests legacy helpers and NORMAL/HARD fallback entry
paths; MASTER's equilibrium entry and the full solver are outside this Node test.
`comparison.json` independently compares full browser snapshots against the
uploaded original. `table-binary-integrity.json` additionally checks byte equality
of all 4,581,244 Float64 DP values, including signed-zero representations.

`break-candidate.json` is an incremental same-realm diagnostic. Two fresh browser
processes load the unmodified received HTML, with its 322 automatic tests and
real Blob Workers. Four-function bundles are compiled locally and switched
outside timing against the same inputs/state/DP and RNG function. Ten A/B cases
and three same-reference A/A controls each use nine paired 20,000-call batches
per run: 9,360,000 timed choices. Sixteen untimed individual decisions per
variant/case audit exact choices, RNG counts, dispatch, state and raw-pass counts.
Five BREAK cases have 18/18 negative duration differences each. This diagnostic
changes function ownership/compilation feedback and is not untouched native HTML
or input-to-display timing. A/A observations are retained without subtraction.

`selector-performance.json` compares normally loaded original/candidate HTML in
two fresh browser processes, reversing frame placement and initial arm order.
It keeps stage6's 104 conditions: 84 nonterminal and 20 one-closed selector
contracts; 8 distinct terminal full-game conditions (16 condition/run rows) are
excluded. Nine paired 20,000-call
batches per condition/run total 74,880,000 timed choices. The one-closed contracts
do not represent post-match user interactions. Both runs confirm all 32 legacy
BREAK conditions as shorter. Overall repeated classifications are 42 negative,
62 unconfirmed, zero positive. The pooled descriptive classification is 58
negative, 45 unconfirmed, one positive (P2 opening BREAK MASTER fallback).
Negative class means interval upper bound <= 0, not a strict difference for
every condition. No universal non-regression PASS is claimed.

The new wrapper preserves raw `performance.now()` endpoints and elapsed values.
Primary differences subtract integer-encoded absolute endpoints, then integer
durations, before per-choice normalization. The 1e6 multiplier encodes exposed
milliseconds; it does not provide nanosecond clock accuracy. It prevents tiny
binary cancellation residues from deciding an apparent timer-grid tie. There is
no epsilon, discarded sample, A/A correction or revised performance allowance.
Raw-float classifications are also retained and happen to agree in this run.
Earlier stage6/7/8 measurements and classifications are unchanged historical data.
Intervals are conditional order-statistic descriptions of correlated batches,
not 18 independent browser processes or a multiple-comparison-adjusted guarantee.

`path-review.md`, `measurement-review.md`, `master-fallback-review.md` and
`final-measurement-review.md` record independent read-only reviews. Source and
adoption evidence is separate from measurements. Older raster/commit-wait
investigations remain in stage8 and are not reattributed to this CPU change.
See `../../段階9比較結果.md` for delivery, results and unfinished items.
