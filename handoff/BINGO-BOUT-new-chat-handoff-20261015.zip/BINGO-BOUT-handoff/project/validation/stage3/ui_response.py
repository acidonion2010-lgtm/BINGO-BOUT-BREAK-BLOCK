#!/usr/bin/env python3
"""Measure trusted click handling and two-frame response without editing the game.

One foreground page visits each version once per round; the second round reverses
the version order. The real Blob Worker prepares the fixed DP once per visit.
Each trial restores the same legal midgame and invalidates old turn callbacks
through the game's existing turnToken guard. Sound and CSS animation stay enabled.
The two-RAF measurement is an observation of browser callbacks, not physical
display presentation, input-device latency, or completion of the reveal animation.
"""

import argparse
import functools
import http.server
import json
import os
from pathlib import Path
import statistics
import threading
from urllib.parse import quote

from playwright.sync_api import sync_playwright


PREPARE = r"""async () => {
    state.turnToken++;
    discardThinkTimer();
    Object.assign(state, {
        gameMode: 'cpu', cpuDifficulty: 'master', cpuFormat: 'single',
        startFormat: 'single', seatChosen: true, isStarting: true,
        isProcessing: true, gameEnded: false, firstPlayer: 1,
        p1NumberLayout: [8, 1, 6, 3, 5, 7, 4, 9, 2],
        p2NumberLayout: [5, 9, 1, 7, 2, 6, 3, 8, 4]
    });
    const started = performance.now();
    startWholeGameCpu();
    await new Promise((resolve, reject) => {
        const poll = () => {
            if (cpuWholeStatus === 'ready') return resolve();
            if (cpuWholeStatus === 'fallback') return reject(new Error(cpuWholeFailure));
            if (performance.now() - started > 31000) return reject(new Error('DP preparation timed out'));
            setTimeout(poll, 5);
        };
        poll();
    });
    if (!state.isStarting || cpuWholeDp.attacker[8] !== 1) throw new Error('Preparation/attacker fixture mismatch');
    return {elapsedMs: performance.now() - started,
        initialValue: cpuWholeStats.initialValue, maxGap: cpuWholeStats.maxGap,
        valueTableBytes: cpuWholeStats.valueTableBytes, status: cpuWholeStatus};
}"""


INSTRUMENT = r"""() => {
    window.uiResponseProbe = {armed: false, pending: null, result: null};
    document.addEventListener('click', event => {
        const button = event.target instanceof Element ? event.target.closest('#board1 .cell') : null;
        const probe = window.uiResponseProbe;
        if (!probe.armed || !button) return;
        const started = performance.now();
        probe.pending = {
            started, trusted: event.isTrusted,
            clickedIndex: Array.prototype.indexOf.call(button.parentElement.children, button),
            wholeBefore: cpuWholeDecisions, hardDpBefore: hardDpDecisions,
            hardLegacyBefore: hardLegacyDecisions
        };
        probe.armed = false;
    }, true);
    document.addEventListener('click', () => {
        const probe = window.uiResponseProbe;
        const pending = probe.pending;
        if (!pending) return;
        const ended = performance.now();
        probe.pending = null;
        const sample = {
            trusted: pending.trusted, clickedIndex: pending.clickedIndex,
            handlerMs: ended - pending.started,
            selectedBreakCell: state.selectedBreakCell,
            processingAtHandlerEnd: state.isProcessing,
            messageAtHandlerEnd: document.getElementById('action-msg').textContent.trim(),
            wholeDecisions: cpuWholeDecisions - pending.wholeBefore,
            hardDpDecisions: hardDpDecisions - pending.hardDpBefore,
            hardLegacyDecisions: hardLegacyDecisions - pending.hardLegacyBefore
        };
        requestAnimationFrame(() => {
            sample.firstRafMs = performance.now() - pending.started;
            requestAnimationFrame(() => {
                sample.twoRafMs = performance.now() - pending.started;
                const message = document.getElementById('action-msg');
                const style = getComputedStyle(message);
                const rect = message.getBoundingClientRect();
                const selected = document.getElementById('board1').children[sample.clickedIndex];
                Object.assign(sample, {
                    processingAtTwoRaf: state.isProcessing,
                    messageAtTwoRaf: message.textContent.trim(),
                    messageVisible: rect.width > 0 && rect.height > 0 &&
                        style.display !== 'none' && style.visibility !== 'hidden' &&
                        Number(style.opacity) > 0,
                    selectedCellAccepted: Boolean(selected && selected.classList.contains('pick-accepted')),
                    selectedCellDisabled: Boolean(selected && selected.disabled),
                    documentVisible: !document.hidden && document.visibilityState === 'visible',
                    audioState: audioCtx ? audioCtx.state : 'uninitialized',
                    soundMuted: state.isMuted, bgmOff: state.isBgmOff,
                    wholeStatus: cpuWholeStatus,
                    turns: [state.p1TurnsTaken, state.p2TurnsTaken]
                });
                probe.result = sample;
            });
        });
    });
}"""


FIXTURE = r"""async difficulty => {
    // Existing token checks reject the previous trial's reveal/turn callbacks.
    // Do not replace timers, animation functions, audio, or game click handlers.
    state.turnToken++;
    discardThinkTimer();
    abortThinkTimeUpFx();
    clearAcceptedPick();
    Object.assign(state, {
        gameMode: 'cpu', cpuDifficulty: difficulty, cpuFormat: 'single',
        startFormat: 'single', firstPlayer: 1, inning: 5, turnRole: 0,
        seatChosen: true, isStarting: false, isProcessing: false,
        gameEnded: false, phase: 'break', selectedBreakCell: null,
        p1Marks: Array.from({length: 9}, (_, i) => Boolean(3 & (1 << i))),
        p2Marks: Array.from({length: 9}, (_, i) => Boolean(24 & (1 << i))),
        p1TurnsTaken: 4, p2TurnsTaken: 4,
        isHowToOpen: false, isQuitConfirmOpen: false,
        isHandoffPending: false, pickPressPending: false,
        acceptedPick: null, pendingPress: null,
        cpuBlockedBreakCell: 0, cpuBlockedBreakStreak: 2, cpuBlockedCooldown: 0,
        cpuSuccessfulBlockCell: 0, cpuSuccessfulBlockStreak: 2, cpuSuccessfulBlockCooldown: 0
    });
    state.p1Score = calculateScore(state.p1Marks, state.p1NumberLayout);
    state.p2Score = calculateScore(state.p2Marks, state.p2NumberLayout);
    Math.random = () => 0.8;
    clearTwoPlayerHandoff();
    document.getElementById('how-to-overlay').classList.remove('show');
    document.getElementById('quit-overlay').classList.remove('show');
    setResultModalVisible(false);
    clearScoreGainCallout();
    clearBlockCallouts();
    clearResultPresentation();
    clearBingoLineOverlays();
    document.getElementById('shuffle-callout').classList.remove('show');
    // resetGame synchronizes these DOM flags separately from renderUI.
    document.getElementById('start-panel').classList.add('hidden');
    document.body.classList.add('match-live');
    syncBackgroundInert();
    renderBoards();
    drawBingoLines();
    renderUI();
    scheduleWideLayoutFit();
    const decision = {maskP1: 3, maskP2: 24, t: 8};
    const policy = cpuWholeDp.analyze(decision);
    if (policy.terminal.isTerminal || policy.attacker !== 1 || policy.gap > CPU_WHOLE_EQ_GAP)
        throw new Error('Invalid midgame DP fixture');
    if (!canHumanInteractWithBoard(1) || getCurrentPlayer() !== 1 || isOverlayPointerGuardActive())
        throw new Error('Fixture cannot accept a human BREAK click');
    if (state.isMuted || state.isBgmOff) throw new Error('Sound unexpectedly disabled');
    if (document.hidden) throw new Error('Timing page is not foreground');
    // Include resetGame's nested layout fit and final line redraw before measuring.
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(() => requestAnimationFrame(resolve))));
    const target = getCellButton(1, 2);
    const rect = target.getBoundingClientRect();
    const hit = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2);
    if (!hit || hit.closest('#board1 .cell') !== target || document.getElementById('game-root').inert)
        throw new Error('Fixture BREAK button is obscured or inert');
    if (!document.getElementById('start-panel').classList.contains('hidden'))
        throw new Error('Fixture start panel is still visible');
    uiResponseProbe.pending = null;
    uiResponseProbe.result = null;
    uiResponseProbe.armed = true;
    return {maskP1: 3, maskP2: 24, t: 8, inning: state.inning, player: getCurrentPlayer()};
}"""


def assert_sample(sample, difficulty):
    """Require actual accepted play and DOM response, not only a timer sample."""
    assert sample['trusted'], sample
    assert sample['clickedIndex'] == 2, sample
    assert sample['selectedBreakCell'] == sample['clickedIndex'], sample
    assert sample['processingAtHandlerEnd'] and sample['processingAtTwoRaf'], sample
    assert sample['messageAtHandlerEnd'] == 'REVEALING PICKS...', sample
    assert sample['messageAtTwoRaf'] == 'REVEALING PICKS...', sample
    assert sample['messageVisible'] and sample['selectedCellAccepted'], sample
    assert sample['selectedCellDisabled'] and sample['documentVisible'], sample
    assert not sample['soundMuted'] and not sample['bgmOff'], sample
    assert sample['audioState'] == 'running', sample
    assert sample['wholeStatus'] == 'ready', sample
    assert sample['turns'] == [4, 4], sample
    assert sample['handlerMs'] >= 0 and sample['twoRafMs'] >= sample['handlerMs'], sample
    if difficulty == 'normal':
        assert sample['wholeDecisions'] == 0, sample
    else:
        assert sample['wholeDecisions'] == 1, sample
    if difficulty == 'hard':
        assert sample['hardDpDecisions'] == 1 and sample['hardLegacyDecisions'] == 0, sample


def click_trial(page, difficulty):
    page.evaluate(FIXTURE, difficulty)
    page.locator('#board1 .cell:not([disabled])').first.click(timeout=10000)
    page.wait_for_function('uiResponseProbe.result !== null', timeout=10000)
    sample = page.evaluate('uiResponseProbe.result')
    assert_sample(sample, difficulty)
    return sample


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('before', type=Path)
    parser.add_argument('after', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--trials', type=int, default=9)
    parser.add_argument('--runs', type=int, default=2)
    parser.add_argument('--difficulties', default='normal,hard,master')
    args = parser.parse_args()
    difficulties = args.difficulties.split(',')
    if args.trials < 1 or args.runs < 1 or any(d not in ('normal', 'hard', 'master') for d in difficulties):
        parser.error('Use positive trial/run counts and normal,hard,master difficulties')
    paths = {version: getattr(args, version).resolve(strict=True) for version in ('before', 'after')}
    serve_root = Path(os.path.commonpath([str(path.parent) for path in paths.values()]))

    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *unused):
            pass

    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(Handler, directory=str(serve_root)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    result = {
        'conditions': {
            'executable': '/usr/bin/chromium', 'viewport': [1280, 900],
            'foregroundPages': 1, 'runs': args.runs, 'trialsPerVersionDifficultyRun': args.trials,
            'warmupTrustedClicksPerVersionDifficultyRun': 1,
            'sampleOrder': 'version blocks; odd rounds before/after, even rounds after/before',
            'pageLoadsPerVersion': args.runs, 'realBlobWorkerPreparationsPerVisit': 1,
            'difficultyOrder': difficulties, 'firstPlayer': 1,
            'layouts': {'p1': [8, 1, 6, 3, 5, 7, 4, 9, 2], 'p2': [5, 9, 1, 7, 2, 6, 3, 8, 4]},
            'fixture': {'maskP1': 3, 'maskP2': 24, 't': 8, 'inning': 5, 'turnRole': 0},
            'fixedRandom': 0.8, 'hardBranch': 'whole-game DP (0.8 >= 0.7)',
            'handlerMsDefinition': 'document click capture through document bubble after the game handler',
            'twoRafMsDefinition': 'click capture through the second nested requestAnimationFrame callback',
            'presentationLimit': 'Two RAF callbacks do not measure physical presentation or input-device latency; reveal completion is excluded.',
            'fixtureReset': 'turnToken increment and existing discardThinkTimer invalidate older callbacks; no timer/animation/audio functions replaced.',
            'audioAndAnimation': 'Actual game initialization, BGM, sound and CSS animations stay enabled; warmup clicks are excluded from summaries.',
            'comparisonLimit': 'Small sequential version blocks with reversed round order; results do not establish all-device latency guarantees.'
        },
        'visits': [], 'rows': [], 'pageErrors': [], 'allPassed': False
    }
    current_visit = {}
    current_trial = {}

    def save_report():
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

    # Preserve a readable partial report even if a later operation cannot finish.
    save_report()
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(executable_path='/usr/bin/chromium', headless=True,
                args=['--no-sandbox', '--disable-dev-shm-usage'])
            result['conditions']['browserVersion'] = browser.version
            page = browser.new_page(viewport={'width': 1280, 'height': 900})
            page.on('pageerror', lambda error: result['pageErrors'].append({**current_visit, 'error': str(error)}))
            for run in range(args.runs):
                order = ['before', 'after'] if run % 2 == 0 else ['after', 'before']
                for version in order:
                    current_visit.clear()
                    current_visit.update({'round': run + 1, 'version': version})
                    relative = quote(paths[version].relative_to(serve_root).as_posix())
                    page.goto(f'http://127.0.0.1:{server.server_port}/{relative}', wait_until='load', timeout=60000)
                    page.bring_to_front()
                    tests = json.loads(page.locator('#rule-test-results').text_content())
                    assert tests['total'] == 322 and tests['passed'] == 322, tests
                    preparation = page.evaluate(PREPARE)
                    page.evaluate(INSTRUMENT)
                    result['visits'].append({**current_visit, 'selfTests': tests, 'preparation': preparation})
                    save_report()
                    for difficulty in difficulties:
                        current_trial.update({'difficulty': difficulty, 'kind': 'warmup', 'trial': 0})
                        warmup = click_trial(page, difficulty)
                        samples = []
                        for trial in range(args.trials):
                            current_trial.update({'difficulty': difficulty, 'kind': 'measured', 'trial': trial + 1})
                            samples.append(click_trial(page, difficulty))
                        row = {**current_visit, 'difficulty': difficulty, 'warmup': warmup,
                            'handlerMedianMs': statistics.median(s['handlerMs'] for s in samples),
                            'twoRafMedianMs': statistics.median(s['twoRafMs'] for s in samples),
                            'samples': samples}
                        result['rows'].append(row)
                        save_report()
                        print(f"round {run + 1} {version} {difficulty}: handler {row['handlerMedianMs']:.3f} ms, two RAF {row['twoRafMedianMs']:.3f} ms, {len(samples)} trusted clicks passed", flush=True)
                    # Release this visit through supported lifecycle before navigation.
                    page.evaluate('() => {state.turnToken++; discardThinkTimer(); releaseWholeGameCpu();}')
            browser.close()
        assert not result['pageErrors'], result['pageErrors']
        result['comparisons'] = []
        for difficulty in difficulties:
            medians = {}
            for version in ('before', 'after'):
                samples = [sample for row in result['rows'] if row['version'] == version and row['difficulty'] == difficulty for sample in row['samples']]
                medians[version] = {key: statistics.median(s[key] for s in samples) for key in ('handlerMs', 'twoRafMs')}
            result['comparisons'].append({'difficulty': difficulty, **medians,
                'medianDeltaMs': {key: medians['after'][key] - medians['before'][key] for key in ('handlerMs', 'twoRafMs')}})
        result['allPassed'] = True
    except Exception as error:
        result['failure'] = {'visit': dict(current_visit), 'trial': dict(current_trial),
            'type': type(error).__name__, 'detail': str(error)}
        save_report()
        raise
    finally:
        server.shutdown()
        server.server_close()
        save_report()


if __name__ == '__main__':
    main()
