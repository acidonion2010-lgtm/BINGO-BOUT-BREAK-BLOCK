'use strict';

// Construct the real classes, including their real score-table setup. No solve,
// browser, timer, random stream, or production source modification is involved.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { performance } = require('node:perf_hooks');

const root = path.resolve(__dirname, '../..');
const files = {
    original: path.join(root, 'index.before.html'),
    stage4: path.join(root, 'stages/index.stage4.html'),
    current: path.join(root, 'index.html')
};
const source = Object.fromEntries(Object.entries(files).map(([name, file]) => [name, fs.readFileSync(file, 'utf8')]));

function loadClass(html) {
    const shared = html.indexOf('        class CpuEquilibriumSolver');
    const start = shared >= 0 ? shared : html.indexOf('        class WholeGameDP');
    const end = html.indexOf('        function wholeGameWorkerSource()', start);
    assert(start >= 0 && end > start, 'Cannot find the real CPU classes');
    const context = vm.createContext({});
    vm.runInContext(html.slice(start, end) + '\nglobalThis.DP = WholeGameDP;', context);
    return context.DP;
}

function withoutChangedMethods(html) {
    const classStart = html.indexOf('        class WholeGameDP');
    const constructorStart = html.indexOf('            constructor(', classStart);
    const constructorEnd = html.indexOf('            buildScores(', constructorStart);
    const layerStart = html.indexOf('            buildLayer(', constructorEnd);
    const layerEnd = html.indexOf('            isTerminal(', layerStart);
    assert(constructorStart >= 0 && constructorEnd > constructorStart && layerEnd > layerStart);
    return html.slice(0, constructorStart) + html.slice(constructorEnd, layerStart) + html.slice(layerEnd);
}

const DP = Object.fromEntries(Object.entries(source).map(([name, html]) => [name, loadClass(html)]));
const report = {
    scope: 'Actual WholeGameDP constructors; no full-game solve. All masks in all layers are checked.',
    files,
    changedOnlyConstructorAndBuildLayer: withoutChangedMethods(source.stage4) === withoutChangedMethods(source.current),
    legacyAllocationFlag: 'Original constructor ignores allocateValues=false and always allocates value tables; stage4/current honor the receiver mode.',
    counts: { constructors: 0, configurations: 0, indexComparisons: 0, maskOrderComparisons: 0, reachabilityChecks: 0, independentExpectedIndices: 0, sameUpperBoundIdentities: 0, unreachableThrows: 0, solved: 0 },
    cases: [],
    failures: []
};

function bitCount(mask) {
    let count = 0;
    while (mask) { count += mask & 1; mask >>>= 1; }
    return count;
}

function uniqueIndices(dp) {
    return new Set(dp.layers.flatMap(layer => [layer.index1, layer.index2]));
}

function sameArray(left, right, description) {
    assert.equal(left.length, right.length, description + ' length');
    for (let i = 0; i < left.length; i++) {
        assert(Object.is(left[i], right[i]), description + ' item ' + i);
    }
}

function verifyInstance(dp, name, config, allocateValues) {
    assert.equal(dp.layers.length, 19, name + ' layer count');
    assert.equal(dp.firstPlayer, config.firstPlayer);
    assert.equal(dp.earlyTermination, config.earlyTermination);
    assert.equal(dp.allSolved, false);
    sameArray(dp.layoutP1, config.layoutP1, name + ' player 1 layout');
    sameArray(dp.layoutP2, config.layoutP2, name + ' player 2 layout');
    assert.notEqual(dp.layoutP1, config.layoutP1, 'constructor must copy player 1 layout');
    assert.notEqual(dp.layoutP2, config.layoutP2, 'constructor must copy player 2 layout');
    const indices = uniqueIndices(dp);
    const indexBytes = [...indices].reduce((sum, index) => sum + index.byteLength, 0);
    assert.equal(indices.size, name === 'current' ? 10 : 38, name + ' unique index arrays');
    assert.equal(indexBytes, name === 'current' ? 10240 : 38912, name + ' unique index bytes');
    assert.equal(new Set([...indices].map(index => index.buffer)).size, indices.size, 'index buffers must be separate between different bounds');

    let valueBytes = 0;
    const valueArrays = new Set();
    const byBound = new Map();
    for (let t = 0; t <= 18; t++) {
        const layer = dp.layers[t];
        const expectedTurns1 = config.firstPlayer === 1 ? (t + 1) >> 1 : t >> 1;
        const expectedTurns2 = config.firstPlayer === 2 ? (t + 1) >> 1 : t >> 1;
        assert.equal(dp.turns1[t], expectedTurns1);
        assert.equal(dp.turns2[t], expectedTurns2);
        assert.equal(dp.attacker[t], (t & 1) === 0 ? config.firstPlayer : 3 - config.firstPlayer);
        assert.equal(layer.n1, layer.masks1.length);
        assert.equal(layer.n2, layer.masks2.length);
        assert.equal(layer.masks1, dp.masksByMaxPop[expectedTurns1]);
        assert.equal(layer.masks2, dp.masksByMaxPop[expectedTurns2]);
        const shouldAllocate = name === 'original' || allocateValues;
        if (shouldAllocate) {
            assert.equal(Object.prototype.toString.call(layer.values), '[object Float64Array]');
            assert.equal(layer.values.length, layer.n1 * layer.n2);
            assert.equal(layer.values.byteLength, layer.n1 * layer.n2 * 8);
            assert.equal(layer.values[0], 0);
            assert.equal(layer.values[layer.values.length - 1], 0);
            valueArrays.add(layer.values);
            valueBytes += layer.values.byteLength;
        } else {
            assert.equal(layer.values, null, name + ' receiver values must remain null');
        }
        for (const player of [1, 2]) {
            const bound = player === 1 ? expectedTurns1 : expectedTurns2;
            const index = layer['index' + player];
            const masks = layer['masks' + player];
            assert.equal(Object.prototype.toString.call(index), '[object Uint16Array]');
            assert.equal(index.length, 512);
            if (name === 'current') {
                assert.equal(index, dp.indexByMaxPop[bound]);
                if (byBound.has(bound)) {
                    assert.equal(index, byBound.get(bound), 'all equal bounds share the same index');
                    report.counts.sameUpperBoundIdentities++;
                } else byBound.set(bound, index);
            }
            let rank = 0;
            for (let mask = 0; mask < 512; mask++) {
                const reachable = bitCount(mask) <= bound;
                assert.equal(index[mask] !== 65535, reachable, `${name}: layer ${t}, player ${player}, mask ${mask}`);
                report.counts.reachabilityChecks++;
                if (reachable) {
                    assert.equal(index[mask], rank, 'independently derived ascending reverse index');
                    assert.equal(masks[rank], mask, 'independently derived ascending mask order');
                    rank++;
                } else assert.equal(index[mask], 65535);
                report.counts.independentExpectedIndices++;
            }
            assert.equal(rank, masks.length);
        }
    }
    assert.equal(valueBytes, name === 'original' || allocateValues ? 18324976 : 0);
    assert.equal(valueArrays.size, name === 'original' || allocateValues ? 19 : 0, 'value tables stay independent per layer');
    if (name === 'current') {
        assert.equal(byBound.size, 10);
        assert.equal(dp.indexByMaxPop.length, 10);
        assert.equal(new Set(dp.indexByMaxPop).size, 10);
    }
    for (const state of [{t: 0, maskP1: 1, maskP2: 0}, {t: 0, maskP1: 0, maskP2: 1}]) {
        assert.throws(() => dp.getValue(state), /Whole-game DP state is unreachable/);
        report.counts.unreachableThrows++;
    }
    return {uniqueIndexArrays: indices.size, indexBytes, valueBytes, valueArrays: valueArrays.size};
}

function compareIndices(left, right, description) {
    for (let t = 0; t <= 18; t++) {
        const a = left.layers[t], b = right.layers[t];
        assert.equal(a.n1, b.n1, description + ' n1');
        assert.equal(a.n2, b.n2, description + ' n2');
        for (const player of [1, 2]) {
            const ma = a['masks' + player], mb = b['masks' + player];
            assert.equal(ma.length, mb.length);
            for (let i = 0; i < ma.length; i++) {
                assert.equal(ma[i], mb[i], description + ' mask order');
                report.counts.maskOrderComparisons++;
            }
            for (let mask = 0; mask < 512; mask++) {
                assert.equal(a['index' + player][mask], b['index' + player][mask], description + ' index');
                report.counts.indexComparisons++;
            }
        }
    }
}

const layouts = [
    {name: 'magic-square-and-shuffled', p1: [8, 1, 6, 3, 5, 7, 4, 9, 2], p2: [5, 9, 1, 7, 2, 6, 3, 8, 4]},
    {name: 'ascending-and-descending', p1: [1, 2, 3, 4, 5, 6, 7, 8, 9], p2: [9, 8, 7, 6, 5, 4, 3, 2, 1]}
];
const started = performance.now();
try {
    assert(report.changedOnlyConstructorAndBuildLayer, 'Unexpected source change outside approved methods');
    let previousCurrent = null;
    for (const fixture of layouts) for (const firstPlayer of [1, 2]) for (const allocateValues of [false, true]) for (const earlyTermination of [false, true]) {
        const config = {layoutP1: fixture.p1, layoutP2: fixture.p2, firstPlayer, earlyTermination};
        const beforeConfig = JSON.stringify(config);
        const instances = Object.fromEntries(Object.entries(DP).map(([name, Class]) => [name, new Class(config, allocateValues)]));
        report.counts.constructors += 3;
        report.counts.configurations++;
        const allocations = {};
        for (const [name, dp] of Object.entries(instances)) allocations[name] = verifyInstance(dp, name, config, allocateValues);
        compareIndices(instances.original, instances.stage4, 'original -> stage4');
        compareIndices(instances.original, instances.current, 'original -> current');
        compareIndices(instances.stage4, instances.current, 'stage4 -> current');
        assert.equal(JSON.stringify(config), beforeConfig, 'constructor must not mutate the config');
        if (previousCurrent) {
            const previousBuffers = new Set(previousCurrent.map(index => index.buffer));
            for (const index of instances.current.indexByMaxPop) {
                assert(!previousCurrent.includes(index), 'DP instances must not share index objects');
                assert(!previousBuffers.has(index.buffer), 'DP instances must not share index buffers');
            }
        }
        // Retain indices only, never the previous DP or its large value tables.
        previousCurrent = instances.current.indexByMaxPop.slice();
        report.cases.push({layout: fixture.name, firstPlayer, allocateValues, earlyTermination, allocations});
        if (global.gc) global.gc();
    }
    const sampleConfig = {layoutP1: layouts[0].p1, layoutP2: layouts[0].p2, firstPlayer: 1, earlyTermination: true};
    const nextConfig = {layoutP1: layouts[1].p1, layoutP2: layouts[1].p2, firstPlayer: 2, earlyTermination: false};
    const sample = new DP.current(sampleConfig, false), next = new DP.current(nextConfig, false);
    report.counts.constructors += 2;
    const snapshot = sample.indexByMaxPop.map(index => index.slice());
    for (let bound = 0; bound <= 9; bound++) {
        const saved = next.indexByMaxPop[bound][0];
        next.indexByMaxPop[bound][0] = 65535;
        sameArray(sample.indexByMaxPop[bound], snapshot[bound], 'another DP must be isolated after a deliberate test write');
        next.indexByMaxPop[bound][0] = saved;
    }
    report.crossInstanceMutationIsolation = true;
    report.passed = true;
} catch (error) {
    report.passed = false;
    report.failures.push({message: error.message, stack: error.stack});
    process.exitCode = 1;
}
report.elapsedMs = performance.now() - started;
const output = path.join(__dirname, 'layer-indices.json');
fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({passed: report.passed, counts: report.counts, changedOnlyConstructorAndBuildLayer: report.changedOnlyConstructorAndBuildLayer, crossInstanceMutationIsolation: report.crossInstanceMutationIsolation, elapsedMs: report.elapsedMs, failures: report.failures, output}));
