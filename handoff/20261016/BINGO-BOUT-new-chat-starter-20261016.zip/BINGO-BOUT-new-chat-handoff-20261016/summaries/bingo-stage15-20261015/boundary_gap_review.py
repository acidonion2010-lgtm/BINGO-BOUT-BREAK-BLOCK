#!/usr/bin/env python3
"""Existing full-X CPU excess versus next same-thread recorded start wall gap."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

from raw_clock_review import finite, record, require


def main():
    report_path, output_path = map(Path, sys.argv[1:])
    require(not output_path.exists(), 'Refuse overwrite')
    report_raw = report_path.read_bytes(); report = json.loads(report_raw)
    result = {'sourceReportSha256': hashlib.sha256(report_raw).hexdigest(),
              'scriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'limits': 'Derived X ends are ts+dur/tts+tdur. Next start is an exported same-thread I/X start, not a proven immediate wall-clock read. Comparison is descriptive and does not identify the actual CPU-clock/export cause.',
              'traces': []}
    for visit in report['visits']:
        path = Path(visit['trace']['path']); path = path if path.is_absolute() else report_path.parent / path
        raw = path.read_bytes(); require(hashlib.sha256(raw).hexdigest() == visit['trace']['sha256'], 'Hash mismatch')
        events = json.loads(raw)['traceEvents']
        name = visit['samples'][0]['markers'][0]['name']
        mark = next(e for e in events if e.get('name') == name)
        thread = (mark['pid'], mark['tid'])
        starts = [(i, e) for i, e in enumerate(events) if (e.get('pid'), e.get('tid')) == thread
                  and e.get('ph') in ('I', 'X') and finite(e.get('tts'))]
        starts.sort(key=lambda pair: (pair[1]['ts'], pair[0]))
        anomalies = []
        for index, event in starts:
            if event['ph'] != 'X' or not finite(event.get('tdur')) or event['tdur'] - event['dur'] <= 1000:
                continue
            end_wall, end_cpu = event['ts'] + event['dur'], event['tts'] + event['tdur']
            following = next(((i, e) for i, e in starts if e['ts'] > end_wall), None)
            row = {'event': record(event, index), 'derivedEndWallUs': end_wall,
                   'derivedEndCpuUs': end_cpu, 'excessUs': event['tdur'] - event['dur'],
                   'nextRecordedIxStart': record(following[1], following[0]) if following else None}
            if following:
                row.update({'wallGapToNextStartUs': following[1]['ts'] - end_wall,
                            'cpuGapToNextStartUs': following[1]['tts'] - end_cpu,
                            'wallGapLessThanExcess': following[1]['ts'] - end_wall < row['excessUs']})
            anomalies.append(row)
        focal = [e for e in anomalies if (visit['run'], visit['version']) == (3, 'original')
                 and e['event']['name'] == 'ParseHTML' and e['derivedEndWallUs'] == 7203002752]
        result['traces'].append({'run': visit['run'], 'version': visit['version'],
                                'traceSha256': visit['trace']['sha256'],
                                'fullXExcessOver1ms': len(anomalies),
                                'withNextStart': sum(e['nextRecordedIxStart'] is not None for e in anomalies),
                                'nextStartGapLessThanExcess': sum(e.get('wallGapLessThanExcess') is True for e in anomalies),
                                'focalParseHtml': focal,
                                'largestExcessExamples': sorted(anomalies, key=lambda e: e['excessUs'], reverse=True)[:3]})
    result['summary'] = {key: sum(t[key] for t in result['traces']) for key in
                         ('fullXExcessOver1ms', 'withNextStart', 'nextStartGapLessThanExcess')}
    with output_path.open('x') as file: file.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result['summary']), flush=True)


if __name__ == '__main__': main()
