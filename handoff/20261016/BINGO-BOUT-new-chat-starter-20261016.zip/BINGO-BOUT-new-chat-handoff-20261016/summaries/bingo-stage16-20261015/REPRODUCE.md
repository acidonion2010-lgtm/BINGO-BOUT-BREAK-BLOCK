# 段階16 再現手順

収集はブラウザー/DP/性能ジョブを他に走らせず、PLAN.mdの固定予算で1回だけ実行する。既存report/rawは上書きしない。Python Playwrightと /usr/bin/chromium 154.0.8037.57 を用いる。実行用helperは元handoff project/validationと段階14 capture_clicks.py に依存し、それぞれhash gateがある。

```sh
python3 /workspace/bingo-stage16-20261015/capture_proto.py
python3 /workspace/bingo-stage16-20261015/analyze_proto_json.py
```

trace_processor_shell は公式Perfetto v58.2のrelease binaryであり、SHA256 58042408e6cc861fb1a731c26bb082dc222285561eaa4e12a48a8b2b90dca7b9 を検証済み。取得経路/失敗した配布URLもtool-download.jsonに保持。ChromiumのDEPS pinとは異なるbinary revisionで、固定pinの配布manifestが指定する版に一致する。traceconv-binは取得直後の同一binary copyであるが、basenameによってconvertモードが選択されるためqueryと新CLIには正式名trace_processor_shellを使う。

保存済みprotoの再変換はブラウザー再実行を必要としない。元のrunN.jsonを上書きせず別の出力名にする。

```sh
/workspace/bingo-stage16-20261015/trace_processor_shell convert json /workspace/bingo-stage16-20261015/run0.pftrace /tmp/stage16-run0-check.json
/workspace/bingo-stage16-20261015/trace_processor_shell query /workspace/bingo-stage16-20261015/run0.pftrace 'SELECT name, value, severity FROM stats WHERE value != 0'
```

raw_counter_check.pyは原counterの限定検算用であり、wall clock変換や完全なslice decoderの代用ではない。利用法と制約はPROTO_DECODE_REVIEW.mdを参照。ThreadTime/schedstatとtrace markerは区間が異なり、値を直接同一区間として引かない。schedstatのendpoint鮮度は保証されない。

同一protoのSQL抽出と照合:

```sh
python3 /workspace/bingo-stage16-20261015/extract_sql.py
python3 /workspace/bingo-stage16-20261015/check_sql_json.py
```

extract_sql.pyは既存official-sql directoryの上書きを拒否する。保存済みSQL/CSV/stderrで解析する場合は再抽出しない。raw checkerは各runに対して `python3 raw_counter_check.py runN.pftrace new-ledger.json` の形式で実行する（既存raw-counter-runN.jsonは上書きしない）。raw/公式照合コードと量子化モデルはverify_raw_counters.py、verify_quantization_resets.pyと各結果のscriptSha256を対応させる。

CPU差分の端数処理を構成するpositive controlはdecoder-validation/CONTROL_PLAN.mdに独立の固定計画を持つ。実ブラウザーの追加計測ではなく、ソースの符号化方式が整合した真の時計から超過を作れるかの対照である。実traceの個々の端数を復元するものではない。
