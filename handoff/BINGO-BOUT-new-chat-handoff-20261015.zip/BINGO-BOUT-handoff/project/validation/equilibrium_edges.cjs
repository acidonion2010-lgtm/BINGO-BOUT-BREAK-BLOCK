const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
function solver(file) {
    const html = fs.readFileSync(file, 'utf8');
    const start = html.indexOf('        class CpuEquilibriumSolver') >= 0
        ? html.indexOf('        class CpuEquilibriumSolver')
        : html.indexOf('        class WholeGameDP');
    const end = html.indexOf('        function wholeGameWorkerSource()', start);
    const context = vm.createContext({});
    vm.runInContext(html.slice(start, end) + '\nglobalThis.DP = WholeGameDP;', context);
    const work = Object.create(context.DP.prototype);
    Object.assign(work, {
        monotone: false,
        pay: new Float64Array(9), probP: new Float64Array(9),
        probQ: new Float64Array(9), order: new Int16Array(9), certifiedGap: 1e-5
    });
    return work;
}
const before = solver(path.join(root, 'index.before.html'));
const after = solver(path.join(root, 'index.html'));
let seed = 0x41b12;
function random() {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
}
const cases = [
    {name: 'one positive action', pay: [11], stay: 2},
    {name: 'one negative action', pay: [-11], stay: 2},
    {name: 'all zero gain', pay: [7, 7, 7], stay: 7},
    {name: 'positive gains and tied support', pay: [9, 9, 6, 4], stay: 2},
    {name: 'positive and negative gains', pay: [-12, 7, -2, 7], stay: 0},
    {name: 'all negative, mixed support', pay: [0, 0, 0], stay: 1},
    {name: 'all negative, pure best', pay: [0, -100, -100], stay: 1},
    {name: 'near zero numerical threshold', pay: [1 + 5e-13, 1, 1 - 5e-13], stay: 1},
    {name: 'above positive numerical threshold', pay: [1 + 2e-12, 1 + 2e-12, 1], stay: 1}
];
for (let count = 1; count <= 9; count++) {
    for (let trial = 0; trial < 512; trial++) {
        const stay = Math.floor(random() * 2101) - 1050;
        const pay = Array.from({length: count}, () => Math.floor(random() * 2101) - 1050);
        cases.push({name: `signed-${count}-${trial}`, stay, pay});
    }
}
function run(work, test) {
    try {
        const result = work.equilibrium(test.pay.length, test.pay, test.stay);
        return {result, p: Array.from(work.probP.slice(0, test.pay.length)), q: Array.from(work.probQ.slice(0, test.pay.length))};
    } catch (error) {
        return {error: error.message};
    }
}
const failures = [];
let certified = 0, matchingErrors = 0;
for (const test of cases) {
    const left = run(before, test), right = run(after, test);
    if (JSON.stringify(left) !== JSON.stringify(right)) failures.push({test, before: left, after: right});
    if (left.error) matchingErrors++;
    else {
        certified++;
        if (!(right.result.gap <= 1e-5) || !Number.isFinite(right.result.value)) failures.push({test, reason: 'uncertified result', right});
    }
}
const result = {total: cases.length, certified, matchingErrors, identical: failures.length === 0, failures};
fs.writeFileSync(path.join(__dirname, 'equilibrium-edges.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
if (failures.length) process.exitCode = 1;
