#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent;OLD=R.parent/'bingo-stage17-20261015'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(n):return json.loads((R/n).read_bytes())
def main():
 residual=read('residual-census.json');precision=read('precision-census.json');boundary=read('boundary-census.json');marker=read('marker-ns-census.json');review=read('independent-census-review.json')
 for name,result in [('residual_census.py',residual),('precision_census.py',precision),('boundary_census.py',boundary),('marker_ns_census.py',marker),('review_saved_censuses.py',review)]:assert result['scriptSha256']==sha(R/name),name
 assert marker['helperScriptSha256']==sha(R/'boundary_census.py')
 reportsha=sha(OLD/'report.json')
 assert residual['sourceReportSha256']==reportsha and residual['planSha256']==sha(R/'PLAN.md')
 assert precision['reportInput']['sha256']==reportsha and boundary['report']['sha256']==reportsha and marker['report']['sha256']==reportsha
 for output in [boundary,marker]:
  for visit in output['visits']:
   for info in visit['inputs'].values():assert info['sha256']==sha(Path(info['path']))
 s=residual['summary'];assert s['withCpu']==83817 and s['strictPositive']==27879 and s['maxPositiveNs']==129988
 assert (s['positiveP50Ns'],s['positiveP95Ns'],s['positiveP99Ns'])==(30,960,1788)
 t=precision['totals'];assert t['sqlPositiveDurationWithCpu']==81065 and t['sqlInstantWithCpu']==2752 and t['strictCountDifferenceFromDurationDivision']==24739
 transitions=precision['positiveDurationSignTransitionsNsToUs'];assert transitions['positive']=={'negative':0,'zero':24739,'positive':3140} and transitions['negative']['positive']==0
 b=boundary['totalBySliceExcessSign']['positive'];assert b['uniqueRawPair']==27879 and b['packetOrder.gapAtLeastExcess.true']==27876 and b['packetOrder.noNextRetainedPoint']==3
 c=marker['counts'];assert c['allWindows']==c['completeUniqueSavedEndpoints']==192 and c['savedNs.positive']==2 and c['savedNs.negative']==190
 assert c['signPair.negative->positive']==1 and c['signPair.positive->zero']==1 and c['bothCpuFloorsToJsonExact']==c['bothWallFloorsToJsonExact']==192
 assert 'Verified 480 files: all SHA-256 hashes match.' in (R/'original-preservation.log').read_text()
 lines=(R/'stage17-preservation.log').read_text().splitlines();assert len(lines)==262 and all(x.endswith(': OK') for x in lines)
 assert not (R/'repository-status.txt').read_text() and (R/'POST_RUN_REVIEW.md').is_file()
 sources=[]
 for folder in ['official-sources','precision-sources']:
  for p in sorted((R/folder).rglob('*')):
   if p.is_file():sources.append({'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
 (R/'source-inventory.json').write_text(json.dumps(sources,indent=2)+'\n')
 out={'status':'completed','stage':18,'clientDate':'2026-10-16','sourceStage':17,'sourceFormalRuns':[3,4,7,8],'newBrowserOrDpMeasurements':0,'newNativeLoadMeasurements':0,'newSyntheticControls':0,'cpuSlices':83817,'cpuMissingCompleteSlices':1617,'sqlStrictPositive':27879,'positiveMedianNs':30,'positiveP95Ns':960,'positiveP99Ns':1788,'maximumPositiveNs':129988,'samePopulationXEvents':81065,'instantSqlSlices':2752,'instantStrictPositive':0,'strictPositiveRoundedToZero':24739,'jsonStrictPositive':3140,'ambiguousJsonEventsAllCandidatesRetained':34,'rawPositiveCpuPairsUnique':27879,'positiveSlicesWithNextPoint':27876,'allAvailableNextPointGapsAtLeastExcess':True,'positiveSlicesWithNoNextPoint':3,'endpointDelaySoleCauseProven':False,'markerWindows':192,'markerSavedNsStrictPositive':2,'markerSavedNsPositiveExcesses':[25,1116],'markerJsonStrictPositive':2,'markerJsonPositiveButSavedNsNegative':1,'markerJsonFalsePositiveSavedExcessNs':-139,'markerSavedNsPositiveButJsonZero':1,'markerCpuAndWallEndpointsFloorExactly':True,'strictCpuAccountingConfirmed':False,'applicationChanged':False,'originalManifestFilesUnchanged':480,'stage17ManifestFilesUnchanged':262,'mainRepositoryWorkingTreeClean':True,'old104ConditionsReclassified':False,'oldUnconfirmedConditions':62,'strictAllPathsNonRegressionConfirmed':False,'sourceInventoryFiles':len(sources),'sourceRawProtosAndLedgersDuplicated':False}
 (R/'integrity.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
