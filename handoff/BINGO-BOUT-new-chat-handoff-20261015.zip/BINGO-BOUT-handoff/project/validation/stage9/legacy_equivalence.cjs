'use strict';

// Semantic comparison only: no browser, solver construction, or timing claim.
// Run sequentially with other CPU validation jobs. Both source closures and all
// their ordinary arrays share one VM realm; each closure has independent state.
// Defaults: node validation/stage9/legacy_equivalence.cjs
// Optional positional arguments: BASE_HTML CANDIDATE_HTML OUTPUT_JSON.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');

const root = path.resolve(__dirname, '../..');
const files = {
  base: path.resolve(process.argv[2] || path.join(root, 'stages/index.handoff-20261015.html')),
  candidate: path.resolve(process.argv[3] || path.join(root, 'stages/index.stage9.candidate.html')),
};
const output = path.resolve(process.argv[4] || path.join(__dirname, 'legacy-equivalence.json'));
const sources = Object.fromEntries(Object.entries(files).map(([key, file]) =>
  [key, fs.readFileSync(file, 'utf8')]));
const changedNames = ['getCpuSelectionWeights', 'prepareCpuBreakCandidates',
  'selectCpuLegacyCell', 'selectCpuBreakCell'];
const functions = ['getCellWeights', 'weightedRandomChoice', 'cpuSelectSmartCell',
  'getCpuDifficultyId', 'getCpuDifficultySettings', 'getCpuSelectionWeights',
  'getCpuChoicePool', 'chooseCpuCandidate', 'getCpuRetryChance',
  'getCpuBreakCandidatePool', 'prepareCpuBreakCandidates', 'getCpuBlockBiasChance',
  'getCpuBlockCandidatePool', 'prepareCpuBlockCandidates', 'takeCpuEqMixRoll',
  'selectCpuLegacyCell', 'selectHardLegacyCell', 'selectHardMixedCell',
  'selectCpuEquilibriumCell', 'selectCpuBreakCell', 'selectCpuBlockCell',
  'getCompletedLines', 'getScoredCellIndices', 'calculateScore'];

function sourceFunction(html, name) {
  const start = html.indexOf(`        function ${name}(`);
  const end = html.indexOf('\n        }', start) + '\n        }'.length;
  assert(start >= 0 && end > start, `Missing complete function ${name}`);
  return html.slice(start, end);
}
function constants(html) {
  const start = html.indexOf('        const CONFIG = {');
  const end = html.indexOf('        const LADDER_STAGES =', start);
  assert(start >= 0 && end > start, 'Missing CONFIG/CPU_DIFFICULTY declarations');
  return html.slice(start, end);
}
function stripChanged(html) {
  for (const name of changedNames) html = html.replace(sourceFunction(html, name), `CHANGED:${name}`);
  return html;
}
assert.equal(stripChanged(sources.base), stripChanged(sources.candidate),
  'Candidate changes extend beyond the four authorized functions');
for (const name of functions.filter(name => !changedNames.includes(name))) {
  assert.equal(sourceFunction(sources.base, name), sourceFunction(sources.candidate, name),
    `Unexpected dependency change: ${name}`);
}

const realm = vm.createContext({});
function install(html, label) {
  // Keep the original script's non-strict function semantics. No host arrays or
  // host Math object enter the realm. Unused full/master equilibrium branches
  // are retained verbatim but are not exercised by this legacy-only harness.
  const code = `(function () {
    ${constants(html)}
    const state = {};
    const CPU_HARD_LEGACY_RATE = 0.7;
    let hardLegacyDecisions = 0, hardDpDecisions = 0;
    let cpuWholeStatus = 'fallback', cpuWholeLegacyDecisions = 0;
    ${functions.map(name => sourceFunction(html, name)).join('\n')}
    let trace = null;
    const unwrappedWeights = getCellWeights;
    getCellWeights = function (marks, layout) {
      const raw = unwrappedWeights(marks, layout);
      if (trace) trace.raw.push(raw);
      return Object.freeze(raw);
    };
    const history = () => ({
      breakCell: state.cpuBlockedBreakCell, breakStreak: state.cpuBlockedBreakStreak,
      breakCooldown: state.cpuBlockedCooldown,
      blockCell: state.cpuSuccessfulBlockCell, blockStreak: state.cpuSuccessfulBlockStreak,
      blockCooldown: state.cpuSuccessfulBlockCooldown,
      selectedBreakCell: state.selectedBreakCell,
    });
    return {
      settings: CPU_DIFFICULTY,
      raw: (marks, layout) => unwrappedWeights(marks, layout),
      retry: getCpuRetryChance,
      execute(input, kind, stream) {
        Object.assign(state, {gameMode:'cpu', cpuDifficulty:input.difficulty,
          p1Marks:input.marks, p2Marks:input.marks,
          p1NumberLayout:input.layout, p2NumberLayout:input.layout,
          cpuBlockedBreakCell:input.memory, cpuSuccessfulBlockCell:input.memory,
          cpuBlockedBreakStreak:input.streak, cpuSuccessfulBlockStreak:input.streak,
          cpuBlockedCooldown:input.cooldown, cpuSuccessfulBlockCooldown:input.cooldown,
          selectedBreakCell:7});
        hardLegacyDecisions = hardDpDecisions = cpuWholeLegacyDecisions = 0;
        cpuWholeStatus = 'fallback';
        trace = {rng:[], raw:[], math:{pow:0,max:0,ceil:0}};
        const saved = {random:Math.random, pow:Math.pow, max:Math.max, ceil:Math.ceil};
        Math.random = () => {
          if (trace.rng.length >= stream.length) throw new Error('RNG stream exhausted');
          const value = stream[trace.rng.length]; trace.rng.push(value); return value;
        };
        for (const name of ['pow','max','ceil']) {
          Math[name] = (...args) => {trace.math[name]++; return saved[name](...args);};
        }
        let answer;
        try {
          if (kind === 'legacy-break') answer = selectCpuLegacyCell('break',input.available);
          else if (kind === 'legacy-block') answer = selectCpuLegacyCell('block',input.available);
          else if (kind === 'entry-break') answer = selectCpuBreakCell(input.available);
          else if (kind === 'entry-block') answer = selectCpuBlockCell(input.marks,input.layout);
          else if (kind === 'supplied-weights') answer = getCpuSelectionWeights(
            input.marks,input.layout,CPU_DIFFICULTY[input.difficulty],input.raw);
          else if (kind === 'supplied-candidates') answer = prepareCpuBreakCandidates(
            input.available,input.marks,input.layout,input.raw);
          else throw new Error('Unknown test kind');
          return {answer, rng:trace.rng.slice(), math:{...trace.math}, history:history(),
            counters:{legacy:hardLegacyDecisions,full:hardDpDecisions,
              masterFallback:cpuWholeLegacyDecisions},
            refsUnchanged:state.p1Marks===input.marks && state.p2Marks===input.marks &&
              state.p1NumberLayout===input.layout && state.p2NumberLayout===input.layout,
            rawPasses:trace.raw.length,
            rawSnapshots:trace.raw.map(raw => raw.slice())};
        } finally {
          for (const name of Object.keys(saved)) Math[name] = saved[name];
          trace = null;
        }
      }
    };
  })()`;
  return new vm.Script(code, {filename:label}).runInContext(realm);
}
realm.base = install(sources.base, 'stage9-base-legacy-source.js');
realm.candidate = install(sources.candidate, 'stage9-candidate-legacy-source.js');

// All loops, fixture creation, equality checks, and source calls execute inside
// this single realm. Avoid one cross-context host call for every case.
const runSource = `(() => {
  let seed = 0x9e3779b9;
  function random() {
    seed = (Math.imul(seed,1664525)+1013904223)>>>0;
    return seed/4294967296;
  }
  const layouts = [[8,1,6,3,5,7,4,9,2], [5,9,1,7,2,6,3,8,4],
    [1,2,3,4,5,6,7,8,9], [9,8,7,6,5,4,3,2,1]];
  while (layouts.length<16) {
    const layout = [1,2,3,4,5,6,7,8,9];
    for (let i=8;i>0;i--) {
      const j=Math.floor(random()*(i+1)); [layout[i],layout[j]]=[layout[j],layout[i]];
    }
    if (!layouts.some(old => old.every((value,i)=>value===layout[i]))) layouts.push(layout);
  }
  for (const layout of layouts) Object.freeze(layout);
  const masks = Array.from({length:512},(_,mask)=>Object.freeze(
    Array.from({length:9},(_,i)=>Boolean(mask&(1<<i)))));
  const diffs = ['normal','hard','master'];
  const summary = {compared:0, phases:{}, kinds:{}, rngCounts:{},
    weightPassTotals:{base:0,candidate:0}, layouts:layouts.map(x=>x.slice()),
    exact:true, failures:[], firstFailure:null};
  function exact(a,b) {
    if (Object.is(a,b)) return true;
    if (typeof a!==typeof b || a===null || b===null || typeof a!=='object') return false;
    const ak=Object.keys(a),bk=Object.keys(b);
    return ak.length===bk.length && ak.every(k=>Object.hasOwn(b,k)&&exact(a[k],b[k]));
  }
  function fail(reason, spec, before, after) {
    const record={reason,spec,before,after};
    summary.exact=false;
    if (!summary.firstFailure) summary.firstFailure=record;
    if (summary.failures.length<8) summary.failures.push(record);
  }
  function fixture(mask,layout,difficulty,availableMode,historyCode) {
    const available=[];
    for(let i=0;i<9;i++) if(!masks[mask][i]) available.push(i);
    if(availableMode===1) available.reverse();
    if(availableMode===2) available.splice(0,available.length,
      ...available.filter((_,i)=>i%2===0));
    const memoryMode=historyCode%3, cooldown=Math.floor(historyCode/3)%3;
    const memory=memoryMode===0 ? null : memoryMode===1 ? available[0]??null :
      Array.from({length:9},(_,i)=>i).find(i=>!available.includes(i))??null;
    const marks=masks[mask];
    const raw=Object.freeze(base.raw(marks,layout));
    return {marks,layout,difficulty,available:Object.freeze(available),raw,
      memory,cooldown,streak:(mask+historyCode)%3};
  }
  function pair(phase,kind,input,stream,metadata) {
    const spec={phase,kind,...metadata,difficulty:input.difficulty,
      available:input.available,memory:input.memory,cooldown:input.cooldown,
      streak:input.streak,stream};
    const immutableBefore=[input.marks.slice(),input.layout.slice(),
      input.available.slice(),input.raw.slice()];
    let a,b;
    try {a=base.execute(input,kind,stream);b=candidate.execute(input,kind,stream);}
    catch(error) {fail('Unexpected throw: '+error.message,spec,a,b);return;}
    const immutableAfter=[input.marks,input.layout,input.available,input.raw];
    if(!exact(immutableBefore,immutableAfter) || !a.refsUnchanged || !b.refsUnchanged)
      fail('Input values or state references changed',spec,a,b);
    const aCompare={...a}, bCompare={...b};
    delete aCompare.rawPasses;delete bCompare.rawPasses;
    delete aCompare.rawSnapshots;delete bCompare.rawSnapshots;
    if(!exact(aCompare,bCompare)) fail('Selection/RNG/Math/history/counter mismatch',spec,a,b);
    for(const side of [a,b]) for(const raw of side.rawSnapshots) {
      if(!exact(raw,input.raw)) fail('Raw weights changed or depend on call order',spec,a,b);
    }
    const isBreak=kind==='legacy-break'||kind==='entry-break';
    if(isBreak && (a.rawPasses!==2 || b.rawPasses!==1))
      fail('Expected two-to-one BREAK raw-weight computation reduction',spec,a,b);
    summary.compared++;
    summary.phases[phase]=(summary.phases[phase]||0)+1;
    summary.kinds[kind]=(summary.kinds[kind]||0)+1;
    const rngKey=kind+':'+a.rng.length;
    summary.rngCounts[rngKey]=(summary.rngCounts[rngKey]||0)+1;
    summary.weightPassTotals.base+=a.rawPasses;
    summary.weightPassTotals.candidate+=b.rawPasses;
  }
  const around = value => [value>0 ? Math.max(0,value-Number.EPSILON) : 0,
    value, Math.min(1-Number.EPSILON,value+Number.EPSILON)];
  // Exhaustive masks x all representative layouts x all three legacy settings.
  // Rotate legal availability, cooldown/history and RNG inputs to avoid an
  // expensive, mostly redundant Cartesian product in this broad sweep.
  for(let mask=0;mask<512;mask++) for(let li=0;li<16;li++) for(let di=0;di<3;di++) {
    const input=fixture(mask,layouts[li],diffs[di],(mask+li+di)%3,(mask+li*3+di)%9);
    const stream=[random(),random(),random()];
    pair('all-masks-layouts-settings','legacy-break',input,stream,{mask,layout:li});
  }
  // Full available/history/threshold cross product for representative boards;
  // includes no closed cells, one/two closed cells, and many closed cells.
  const focusedMasks=[0,3,24,255,508,509,510,511];
  for(const mask of focusedMasks) for(let di=0;di<3;di++)
    for(let avail=0;avail<3;avail++) for(let hist=0;hist<9;hist++) {
      const li=(mask+hist+avail)%16;
      const input=fixture(mask,layouts[li],diffs[di],avail,hist);
      const settings=base.settings[input.difficulty];
      const retry=base.retry(input.memory,input.available,input.streak,settings,input.raw);
      const retryEdges=around(retry),poolEdges=around(settings.topPoolChance);
      const streams=[...retryEdges.map(value=>[value,0.91,0.37]),
        ...poolEdges.map(value=>[0.93,value,0.63]),
        [0,0,0],[1-Number.EPSILON,1-Number.EPSILON,1-Number.EPSILON]];
      for(let si=0;si<streams.length;si++) {
        const stream=streams[si],metadata={mask,layout:li,avail,hist,streamIndex:si};
        pair('history-thresholds','legacy-break',input,stream,metadata);
        if(input.difficulty==='normal')
          pair('normal-public-entry','entry-break',input,stream,metadata);
        if(input.difficulty==='hard') for(const mix of [0.3,0.8])
          pair('hard-fallback-public-entry','entry-break',input,[mix,...stream],{...metadata,mix});
      }
    }
  // Confirm optional raw-weight injection and preserve BLOCK's existing path.
  for(let mask=0;mask<512;mask++) for(let di=0;di<3;di++) {
    const li=mask%16,input=fixture(mask,layouts[li],diffs[di],mask%3,mask%9);
    pair('block-control','legacy-block',input,[0.19,0.47,0.81],{mask,layout:li});
    if(mask%16===0) {
      pair('optional-raw-helper','supplied-weights',input,[],{mask,layout:li});
      pair('optional-raw-helper','supplied-candidates',input,[0.67],{mask,layout:li});
    }
  }
  summary.seed=seed;
  summary.coverage={allMasks:512,representativeLayouts:16,legacyDifficulties:diffs,
    availability:['all closed in order','all closed reversed','every other closed'],
    history:'cooldown 0/1/2 x remembered null/in-pool/out-of-pool; streaks 0/1/2 rotated',
    historyLimit:'If no in/out board cell exists, that remembered-cell variant uses null',
    focusedMasks,retryBoundary:'below/equal/above value-biased retry chance',
    topPoolBoundary:'below/equal/above configured chance',
    weightedSampleEdges:[0,1-Number.EPSILON],
    fullSolverExercised:false,
    hardEntry:'fallback status, both .3/.8 mix rolls; original/candidate RNG traces compared',
    master:'direct legacy helper with MASTER settings; MASTER equilibrium entry excluded',
    emptyPool:'Included; actual consumed RNG trace compared without fixed draw-count assumption'};
  return summary;
})()`;

const result = {
  sources: Object.fromEntries(Object.entries(files).map(([key,file]) => [key,{
    path:file,sha256:crypto.createHash('sha256').update(sources[key]).digest('hex'),
  }])),
  method:'Exact source function extraction; two independent closures in one Node VM realm',
  implementationBoundary:'Only the four expected functions differ; all other HTML bytes match',
  plainArrayContract:'Frozen ordinary Boolean mark arrays and permutation layouts; input/RNG mutation hooks excluded',
  measurement:'Functional semantics only; no performance conclusion',
  nodeVersion:process.version,
};
try {
  Object.assign(result,new vm.Script(runSource,{filename:'stage9-legacy-cases.js'}).runInContext(realm));
  result.completed=true;
} catch(error) {
  result.completed=false;result.exact=false;result.failure=error.stack;
}
fs.mkdirSync(path.dirname(output),{recursive:true});
fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({completed:result.completed,exact:result.exact,
  compared:result.compared,phases:result.phases,firstFailure:result.firstFailure,
  weightPassTotals:result.weightPassTotals,output},null,2));
if(!result.completed || !result.exact) process.exitCode=1;
