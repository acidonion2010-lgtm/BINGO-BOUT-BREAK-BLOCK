#!/usr/bin/env python3
"""Add an explicit synthetic BOOTTIME/MONOTONIC relationship to fixture v1.

The v1 fixture's numeric CPU results already match official conversion. Its
official loader logs an unrelated unrelatable-default-BOOTTIME clock warning.
This fixture explicitly supplies that relationship to make all clock domains
used by the loader resolvable. Equality here is constructed test data, never
an assertion about a real device's clocks. Existing v1 outputs are preserved.
"""
from pathlib import Path
import hashlib
import json
import make_fixture as wire

ROOT = Path(__file__).resolve().parent
snapshot = (
    wire.message(1, wire.scalar(1, 3) + wire.scalar(2, 1_000_000_000))
    + wire.message(1, wire.scalar(1, 6) + wire.scalar(2, 1_000_000_000))
    + wire.scalar(2, 3)
)
# Global/builtin snapshot needs no sequence-scoped clock or sequence ID.
prefix = wire.message(1, wire.message(6, snapshot))
raw = prefix + (ROOT / "counter_fixture.pftrace").read_bytes()
out = ROOT / "counter_fixture_clock_mapped.pftrace"
with out.open("xb") as f:
    f.write(raw)
expected = json.loads((ROOT / "expected.json").read_text())
expected["packet_count"] = 21
expected["clock_mapping"] = "synthetic BOOTTIME6 = MONOTONIC3, explicit snapshot"
with (ROOT / "expected_clock_mapped.json").open("x") as f:
    f.write(json.dumps(expected, indent=2) + "\n")
print(json.dumps({"fixture": str(out), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}))
