# 保存済み unit=1 残差の終端境界と marker の ns 照合

stage17 の正式取得 run 3 / 4 / 7 / 8 のみを、保存済み raw ledger と公式 SQL で照合した。新しいブラウザー実行、ゲーム性能測定、raw decoder の変更は行っていない。厳密な正負を用い、許容差や不都合な標本の除外は設けていない。

結果は、残差に必要な時間の余地が次の保存イベントまでに存在することを示す。残差すべての原因が解決したという結論ではない。marker の追加照合では、整数 µs の JSON 出力が小さな差の符号を変える例を確認した。

## 対応方法と保持範囲

`boundary_census.py` は同一 raw sequence / event track の BEGIN・END スタックから組を作り、`name + exact CPU begin + exact CPU end` が SQL slice と一意に対応する場合だけ解析する。端点の wall ns は、raw の `(thread_time counter UUID, exact absolute CPU ns)` と保存済み公式 SQL counter の `(uuid, value)` が一意に対応する場合に限り `counter.ts` を採用する。候補が複数なら選ばず、その状態を保存する。

SQL の CPU 付き完了 slice は 83,817 件（負 49,070 / ゼロ 6,868 / 正 27,879）。正 27,879 件はすべて raw B/E と一意に対応し、begin/end の counter wall ns は SQL slice の `ts` / `ts+dur` と完全一致した。ゼロ slice の 2,752 件は raw B/E の対象外として `missingRawPair` に保持した。これは retained raw instant 2,752 件と同数だが、このスクリプトは個々の instant と SQL zero slice を別ルールで選び直していない。

same-thread の retained CPU-bearing raw TrackEvent は計 164,882 件で、すべて SQL counter wall に一意対応した。retained 範囲では未対応 END と未閉鎖 BEGIN はともに 0。ledger は CPU を持たない一部イベントを保持しないため、「次」は全実行命令や全 TrackEvent の次ではない。

## end → 次の retained CPU-bearing point

主解析の次点は raw packet 順で直後の same-thread CPU-bearing raw TrackEvent。別に `(SQL wall ns, packet index)` で並べた次点も計算した。custom/default の分類を理由に次点を飛ばさない。

| run | 正の slice | 次点あり | 次点なし | slice 内 clear 跨ぎ |
| --- | ---: | ---: | ---: | ---: |
| 3 | 8,309 | 8,308 | 1 | 1 |
| 4 | 6,937 | 6,937 | 0 | 1 |
| 7 | 6,165 | 6,164 | 1 | 0 |
| 8 | 6,468 | 6,467 | 1 | 0 |
| 合計 | 27,879 | 27,876 | 3 | 2 |

次点ありの正 27,876 件はすべて以下を満たした。

- end→next の wall gap と CPU gap が正で、wall gap が元 slice の CPU-minus-wall 超過以上。
- end/next の raw `packet_clock_id` は省略、`default_clock_id=64`、legacy event timestamp フィールドなし。
- packet 順の次点と wall 順の次点が一致。

end→next の clear 跨ぎは 11 件、loss 跨ぎは 0。正の slice 内 clear 跨ぎは 2 件、loss 跨ぎは 0。次点なしの 3 件は不合格にも合格にも置き換えず、そのまま保存している。次点ありの最小 `wall gap - slice excess` は 302 ns（許容差として使用していない）。

全 retained raw point の隣接間は 164,878 組で、wall/CPU gap はすべて正。各 run に explicit packet clock のイベントが 33 件（合計 132 件）あり、それらも次点探索から除外していない。正 slice の end→next がいずれも default64 になったのは集計結果である。

### 最大の残差 4 例

すべて同一 epoch 内の slice。以下の CPU は保存された thread_time counter、wall は保存 SQL ns である。

| run / SQL id | slice | wall ns | CPU ns | excess ns | end→next wall ns | end→next CPU ns |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 8 / 13466 | ThreadControllerImpl::RunTask | 1,701,211 | 1,831,199 | 129,988 | 132,858 | 1,834 |
| 8 / 10866 | BlinkScheduler_OnTaskCompleted | 4,438 | 66,815 | 62,377 | 71,363 | 8,866 |
| 3 / 17112 | LocalFrameView::ScheduleAnimation | 2,264 | 50,274 | 48,010 | 76,253 | 28,343 |
| 7 / 8631 | LocalFrameView::ScheduleAnimation | 1,453 | 47,599 | 46,146 | 55,624 | 9,498 |

### 条件付きの解釈

default wall end の取得後に CPU end の読取が遅れ、その CPU 読取後に次の default wall が取得されるなら、単純な CPU 終端読取遅延だけで超過を説明するには、次の wall gap が元 slice の超過以上である必要がある。今回の次点あり 27,876 件ではこの必要条件への反例はなかった。

必要条件を満たすことは、CPU 読取遅延が原因である証明ではない。raw の clock metadata はソース側の取得順序そのものを記録しない。開始端の読取差、timestamp の明示指定、計測処理、時計、変換などをこの集計だけで全件識別できない。nested slice は互いに独立した観測でもない。stage15 の別設定・別取得 JSON の結果を、この unit=1 集計で取り消さない。

## 全 192 marker window の保存 ns と JSON µs

`marker_ns_census.py` は run 3 / 4 / 7 / 8 の marker 全 192 windows（正式 144 / warmup 48）を対象にした。各試行の capture→handler-end / first-raf / second-raf を mark と stamp の両方で照合した。raw name / TimeStamp.data_message と report marker 名・kind の対応を使用し、raw CPU ns と公式 SQL counter wall ns の一意対応だけを採用した。192 windows すべて一意対応し、全端点で CPU と wall の `ns // 1000` が同じ protobuf 由来 JSON の `tts` と `ts` に一致した。

| 保存 ns の符号 → JSON µs 端点差の符号 | windows |
| --- | ---: |
| 負 → 負 | 178 |
| 負 → ゼロ | 11 |
| 負 → 正 | 1 |
| 正 → ゼロ | 1 |
| 正 → 正 | 1 |

保存 ns では負 190 / ゼロ 0 / 正 2、JSON 端点差では負 178 / ゼロ 12 / 正 2。全 warmup 48 windows の保存 ns 超過は負。正式 144 windows のうち保存 ns の正は以下の 2 件である。

| run / branch / trial / kind / window | 保存 wall ns | 保存 CPU ns | 保存 excess ns | JSON excess ns相当 |
| --- | ---: | ---: | ---: | ---: |
| 7 / legacy / 1 / stamp / capture→handler-end | 3,150,681 | 3,150,706 | +25 | 0 |
| 7 / legacy / 3 / mark / capture→handler-end | 3,316,000 | 3,317,116 | +1,116 | +1,000 |

既知のもう一方の JSON 正例、run 8 / dp / trial 1 / stamp / capture→handler-end は、保存 wall 3,424,705 ns・CPU 3,424,566 ns・excess **−139 ns** に対して JSON は **+1,000 ns 相当**だった。整数 µs の端点切り捨てで符号が反転した。この 1 件の符号反転だけを理由に、保存 ns の正 2 件まで解消済みとはしない。

これらは保存された ns counter 端点の差であり、同時に取得した物理 CPU 真値とは呼ばない。mark と stamp には異なる timestamp 経路があり、同じ試行でも相互に置き換えない。

## 成果物と再現

- `boundary_census.py` / `boundary-census.json`: 全符号集計、全正 27,879 件の端点・次点・raw clock フィールド・候補数、最大 4 例。
- `marker_ns_census.py` / `marker-ns-census.json`: 全 192 windows、保存 ns と同一 protobuf 由来 JSON 端点の全件照合。
- 各 JSON は実行スクリプト・元 report・入力 raw ledger / SQL / protobuf の SHA-256 を保存する。raw decoder SHA は既存固定値を確認した。

実行は `python3 boundary_census.py` と `python3 marker_ns_census.py`。どちらも既存出力を上書きしない。再検算では空の別フォルダーへ解析器と必要な補助ファイルを複製し、保存済みJSONを移動・上書きせず実行する。入力は sibling の `bingo-stage17-20261015` に固定してあり、stage17 の資料は変更しない。
