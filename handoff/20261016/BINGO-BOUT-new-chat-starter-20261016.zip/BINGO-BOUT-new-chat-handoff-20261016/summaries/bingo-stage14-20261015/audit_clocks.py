#!/usr/bin/env python3
"""Retain impossible local CPU/wall differences without filtering timings."""
import argparse
import hashlib
import json
import math
from pathlib import Path

ENDPOINTS={'handler':('capture','handler-end'),'handlerToFirstRaf':('handler-end','first-raf'),
           'firstToSecondRaf':('first-raf','second-raf'),'captureToSecondRaf':('capture','second-raf')}


def main():
    p=argparse.ArgumentParser();p.add_argument('report',type=Path);p.add_argument('analysis',type=Path)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    assert not args.output.exists(),'Refuse overwrite'
    report_raw=args.report.read_bytes();analysis_raw=args.analysis.read_bytes()
    report=json.loads(report_raw);analysis=json.loads(analysis_raw)
    assert report['status']==analysis['status']=='completed'
    assert analysis['reportSha256']==hashlib.sha256(report_raw).hexdigest()
    anomalies=[];cache={}
    for sample in analysis['samples']:
        bad=[(name,w) for name,w in sample['windows'].items() if w['cpuWithinWallWithoutTolerance'] is False]
        if not bad:continue
        visit=next(v for v in report['visits'] if (v['run'],v['version'])==(sample['run'],sample['version']))
        key=(sample['run'],sample['version'])
        if key not in cache:
            path=Path(visit['trace']['path'])
            if not path.is_file():path=args.report.parent/'traces'/path.name
            raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==visit['trace']['sha256']
            cache[key]=json.loads(raw)['traceEvents']
        events=cache[key];names=set(sample['markerNames'])
        marks={e['name'].rsplit('.',1)[1]:e for e in events if e.get('cat')=='blink.user_timing' and e.get('name') in names}
        stamps={e['args']['data']['message'].rsplit('.',1)[1]:e for e in events
                if e.get('name')=='TimeStamp' and e.get('args',{}).get('data',{}).get('message') in names}
        pid,tid=marks['capture']['pid'],marks['capture']['tid']
        main=[e for e in events if (e.get('pid'),e.get('tid'))==(pid,tid)]
        for name,window in bad:
            a,b=ENDPOINTS[name];lo,hi=marks[a]['ts'],marks[b]['ts']
            def difference(records):
                wall=records[b]['ts']-records[a]['ts'];cpu=records[b]['tts']-records[a]['tts']
                return {'wallUs':wall,'threadCpuCounterDeltaUs':cpu,'cpuExcessUs':cpu-wall}
            x=[e for e in main if e.get('ph')=='X' and isinstance(e.get('tdur'),(int,float))
               and e.get('dur',0)>0 and e['ts']<hi and e['ts']+e['dur']>lo]
            excessive=[e for e in x if e['tdur']>e['dur']]
            def record(e):return {k:e[k] for k in ['name','cat','ph','pid','tid','ts','tts','dur','tdur','args'] if k in e}
            near={label:[record(e) for e in sorted([e for e in main
                    if isinstance(e.get('tts'),(int,float)) and 'ts' in e],key=lambda e:abs(e['ts']-marks[label]['ts']))[:6]]
                    for label in (a,b)}
            anomalies.append({'run':sample['run'],'version':sample['version'],'branch':sample['branch'],
                'trial':sample['trial'],'warmup':sample['warmup'],'window':name,
                'performanceMarkDifference':difference(marks),'consoleTimeStampDifference':difference(stamps),
                'allFourPerformanceMarks':{k:record(v) for k,v in marks.items()},
                'allFourConsoleTimeStamps':{k:record(v) for k,v in stamps.items()},
                'fullXEventsOverlappingWindow':len(x),'fullXEventsWithCpuDurationExceedingWall':len(excessive),
                'excessiveFullXEvents':[record(e) for e in excessive],
                'nearbyRecordedThreadClockSamples':near,'traceSha256':visit['trace']['sha256']})
    assert len(anomalies)==analysis['checks']['cpuExceedsWallWindowCountWithoutTolerance']
    result={'status':'completed','reportSha256':hashlib.sha256(report_raw).hexdigest(),
        'analysisSha256':hashlib.sha256(analysis_raw).hexdigest(),'auditorSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'anomalousWindows':len(anomalies),'anomalousSamples':len({(x['run'],x['version'],x['branch'],x['trial']) for x in anomalies}),
        'cpuCounterPhysicalAccountingConfirmed':False,'rawRecordsModifiedOrSamplesRemoved':False,
        'interpretation':'Finite same-thread marker correspondence is not a physical CPU accounting validation. Both marker types exceed wall in these windows. Do not treat differences as precise CPU/wait attribution, clamp residuals, exclude samples or assign an unobserved cause. Containing windows may look plausible while including the same clock inconsistency.',
        'anomalies':anomalies}
    with args.output.open('x') as f:f.write(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'anomalousWindows':len(anomalies),'fullXExcessCounts':[x['fullXEventsWithCpuDurationExceedingWall'] for x in anomalies]}))


if __name__=='__main__':main()
