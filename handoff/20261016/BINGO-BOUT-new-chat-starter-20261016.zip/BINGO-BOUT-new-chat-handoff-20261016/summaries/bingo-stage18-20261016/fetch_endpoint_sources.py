#!/usr/bin/env python3
"""Save fixed-revision callsites used for stage18 read-only endpoint review."""
import concurrent.futures
import datetime
import hashlib
import json
import pathlib
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent
DEST = ROOT / 'official-sources' / 'endpoint-review'
REV = '73c14f6228d7cd537c855007e8f88678969cc0eb'
PATHS = [
    'base/task/sequence_manager/thread_controller_with_message_pump_impl.cc',
    'base/task/sequence_manager/thread_controller_impl.cc',
    'third_party/blink/renderer/platform/scheduler/main_thread/main_thread_scheduler_impl.cc',
    'third_party/blink/renderer/core/frame/local_frame_view.cc',
    'cc/paint/recording_source.cc',
]

def save(path):
    url = f'https://raw.githubusercontent.com/chromium/chromium/{REV}/{path}'
    result = dict(repository='chromium/chromium', revision=REV, sourcePath=path,
                  url=url, retrievedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    try:
        with urllib.request.urlopen(url, timeout=45) as response:
            data = response.read()
            result['httpStatus'] = response.status
        target = DEST / 'chromium' / path
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as output:
            output.write(data)
        result.update(savedPath=str(target.relative_to(ROOT)), bytes=len(data),
                      sha256=hashlib.sha256(data).hexdigest(),
                      lineCount=len(data.splitlines()), passed=True)
    except Exception as error:
        result.update(passed=False, error=repr(error))
    return result

def main():
    DEST.mkdir(parents=True, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        records = list(executor.map(save, PATHS))
    (DEST/'fetch-manifest.json').write_text(json.dumps(records, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(dict(total=len(records), saved=sum(r['passed'] for r in records)), ensure_ascii=False))

if __name__ == '__main__':
    main()
