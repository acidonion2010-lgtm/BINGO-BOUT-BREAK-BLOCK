'use strict';
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const {load,rng,seed}=require('./loader.cjs');
const design=require('./design.json');
const all=Array.from({length:9},(_,i)=>i);
const memoryKeys=['cpuBlockedBreakCell','cpuBlockedBreakStreak','cpuBlockedCooldown','cpuSuccessfulBlockCell','cpuSuccessfulBlockStreak','cpuSuccessfulBlockCooldown'];
const marks=mask=>all.map(i=>Boolean(mask&(1<<i)));
function sample(p,random){let u=random(),sum=0,last=-1;for(let i=0;i<p.length;i++){if(p[i]>0){last=i;sum+=p[i];if(u<sum)return i;}}assert(last>=0);return last;}
function localMatrix(dp,m1,m2,t){
  const a=dp.analyze({maskP1:m1,maskP2:m2,t});
  const child=dp.layers[t+1];
  const value=(x,y)=>child.values[child.index1[x]*child.n2+child.index2[y]];
  const stay=value(m1,m2);
  const pay=a.legalActions.map(i=>a.attacker===2?value(m1,m2|(1<<i)):value(m1|(1<<i),m2));
  return {...a,pay,stay};
}
function opponent(api,id,role,random,dp,eqTables,m1,m2,t,oppMemory){
  const s=api.state, own=role==='break', target=own?s.p1Marks:s.p2Marks;
  const layout=own?s.p1NumberLayout:s.p2NumberLayout;
  const legal=all.filter(i=>!target[i]);
  if(id==='uniform')return legal[Math.floor(random()*legal.length)];
  if(id==='greedy'){
    const w=api.getCellWeights(target,layout);const best=Math.max(...legal.map(i=>w[i]));
    const ties=legal.filter(i=>w[i]===best);return ties[Math.floor(random()*ties.length)];
  }
  if(id==='normal'){
    // The original CPU always occupies P2. Exchange player labels for this
    // isolated decision, including both boards, counters, first player and memory.
    const saved={...s};
    Object.assign(s,{p1Marks:saved.p2Marks,p2Marks:saved.p1Marks,
      p1NumberLayout:saved.p2NumberLayout,p2NumberLayout:saved.p1NumberLayout,
      p1Score:saved.p2Score,p2Score:saved.p1Score,p1TurnsTaken:saved.p2TurnsTaken,
      p2TurnsTaken:saved.p1TurnsTaken,firstPlayer:3-saved.firstPlayer,cpuDifficulty:'normal',...oppMemory});
    api.setRandom(random);
    const cell=own?api.selectCpuBreakCell(legal):api.selectCpuBlockCell(s.p1Marks,s.p1NumberLayout);
    for(const k of memoryKeys)oppMemory[k]=s[k];Object.assign(s,saved);return cell;
  }
  if(id==='board_eq'){
    const table=eqTables[own?0:1],mask=own?m1:m2;
    const remaining=9-(own?s.p1TurnsTaken:s.p2TurnsTaken);
    const dist=(own?table.breakProbs:table.blockProbs)[remaining][mask];
    return sample(dist,random);
  }
  const p=localMatrix(dp,m1,m2,t);
  if(id==='nash')return p.legalActions[sample(own?p.breakStrategy:p.blockStrategy,random)];
  if(id==='master_local_br'){
    // Best one-step response to MASTER, assuming Nash continuation values.
    // It observes public state and MASTER's known distribution, never the pick.
    let vals;
    if(own) vals=p.pay.map((v,i)=>v+p.blockStrategy[i]*(p.stay-v));
    else {
      const actual=api.cpuBreakSelectionWeights(p,dp.resultGap);
      const base=p.pay.reduce((v,x,i)=>v+actual[p.legalActions[i]]*x,0);
      vals=p.pay.map((v,i)=>base+actual[p.legalActions[i]]*(p.stay-v));
    }
    const best=Math.min(...vals);const ties=p.legalActions.filter((_,i)=>Math.abs(vals[i]-best)<1e-10);
    return ties[Math.floor(random()*ties.length)];
  }
  throw new Error('Unknown opponent '+id);
}
function game(api,dp,eqTables,condition,difficulty,opp,rep,trace=false){
  const {pair,swap,firstPlayer,p1,p2}=condition,s=api.state;
  Object.assign(s,{gameMode:'cpu',cpuDifficulty:difficulty==='nash_control'?'master':difficulty,
    p1Marks:Array(9).fill(false),p2Marks:Array(9).fill(false),p1NumberLayout:p1,p2NumberLayout:p2,
    p1Score:0,p2Score:0,p1TurnsTaken:0,p2TurnsTaken:0,firstPlayer,inning:1,turnRole:0,
    selectedBreakCell:null,seatChosen:true,gameEnded:false,isStarting:false});
  api.resetCpuBreakMemory();api.resetCpuBlockMemory();api.setDp(dp);
  const oppMemory={cpuBlockedBreakCell:null,cpuBlockedBreakStreak:0,cpuBlockedCooldown:0,
    cpuSuccessfulBlockCell:null,cpuSuccessfulBlockStreak:0,cpuSuccessfulBlockCooldown:0};
  let m1=0,m2=0,defBlocks=0,atkBlocked=0,defN=0,atkN=0;
  let deviated=0,totalVariation=0,localLoss=0,early=false;const history=[];
  const updateOpp=(role,cell,blocked)=>{
    const saved={};for(const k of memoryKeys){saved[k]=s[k];s[k]=oppMemory[k];}
    (role==='break'?api.rememberCpuBreakResult:api.rememberCpuBlockResult)(cell,blocked);
    for(const k of memoryKeys){oppMemory[k]=s[k];s[k]=saved[k];}
  };
  for(let t=0;t<18;t++){
    s.inning=Math.floor(t/2)+1;s.turnRole=t%2;
    const attacker=api.getCurrentPlayer();assert.equal(attacker,dp.attacker[t]);
    const cpuRole=attacker===2?'break':'block', oppRole=attacker===1?'break':'block';
    const cpuRand=rng(seed('bingo-v1','action',pair,swap,firstPlayer,rep,t,2));
    const oppRand=rng(seed('bingo-v1','action',pair,swap,firstPlayer,rep,t,1));
    // Independent RNG streams and both choices precede resolution.
    let cpuPick;
    if(difficulty==='nash_control'){
      const pol=dp.analyze({maskP1:m1,maskP2:m2,t});
      cpuPick=pol.legalActions[sample(cpuRole==='break'?pol.breakStrategy:pol.blockStrategy,cpuRand)];
    } else {
      api.setRandom(cpuRand);
      cpuPick=cpuRole==='break'?api.selectCpuBreakCell(all.filter(i=>!s.p2Marks[i])):
        api.selectCpuBlockCell(s.p1Marks,s.p1NumberLayout);
      assert.equal(api.dpStatus(),'ready','Fallback must never be silently mixed into results');
    }
    const oppPick=opponent(api,opp,oppRole,oppRand,dp,eqTables,m1,m2,t,oppMemory);
    const b=attacker===2?cpuPick:oppPick,k=attacker===2?oppPick:cpuPick;
    const target=attacker===2?s.p2Marks:s.p1Marks;
    assert(Number.isInteger(b)&&Number.isInteger(k)&&!target[b]&&!target[k]);
    const blocked=b===k;
    if(attacker===2){atkN++;atkBlocked+=blocked;api.rememberCpuBreakResult(b,blocked);updateOpp('block',b,blocked);}
    else{defN++;defBlocks+=blocked;api.rememberCpuBlockResult(b,blocked);updateOpp('break',b,blocked);}
    if(!blocked){target[b]=true;if(attacker===2)m2|=1<<b;else m1|=1<<b;}
    if(attacker===2)s.p2TurnsTaken++;else s.p1TurnsTaken++;
    s.p1Score=api.calculateScore(s.p1Marks,p1);s.p2Score=api.calculateScore(s.p2Marks,p2);
    const end=api.evaluateEndState({...s,half:t%2?'bottom':'top'});
    const dpEnd=dp.isTerminal(t+1,s.p1Score,s.p2Score,
      dp.max1[s.p1TurnsTaken][m1],dp.max2[s.p2TurnsTaken][m2]);
    assert.equal(end.shouldEnd,dpEnd,'Original UI rules and DP termination disagree');
    if(trace)history.push({t,attacker,b,k,blocked,m1,m2,s1:s.p1Score,s2:s.p2Score,end:end.shouldEnd});
    if(end.shouldEnd){early=t<17;break;}
  }
  const margin=s.p2Score-s.p1Score;
  const out={pair,swap,firstPlayer,difficulty,opponent:opp,rep,
    win:+(margin>0),draw:+(margin===0),loss:+(margin<0),margin,
    scoreCPU:s.p2Score,scoreOpponent:s.p1Score,utility:1000*Math.sign(margin)+margin,
    defBlocks,defN,atkBlocked,atkN,turns:defN+atkN,early:+early,
    hardLegacy:api.counters().legacy,hardDp:api.counters().dp};
  if(trace)out.history=history;
  return out;
}
function runPair(pair,{reps=design.replicates_per_cell,outDir='results',smoke=false}={}){
  const {api,sha256}=load();assert.equal(sha256,design.source_sha256);
  api.setRandom(rng(seed('bingo-v1','layout',pair)));
  const layouts=api.createIndividualNumberLayouts();
  const output=[],metadata=[];
  for(let swap=0;swap<2;swap++)for(const firstPlayer of [1,2]){
    const p1=Array.from(swap?layouts.p2:layouts.p1),p2=Array.from(swap?layouts.p1:layouts.p2);
    const start=performance.now();const dp=new api.WholeGameDP({layoutP1:p1,layoutP2:p2,firstPlayer});
    const stats=dp.solve();assert(stats.maxGap<=1e-5);
    const eqTables=[api.buildCpuEqTable(p1),api.buildCpuEqTable(p2)];
    metadata.push({pair,swap,firstPlayer,p1,p2,...stats,solveSeconds:(performance.now()-start)/1000});
    const condition={pair,swap,firstPlayer,p1,p2};
    for(const opp of design.opponents)for(const diff of design.difficulties)for(let rep=0;rep<reps;rep++)
      output.push(game(api,dp,eqTables,condition,diff,opp,rep,smoke&&rep===0));
    console.log(JSON.stringify({event:'condition_complete',pair,swap,firstPlayer,games:output.length,stats}));
  }
  fs.mkdirSync(outDir,{recursive:true});
  fs.writeFileSync(path.join(outDir,`pair-${pair}.jsonl`),output.map(x=>JSON.stringify(x)).join('\n')+'\n');
  fs.writeFileSync(path.join(outDir,`dp-${pair}.json`),JSON.stringify(metadata,null,2));
  return output;
}
if(require.main===module){
  const start=Number(process.argv[2]||0),end=Number(process.argv[3]||start+1);
  for(let pair=start;pair<end;pair++)runPair(pair,{reps:Number(process.env.BINGO_REPS||design.replicates_per_cell),outDir:process.env.BINGO_OUT||'results',smoke:process.env.BINGO_SMOKE==='1'});
}
module.exports={runPair,game,localMatrix,sample,opponent};
