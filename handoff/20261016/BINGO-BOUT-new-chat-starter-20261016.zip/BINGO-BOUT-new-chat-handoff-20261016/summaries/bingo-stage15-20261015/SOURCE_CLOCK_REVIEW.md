# 段階15 時計取得実装の読み取り調査

段階14の `ts` と `tts` は、同時に採取した2種類の時計とは扱えない。通常の TRACE_EVENT でも wall を先に読み、状態準備・packet作成の後に thread CPU を読む。`performance.mark(name)` はさらに前に取得した wall timestamp を明示して emit する。一方、実際の Chromium JSON 出力経路で、CPU時間をwallから補間・推定する実装は見つからなかった。これらはソースから確認できた事実であり、段階14の数msの超過原因を特定したものではない。

本調査は既存資料・raw JSONと、固定revisionの公式Chromium/Perfettoソースの読み取りだけで行った。ブラウザー・DP・性能ジョブ・ビルドは起動していない。本体と過去成果物は変更していない。

## 対象revisionと保存原本

既存stage8の `browser-revision-check.json` と段階14 `traces/run1-original.json` のmetadataは、どちらも Chromium **`73c14f6228d7cd537c855007e8f88678969cc0eb`** を示す。段階14の完全表記は `73c14f6228d7cd537c855007e8f88678969cc0eb-refs/branch-heads/8037@{#1293}`、clock-domainは `LINUX_CLOCK_MONOTONIC`。同commitの公式 `chrome/VERSION` は **154.0.8037.57**。同commitのDEPS:2817–2818がPerfetto **`5dbeaad4ceb91470a835426b52e0cb43a3e5ef10`** をpinする。確認元・rawファイルSHA256・選択metadataは [source-revision-evidence.json](/workspace/bingo-stage15-20261015/source-revision-evidence.json) に保存した。これは既存ブラウザーが申告したrevisionと対応ソースの照合であり、配布binary全体と無改変upstreamビルドとの同一性検証ではない。

以下の公式原本をcommit固定URLから取得し、本文を変更せず保存した。URL・バイト数・SHA256は各manifestにある。存在しなかった候補pathのHTTP 404も取得履歴に残した。

- BlinkとVERSION: [blink-manifest.json](/workspace/bingo-stage15-20261015/official-sources/blink-manifest.json)、[followup1](/workspace/bingo-stage15-20261015/official-sources/blink-manifest-followup1.json)、[followup2](/workspace/bingo-stage15-20261015/official-sources/blink-manifest-followup2.json)
- Linux時計・Chromium/Perfetto producer: [MANIFEST.json](/workspace/bingo-stage15-20261015/official-sources/linux-threadticks-review/MANIFEST.json)、[詳細所見](/workspace/bingo-stage15-20261015/official-sources/linux-threadticks-review/FINDINGS.md)
- Chromium export入口・Perfetto importer/exporter: [MANIFEST.json](/workspace/bingo-stage15-20261015/official-sources/perfetto-review/MANIFEST.json)、[詳細所見](/workspace/bingo-stage15-20261015/official-sources/perfetto-review/FINDINGS.md)
- ParseHTML確認の追加原本: [PARSEHTML_EXTRA_MANIFEST.json](/workspace/bingo-stage15-20261015/official-sources/linux-threadticks-review/PARSEHTML_EXTRA_MANIFEST.json)
- 配布用の固定revision LICENSE原文: [license-manifest.json](/workspace/bingo-stage15-20261015/official-sources/license-manifest.json)。Chromium LICENSEは1,536 bytes/SHA256 `368cca1106be99d39ecd32a38d8305585d802a475effb66380b91ffc9bcf709b`、Perfetto LICENSEは14,990 bytes/SHA256 `9a682a56cffc9524dfa9b0b1c0dca9cb81a19e96d5bd0793aaf02c08a95ee7ca`。両repositoryの同commit root NOTICEはHTTP 404で、その事実もmanifestに保持した。Perfetto LICENSEに含まれる追加のnotice本文も省略していない。

LICENSE追加前の69原本capture、計1,986,749 bytesは、全manifestのSHA256・サイズ（記載があるものは行数も）をこの調査担当が再計算し [source-manifest-audit.json](/workspace/bingo-stage15-20261015/source-manifest-audit.json) に保存した。LICENSE2原本も保存直後にhash照合した。同一ファイルを別調査系列で重複取得したcaptureを含む件数である。

以下の行番号はこれらの未変更原本に対応する。リンク先も同じimmutable commitを指す。

## UserTimingのwall timestamp

段階14は、固定したstage7 helperの `performance.mark(name); console.timeStamp(name);` を使う。`performance.mark` に `startTime` やdetailを渡していない（`validation/stage7/trace_response.py:34–45`、段階14capture script:37でprefixだけ置換）。

`Performance::mark` はまず `PerformanceMark::Create`、続いて `UserTiming::AddMarkToPerformanceTimeline` を呼ぶ（[performance.cc:904–910](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/third_party/blink/renderer/core/timing/performance.cc#L904-L910)）。

[performance_mark.cc:54–81](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/third_party/blink/renderer/core/timing/performance_mark.cc#L54-L81)では、optionsなしの場合も `performance->now()` と別に `base::TimeTicks::Now()` を読み、後者を `unsafe_start_for_traces` に保持する。利用者が明示startTimeを渡した場合は `timeOrigin + startTime` に置き換える。stage14は前者なので、利用者による過去時刻指定はない。

[performance_user_timing.cc:75–120](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/third_party/blink/renderer/core/timing/performance_user_timing.cc#L75-L120)はtimelineへの挿入、detail処理、別の `callTime=TimeTicks::Now()`、`v8::CpuProfiler::CollectSample` 等の後に、`TRACE_EVENT_INSTANT("blink.user_timing", nullptr, mark.UnsafeTimeForTraces(), ...)` を呼ぶ。したがって、**optionsなしのmarkでもtraceのwallは先に保存した明示timestamp、CPUは後述のemit時snapshot**になる。JSONの `args.data.callTime` と `startTime` は追加情報であり、その値からttsを歴史的時刻へ戻す処理はない。`performance.now()` の公開値のcoarseningと、trace用TimeTicksの取得も区別が必要である。

## console.timeStampのwall timestamp

[thread_debugger_common_impl.cc:1032–1045](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/third_party/blink/renderer/core/inspector/thread_debugger_common_impl.cc#L1032-L1045)は、引数1個の `consoleTimeStamp` をempty argsで `consoleTimeStampWithArgs` に渡す。そこでは `DEVTOOLS_TIMELINE_TRACE_EVENT_INSTANT("TimeStamp", inspector_time_stamp_event::Data, ...)` を呼び、wall timestampを渡さない。

[inspector_trace_events.h:149–165](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/third_party/blink/renderer/core/inspector/inspector_trace_events.h#L149-L165)のmacroは通常の `TRACE_EVENT_INSTANT(categories,event_name,"data",callback)` に展開される。`Data` はmessage/frame/sampleTraceIdを記入し `CollectSample` を呼ぶ（[inspector_trace_events.cc:1511–1540](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/third_party/blink/renderer/core/inspector/inspector_trace_events.cc#L1511-L1540)）。追加の数値start/end引数はannotationの変換処理で、stage14では渡していない。Data callbackはproducerのCPU snapshotの後に実行される。従って、**stage14のconsole TimeStampはUserTimingの保存済みwall時刻を再利用していない**。

両marker系列で同様の超過があるというraw所見に対し、UserTiming固有の先行timestampだけを原因とする説明は足りない。

## 通常イベントにもあるwall→CPUの取得差

Chromiumのmodern TRACE_EVENTはPerfettoを使う。`trace_log.cc:134–138`もTRACE_EVENT macroがTraceLogをbypassすると明記する。したがって、古いTraceLogの `ThreadNow` だけを追って現行ttsの取得元と説明してはいけない。

Perfettoの通常timestamp経路は次の順序である。

| 順序 | 固定revisionの箇所 | 処理 |
|---|---|---|
| 1 | [track_event_data_source.h:1078–1084](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/include/perfetto/tracing/internal/track_event_data_source.h#L1078-L1084) | `GetTraceTime()` でwallを読む |
| 2 | [同989–1003](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/include/perfetto/tracing/internal/track_event_data_source.h#L989-L1003) | TLS、incremental state、必要時のreset/descriptorsを準備 |
| 3 | [track_event_internal.cc:591–596](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/src/tracing/internal/track_event_internal.cc#L591-L596) | `NewTracePacket`、EventContext作成、type設定 |
| 4 | [同598–610](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/src/tracing/internal/track_event_internal.cc#L598-L610) | 有効なimplicit current-thread trackで `GetThreadCPUTimeNs()`、counter差分記録 |
| 5 | data_source.h:1011以降、1114–1117、1144以降 | name/categoryと利用者callback/argsを書き込む |

明示timestamp経路（同1058–1068）は供給された値を変換して同じ `WriteTrackEventImpl` に入る。CPU取得点は同じで、指定wall時刻へ遡らない。implicit default trackとのaddress equalityでcurrent-thread判定するため、任意の明示trackが同じCPU採取条件になるとは限らない。sampling/subsampling設定にも従う。

reset時はdefaults、thread/process/counter descriptorsと必要なclock snapshotを書き込む（internal.cc:429–518）。その処理自体はCPUを読まず、後のWriteEventが読む。packet allocationやこの準備の時間、割り込み等は2読取点の間に入り得るが、**対象超過イベントで実際に何が何ms入ったかはソースから測れない**。

同一threadの2markerや通常B/Eの両端でこの差が異なれば、`Δtts` と `Δts` の指す境界も異なる。end側wall取得後のthread CPUを含み、begin側wall取得後の一部CPUを含まないなどの差は原理上あり得る。ただし、取得順序の確認だけで今回の2–7ms差を説明できたとはしない。

### ParseHTMLの具体的な制約

[inspector_trace_events.cc:243–259](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/third_party/blink/renderer/core/inspector/inspector_trace_events.cc#L243-L259)は `Will(probe::ParseHTML)` で `TRACE_EVENT_BEGIN("devtools.timeline","ParseHTML","beginData",callback)`、`Did` で `TRACE_EVENT_END("devtools.timeline","endData",callback)` を呼ぶ。どちらも明示timestamp/trackを渡さない。`html_document_parser.cc:712`のPumpTokenizer内probeに対応する。JSONのXとして出力されても、この経路の元は通常B/Eである。

raw解析担当の [boundary-gap-review.json](/workspace/bingo-stage15-20261015/boundary-gap-review.json) は、同じrenderer main threadのfinite ttsを持つI/X startを `(ts,raw index)` 順にし、各 `tdur−dur>1000us` のXについて `derivedEndWall=ts+dur`、`derivedEndCpu=tts+tdur` と、そのwall endを厳密に超える最初のstartを比較する。169件全てに次startがあり、**168/169件で次startまでのwall gapが元のCPU超過量より短い**。これはexport済みstartとの記述的比較であり、全followingのtsが実行時点の即時wall readであると証明したものではない。

この調査担当も全16raw traceのhashを照合し、別実装の二分探索で上記件数を再計算した。finiteなdur/tdur/ttsを持つmain-thread Xは616,717件、1msを超えるCPU超過169件、next startあり169件、gap条件168件となり、各visitの件数とParseHTML例を含め一致した。結果は [independent-boundary-source-check.json](/workspace/bingo-stage15-20261015/independent-boundary-source-check.json) に保存した。新計測ではなく保存済みJSONの再集計である。

具体例のrun3 original、ParseHTML（raw index26216）はwall132usに対してCPU5419us、derived end `(7203002752,19581644)`、次のParseHTML（index26232）は `(7203002792,19581647)`、すなわちwall40us/CPU3usのgapである。上記emit箇所にはbackdatingがないため、この例を単純な「endのCPU読取がwallより約5ms遅れた」だけで説明するには、後続イベントと整合する追加根拠が必要になる。**default wall→CPU順序は候補の成立条件であり、この隣接イベント制約への解答ではない。** 個別のoriginal protobuf counter/clock状態や実行順をJSONだけから確定したわけでもない。

## Linux時計APIと精度

実際のPerfetto producerは [include/perfetto/base/time.h:274–277,307–309](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/include/perfetto/base/time.h#L274-L309) のchecked `clock_gettime(CLOCK_THREAD_CPUTIME_ID)` を呼び、nsを得る。Chromium `base::ThreadTicks` overrideを通らない。別途、Chromium側のThreadTicks標準Linux実装も [time_now_posix.cc:135–138](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/base/time/time_now_posix.cc#L135-L138) で同じclock IDを読むが、31–43行でnsをusへ切り捨てる。この2経路を混同しない。

標準Chromium初期化は `use_monotonic_clock=true`（perfetto_traced_process.cc:347–355）、Perfettoは `BUILTIN_CLOCK_MONOTONIC` に設定する（tracing.cc:53–56）。通常GetTraceTimeはCLOCK_MONOTONICのns、Blinkのbase::TimeTicksも標準POSIXではCLOCK_MONOTONICだが最初にusへ切り捨てる（time_now_posix.cc:31–43,100–102）。custom TimeTicks traitsは値をnsへ戻してtrace clock IDを付けるだけ（trace_event_impl.cc:25–29）。段階14metadataもMONOTONICである。

標準trace configはthread sampling=true、timestamp multiplier=1000（Chromium trace_config.cc:827–828、perfetto_config.cc:191–195）。CPUの各sample差分はこのmultiplierで整数除算した後に送り、内部last CPU sampleは切捨て前のns値へ進む。wall incremental timestampのbaseline更新は表現できた単位分だけ進む（internal.cc:535–542,603–610）。従ってJSON値は無加工の2つの同時ns読取でもない。この丸めは区別すべきだが、今回の数msのCPU過大差を丸めだけで説明したとはしない。subsamplingやpacket resetをraw protobufから個別追跡したわけではない。

これらは時計API/取得順序を確認するもので、動作中kernel/libc/VMのthread CPU accountingの正確さを実証しない。`CLOCK_THREAD_CPUTIME_ID`という名称やttsの単調性だけでも、その正確さは確定しない。

## JSON exporterはCPUを補間しているか

実際のChromium legacy JSON経路は [consumer_host.cc:423–447,490–503](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/services/tracing/perfetto/consumer_host.cc#L423-L503) のTraceProcessorStorage→protobuf parse→NotifyEndOfFile→ExportJsonである。

固定Perfettoの [track_event_event_importer.h:806–807](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/src/trace_processor/importers/proto/track_event_event_importer.h#L806-L807) はextra counterの `thread_time` をthread timestampへ直接入れる。B/Eはbeginのthread_tsを保持し、endから差し引く（814–865）。legacy Xはproducer供給のthread_durationを保存（876–895）、instantは供給thread_timestampでduration0（1022–1052）。旧thread-time delta/absolute encodingもdescriptor基準から直接累積・変換する（tokenizer.cc:507–522、sequence_state.h:61–80）。

[export_json.cc:849–914](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/src/trace_processor/export_json.cc#L849-L914) はそのstored thread_ts/thread_durを取り出し、整数ns/1000で `tts` / `tdur` を書く。調査した経路には、wallからのCPU補間、schedulerからのCPU推定、CPU≤wallへのclampはない。したがって `tdur>dur` やmarker間 `Δtts>Δts` はそのままJSONに残り得る。段階14のPerformanceMarkは実データではph=Iであり、一般的な旧R phase説明とは区別する。

これは全ての異常がproducer側で生まれたという証明ではない。保存物がexport後のJSONなので、元protobuf packet、counter reset、全producer callsite、processorの全経路を個別再現したものではない。今回確認した経路では「exporterの補間値だから」という説明を支持する実装はない、という結論である。

## 確定したこと・残る候補

| 判定 | 内容 |
|---|---|
| ソースで確認 | PerformanceMarkは先に保存したwall、console TimeStampとParseHTMLは通常wall。いずれのimplicit-thread TRACE_EVENTでもCPUはpacket準備後に読む |
| ソースで確認 | modern producerはCLOCK_THREAD_CPUTIME_IDを直接使用。標準wallはCLOCK_MONOTONIC。ThreadTicks override経路とは別 |
| ソースで確認 | 実export経路はcounter復元・B/E差分・整数単位変換。調査範囲でCPU補間/推定/上限制約はない |
| 候補、量は未検証 | wallとCPUの取得位置の差、trace内部の可変準備処理、reset/packet関連処理等による境界不一致 |
| なお未確定 | kernel/VM等のCPU会計、producer/processorの個別不具合、隣接イベントを含む今回のms超過の因果経路と寄与量 |

段階14の全marker対応PASSと時計の物理的一貫性PASSは別である。本調査によってCPU寄与率を確定しない。超過3件や通常Xの超過を除外・0clamp・事後許容差で救済する根拠も得ていない。UserTiming固有のtimestampと通常イベント共通の取得順序を切り分けた上で、raw隣接関係や別途固定計画の時計API検証と照合する必要がある。
