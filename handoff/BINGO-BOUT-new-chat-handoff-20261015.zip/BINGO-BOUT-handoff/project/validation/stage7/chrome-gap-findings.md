# Chrome の同一 receiver での均衡処理切り分け

`chrome-gap.json` は `completed: true`。本番 HTML は変更していない。2 回の fresh Chromium で自動テストは各 322/322、page error は 0。実 Blob Worker で P1 の DP を準備後、同じ DP・作業配列・値テーブル・入力盤面を使い、P1 late BLOCK / HARD full（mask 508/502、t=14、乱数 0.8）だけを比較した。

5 variants の policy・value・gap・P/Q・選択・履歴は再帰的な `Object.is` 比較で一致。各 variant の untimed 8 choices は cell 0、RNG 16 calls、whole/full 各 8、legacy/fallback 各 0。計測 3,600,000 choices と warmup 560,000 choices の checksum・dispatch・参照保持検査も通過した。結果履歴を更新しない固定 selector 契約の試験であり、実クリックの応答時間ではない。

差はすべて B−A、単位は ns/choice。各 run 9 paired batches、pooled は計 18 batches。

| A → B | run 1 の paired median | run 2 の paired median | pooled paired median | pooled paired range | 正/負/零の batch 数 |
|---|---:|---:|---:|---:|---:|
| current → current A/A | +20 | −20 | +7.5 | −210 ～ +215 | 9 / 9 / 0 |
| oldGap のみ → current | −15 | −20 | −17.5 | −140 ～ +780 | 6 / 12 / 0 |
| current → smallGap 候補 | −40 | −15 | −20 | −160 ～ +200 | 7 / 11 / 0 |
| original 6 methods → current 6 methods | −60 | −15 | −17.5 | −145 ～ +95 | 7 / 11 / 0 |
| oldSolve のみ → current | −60 | −10 | −27.5 | −190 ～ +35 | 6 / 11 / 1 |

表の statistic は **各 pair の差の median**。A と B の測定値を別々に median にしてから引いた値とは違う。例えば smallGap は pooled A=1,260 ns、B=1,265 ns、別々の median の差は **+5 ns**。original 6 → current 6 は A=1,212.5 ns、B=1,220 ns、別々の median の差は **+7.5 ns**。この差と表の −20 / −17.5 ns を入れ替えて扱わない。

smallGap 候補は Chrome の paired median では負になったが、各 run とも paired range は両符号を含む。Node の同じ target に対する `solveState+packStrategy` では候補の paired median は逆方向の +33.62548 ns、range −24.29467 ～ +74.89038 ns だった。Node と Chrome は計測 scope と実行環境が違うため直接統合できず、双方とも一貫した改善の根拠には足りない。今回は候補の本番採用を見送る。

oldGap → current と original 6 → current 6 も、全 batch が負ではない。別 realm の原本/現行比較で観測した +37.5 ns の原因を今回の負 median だけで確定できない。A/A の差を差し引いたり、許容幅として扱ったりしない。この一条件で他の selector 条件の性能 PASS を宣言しない。ordinary HTTP の時計の分解能、有限 batch、順序/JIT/GC/共有環境の影響が残る。oldSolve の「正 6」には +9.313239e−8 ns の浮動小数点差が 1 件含まれ、物理的な増加を示す値ではない。

ソース確認では、`solveState` は原本から次の **3 行だけ**を除くと現行と byte 一致した。payoff を取得するループ自体は保持している。

```js
let maxPay = -Infinity;
if (next > maxPay) maxPay = next; // attacker === 2 の loop
if (next > maxPay) maxPay = next; // attacker === 1 の loop
```

`packStrategy`・`sanitizePair`・`sanitize` は原本/現行で byte 一致。6 methods 全体の差は、この未使用 tracking の削除に加えて `equilibrium` の monotone 分岐と flag の局所読出し、`strategyGap` の対角分離を含む。今回の full DP receiver は `monotone=false`。従って「current solveState 自体は未使用 tracking だけを削除」は正しいが、「6 methods 全体の変更がそれだけ」とは言えない。
