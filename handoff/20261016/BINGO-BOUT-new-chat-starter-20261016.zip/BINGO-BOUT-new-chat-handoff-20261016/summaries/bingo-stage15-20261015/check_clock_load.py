#!/usr/bin/env python3
"""Finite native same-thread clock brackets and a labeled delayed-read control."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def cpu_stat():
    path=Path('/sys/fs/cgroup/cpu.stat')
    try:return {k:int(v) for k,v in (line.split() for line in path.read_text().splitlines())}
    except (OSError,ValueError) as e:return {'unavailable':type(e).__name__}


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    root=Path(__file__).resolve().parent;assert not args.output.exists(),'Refuse overwrite'
    build=args.output.parent/'native-load-build';assert not build.exists(),'Refuse existing build'
    build.mkdir(parents=True);binary=(build/'native-clock-load').resolve()
    command=['cc','-std=c11','-O2','-Wall','-Wextra','-Werror','-pthread',str(root/'native_clock_load.c'),'-o',str(binary)]
    data={'status':'running','scriptSha256':digest(Path(__file__)),'sourceSha256':digest(root/'native_clock_load.c'),
          'planSha256':digest(root/'NATIVE_PLAN.md'),'compileCommand':command,'processes':[]}
    def save():
        tmp=args.output.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');tmp.replace(args.output)
    save()
    try:
        compiled=subprocess.run(command,capture_output=True,text=True,timeout=30)
        data['compiler']={'returnCode':compiled.returncode,'stdout':compiled.stdout,'stderr':compiled.stderr}
        assert compiled.returncode==0,'Compiler failed';data['binarySha256']=digest(binary)
        for run in range(1,5):
            for threads in ([1,8] if run%2 else [8,1]):
                record={'run':run,'threads':threads,'cpuStatBefore':cpu_stat()};data['processes'].append(record);save()
                capture=subprocess.run([str(binary),str(threads)],capture_output=True,text=True,timeout=60)
                record.update({'returnCode':capture.returncode,'stderr':capture.stderr,'stdout':capture.stdout,'cpuStatAfter':cpu_stat()})
                assert capture.returncode==0,'Native helper failed'
                result=json.loads(capture.stdout);record['result']=result;assert result['threads']==threads and len(result['workers'])==threads
                for worker in result['workers']:
                    assert len(worker['samples'])==128
                    for index,s in enumerate(worker['samples']):
                        assert s['sample']==index and s['scenario']==(index+worker['index'])%4
                        assert s['wall0Ns']<=s['wall1Ns']<=s['wall2Ns']<=s['wall3Ns'] and s['cpu1Ns']>=s['cpu0Ns']
                        s['cpuDeltaNs']=s['cpu1Ns']-s['cpu0Ns'];s['outerWallNs']=s['wall3Ns']-s['wall0Ns']
                        s['nonSimultaneousWallNs']=s['wall2Ns']-s['wall0Ns']
                        s['outerExcessNs']=s['cpuDeltaNs']-s['outerWallNs']
                        s['nonSimultaneousExcessNs']=s['cpuDeltaNs']-s['nonSimultaneousWallNs']
                save();print(f'run{run} threads{threads}: {threads*128} brackets retained',flush=True)
        rows=[(record['threads'],s) for record in data['processes'] for w in record['result']['workers'] for s in w['samples']]
        assert len(rows)==4608
        data.update({'status':'completed','samples':len(rows),'outerCpuExcessCount':sum(s['outerExcessNs']>0 for _,s in rows),
            'delayedControlNonSimultaneousExcessCount':sum(s['scenario']==3 and s['nonSimultaneousExcessNs']>0 for _,s in rows),
            'chromiumCpuAccountingConfirmed':False})
    except BaseException as error:data.update({'status':'failed','failure':repr(error)});raise
    finally:save()
    print(json.dumps({k:data[k] for k in ['status','samples','outerCpuExcessCount','delayedControlNonSimultaneousExcessCount']}))


if __name__=='__main__':main()
