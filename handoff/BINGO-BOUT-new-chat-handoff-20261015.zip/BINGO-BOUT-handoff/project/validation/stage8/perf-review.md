# Stage 8 perf and scheduler accounting review

Reviewed the existing `perf_switch.py`, `analyse_tasks.py`, relevant selection code in `trace_tasks.py`, four traced perf-pilot samples, 16 traced `task-response/run1` samples, and the locally saved Linux v6.18.44 scheduler sources. No browser, benchmark, OS-setting change, or production HTML edit was performed. Run 2 was not read because it was being written during this review.

## Result

No integrity problem was found in the reviewed captures. The pilot supports a complete same-thread off-CPU interval inside the recorded commit-completion wait. Its enclosing proc counter delta supports a comparison with **accounted runqueue delay**, without determining the exact wakeup time, physical blocked duration, or upstream cause of the commit wait.

Recommended wording:

> In pilot `cdp-cue.before.02`, the complete 37.299 ms off-CPU interval exceeded the same thread's entire 1.861 ms increase in accounted runqueue delay across the enclosing host bracket by about 35.44 ms. That portion is not explained by recorded runnable-runqueue wait. These counters do not identify when the thread woke or why the commit completion took that long.

The arithmetic `37.298787 - 1.860984 = 35.437803 ms` is correct. “At least 35.437803 ms was not accounted as runnable runqueue wait” is defensible as a conservative comparison of the recorded accounting totals, conditional on the checked identity and enclosure. Presenting it as an exact physical sleep/blocked-time lower bound is stronger than this evidence establishes. Rounded wording makes that distinction clearer.

## Collector ABI and correspondence

- The explicitly restricted Linux x86_64 little-endian ABI is consistent with `/usr/include/linux/perf_event.h`: a 128-byte `perf_event_attr`, software DUMMY type/config `1/9`, `disabled`, `sample_id_all`, `use_clockid`, and `context_switch`; TID/TIME/CPU sample identity tail is 24 bytes. Per-thread `PERF_RECORD_SWITCH` is therefore 32 bytes. Syscall 298 and CLOEXEC flag 8 are appropriate on this architecture.
- `clockid=1` requests `CLOCK_MONOTONIC`. The saved host clock implementation is `clock_gettime(CLOCK_MONOTONIC)`, and trace metadata says `LINUX_CLOCK_MONOTONIC`. `analyse_tasks.py:25` checks these together, then checks enable/disable brackets, every record's PID/TID, alternating direction, and ordered timestamps. This is explicit clock correspondence; it does not subtract page-relative `performance.now()` from host timestamps.
- Proc selection requires trace PID==TID, matching renderer candidates in both snapshots, and equal `/proc/.../stat` start ticks before interpreting differences (`trace_tasks.py:211`). The pilot target is PID/TID 27436 with start ticks 1400088 in both reads; proc status Tgid/Pid/NSpid/NStgid also all match 27436.
- All four pilot and 16 run-1 selected captures have zero reported lost records/samples, throttle/unthrottle records, parser errors, overflow, and truncation; both FD and mmap closure are recorded. Independently decoding every saved `rawHex` reproduced the saved record type, misc, size, PID/TID, timestamp, CPU, and reserved field.
- Pilot ring occupancy is 1056–1664 bytes out of 65536; run-1 occupancy is 768–3264 bytes. All selected proc identities and basic run-delay interpretation flags are valid. There is no evidence of capacity pressure in these runs.

## Pilot interval and clipping

`cdp-cue.before.02` has first→second RAF trace wall time 39.954 ms and same-thread `tts` delta 2.600 ms. The complete non-preempt-flag pair is:

| Observation | CLOCK_MONOTONIC ns |
| --- | ---: |
| First RAF mark | 14010507960000 |
| OUT, CPU 4 | 14010509591609 |
| IN, CPU 4 | 14010546890396 |
| Second RAF mark | 14010547914000 |

Its duration is 37.298787 ms. The same-thread `LayerTreeHost::WaitForCommitCompletion` X event spans 14010509583000–14010546898000 ns (37.315 ms), enclosing the entire OUT→IN pair. The computed first→second off-CPU total is exactly this pair; on-scheduled wall remainder is 2.655213 ms, differing from trace thread CPU by 0.055213 ms. Scheduled wall time and thread CPU are different observations; the residual need not be assigned to application execution.

`analyse_tasks.py:33` builds only complete adjacent OUT→IN pairs and `:43` verifies that all four application marks lie in known-running portions of the capture. `:65` clips pairs to each marker window and `:85` unions their overlap with commit-wait spans. These operations correctly avoid allocating complete out-of-window intervals to the response windows or double-counting overlapping wait events. An incomplete leading/trailing off-CPU interval cannot silently cross a marker under these checks when the record stream is complete.

The before proc read ends at 14010469502230 ns, before capture mark 14010491933000 ns. The after read starts at 14010559903876 ns, after second RAF and actual resumed renderer execution. The run-delay counter increases from 91528984 to 93389968 ns: 1860984 ns. This wider bracket can include other runnable waits, so charging its entire increment to the 37.299 ms pair is deliberately conservative for an accounting comparison.

## Scheduler source and inference limits

The saved source release matches the reported kernel release `6.18.44`; it is source-level support, not verification of the running kernel's binary build.

- `kernel/sched/stats.h:239` places basic per-task accounting under `CONFIG_SCHED_INFO`, independently of the detailed `CONFIG_SCHEDSTATS` section at `:5`. In the saved include `linux/sched/stat.h:25`, `sched_info_on()` is enabled by `CONFIG_SCHED_INFO`. Thus `CONFIG_SCHEDSTATS=n` does not disable these basic per-task counters.
- `stats.h:246–297` adds queued time at dequeue or arrival and stamps enqueue time. `:324–335` performs departure/arrival accounting when switching tasks. `kernel/sched/core.c:5129` calls this before `perf_event_task_sched_out()`; `:5195` calls the perf schedule-in hook after switching. More decisively for this capture, the second RAF mark demonstrates actual execution after the observed IN and precedes the final proc sample. A queue wait ending at this IN is not still pending solely because the task has yet to resume.
- `fs/proc/base.c:508–517` prints the cumulative `sched_info.run_delay` directly. It does not itself settle a currently pending wait. This generic pending-wait caveat matters for an arbitrary proc endpoint; it does not erase the completed pair followed by actual renderer execution here.
- `run_delay` uses `rq_clock`, based on `sched_clock_cpu` (`core.c:835–857`), rather than the explicit perf/trace monotonic clock. Migration accounting is split across queues to cancel clock offsets (`stats.h:240–244`); time between dequeue and enqueue can remain uncharged. Nanosecond units do not establish exact physical-time equivalence or complete coverage of every runnable state transition.
- Do not assert that steal time is explicitly subtracted from `run_delay`. The steal subtraction in `core.c:812–825` affects `rq_clock_task`; run delay uses `rq_clock` instead.
- The absence of `PERF_RECORD_MISC_SWITCH_OUT_PREEMPT` does not identify a sleep cause, and voluntary runnable yields are possible. OUT→IN records contain no wakeup timestamp. The matching Chromium wait span locates the observed off-CPU interval in the commit-completion path; its duration alone does not establish whether the producer was delayed by raster work, another thread/process, GPU work, or scheduling.

Scheduler source URLs are pinned to [Linux v6.18.44 stats.h](https://github.com/gregkh/linux/blob/v6.18.44/kernel/sched/stats.h), [core.c](https://github.com/gregkh/linux/blob/v6.18.44/kernel/sched/core.c), [sched/stat.h](https://github.com/gregkh/linux/blob/v6.18.44/include/linux/sched/stat.h), and [proc/base.c](https://github.com/gregkh/linux/blob/v6.18.44/fs/proc/base.c). Existing fetch metadata is in `scheduler-source-fetch.json`; the source copies were already present under `/tmp/bingo-sched-info-source`.

## Robustness findings for future captures

1. **Trailing ring loss can evade the current generic integrity flag.** `perf_switch.py:196` checks `head-tail > dataSize`, but a writable forward perf ring does not overwrite unread data; a full ring drops a record and can defer its LOST notification until a later successful write. If recording stops while full, `lostRecords==0` and `head-tail<=dataSize` need not establish completeness, and a missing final OUT could make a later mark appear to follow an IN. A conservative rejection of near-capacity captures, or a separately verified lost-event count, would harden future use. This does not invalidate these small captures: no consumer advanced the tail before disable, and the final occupancy was far below capacity for their fixed-size switch records.
2. **Proc values are exported even when validity flags fail.** `analyse_tasks.py:206` copies any nonempty `schedstatDeltas` into `hostBracketRunqueueWaitMs` without requiring `runqueueWaitInterpretationAvailable`, monotonic counters, matching identity, or the bracket boolean. The current files pass all those checks, but any future derived bound should explicitly require them instead of treating a numeric field alone as valid evidence.
3. **Unthrottle-only records are not rejected.** `perf_switch.py:320` includes `throttleRecords` in the integrity predicate but omits `unthrottleRecords`; `analyse_tasks.py:22` does the same. Unexpected unthrottle activity would merit rejecting this switch-only diagnostic. None occurred in the reviewed data.

These are bounded collector/analyzer hardening opportunities. No code or existing JSON was changed as part of this review.

## Follow-up after hardening and final report review

The three findings above describe the collector/analyzer before the root agent's subsequent fixes. The final collector and analyzer reject unthrottle records, require 112 bytes of ring headroom for the supported layouts, and gate exported proc accounting values on identity, configuration/counter validity, and marker enclosure. The headroom check is a recording-integrity guard, not a performance threshold. Existing raw captures were preserved; the hardened collector's separate self-thread smoke has six switch records and successful FD/mmap closure.

The completed final file review independently confirmed 4 measured + 2 warmup samples for each pilot and 16 measured + 4 warmups for each formal run: 40 measured, 12 warmups, all 52 accepted; 36 measured samples have selected perf captures. The 32 formal samples contain 1797 switch records (1954 including the perf pilot); maximum formal ring occupancy is 4352/65536 bytes. All 40 reanalysis rows report valid proc accounting correspondence, all requested perf clock checks pass, and all shared throttle deltas are zero. The formal visit order is reversed between runs; all eight formal visits report self-tests 322/322 and no page errors.

The numbers in `未完了検証8結果.md` and `README.md`, including the four formal median cells, both run-2 long commit-wait examples, and unchanged production SHA-256, agree with the saved records. No concrete accounting/source overclaim was found in their final wording. Stage8's `marker_windows.py` preserves the three unfinished B scopes beginning after the second response mark and rejects unsupported B/E scopes that could overlap a response window; this does not claim that every scope in the full trace is closed. Stage7 and measured raw files remain unchanged.

For clarity on kernel ordering, these observations are `PERF_RECORD_SWITCH`, not the `trace_sched_switch` tracepoint: scheduler arrival accounting precedes the perf schedule-in hook. The later second-RAF mark and proc read independently demonstrate resumed execution after the long OUT→IN interval.
