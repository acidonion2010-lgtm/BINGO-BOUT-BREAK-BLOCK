# Stage16: extra counter のスキーマ・復元規則の確認

対象は Chromium が固定する Perfetto `5dbeaad4ceb91470a835426b52e0cb43a3e5ef10`。公式原文の読み取り調査のみを行った。ブラウザー、DP、性能測定、ビルドは実行せず、stage15 以前の成果物は変更していない。

**CPU 時計が旧 `thread_time_absolute_us` / `thread_time_delta_us` にない場合でも、TrackEvent の extra counter と CounterDescriptor から得られる場合がある。値を読むだけでは足りず、UUID の既定値、倍率、sequence ごとの加算・reset、thread への対応を復元する必要がある。** 本資料はソース上の規則を確定したもので、対象 raw trace に各形式が実在するという判定ではない。

## 1. 読むフィールド

以下の `#` は protobuf の field number。数値の enum 値と区別する。

| Message | フィールドと型 | 正確な原文 |
| --- | --- | --- |
| TrackEvent | `type #9` enum。`TYPE_COUNTER = 4`。`track_uuid #11` uint64 | [track_event.proto 131–178](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/protos/perfetto/trace/track_event/track_event.proto#L131-L178) |
| TrackEvent 単独 counter | `counter_value #30` int64、または `double_counter_value #44` double の oneof | 同上 180–188 |
| TrackEvent 整数 extra | `extra_counter_track_uuids #31` repeated uint64 と `extra_counter_values #12` repeated int64 | 同上 191–206 |
| TrackEvent 浮動小数 extra | `extra_double_counter_track_uuids #45` repeated uint64 と `extra_double_counter_values #46` repeated double | 同上 208–210 |
| TrackEventDefaults | `track_uuid #11`、整数 UUID 配列 `#31`、double UUID 配列 `#45` | 同上 517–524 |
| TracePacketDefaults | `track_event_defaults #11` message。`timestamp_clock_id #58` uint32 | [trace_packet_defaults.proto 26–37](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/protos/perfetto/trace/trace_packet_defaults.proto#L26-L37) |
| TrackDescriptor | `uuid #1` uint64、`parent_uuid #5` uint64、`name #2` / `static_name #10` / `atrace_name #13` の oneof、`process #3`、`thread #4`、`counter #8` | [track_descriptor.proto 43–171](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/protos/perfetto/trace/track_event/track_descriptor.proto#L43-L171) |
| CounterDescriptor | `type #1` enum、`categories #2` repeated string、`unit #3` enum、`unit_multiplier #4` int64、`is_incremental #5` bool、`unit_name #6` string、`y_axis_share_key #7` string | [counter_descriptor.proto 35–103](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/protos/perfetto/trace/track_event/counter_descriptor.proto#L35-L103) |
| CounterDescriptor の enum | `COUNTER_THREAD_TIME_NS = 1` は `UNIT_TIME_NS = 1` を含意。`COUNTER_THREAD_INSTRUCTION_COUNT = 2` は `UNIT_COUNT = 2` を含意。`UNIT_SIZE_BYTES = 3` | 同上 39–58 |
| ThreadDescriptor | `pid #1` int32、`tid #2` int64、`thread_name #5` string。旧時計用 reference は timestamp_us `#6`、thread_time_us `#7`、instruction_count `#8` | [thread_descriptor.proto 25–71](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/protos/perfetto/trace/track_event/thread_descriptor.proto#L25-L71) |
| ProcessDescriptor | `pid #1` int32、`process_name #6` string | [process_descriptor.proto 25–28](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/protos/perfetto/trace/track_event/process_descriptor.proto#L25-L28) |

CounterDescriptor は counter track を定義する。整数・double の extra はそれぞれ別の UUID 配列と対応し、位置 N 同士を結び付ける。値数より UUID 数が多いのは許され、余りの UUID は使わない。イベント側に UUID 配列があれば、その系列の defaults 配列全体を置き換える。短いイベント配列を defaults の残りで埋めてはいけない。整数系列と double 系列の defaults 選択は独立している。

実装根拠: `track_event_tokenizer.cc:592–608,624–664` と `track_event_event_importer.h:748–776`。値は整数系列を先、double 系列を後に同じ保存配列へ入れる。合計上限は **8 個** (`parser_types.h:172–186`)。UUID 不足・0、counter track ではない UUID、上限超過は tokenization error となり、その TrackEvent は stream に送られない。

## 2. 単位と数値変換

Descriptor の `type` が thread time なら、tokenizer は unit を ns とし、名前が未指定の場合に `thread_time` を補う (`track_event_tokenizer.cc:326–367`)。明示名がある場合は、その名前を保つ。

値の変換は次の順序 (`track_event_tracker.cc:618–648`)。

1. UUID が登録済みの counter track か確認する。
2. 入力値を `double` として扱う。
3. `unit_multiplier > 0` のときだけ掛ける。未指定・0・負値は、この実装では掛けない。
4. `is_incremental` なら sequence の UUID 別現在値へ加算する。それ以外は絶対値として使う。

`UNIT_TIME_NS` の enum を読むこと自体で追加の 1000 倍は行われない。たとえば raw を μs で持つ `COUNTER_THREAD_TIME_NS` は、倍率 1000 を指定して ns にする。旧 `thread_time_*_us` の専用復元は別経路なので、extra の値へ旧経路の 1000 倍を二重適用しない。

この経路は整数入力も `double` に変換してから倍率・加算を処理する (`tokenizer.cc:654–663`)。2^53 を超える整数を常に整数精度で保持する独自復元は、ソース上の Perfetto 数値処理と同じではない。raw の符号付き整数原値と、Perfetto 同等に変換した値を区別して記録するのがよい。

## 3. thread_time と slice の対応

CounterDescriptor の説明では、thread-scoped counter の `parent_uuid` を thread track に向ける (`counter_descriptor.proto:42–46`, `track_descriptor.proto:51–73`)。tracker は親階層をたどり thread / process の関連を引き継ぐ (`track_event_tracker.cc:301–386`)。数値 TID だけの一致ではなく、counter UUID、親 thread UUID、pid/tid を残す必要がある。descriptor の重複は trace 全体で解決され、再出現だけで加算値を reset する規則ではない。

slice への代入は **解決後の counter 名** が `thread_time` かどうかで分岐する (`track_event_event_importer.h:789–810`)。enum をその場で直接比較しているわけではない。値は `double` から `int64_t` に変換して `thread_timestamp_` に入る。整数 extras を先、double extras を後に処理するので、複数の同名 extra がある場合は後の代入が勝つ。専用旧 thread timestamp も先に設定されており、extra の代入が後になる (`同:178,201–208`)。

その後は begin の `thread_ts` を保存し、end との差を `thread_dur` とする。instant / mark も `thread_ts` を保存する (`同:814–865,1022–1052`)。JSON exporter はこの保存値を整数 `/1000` で μs の `tts` / `tdur` にする (`export_json.cc:851–914`)。extra 復元にも補間・経過時間による上限補正はない。

この名前判定だけから「必ず当該イベントの実行 thread の CPU 時計」と断定してはいけない。raw 検証では builtin type、解決後の名前、counter 親 thread、event 側 thread、sequence を併記し、矛盾を検出する。

## 4. 加算と reset の境界

詳細な独立確認は [counter-reset-review/FINDINGS.md](official-sources/counter-reset-review/FINDINGS.md)。主要規則は次のとおり。

- 有効な加算キーは `(trusted_packet_sequence_id, counter_track_uuid, reset 区間)`。初値は 0.0 (`track_event_sequence_state.h:90–95`)。単独 TYPE_COUNTER と extra は同じ変換関数・現在値を使う。marker だけを抽出してから加算すると、間の delta を落とす。
- `trace_packet_defaults` の更新だけでは現在値を消さない (`同:31–44`, `packet_sequence_state_generation.cc:105–113`)。
- `sequence_flags #13` の clear bit 1、または旧 bool `incremental_state_cleared #41` があれば、加算・interned data・defaults を fresh にし、state を有効化する。最初の加算値は実質絶対値になる。
- `previous_packet_dropped #42` は任意の非 0 値で loss。bitmask のため `== 1` だけを調べてはいけない。loss は counter の custom state を破棄し無効化する。defaults / interned data は物理的には一時保持される。
- **同じ packet に clear と loss があれば clear が優先**。`proto_trace_reader.cc:340–347` は `if clear ... else if loss ...`。その後に同じ packet の defaults / interned data を処理する。
- 初期 state は無効。`SEQ_NEEDS_INCREMENTAL_STATE` bit 2 がある payload は、無効な間 skip される (`reader:397–425`)。無効な間の全 packet を無条件に捨てる実装ではない。`first_packet_on_sequence` 自体は state を有効にしない (`reader:610–615`)。

加算は入力 packet 順に行い、timestamp で並べ替える前に復元する。TrackEvent tokenizer もその時点で絶対 counter 値へ変換してから event stream へ送る (`tokenizer.cc:592–610`)。descriptor と defaults、interned 名はそれぞれの寿命を混同しない。

## 5. 限定デコーダーで落としやすい点

- `int64` は通常の varint を符号付き 64 bit として読む。**ZigZag ではない**。負値は 64 bit の二の補数として復元する。`field.h:103–112` も `as_int64()` と `as_sint64()` を別にしている。UUID は uint64 なので、浮動小数へ変換して識別子にしない。
- `double` は wire type 1 の fixed64、IEEE 754 のビット列 (`field.h:123–127`)。整数配列と同じ varint 処理を使わない。
- proto2 のこれらの repeated 宣言には `[packed=true]` がない。固定版 generator は non-packed を `GetRepeated`、packed 指定を `GetPackedRepeated` に分ける (`protozero_plugin.cc:874–890`)。`proto_decoder.h:439–442` も、通常アクセサーで packed / non-packed を自動互換にしないと明記している。別途 unified accessor はある (`同:457–480`) が、extra-counter importer は通常 `RepeatedFieldIterator` を使う。**固定版 importer が packed extra を自動受理すると仮定しない**。独自 decoder が wire type 2 の packed 数値を支援するなら、明示的に分類・展開し、その対応が固定版 importer と同じとは主張しない。限定実装なら unsupported wire form として明記して止める。
- repeated の出現順を保存し、同じ field number が複数回出た値を上書きで落とさない。整数と double の UUID 配列は混ぜない。値が 0 だから「未設定」と扱わない。
- descriptor 不明・値数と UUID 数の不整合・loss 後の状態不明・未対応 wire form は、推定値を埋めず欠測／未対応として診断する。無効な delta を絶対値と解釈しない。

## 原文保存と範囲

[counter-review/MANIFEST.json](official-sources/counter-review/MANIFEST.json) は原文 21 件の immutable URL、bytes、SHA-256、行数、ライセンス、取得方法を記録する。stage15 から必要な原文を byte-for-byte コピーし、その manifest の SHA-256 と照合したものを含む。原文の copyright / Apache-2.0 notice を残し、同 revision の `LICENSE` も保存した。reset 補助調査の原文は別 [manifest](official-sources/counter-reset-review/MANIFEST.json) にある。

本確認はスキーマと固定版 importer の規則の調査であり、実 trace の完全性、対象 marker の counter 有無、クロックのサンプリング時点、3 区間の超過原因、過去性能差の原因を確定しない。
