# 段階17 再開前の独立レビュー

記録: 2026-10-15T15:10:14.148337+00:00

**致命的blockerなし。** 既存preflight再検証と不足していたrun1 config/clock/health確認が成功した後、元予算の残り4 fresh browser（8visits、48formal+16warm）へ進める。reviewerはbrowser/Worker/DP/performanceを起動していない。

- 初回gateのraw multiplier比較誤りとfailureを明示している。固定 `track.cc` は倍率1のfield4を省略し、固定official importerはraw値>0時だけ乗算する。raw0はidentity、effective1であり、値復号を変更する修正ではない。
- `resume_capture.py`を原collectorとの差分でレビュー。raw/effective倍率の別記録、既存raw/proto/JSONのSHA再確認、初回collector/plan SHAとfailed reportの保持、未実施healthのみ補完、range(1,5)の残り4browser開始が変更点。元の順序・config・branch fixture・機能assert・停止条件・48formal16warmを維持する。新preflight取得とタイミング符号に基づく再試行はない。
- 既存preflight2本のproto/JSON SHAを初回reportと独立照合した。raw ledger input SHAも一致し、target CPUサンプルのincrementalとeffective倍率1000/1をread-only再確認した。初回report内のcollector/plan hashは現保存版と一致する。
- 再検証失敗は別reportへfailure/hashを保存する。元failed report/raw/JSON/ledgerを上書きしない。既存unit1000 confighealthのhashを再確認し、unit1の不足分だけ元protoから検査する。既存数値の再解釈であり追加の実測ではない。
- 解析改訂もraw値を残してeffective値を別保存する。floor boundはeffective1で0となり、CPU数値、strict/>1ms閾値、clear/missing/multisetの処理は変わらない。変更前解析snapshotと改訂文書を保持する。
- 初回停止を成功captureだけの記述で隠さず、最終結果に明記する。raw/SQL/JSONの照合は独立真値の証明ではない。

## レビューsnapshot

| file | bytes | SHA-256 |
|---|---:|---|
| `PLAN.md` | 5186 | `f9783315ab5ae0036ea6e2056e0816846481c987010c73f83e87612f1d6d141f` |
| `capture_units.py` | 12943 | `ec5ed35d0fed7aefe38d13b8ec6414485b3b6e41201164038e09983bd909dabb` |
| `PLAN_AMENDMENT.md` | 2133 | `89a8467ba7a4e3ffb0235b41a69b73be788ef5fdb646c9667b4e6503bcc78975` |
| `resume_capture.py` | 14490 | `6b1cde8523a7bb4ef67311e8df34c39a8c3642bc13368cb9afd1dd2f5feeff7f` |
| `ANALYSIS_PLAN.md` | 4464 | `be365795af63c585dbdf959e8066491d1237d89d058975404dd53a0f7b70093b` |
| `ANALYSIS_AMENDMENT.md` | 2441 | `109cc529ad0e746e223ba49d458521be91326fa3da65e2dd50ea9e3c508c7150` |
| `analyze_counter_units.py` | 23152 | `1af891dc4f807f6e8ce77dde7919282e670982bcc95b93b0a1b691348cc762a6` |
| `run_formal_ledgers.py` | 3031 | `dface1c8c8a25a2474c1d56c0e66d4792b50fab4dd10634a1df5f4d6ce1b7389` |
| `ZERO_UNIT_REVIEW.md` | 2950 | `b6fbb6a106a63642eddcec46ce4d4c0dbab0ede6b0e25bc2a890be35e6ca1f05` |
| `preflight-failed-report.json` | 51546 | `c8ec3472d0082b0b47c99a3936074dbc9f2543fddadb509ec46529dc0a97fecd` |
| `run0.pftrace` | 224180 | `f2329c58f9156dff56e777c7925fb939922070334a8f7ca627644b7e9da3efda` |
| `run1.pftrace` | 274149 | `4a2ba769bf08ed00c40f391c41e38dac69435de2cffb91445112a59d504f189a` |
| `raw-counter-run0.json` | 1730469 | `c16b9e29616c382482e19877e233362e46aef791018fc8c1d52d36a3a4e2b482` |
| `raw-counter-run1.json` | 4026543 | `ee7b372e80210c1e5e3b8b5673908766c1d3272191132716c0abc41aa11c1d5a` |
