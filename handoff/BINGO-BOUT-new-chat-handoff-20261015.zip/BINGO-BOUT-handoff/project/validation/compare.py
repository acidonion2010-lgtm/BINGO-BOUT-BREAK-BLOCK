#!/usr/bin/env python3
"""Compare captured mathematical tables separately from seeded choices."""
import argparse
from array import array
import json
import math
from pathlib import Path
import statistics

def recursive_numeric(left,right,path='root',eps=1e-9):
    differences=[]
    largest=0.0
    def visit(a,b,where):
        nonlocal largest
        if isinstance(a,dict) and isinstance(b,dict):
            if a.keys()!=b.keys(): differences.append({'path':where,'reason':'keys differ'}); return
            for key in a: visit(a[key],b[key],where+'.'+key)
        elif isinstance(a,list) and isinstance(b,list):
            if len(a)!=len(b): differences.append({'path':where,'reason':'length differs'}); return
            for i,(x,y) in enumerate(zip(a,b)): visit(x,y,f'{where}[{i}]')
        elif isinstance(a,(float,int)) and not isinstance(a,bool) and isinstance(b,(float,int)) and not isinstance(b,bool):
            if not math.isfinite(a) or not math.isfinite(b):
                differences.append({'path':where,'reason':'non-finite numeric value'}); return
            delta=abs(a-b); largest=max(largest,delta)
            tolerance=1e-8 if 'Strategy' in where or 'selectionWeights' in where else eps
            if delta>tolerance: differences.append({'path':where,'before':a,'after':b,'delta':delta,'tolerance':tolerance})
        elif a!=b: differences.append({'path':where,'before':a,'after':b})
    visit(left,right,path)
    return {'equalWithinTolerance':not differences,'maxAbsoluteDifference':largest,'differenceCount':len(differences),'firstDifferences':differences[:20]}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('before',type=Path);parser.add_argument('after',type=Path)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    before=json.loads((args.before/'snapshot.json').read_text())
    after=json.loads((args.after/'snapshot.json').read_text())
    result={'before':str(args.before),'after':str(args.after),'tables':[]}
    for first in [1,2]:
        name=f'whole-first{first}.bin'
        b=array('d');b.frombytes((args.before/name).read_bytes())
        a=array('d');a.frombytes((args.after/name).read_bytes())
        if len(b)!=len(a):
            result['tables'].append({'firstPlayer':first,'equalWithinTolerance':False,'beforeCount':len(b),'afterCount':len(a)})
            continue
        max_delta=0.;nonexact=0;outside=0
        for x,y in zip(b,a):
            if not math.isfinite(x) or not math.isfinite(y):
                nonexact+=1;outside+=1;max_delta=math.inf;continue
            if x!=y: nonexact+=1
            delta=abs(x-y)
            max_delta=max(max_delta,delta)
            if delta>1e-9:outside+=1
        result['tables'].append({'firstPlayer':first,'valuesCompared':len(b),'nonexactValues':nonexact,
            'maxAbsoluteDifference':max_delta,'valuesOutside1e9':outside,'equalWithinTolerance':outside==0})
    for key in ['fallbackTables','policies','equilibriumCases','ruleEdges','endings','layerShapes']:
        result[key]=recursive_numeric(before[key],after[key],key)
    result['selections']={'caseCount':len(before['selections']), 'equalExactly':before['selections']==after['selections']}
    if not result['selections']['equalExactly']:
        result['selections']['differences']=recursive_numeric(before['selections'],after['selections'],eps=0)
    b_measure=json.loads((args.before/'measurements.json').read_text())
    a_measure=json.loads((args.after/'measurements.json').read_text())
    result['selfTests']={'before':b_measure['selfTests'],'after':a_measure['selfTests'],
        'beforeExplicit':b_measure['selfTestTiming'],'afterExplicit':a_measure['selfTestTiming']}
    result['timings']={}
    for label,key in [('startup','startupMedianMs'),('preparation','preparationMedianMs')]:
        bv,av=b_measure[key],a_measure[key]
        result['timings'][label]={'beforeMedianMs':bv,'afterMedianMs':av,'changePercent':(av/bv-1)*100,
            'beforeSamples':len(b_measure['startupMs']),'afterSamples':len(a_measure['startupMs'])}
    hands=[]
    for b,a in zip(before['handTimings'],after['handTimings']):
        bv=statistics.median(b['msPerDecision']);av=statistics.median(a['msPerDecision'])
        hands.append({'firstPlayer':b['firstPlayer'],'role':b['role'],'difficulty':b['difficulty'],
            'beforeMedianMs':bv,'afterMedianMs':av,'changePercent':(av/bv-1)*100})
    result['timings']['hand']=hands
    result['pageErrors']={'before':b_measure['pageErrors'],'after':a_measure['pageErrors']}
    summaries=b_measure['selfTests']+a_measure['selfTests']+[b_measure['selfTestTiming']['summary'],a_measure['selfTestTiming']['summary']]
    result['passed']=all(row['equalWithinTolerance'] for row in result['tables']) and all(result[key]['equalWithinTolerance'] for key in ['fallbackTables','policies','equilibriumCases','ruleEdges','endings','layerShapes']) and result['selections']['equalExactly'] and all(summary['passed']==summary['total'] for summary in summaries) and not b_measure['pageErrors'] and not a_measure['pageErrors']
    text=json.dumps(result,ensure_ascii=False,indent=2)
    if args.output:args.output.write_text(text)
    print(text)
    return 0 if result['passed'] else 1

if __name__=='__main__':
    raise SystemExit(main())
