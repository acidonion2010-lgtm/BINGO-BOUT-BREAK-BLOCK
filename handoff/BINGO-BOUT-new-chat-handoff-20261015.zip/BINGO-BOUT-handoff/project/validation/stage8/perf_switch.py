"""Nonprivileged, per-thread Linux perf context-switch diagnostics.

Only an explicitly selected thread is observed.  No sampling, kernel settings,
CPU-wide event, privilege change, or process suspension is used.  ABI constants
and record layouts come from /usr/include/linux/perf_event.h on this environment.
The ring is read only after the event is disabled; concurrent-ring memory
ordering is intentionally outside this small collector's supported interface.
"""

import argparse
import ctypes
import errno
import fcntl
import json
import mmap
import os
from pathlib import Path
import platform
import struct
import sys
import time


class PerfEventAttr(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_uint32), ("size", ctypes.c_uint32),
        ("config", ctypes.c_uint64), ("sample_period", ctypes.c_uint64),
        ("sample_type", ctypes.c_uint64), ("read_format", ctypes.c_uint64),
        ("flags", ctypes.c_uint64), ("wakeup_events", ctypes.c_uint32),
        ("bp_type", ctypes.c_uint32), ("bp_addr", ctypes.c_uint64),
        ("bp_len", ctypes.c_uint64), ("branch_sample_type", ctypes.c_uint64),
        ("sample_regs_user", ctypes.c_uint64),
        ("sample_stack_user", ctypes.c_uint32), ("clockid", ctypes.c_int32),
        ("sample_regs_intr", ctypes.c_uint64),
        ("aux_watermark", ctypes.c_uint32),
        ("sample_max_stack", ctypes.c_uint16), ("reserved_2", ctypes.c_uint16),
        ("aux_sample_size", ctypes.c_uint32), ("reserved_3", ctypes.c_uint32),
        ("sig_data", ctypes.c_uint64),
    ]


PERF_EVENT_IOC_ENABLE = 0x2400
PERF_EVENT_IOC_DISABLE = 0x2401
PERF_RECORD_SWITCH = 14
PERF_RECORD_SWITCH_CPU_WIDE = 15
PERF_RECORD_MISC_SWITCH_OUT = 1 << 13
PERF_RECORD_MISC_SWITCH_OUT_PREEMPT = 1 << 14
SAMPLE_TYPE = (1 << 1) | (1 << 2) | (1 << 7)  # TID | TIME | CPU
ATTR_FLAGS = (1 | (1 << 5) | (1 << 6) | (1 << 18) |
              (1 << 25) | (1 << 26))  # disabled, exclusions, sample_id, clock, switches


class PerfSwitchCollector:
    """start() -> bool; finish()/close() -> JSON-serializable final report.

    start opens a disabled DUMMY event, maps a 64KiB ring, and enables it.
    finish disables it, drains once, and closes all resources.  Errors are
    preserved in the report instead of requiring callers to catch an exception.
    finish is idempotent.  There is no live read interface or automatic retry.
    """

    def __init__(self, tid, ring_bytes=65536):
        self.tid = int(tid)
        self.ring_bytes = int(ring_bytes)
        self.fd = None
        self.mapping = None
        self.finished = False
        self.enabled = False
        self.report = {
            "schemaVersion": 1, "collector": "per-thread-perf-DUMMY-switch",
            "targetTid": self.tid, "observerPid": os.getpid(),
            "observerTid": __import__("threading").get_native_id(),
            "kernelRelease": platform.release(), "architecture": platform.machine(),
            "clock": {"id": 1, "name": "CLOCK_MONOTONIC", "unit": "ns",
                      "explicitUseClockid": True,
                      "hostImplementation": time.get_clock_info("monotonic").implementation,
                      "traceClockEquivalenceVerified": False},
            "attr": {"type": 1, "config": 9, "size": ctypes.sizeof(PerfEventAttr),
                     "sizeVersion": "PERF_ATTR_SIZE_VER7 (128; config3 extension unused)",
                     "flags": ATTR_FLAGS, "sampleType": SAMPLE_TYPE,
                     "samplePeriod": 0, "sampleIdAll": True,
                     "contextSwitch": True, "excludeKernel": True,
                     "excludeHypervisor": True, "inherit": False,
                     "cpuArgument": -1, "groupFdArgument": -1,
                     "syscallFlags": 8, "sampling": False},
            "ringBytesRequested": self.ring_bytes, "available": False,
            "started": False, "disabledSuccessfully": False,
            "records": [], "switchRecordCount": 0,
            "lostRecords": 0, "lostSamples": 0,
            "throttleRecords": 0, "unthrottleRecords": 0,
            "overflow": False, "truncation": False,
            "nearCapacityTrailingLossRisk": False,
            "errors": [], "failure": None, "integrityChecksPassed": False,
            "recordEmissionVerified": False, "captureSucceeded": False,
            "resourceClosure": {"fdClosed": False, "mapClosed": False},
            "settingsChanged": False,
            "limits": ["No wakeup events: switch-out/in alone does not separate all blocked and runnable delay.",
                       "A switch-out PREEMPT flag identifies preemption in TASK_RUNNING; absence is not proof of a particular sleep cause.",
                       "Capture begins/ends at ioctl brackets, which differ from application markers.",
                       "CLOCK_MONOTONIC timestamps require explicit correspondence checks before comparison with Chromium trace timestamps."],
        }

    def _error(self, stage, error, **extra):
        value = {"stage": stage, "kind": type(error).__name__, "message": str(error), **extra}
        error_number = getattr(error, "errno", None)
        if error_number is not None:
            value.update(errno=error_number, errnoName=errno.errorcode.get(error_number))
        self.report["errors"].append(value)

    def _metadata(self):
        mm = self.mapping
        return {
            "version": struct.unpack_from("<I", mm, 0)[0],
            "compatVersion": struct.unpack_from("<I", mm, 4)[0],
            "lock": struct.unpack_from("<I", mm, 8)[0],
            "index": struct.unpack_from("<I", mm, 12)[0],
            "timeEnabledNs": struct.unpack_from("<Q", mm, 24)[0],
            "timeRunningNs": struct.unpack_from("<Q", mm, 32)[0],
            "capabilities": struct.unpack_from("<Q", mm, 40)[0],
            "dataHead": struct.unpack_from("<Q", mm, 1024)[0],
            "dataTail": struct.unpack_from("<Q", mm, 1032)[0],
            "dataOffset": struct.unpack_from("<Q", mm, 1040)[0],
            "dataSize": struct.unpack_from("<Q", mm, 1048)[0],
        }

    def start(self):
        if self.finished or self.report["started"] or self.fd is not None:
            self._error("start", RuntimeError("Collector cannot be started twice"))
            return False
        stage = "validate"
        self.report["startHostMonotonicNs"] = time.monotonic_ns()
        try:
            if platform.system() != "Linux" or platform.machine() != "x86_64" or sys.byteorder != "little":
                raise RuntimeError("This collector validates only Linux x86_64 little-endian syscall/ABI")
            if ctypes.sizeof(PerfEventAttr) != 128:
                raise RuntimeError("Unexpected perf_event_attr ABI size")
            page_size = mmap.PAGESIZE
            if self.tid <= 0 or self.ring_bytes < page_size or self.ring_bytes & (self.ring_bytes - 1) or self.ring_bytes % page_size:
                raise ValueError("A positive target TID and power-of-two, page-multiple ring are required")
            self.report["pageSize"] = page_size
            attr = PerfEventAttr()
            attr.type, attr.size, attr.config = 1, ctypes.sizeof(attr), 9
            attr.sample_type, attr.flags, attr.clockid = SAMPLE_TYPE, ATTR_FLAGS, 1
            self.report["attr"]["bytesHex"] = bytes(attr).hex()
            libc = ctypes.CDLL(None, use_errno=True)
            libc.syscall.restype = ctypes.c_long
            ctypes.set_errno(0)
            stage = "perf_event_open"
            fd = libc.syscall(ctypes.c_long(298), ctypes.byref(attr),
                              ctypes.c_int(self.tid), ctypes.c_int(-1),
                              ctypes.c_int(-1), ctypes.c_ulong(8))
            if fd < 0:
                error_number = ctypes.get_errno()
                raise OSError(error_number, os.strerror(error_number))
            self.fd = int(fd)
            self.report["opened"] = True
            stage = "mmap"
            self.mapping = mmap.mmap(self.fd, page_size + self.ring_bytes,
                                     flags=mmap.MAP_SHARED,
                                     prot=mmap.PROT_READ | mmap.PROT_WRITE)
            initial = self._metadata()
            self.report["mmapInitial"] = initial
            if initial["dataOffset"] < page_size or initial["dataSize"] != self.ring_bytes or initial["dataOffset"] + initial["dataSize"] > len(self.mapping):
                raise RuntimeError("Unexpected mmap perf ring offsets/size")
            if initial["dataHead"] != initial["dataTail"]:
                raise RuntimeError("Fresh disabled ring unexpectedly contains unread records")
            self.report["available"] = True
            stage = "ioctl_enable"
            self.report["enableIoctlStartHostNs"] = time.monotonic_ns()
            fcntl.ioctl(self.fd, PERF_EVENT_IOC_ENABLE, 0)
            self.enabled = True
            self.report["enableIoctlEndHostNs"] = time.monotonic_ns()
            self.report["started"] = True
            return True
        except Exception as error:
            self._error(stage, error)
            self._close_resources()
            return False
        finally:
            self.report["startReturnHostMonotonicNs"] = time.monotonic_ns()

    def _ring_bytes(self, absolute_position, length, metadata):
        offset, size = metadata["dataOffset"], metadata["dataSize"]
        position = absolute_position % size
        first = min(length, size - position)
        return (self.mapping[offset + position:offset + position + first] +
                self.mapping[offset:offset + length - first])

    def _drain_disabled(self):
        if self.enabled:
            raise RuntimeError("Ring parsing requires a successfully disabled event")
        metadata = self._metadata()
        self.report["mmapFinalBeforeRead"] = metadata
        head, tail = metadata["dataHead"], metadata["dataTail"]
        if head < tail:
            raise RuntimeError("Perf ring head is behind tail")
        if head - tail > metadata["dataSize"]:
            self.report["overflow"] = True
            self._error("ring_overflow", RuntimeError("Unread bytes exceed ring capacity"), unreadBytes=head-tail)
            return
        # The supported switch/loss/throttle layouts have at most 56 bytes
        # including the sample-ID tail. Keep room for two such records: a
        # forward ring can defer a LOST record until a later successful write.
        # A near-full final ring therefore fails this conservative integrity
        # guard even if no LOST record has yet been exported.
        reserve = 2 * 56
        self.report["ringHeadroomBytes"] = metadata["dataSize"] - (head - tail)
        self.report["trailingLossReserveBytes"] = reserve
        if self.report["ringHeadroomBytes"] < reserve:
            self.report["nearCapacityTrailingLossRisk"] = True
            self._error("ring_headroom", RuntimeError("Near-full forward ring cannot exclude deferred trailing loss"))
        cursor = tail
        while cursor < head:
            remaining = head - cursor
            if remaining < 8:
                self.report["truncation"] = True
                self._error("record_header", RuntimeError("Incomplete record header"), remainingBytes=remaining)
                break
            header = self._ring_bytes(cursor, 8, metadata)
            kind, misc, size = struct.unpack("<IHH", header)
            if size < 8 or size > remaining or size > metadata["dataSize"]:
                self.report["truncation"] = True
                self._error("record_size", RuntimeError("Invalid or incomplete record length"), recordType=kind, size=size, remainingBytes=remaining)
                break
            raw = self._ring_bytes(cursor, size, metadata)
            record = {"type": kind, "misc": misc, "size": size,
                      "absoluteRingPosition": cursor, "rawHex": raw.hex()}
            if size < 32:
                self._error("sample_id_tail", RuntimeError("Missing TID/TIME/CPU tail"), recordType=kind, size=size)
            else:
                pid, tid, stamp, cpu, reserved = struct.unpack_from("<IIQII", raw, size - 24)
                record.update(pid=pid, tid=tid, timeNs=stamp, cpu=cpu, cpuReserved=reserved)
                if tid != self.tid or reserved != 0:
                    self._error("sample_id_identity", RuntimeError("Unexpected target TID or CPU reserved field"), sampleTid=tid, targetTid=self.tid, cpuReserved=reserved)
            payload_end = size - 24
            if kind in (PERF_RECORD_SWITCH, PERF_RECORD_SWITCH_CPU_WIDE):
                expected = 32 if kind == PERF_RECORD_SWITCH else 40
                if size != expected:
                    self._error("switch_record_size", RuntimeError("Unexpected switch record layout"), recordType=kind, size=size, expectedSize=expected)
                record["switchOut"] = bool(misc & PERF_RECORD_MISC_SWITCH_OUT)
                record["preemptedTaskRunning"] = bool(misc & PERF_RECORD_MISC_SWITCH_OUT_PREEMPT)
                if record["preemptedTaskRunning"] and not record["switchOut"]:
                    self._error("switch_misc", RuntimeError("PREEMPT flag on switch-in record"))
                if kind == PERF_RECORD_SWITCH_CPU_WIDE and payload_end >= 16:
                    record["nextPrevPid"], record["nextPrevTid"] = struct.unpack_from("<II", raw, 8)
                    self._error("unexpected_cpu_wide", RuntimeError("Per-thread capture returned a CPU-wide record"))
            elif kind == 2 and payload_end >= 24:
                record["eventId"], record["lost"] = struct.unpack_from("<QQ", raw, 8)
                self.report["lostRecords"] += record["lost"]
            elif kind == 13 and payload_end >= 16:
                record["lost"] = struct.unpack_from("<Q", raw, 8)[0]
                self.report["lostSamples"] += record["lost"]
            elif kind in (5, 6):
                if payload_end >= 32:
                    record["eventTimeNs"], record["eventId"], record["streamId"] = struct.unpack_from("<QQQ", raw, 8)
                self.report["throttleRecords" if kind == 5 else "unthrottleRecords"] += 1
            else:
                self._error("unexpected_record", RuntimeError("Unexpected record in switch-only capture"), recordType=kind)
            self.report["records"].append(record)
            cursor += size
        self.report["bytesConsumed"] = cursor - tail
        self.report["unreadBytesAfterParsing"] = head - cursor
        # Producer is disabled, so no live memory-barrier protocol is needed.
        struct.pack_into("<Q", self.mapping, 1032, cursor)
        self.report["mmapFinalAfterRead"] = self._metadata()
        if self.report["mmapFinalAfterRead"]["dataHead"] != head:
            self._error("disabled_producer", RuntimeError("Ring head changed after event disable"))

    def _close_resources(self):
        if self.enabled and self.fd is not None:
            try:
                fcntl.ioctl(self.fd, PERF_EVENT_IOC_DISABLE, 0)
                self.enabled = False
                self.report["disabledSuccessfully"] = True
            except Exception as error:
                self._error("ioctl_disable_cleanup", error)
        if self.mapping is not None:
            try:
                self.mapping.close()
                self.report["resourceClosure"]["mapClosed"] = True
            except Exception as error:
                self._error("mmap_close", error)
            finally:
                self.mapping = None
        if self.fd is not None:
            try:
                os.close(self.fd)
                self.report["resourceClosure"]["fdClosed"] = True
            except Exception as error:
                self._error("fd_close", error)
            finally:
                self.fd = None
                self.enabled = False

    def finish(self):
        if self.finished:
            return self.report
        self.report["finishStartHostMonotonicNs"] = time.monotonic_ns()
        try:
            if self.enabled:
                self.report["disableIoctlStartHostNs"] = time.monotonic_ns()
                try:
                    fcntl.ioctl(self.fd, PERF_EVENT_IOC_DISABLE, 0)
                    self.enabled = False
                    self.report["disabledSuccessfully"] = True
                except Exception as error:
                    self._error("ioctl_disable", error)
                self.report["disableIoctlEndHostNs"] = time.monotonic_ns()
            if self.mapping is not None and self.report["disabledSuccessfully"]:
                try:
                    self._drain_disabled()
                except Exception as error:
                    self._error("ring_parse", error)
        finally:
            self._close_resources()
            self.finished = True
            self.report["finishEndHostMonotonicNs"] = time.monotonic_ns()
        switches = [r for r in self.report["records"] if r["type"] == PERF_RECORD_SWITCH]
        self.report["switchRecordCount"] = len(switches)
        self.report["recordEmissionVerified"] = bool(switches)
        timestamps = [r.get("timeNs") for r in switches]
        self.report["switchTimestampsNondecreasing"] = all(a is not None and b is not None and a <= b for a, b in zip(timestamps, timestamps[1:]))
        self.report["switchDirectionsAlternate"] = all(a["switchOut"] != b["switchOut"] for a, b in zip(switches, switches[1:]))
        if switches and (not self.report["switchTimestampsNondecreasing"] or not self.report["switchDirectionsAlternate"]):
            self._error("switch_sequence", RuntimeError("Invalid timestamp ordering or repeated switch direction"))
        if switches:
            lower = self.report.get("enableIoctlStartHostNs", 0)
            upper = self.report.get("disableIoctlEndHostNs", self.report["finishEndHostMonotonicNs"])
            self.report["switchTimesInsideHostCaptureBracket"] = all(isinstance(r.get("timeNs"), int) and lower <= r["timeNs"] <= upper for r in switches)
            if not self.report["switchTimesInsideHostCaptureBracket"]:
                self._error("clock_bracket", RuntimeError("Event time falls outside CLOCK_MONOTONIC ioctl capture bracket"))
        self.report["integrityChecksPassed"] = bool(self.report["started"] and self.report["disabledSuccessfully"] and not self.report["errors"] and not self.report["lostRecords"] and not self.report["lostSamples"] and not self.report["throttleRecords"] and not self.report["unthrottleRecords"] and not self.report["overflow"] and not self.report["truncation"] and not self.report["nearCapacityTrailingLossRisk"])
        self.report["captureSucceeded"] = self.report["integrityChecksPassed"] and self.report["recordEmissionVerified"]
        self.report["failure"] = self.report["errors"][0] if self.report["errors"] else None
        return self.report

    def close(self):
        return self.finish()


def smoke(output):
    import threading
    tid = threading.get_native_id()
    fd_count_before = len(list(Path("/proc/self/fd").iterdir()))
    collector = PerfSwitchCollector(tid)
    waits = []
    if collector.start():
        for _ in range(3):
            started = time.monotonic_ns()
            time.sleep(0.003)
            waits.append({"startedHostNs": started, "endedHostNs": time.monotonic_ns(), "requestedWaitNs": 3000000})
    report = collector.finish()
    fd_count_after = len(list(Path("/proc/self/fd").iterdir()))
    report["smoke"] = {"target": "own-thread", "waits": waits,
                       "fdCountBefore": fd_count_before,
                       "fdCountAfter": fd_count_after,
                       "fdCountRestored": fd_count_after == fd_count_before,
                       "purpose": "record-emission and ABI/clock/closure check; no benchmark",
                       "rendererTargetVerified": False}
    Path(output).write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"output": str(output), "captureSucceeded": report["captureSucceeded"],
                      "switchRecordCount": report["switchRecordCount"],
                      "integrityChecksPassed": report["integrityChecksPassed"],
                      "errors": report["errors"], "resourceClosure": report["resourceClosure"]}, ensure_ascii=False))
    return 0 if report["captureSucceeded"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--smoke", type=Path, required=True)
    arguments = parser.parse_args()
    raise SystemExit(smoke(arguments.smoke))
