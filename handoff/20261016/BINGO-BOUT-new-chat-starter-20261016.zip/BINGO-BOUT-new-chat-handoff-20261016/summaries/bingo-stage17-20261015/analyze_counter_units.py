#!/usr/bin/env python3
"""Stage17 raw-ledger / official SQL / same-proto JSON unit comparison.

No browser is launched, no raw counter decoder is changed, and no tolerance is
applied. Counts of nested trace slices are not independent observations.
"""
from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
CHECKER_SHA = '91762a94d1e1e05305c2a11fbb237dd4b42bffd3ebb5162f48c4cec42b038c23'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(value):
    if value in (None, '[NULL]', ''):
        return None
    decimal = Decimal(str(value))
    integer = int(decimal)
    assert integer == decimal, ('noninteger', value)
    return integer


def csv_rows(path):
    with path.open() as file:
        return list(csv.DictReader(file))


def signs(values):
    values = list(values)
    return {'observations': len(values), 'negative': sum(v < 0 for v in values),
            'zero': sum(v == 0 for v in values), 'strictPositive': sum(v > 0 for v in values),
            'greaterThan1ms': sum(v > 1_000_000 for v in values),
            'minNs': min(values) if values else None, 'maxNs': max(values) if values else None}


def effective_multiplier(raw_multiplier):
    # Pinned tokenizer semantics: apply unit_multiplier only when strictly
    # positive; descriptor omission/default0 therefore means identity scaling.
    return raw_multiplier if raw_multiplier > 0 else 1


def summary_counts(rows):
    total = Counter()
    for row in rows:
        total.update(row)
    return dict(total)


def analyze_visit(visit):
    run = visit['run']
    if not visit.get('completed'):
        return {'run': run, 'unit': visit['unit'], 'preflight': visit['preflight'], 'completed': False}
    ledger_path = ROOT / f'raw-counter-run{run}.json'
    ledger = json.loads(ledger_path.read_bytes())
    assert ledger['script_sha256'] == CHECKER_SHA
    assert ledger['input']['sha256'] == sha(ROOT / f'run{run}.pftrace')
    assert ledger['status'] == 'limited_scope_complete'
    pid, tid = visit['conversion']['rendererPidTid']

    def on_main(association):
        return association.get('status') == 'thread' and (association.get('pid'), association.get('tid')) == (pid, tid)

    rows = [r for r in ledger['ledger'] if on_main(r['event_association_at_end'])]
    descriptors = [d for d in ledger['descriptors'].values() if d['name'] == 'thread_time' and d.get('counter') and on_main(d['association_at_end'])]
    actual_multipliers = sorted({d['counter']['unit_multiplier'] for d in descriptors})
    effective_multipliers = sorted({effective_multiplier(m) for m in actual_multipliers})
    sql_slices_path = ROOT / f'official-sql/run{run}-slices.csv'
    sql_counters_path = ROOT / f'official-sql/run{run}-counters.csv'
    sql_slices = []
    for row in csv_rows(sql_slices_path):
        sql_slices.append({k: (v if k == 'name' else number(v)) for k, v in row.items()})
    complete = [r for r in sql_slices if r['dur'] is not None and r['dur'] >= 0]
    complete_cpu = [r for r in complete if r['thread_ts'] is not None and r['thread_dur'] is not None]
    sql_excess = [r['thread_dur'] - r['dur'] for r in complete_cpu]
    official_counters = [r for r in csv_rows(sql_counters_path) if r['name'] == 'thread_time']
    official_multiset = Counter((str(number(r['uuid']) & ((1 << 64) - 1)), number(r['value'])) for r in official_counters)
    official_times = defaultdict(list)
    for row in official_counters:
        official_times[(str(number(row['uuid']) & ((1 << 64) - 1)), number(row['value']))].append(number(row['ts']))

    raw_multiset = Counter()
    emissions = Counter()
    samples = defaultdict(list)
    cpu_rows = {}
    delta_counts = Counter()
    multipliers_by_samples = Counter()
    effective_multipliers_by_samples = Counter()
    negative_before = defaultdict(bool)
    for row in ledger['ledger']:
        for entry in row['counters']:
            if entry.get('descriptor_name') != 'thread_time' or not on_main(entry['association_at_end']):
                continue
            delta_counts['allMainThreadTimeEntries'] += 1
            if entry.get('status') != 'decoded' or not entry.get('sum_reliable'):
                delta_counts['unacceptedThreadTimeEntries'] += 1
                continue
            absolute = number(entry['absolute_value'])
            raw_multiset[(entry['counter_uuid'], absolute)] += 1
            multiplier = entry['unit_multiplier']
            effective = effective_multiplier(multiplier)
            multipliers_by_samples[str(multiplier)] += 1
            effective_multipliers_by_samples[str(effective)] += 1
            key = (row['sequence_id'], row['sequence_epoch'], entry['counter_uuid'])
            emissions[key] += 1
            negative_before[key] |= entry['raw_value'] < 0
            delta_counts['acceptedThreadTimeEntries'] += 1
            delta_counts['zeroEncodedCpuDeltas'] += entry['raw_value'] == 0
            delta_counts['negativeEncodedCpuDeltas'] += entry['raw_value'] < 0
            delta_counts['positiveEncodedCpuDeltas'] += entry['raw_value'] > 0
            eligible = entry['is_incremental'] and entry['kind'] == 'integer_extra' and not negative_before[key]
            sample = {'packetIndex': row['packet_index'], 'sequenceId': row['sequence_id'],
                      'epoch': row['sequence_epoch'], 'counterUuid': entry['counter_uuid'], 'cpuNs': absolute,
                      'rawValue': entry['raw_value'], 'unitMultiplier': multiplier, 'effectiveUnitMultiplier': effective,
                      'emissionsSinceClear': emissions[key], 'floorModelEligible': eligible,
                      'maxCumulativeFloorLossNs': emissions[key] * (effective - 1) if eligible else None}
            samples[(row['sequence_id'], entry['counter_uuid'])].append(sample)
            if row.get('cpu_counter_uuid') == entry['counter_uuid']:
                cpu_rows[row['packet_index']] = sample

    main_sequences = {r['sequence_id'] for r in rows}
    transitions = [t for t in ledger['transitions'] if t['sequence_id'] in main_sequences]
    transition_indices = defaultdict(list)
    transitions_by_sequence = defaultdict(list)
    for transition in transitions:
        transition_indices[transition['sequence_id']].append(transition['packet_index'])
        transitions_by_sequence[transition['sequence_id']].append(transition)

    stacks = defaultdict(list)
    raw_pairs = defaultdict(list)
    pair_counts = Counter()
    for row in rows:
        if row['cpu_ns'] is None:
            continue
        key = (row['sequence_id'], row['event_track_uuid'])
        if row['type'] == 1:
            stacks[key].append(row)
        elif row['type'] == 2:
            if not stacks[key]:
                pair_counts['unmatchedRawEnds'] += 1
                continue
            begin = stacks[key].pop()
            raw_pairs[(begin['name'], begin['cpu_ns'], row['cpu_ns'])].append((begin, row))
    pair_counts['rawBeginEndPairs'] = sum(len(v) for v in raw_pairs.values())
    pair_counts['unclosedRawBegins'] = sum(len(v) for v in stacks.values())

    all_cpu_match_counts = Counter()
    strict_match_counts = Counter()
    large_match_counts = Counter()
    large_details = []

    def proof(begin, end):
        begin_sample, end_sample = cpu_rows.get(begin['packet_index']), cpu_rows.get(end['packet_index'])
        indices = transition_indices[begin['sequence_id']]
        lo, hi = bisect_right(indices, begin['packet_index']), bisect_right(indices, end['packet_index'])
        inside = transitions_by_sequence[begin['sequence_id']][lo:hi]
        epoch_diff = begin['sequence_epoch'] != end['sequence_epoch']
        return {'beginPacketIndex': begin['packet_index'], 'endPacketIndex': end['packet_index'],
                'beginPacketTraceOffset': begin['packet_trace_offset'], 'endPacketTraceOffset': end['packet_trace_offset'],
                'sequenceId': begin['sequence_id'], 'trackUuid': begin['event_track_uuid'],
                'begin': begin_sample, 'end': end_sample, 'epochsDiffer': epoch_diff,
                'insideTransitions': inside, 'hasClearInside': any(t['action'] == 'clear' for t in inside),
                'hasLossInside': any(t['action'] == 'loss' for t in inside)}

    for sql in complete_cpu:
        candidates = raw_pairs.get((sql['name'], sql['thread_ts'], sql['thread_ts'] + sql['thread_dur']), [])
        excess = sql['thread_dur'] - sql['dur']
        classification = 'uniqueRawCpuPair' if len(candidates) == 1 else ('missingRawCpuPair' if not candidates else 'ambiguousRawCpuPair')
        category = Counter({classification: 1})
        details = []
        if len(candidates) == 1:
            p = proof(*candidates[0])
            category['uniqueAcrossEpoch' if p['epochsDiffer'] else 'uniqueSameEpoch'] += 1
            category['uniqueWithClearInside'] += p['hasClearInside']
            category['uniqueWithLossInside'] += p['hasLossInside']
            if excess > 1_000_000:
                bound = p['begin']['maxCumulativeFloorLossNs'] if p['begin'] else None
                p['positiveFloorArtifactUpperBoundNs'] = bound
                p['excessWithinFloorLossUpperBound'] = excess <= bound if bound is not None else None
                details.append(p)
        elif excess > 1_000_000:
            details.extend(proof(*pair) for pair in candidates)
        all_cpu_match_counts.update(category)
        if excess > 0:
            strict_match_counts.update(category)
        if excess > 1_000_000:
            large_match_counts.update(category)
            large_details.append({'sql': sql, 'excessNs': excess, 'rawPairCandidates': len(candidates), 'rawProofs': details})

    boundaries = []
    for (sequence, uuid), group in samples.items():
        positions = [s['packetIndex'] for s in group]
        for transition in transitions_by_sequence[sequence]:
            if transition['action'] != 'clear':
                continue
            index = bisect_left(positions, transition['packet_index'])
            if index == 0 or index >= len(group):
                continue
            before, after = group[index - 1], group[index]
            btimes = official_times[(uuid, before['cpuNs'])]
            etimes = official_times[(uuid, after['cpuNs'])]
            wall = etimes[0] - btimes[0] if len(btimes) == len(etimes) == 1 else None
            cpu = after['cpuNs'] - before['cpuNs']
            excess = cpu - wall if wall is not None else None
            bound = before['maxCumulativeFloorLossNs']
            boundaries.append({'clearPacketIndex': transition['packet_index'], 'sequenceId': sequence, 'counterUuid': uuid,
                               'before': before, 'after': after, 'officialBeforeWallCandidates': btimes,
                               'officialAfterWallCandidates': etimes, 'cpuStepNs': cpu, 'wallStepNs': wall,
                               'cpuMinusWallStepNs': excess,
                               'positiveStepWithinPriorFloorLossBound': excess <= bound if excess is not None and bound is not None else None})

    events = json.loads((ROOT / f'run{run}.json').read_bytes())['traceEvents']
    main_events = [e for e in events if (e.get('pid'), e.get('tid')) == (pid, tid)]
    complete_events = [e for e in main_events if e.get('ph') == 'X']
    cpu_events = [e for e in complete_events if all(k in e for k in ('dur', 'tts', 'tdur'))]
    json_excess = [(e['tdur'] - e['dur']) * 1000 for e in cpu_events]
    sql_index = defaultdict(list)
    for sql in complete_cpu:
        key = (sql['name'], sql['ts'] // 1000, sql['dur'] // 1000, sql['thread_ts'] // 1000, sql['thread_dur'] // 1000)
        sql_index[key].append(sql['id'])
    json_missing = []
    json_ambiguous = 0
    for event in cpu_events:
        candidates = sql_index.get((event.get('name'), event['ts'], event['dur'], event['tts'], event['tdur']), [])
        if not candidates:
            json_missing.append(event)
        elif len(candidates) > 1:
            json_ambiguous += 1

    markers = visit['conversion'].get('markers', [])
    marker_names = {m['name'] for m in markers}
    raw_markers = defaultdict(list)
    for row in rows:
        name = row.get('data_message') if row['name'] == 'TimeStamp' else row['name']
        if name in marker_names:
            raw_markers[(name, row['name'] == 'TimeStamp')].append(row)
    marker_checks = []
    for marker in markers:
        for kind, is_console in [('mark', False), ('stamp', True)]:
            expected = marker.get(kind)
            raw = raw_markers[(marker['name'], is_console)]
            marker_checks.append({'name': marker['name'], 'kind': kind, 'rawRows': len(raw),
                                  'rawCpuMissing': sum(r['cpu_ns'] is None for r in raw),
                                  'jsonCpuMissing': expected is None or 'tts' not in expected,
                                  'exactCpuAfterUsExport': len(raw) == 1 and raw[0]['cpu_ns'] is not None and expected is not None and raw[0]['cpu_ns'] // 1000 == expected.get('tts')})
    marker_windows = []
    marker_index = {m['name']: m for m in markers}
    for sample in visit['samples']:
        labels = {m['label']: m['name'] for m in sample['markers']}
        for kind in ('mark', 'stamp'):
            start = marker_index.get(labels['capture'], {}).get(kind)
            for label in ('handler-end', 'first-raf', 'second-raf'):
                end = marker_index.get(labels[label], {}).get(kind)
                missing = start is None or end is None or any(k not in e for e in (start, end) for k in ('ts', 'tts'))
                wall = None if missing else (end['ts'] - start['ts']) * 1000
                cpu = None if missing else (end['tts'] - start['tts']) * 1000
                marker_windows.append({'branch': sample['branch'], 'trial': sample['trial'], 'warmup': sample['warmup'],
                                       'kind': kind, 'to': label, 'missing': missing, 'wallNs': wall, 'cpuNs': cpu,
                                       'excessNs': None if missing else cpu - wall,
                                       'resolution': 'Official JSON integer-us endpoints multiplied by 1000; not recovered ns endpoints.'})

    counts = {'sqlAllSlices': len(sql_slices), 'sqlIncompleteSlices': len(sql_slices) - len(complete),
              'sqlCompleteSlices': len(complete), 'sqlCompleteWithCpu': len(complete_cpu),
              'sqlCompleteMissingCpu': len(complete) - len(complete_cpu),
              'sqlZeroWallDuration': sum(r['dur'] == 0 for r in complete),
              'sqlZeroThreadDuration': sum(r['thread_dur'] == 0 for r in complete_cpu),
              'sqlNegativeThreadDuration': sum(r['thread_dur'] < 0 for r in complete_cpu),
              'sqlStrictCpuGreaterThanWall': sum(e > 0 for e in sql_excess),
              'sqlCpuExcessOver1ms': sum(e > 1_000_000 for e in sql_excess),
              'jsonCompleteEvents': len(complete_events), 'jsonCompleteWithCpu': len(cpu_events),
              'jsonCompleteMissingCpu': len(complete_events) - len(cpu_events),
              'jsonStrictCpuGreaterThanWall': sum(e > 0 for e in json_excess),
              'jsonCpuExcessOver1ms': sum(e > 1_000_000 for e in json_excess),
              'jsonCompleteMissingSql': len(json_missing), 'jsonAmbiguousSqlTuple': json_ambiguous,
              'retainedMainLedgerRows': len(rows), 'retainedMainRowsWithoutCpu': sum(r['cpu_ns'] is None for r in rows),
              'mainSequenceClears': sum(t['action'] == 'clear' for t in transitions),
              'mainSequenceLossTransitions': sum(t['action'] == 'loss' for t in transitions),
              'mainSubsequentClearBoundaries': len(boundaries),
              'largeSlicesWithUniqueSameEpochPair': large_match_counts['uniqueSameEpoch'],
              'largeSlicesWithUniqueAcrossEpochPair': large_match_counts['uniqueAcrossEpoch'],
              'largeSlicesWithUniqueClearInside': large_match_counts['uniqueWithClearInside'],
              'largeSlicesMissingOrAmbiguousRawPair': large_match_counts['missingRawCpuPair'] + large_match_counts['ambiguousRawCpuPair'],
              **delta_counts}
    return {'run': run, 'browserRun': visit.get('browserRun'), 'unit': visit['unit'], 'preflight': visit['preflight'],
            'completed': True, 'pid': pid, 'tid': tid, 'protoSha256': ledger['input']['sha256'],
            'ledgerSha256': sha(ledger_path), 'jsonSha256': sha(ROOT / f'run{run}.json'),
            'sqlSlicesSha256': sha(sql_slices_path), 'sqlCountersSha256': sha(sql_counters_path),
            'actualMainMultipliers': actual_multipliers, 'actualMainEffectiveMultipliers': effective_multipliers,
            'requestedMultiplierExact': effective_multipliers == [visit['unit']],
            'mainThreadTimeDescriptors': descriptors, 'sampleCountsByActualMultiplier': dict(multipliers_by_samples),
            'sampleCountsByEffectiveMultiplier': dict(effective_multipliers_by_samples),
            'counts': counts, 'sqlExcessSigns': signs(sql_excess), 'jsonExcessSigns': signs(json_excess),
            'mainTransitions': transitions, 'mainSubsequentClearBoundaries': boundaries,
            'rawCpuPairCoverageAllCompleteSqlCpu': dict(all_cpu_match_counts),
            'rawCpuPairCoverageStrictSql': dict(strict_match_counts), 'rawCpuPairCoverageLargeSql': dict(large_match_counts),
            'rawPairDiagnostics': dict(pair_counts), 'largeSqlSlices': large_details,
            'counterMultisetsEqual': raw_multiset == official_multiset,
            'rawThreadTimeSamples': raw_multiset.total(), 'officialThreadTimeSamples': official_multiset.total(),
            'rawOnlySamples': [[list(k), v] for k, v in (raw_multiset - official_multiset).items()],
            'officialOnlySamples': [[list(k), v] for k, v in (official_multiset - raw_multiset).items()],
            'duplicateAbsoluteRawCpuSamples': sum(n - 1 for n in raw_multiset.values() if n > 1),
            'jsonMissingSqlEvents': json_missing, 'markerChecks': marker_checks, 'markerWindows': marker_windows,
            'rawDiagnostics': ledger['diagnostic_counts'],
            'subsamplingLimit': 'Retained raw ledger drops some events without CPU; raw missing/zero counts are not a census of all TrackEvents. SQL missing and config/source subsampling evidence are separate.'}


def main():
    report_path = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'report.json'
    output = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / 'unit-analysis.json'
    assert len(sys.argv) <= 3, 'usage: analyze_counter_units.py [report.json [output.json]]'
    assert not output.exists(), output
    report = json.loads(report_path.read_bytes())
    out = {'schema': 'stage17.counter-unit-analysis.v1', 'scriptSha256': sha(Path(__file__)),
           'analysisPlanSha256': sha(ROOT / 'ANALYSIS_PLAN.md'), 'reportSha256': sha(report_path),
           'analysisAmendmentSha256': sha(ROOT / 'ANALYSIS_AMENDMENT.md'),
           'frozenCheckerSha256': CHECKER_SHA,
           'scope': 'Strict descriptive signs from retained same-proto raw ledgers, official SQL and official JSON; not independent CPU validation or application performance non-regression.',
           'limits': ['Nested slices are not independent observations.', 'JSON integer-us export may change SQL ns signs.',
                      'Marker windows use JSON integer-us endpoints multiplied by 1000; their names ending in Ns do not recover lost ns resolution.',
                      'Packet-order raw BEGIN/END matching uses retained accepted-CPU events and is not a full slice importer.',
                      'No pre-division CPU values/remainders are recoverable from this trace. Floor bounds are compatibility checks.',
                      'No assumption that visits have equal trace durations or slice/sample counts.'], 'visits': []}
    for visit in report['visits']:
        record = analyze_visit(visit)
        out['visits'].append(record)
        print(json.dumps({k: record.get(k) for k in ('run', 'unit', 'preflight', 'completed', 'actualMainMultipliers', 'actualMainEffectiveMultipliers', 'counterMultisetsEqual', 'counts')}), flush=True)
    out['conditions'] = []
    for preflight in (True, False):
        for unit in (1000, 1):
            group = [r for r in out['visits'] if r['unit'] == unit and r['preflight'] == preflight]
            completed = [r for r in group if r['completed']]
            counts = summary_counts([r['counts'] for r in completed])
            condition = {'unit': unit, 'preflight': preflight, 'visits': len(group), 'completedVisits': len(completed),
                         'runs': [r['run'] for r in group], 'counts': counts,
                         'allRequestedMultipliersExact': bool(completed) and all(r['requestedMultiplierExact'] for r in completed),
                         'allCounterMultisetsEqual': bool(completed) and all(r['counterMultisetsEqual'] for r in completed),
                         'rawPairCoverageLargeSql': summary_counts([r['rawCpuPairCoverageLargeSql'] for r in completed]),
                         'markerRows': sum(len(r['markerChecks']) for r in completed),
                         'markerChecksPassed': sum(m['exactCpuAfterUsExport'] for r in completed for m in r['markerChecks']),
                         'markerWindowGroups': []}
            for basis, numerator, denominator in [('sqlStrictRate', 'sqlStrictCpuGreaterThanWall', 'sqlCompleteWithCpu'),
                                                   ('sqlLargeRate', 'sqlCpuExcessOver1ms', 'sqlCompleteWithCpu'),
                                                   ('jsonStrictRate', 'jsonStrictCpuGreaterThanWall', 'jsonCompleteWithCpu'),
                                                   ('jsonLargeRate', 'jsonCpuExcessOver1ms', 'jsonCompleteWithCpu')]:
                condition[basis] = counts.get(numerator, 0) / counts[denominator] if counts.get(denominator) else None
            for warmup in (False, True):
                for branch in ('dp', 'legacy'):
                    for kind in ('mark', 'stamp'):
                        windows = [w for r in completed for w in r['markerWindows'] if (w['warmup'], w['branch'], w['kind']) == (warmup, branch, kind)]
                        values = [w['excessNs'] for w in windows if not w['missing']]
                        condition['markerWindowGroups'].append({'warmup': warmup, 'branch': branch, 'kind': kind,
                                                               'windows': len(windows), 'missing': len(windows) - len(values),
                                                               'signs': signs(values)})
            out['conditions'].append(condition)
    with output.open('x') as file:
        json.dump(out, file, ensure_ascii=False, indent=2, allow_nan=False)
        file.write('\n')
    print(json.dumps({'conditions': [{k: c[k] for k in ('unit', 'preflight', 'completedVisits', 'counts')} for c in out['conditions']]}, indent=2), flush=True)


if __name__ == '__main__':
    main()
