# 段階17：実トレースで1µs単位と1ns単位を対照

**固定回数の実収集で、CPU時間がwallを1ms超えた記録は1µs条件で32件、1ns条件で0件だった。** 32件は全て差分状態のclearをまたぎ、元CPU端点と公式SQLが一意に一致した。1ns条件でも小さな厳密超過が残り、厳密なCPU会計や過去の超過の単独原因を確認したとはしない。ゲーム本体の変更は0。

## 今回の条件と取得

原版HTMLだけを使い、4つの新規Chromiumそれぞれで、1000nsと1nsを各1訪問ずつ比較した。単位順はAB/BA/AB/BA。各訪問はHARD DP(.8)・ready-engine legacy(.3)を各1warm+3formal trustedクリック、合計48formal+16warm。両訪問の分岐順はbrowser1/2でDP先、3/4でlegacy先。別のpreflight browser2訪問を含め、全10ロードで322/322の自己テスト、合計3,220件が成功し、正式8訪問は実Worker準備完了。

両条件はraw CDP perfettoConfigを使い、要求設定の意味上の差をtimestamp_unit_multiplierだけにした。clear500ms、CPU sampling有効・subsampling0、incremental wall clock、primary clock3、categories、buffer等は同一。全10本で設定echo・時計snapshot/defaultsと実効単位を独立確認した。実行時PIDフィルタ等の未知fieldも保存しており、実際の設定bytes全体が同一という意味ではない。段階16のlegacy categories経路とは別条件なので、今回の1000nsが対照であり段階16の数字を混ぜない。

5ブラウザープロセス・10訪問・64クリックの元予算を完了。raw protobuf82,645,720 bytes、同一proto公式変換JSON175,101,690 bytes、699,582eventsを保存した。全streamでEOF、data loss=false、buffer-fullなし。全公式SQLの非zero error/data_loss診断は0。ゲーム関数の置換、サンプル除外、A/A差し引き、符号による停止、事後許容幅の追加はない。音/BGM/アニメーション有効・headless標準mute-audioで、物理音声/画面提示の測定ではない。

## 正式4訪問ずつの結果

SQLは完了slice（instantを含む）、JSONはX eventを対象とする。分母と単位化が異なるため、strict件数の差を全て丸めだけの差とはしない。入れ子の記録を独立事象として足し合わせない。

| 集計 | 実効1000ns | 実効1ns |
| --- | ---: | ---: |
| CPU付き完了SQL slice | 71,877 | 83,817 |
| SQLのCPU > wall（nsの厳密比較） | 1,347 | 27,879 |
| SQLのCPU超過 > 1ms | **32** | **0** |
| JSONの全main X | 77,677 | 81,065 |
| CPU付きJSON X | 69,054 | 81,065 |
| JSONのCPU fields欠測X | 8,623 | 0 |
| JSONのCPU > wall（µs表現） | 1,335 | 3,140 |
| JSONのCPU超過 > 1ms | **32** | **0** |
| main clear（初回を含む） | 18 | 21 |
| 前後CPUのある後続clear境界 | 14 | 17 |

1000nsの大きな超過はrun2/5/6/9で6/6/11/9件、全32件が異epoch・同sequence clearを内包した。同epochの大きな超過は0。32件のCPU端点はraw/SQLへ一意対応し、非負真CPU差分を仮定した端数損失上限にも適合した。上限の範囲は7.757235–14.748237msだが、実際の損失をこの値と推定したものではない。

1nsの4訪問は全て1ms超過0だった。clearが観測されなかったため0になったわけではない。raw CPU両端が一意対応するclearまたぎsliceも19件あり、全て1ms超過なしだった。除算の端数損失項は実効倍率1で数学的に0になる。一方、SQLの最大の正の差は129,988ns、JSONでは130µsで、小さな超過は残る。1msは過去段階からの記述用binであり、これ未満を正しい値として認定する許容幅ではない。

全10本で、元thread_timeカウンターのUUID/value多重集合が公式SQLと一致した。CPU付きJSON XのSQL候補未一致は0だが、1ns条件の34件はµs tupleが重なり候補複数であり、一対一の対応と主張しない。SQL complete CPU欠測は1000ns13,472件・1ns1,617件、未完sliceは12件・0件で、rawにも残す。frozen補助decoderは完全なTrackEvent censusではなく、ledgerのCPUなし行0からCPU省略がないとは推論しない。

## クリック区間と別経路の記録

正式48クリックの288 marker区間、warm16クリックの96区間をmark/console stamp別に保存した。marker CPU端点はformal訪問分512件すべてraw/JSONに一致。正式の1ns条件に+1µsの厳密超過が2件あり、1000ns条件は0件だった。warmの超過は両条件0。全marker区間で1ms超過0、欠測0。これはJSONのµs端点の差であり、×1000してもns精度は回復しない。

+1µsの2例はrun7 legacy trial3のhandler-end mark（wall3316µs/CPU3317µs）と、run8 DP trial1のhandler-end stamp（3424µs/3425µs）。どちらも除外・補正していない。

全66操作のCDP ThreadTime/TaskDuration・proc schedstat前後差は、各host外側wallを超えなかった。CDPはexportを経ないが下位のCPU時計を共有し、原子的同時snapshotではない。schedstatの読取端点の鮮度も保証されない。広い区間のCPUを狭いhandlerへ帰属せず、wall−CPUを厳密な待ち時間と解釈しない。

## 初回preflight停止と修正の履歴

最初の収集器は、1nsのCounterDescriptorで倍率fieldが省略される形式をraw倍率0として読み、raw1を要求して停止した。**この時点の正式計測は0回。** 固定Perfetto sourceは倍率1のfieldを省略し、importerは正の値だけを乗算するのでraw0の実効値は1である。frozen decoderの数値復元は最初からidentity scalingで正しかった。collectorの採否gateが不適切だった。

初回の`PLAN.md`・`capture_units.py`・`capture-console.log`・`preflight-failed-report.json`、2本のraw/JSON/ledgerを不変で保持。`PLAN_AMENDMENT.md`、`ZERO_UNIT_REVIEW.md`と独立事前レビューに基づき、同じ保存bytesをraw0/effective1で再検証した。未実施だったunit1のconfig/clock/health確認を完了して、`resume_capture.py`が予定済みの残り4ブラウザーだけを収集した。preflightの取り直しも、追加の本計測もない。解析もraw値と実効値を区別し、初期source/旧データreplayを残している。

## 結論の範囲

段階16のsource・構成対照と今回の対照は、µs差分の端数損失とclear時の回復が大きなCPU超過を生む説明を強く支持する。今後のこの診断では明示1ns設定がこの端数項を避ける手段になる。ただし単位変更はwall表現や記録負荷も変えるため、ゲームが速くなった、全てのCPU超過原因を特定した、カーネル時計が正確、とは結論しない。

原版/current HTML、元handoff480ファイル、段階16の269manifest対象、repo mainのclean状態は不変。段階14/15の過去記録も書き換えず、旧104条件は42反復非増加・62未確定のまま。全経路の厳密な非退行とCPU会計の完全妥当性は未確認。

[再検算手順](REPRODUCE.md)、[単位別全解析](unit-analysis.json)、[設定の事後レビュー](CONFIG_POST_REVIEW.md)、[独立事後レビュー](POST_RUN_REVIEW.md)と、失敗を含む全原データ・コード・固定ソース/ライセンスを保存した。
