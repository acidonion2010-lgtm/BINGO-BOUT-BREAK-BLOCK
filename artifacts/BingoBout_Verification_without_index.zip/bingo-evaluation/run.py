#!/usr/bin/env python3
"""Reproduce fixed-size benchmark; every process exit status is checked."""
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def check_results(directory):
    design = json.loads((ROOT / 'design.json').read_text())
    expected = 4 * design['replicates_per_cell'] * len(design['opponents']) * len(design['difficulties'])
    counts = {}
    for pair in range(design['layout_pairs']):
        file = directory / f'pair-{pair}.jsonl'
        rows = [json.loads(line) for line in file.read_text().splitlines()]
        assert len(rows) == expected, (pair, len(rows), expected)
        keys = {(r['swap'], r['firstPlayer'], r['difficulty'], r['opponent'], r['rep']) for r in rows}
        assert len(keys) == expected, f'Duplicate or missing cells: {pair}'
        for r in rows:
            assert r['pair'] == pair
            assert r['difficulty'] in design['difficulties']
            assert r['opponent'] in design['opponents']
            assert r['swap'] in [0, 1] and r['firstPlayer'] in [1, 2]
            assert 0 <= r['rep'] < design['replicates_per_cell']
            assert r['win'] + r['draw'] + r['loss'] == 1
            assert r['margin'] == r['scoreCPU'] - r['scoreOpponent']
            assert r['defBlocks'] <= r['defN'] and r['atkBlocked'] <= r['atkN']
            assert 0 < r['turns'] <= 18
        counts[pair] = len(rows)
    return {'pairs': len(counts), 'games': sum(counts.values()), 'games_per_pair': expected, 'complete': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--jobs', type=int, default=3)
    parser.add_argument('--out', type=Path, default=ROOT / 'rerun_results')
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    os.chdir(ROOT)
    directory = args.out.resolve()
    if args.check_only:
        print(json.dumps(check_results(directory), indent=2))
        return
    assert 1 <= args.jobs <= 8
    directory.mkdir(parents=True, exist_ok=True)
    if list(directory.glob('pair-*.jsonl')):
        raise SystemExit('Output already contains results. Choose a new --out directory.')
    design = json.loads((ROOT / 'design.json').read_text())
    digest = hashlib.sha256((ROOT / 'source.html').read_bytes()).hexdigest()
    assert digest == design['source_sha256']
    metadata = {'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                'source_sha256': digest, 'design_sha256': hashlib.sha256((ROOT / 'design.json').read_bytes()).hexdigest(),
                'node': subprocess.check_output(['node', '--version'], text=True).strip(),
                'python': sys.version, 'platform': platform.platform(), 'jobs': args.jobs}
    started = time.monotonic()
    def one(pair):
        env = os.environ.copy()
        env['BINGO_OUT'] = str(directory)
        # Never inherit overrides of the prespecified primary experiment counts.
        env['BINGO_REPS'] = str(design['replicates_per_cell'])
        env.pop('BINGO_SMOKE', None)
        with (directory / f'run-{pair}.log').open('w') as log:
            subprocess.run(['node', 'simulate.cjs', str(pair), str(pair + 1)],
                           env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        return pair
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        futures = [pool.submit(one, pair) for pair in range(design['layout_pairs'])]
        for future in concurrent.futures.as_completed(futures):
            print(json.dumps({'completed_pair': future.result()}), flush=True)
    metadata.update(check_results(directory))
    metadata['elapsed_seconds'] = time.monotonic() - started
    (directory / 'execution.json').write_text(json.dumps(metadata, indent=2))
    print(json.dumps(metadata, indent=2))


if __name__ == '__main__':
    main()
