# 再現方法

Python 3.12、Python Playwright、Node 24、Chromium 154.0.8037.57を使用。
アプリHTMLの外部依存を増やす変更は行っていない。

元の引き継ぎZIPを `/workspace/handoff/BINGO-BOUT-handoff/` に展開し、
この調査フォルダを `/workspace/bingo-continuation-20261015/` に配置する。
ゲームを開く対象は引き継ぎの `project/index.html`（段階9）。
GitHub mainの旧HTMLとは異なる。

先に `PLAN.md` と報告の限界を読む。ブラウザー・DP・性能ジョブは直列で実行する。
以下は既存結果を上書きしない、新しい再現出力先を作る例。

```bash
cd /workspace/bingo-continuation-20261015
mkdir -p reproduction
python3 startup_diagnosis.py native --output reproduction/native.json
python3 startup_diagnosis.py diagnostic --output reproduction/diagnostic.json
python3 summarize.py reproduction
python3 startup_diagnosis.py original-check --output reproduction/original-check.json
node /workspace/handoff/BINGO-BOUT-handoff/project/validation/stage9/legacy_equivalence.cjs /workspace/handoff/BINGO-BOUT-handoff/project/stages/index.handoff-20261015.html /workspace/handoff/BINGO-BOUT-handoff/project/index.html reproduction/legacy-equivalence.json
```

測定器は既存JSONへの上書きを拒否する。再実行時は別名の出力先を使う。
再実行の絶対時間を今回や前チャットの別マシンの絶対時間から引かない。
native/diagnosticは別の実験。診断版のsource hashや時間を通常HTMLと混ぜない。

`startup_diagnosis.initial-protocol.py` は初期計測の監査用で、再利用しない。
`startup_diagnosis.native-protocol.py` は今回の正式native記録とscript hashが一致する保存版。
その後の現行スクリプトとの差はWorker source種別のメタデータ追加とコメント修正のみ。
現行スクリプトの通常版動作と計時境界は正式native保存版と同じ。

## 区間の意味

- 起動：Pythonの `page.goto(..., wait_until='load')` 前後。自動自己テストを含む。
- 準備：固定配置・P1先攻で `startWholeGameCpu()` 開始から5ms pollによるready検出まで。
- `startupDpSolvesMs`：自己テスト内の同期 `WholeGameDP.solve` 5回の合計。
- `workerCtorMs` / `workerSolveMs`：Worker内だけのclock差。
- `mainPostToReceiveMs`：mainのpost直前からreadyメッセージ受信まで。
- `workerTransportCompileQueueOtherMs`：上記からWorker constructor/solveの**経過時間**を引いた残り。
  Workerの起動・コンパイル・dispatch・転送・スケジューリング等を含み、個別寄与は分からない。
- `handlerMs`：受信handlerによるDP復元・検証・cleanup・finalization。ready代入だけの時間ではない。
- `pollTailMs`：handler終了からpoll/promise完了まで。ready代入からの厳密な時間ではない。
- `rafDuringPreparationMs`：記録したRAF callbackのうち準備期間と重なる部分。
  bootstrap固有のRAFという識別は行っていない。

診断はserved copyへの計装と、準備前の計装用RPCがある。自己テスト・solverのラッパーは
JITや割当履歴を変え得る。settledは4回RAFを待つが、GC/JIT/他タスクの時間も増える。
この診断での重なりの有無を、無計装版や過去の試行へそのまま適用しない。

全開始・終了時刻をJSONに保存。Workerとmainの絶対clockは差し引かない。
timerの小数桁は実時計の精度を意味しない。中央値比と対応する対の差の中央値は別統計。
順序や初回を理由に標本を除去せず、A/A差し引きや後付け許容差は用いない。
