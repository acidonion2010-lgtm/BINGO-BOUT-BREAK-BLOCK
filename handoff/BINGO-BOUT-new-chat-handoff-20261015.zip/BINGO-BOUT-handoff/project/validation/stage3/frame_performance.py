#!/usr/bin/env python3
"""Compare complete game selectors in visible same-origin iframe realms.

Runs are fixed before measurement. All game HTML and automatic self tests load
normally; no game script is patched or extracted. Only benchmark state, random
input, and engine readiness are controlled. Do not run alongside other CPU jobs.
"""
import argparse
import functools
import hashlib
import http.server
import json
import math
from pathlib import Path
import statistics
import threading
from urllib.parse import quote

from playwright.sync_api import sync_playwright


ROOT = Path('/workspace')
RUNS = 2
WARMUP_CALLS = 20_000
BATCH_WARMUP_CALLS = 2_000
CALLS_PER_BATCH = 20_000
PAIRED_BATCHES = 9
LAYOUTS = {'p1': [8, 1, 6, 3, 5, 7, 4, 9, 2],
           'p2': [5, 9, 1, 7, 2, 6, 3, 8, 4]}
SCENARIOS = [
    {'name': 'opening', 'maskP1': 0, 'maskP2': 0, 'baseT': 0},
    {'name': 'middle', 'maskP1': 3, 'maskP2': 24, 'baseT': 8},
    {'name': 'late', 'maskP1': 508, 'maskP2': 502, 'baseT': 14},
    # With one closed cell, the full-game DP is terminal, but the board-only
    # fallback selector still has a legal reachable r=1 decision to validate.
    {'name': 'one-closed', 'maskP1': 510, 'maskP2': 509, 'baseT': 16,
     'fallbackOnly': True},
]
PATHS = [
    {'name': 'normal-legacy', 'difficulty': 'normal', 'engine': 'ready', 'roll': 0.8},
    {'name': 'hard-legacy', 'difficulty': 'hard', 'engine': 'ready', 'roll': 0.3},
    {'name': 'hard-full', 'difficulty': 'hard', 'engine': 'ready', 'roll': 0.8},
    {'name': 'master-ready', 'difficulty': 'master', 'engine': 'ready', 'roll': 0.8},
    {'name': 'master-fallback', 'difficulty': 'master', 'engine': 'fallback', 'roll': 0.8},
]
HOST_HTML = b'''<!doctype html><meta charset="utf-8"><title>Selector comparison</title>
<style>html,body{margin:0;width:2560px;height:900px;overflow:hidden}
body{display:flex}iframe{border:0;display:block;width:1280px;height:900px;flex:0 0 1280px}</style>
<body></body>'''


INSTALL_BENCH = r'''layouts => {
  const nativeRandom = Math.random;
  let fixedRoll = 0.8;
  Math.random = () => fixedRoll;
  const marks = mask => Array.from({length:9}, (_,i) => Boolean(mask & (1 << i)));
  const counters = () => ({whole:cpuWholeDecisions, fallback:cpuWholeLegacyDecisions,
    hardLegacy:hardLegacyDecisions, hardFull:hardDpDecisions});
  const memory = () => ({breakCell:state.cpuBlockedBreakCell,
    breakStreak:state.cpuBlockedBreakStreak, breakCooldown:state.cpuBlockedCooldown,
    blockCell:state.cpuSuccessfulBlockCell, blockStreak:state.cpuSuccessfulBlockStreak,
    blockCooldown:state.cpuSuccessfulBlockCooldown});
  Object.assign(state, {gameMode:'cpu', cpuDifficulty:'master', seatChosen:true,
    isStarting:true, gameEnded:false, isProcessing:false,
    p1NumberLayout:layouts.p1.slice(), p2NumberLayout:layouts.p2.slice()});
  const started = performance.now();
  cpuEqBundle = {p1:buildCpuEqTable(layouts.p1), p2:buildCpuEqTable(layouts.p2)};
  const fallbackBuildMs = performance.now() - started;
  window.__frameCpuBench = {
    dp:null, firstPlayer:null, spec:null, available:null, expectedCell:null,
    async prepare(firstPlayer) {
      this.dp = null;
      Object.assign(state, {gameMode:'cpu', cpuDifficulty:'master', seatChosen:true,
        isStarting:true, gameEnded:false, isProcessing:false, firstPlayer,
        p1Marks:marks(0), p2Marks:marks(0), p1TurnsTaken:0, p2TurnsTaken:0,
        p1NumberLayout:layouts.p1.slice(), p2NumberLayout:layouts.p2.slice()});
      const started = performance.now();
      startWholeGameCpu();
      await new Promise((resolve,reject) => {
        const poll = () => {
          if (cpuWholeStatus === 'ready') return resolve();
          if (cpuWholeStatus === 'fallback') return reject(new Error(cpuWholeFailure));
          setTimeout(poll,5);
        };
        poll();
      });
      this.dp = cpuWholeDp;
      this.firstPlayer = firstPlayer;
      return {elapsedMs:performance.now()-started, stats:{...cpuWholeStats}};
    },
    configure(spec) {
      this.spec = spec;
      fixedRoll = spec.roll;
      const attacker = spec.role === 'break' ? 2 : 1;
      const t = this.dp.attacker[spec.baseT] === attacker ? spec.baseT : spec.baseT + 1;
      Object.assign(state, {gameMode:'cpu', cpuDifficulty:spec.difficulty,
        seatChosen:true, isStarting:true, gameEnded:false, isProcessing:false,
        phase:spec.role === 'break' ? 'break' : 'block', firstPlayer:this.firstPlayer,
        p1Marks:marks(spec.maskP1), p2Marks:marks(spec.maskP2),
        p1NumberLayout:layouts.p1.slice(), p2NumberLayout:layouts.p2.slice(),
        p1TurnsTaken:this.firstPlayer === 1 ? (t+1)>>1 : t>>1,
        p2TurnsTaken:this.firstPlayer === 2 ? (t+1)>>1 : t>>1,
        cpuBlockedBreakCell:0, cpuBlockedBreakStreak:2, cpuBlockedCooldown:0,
        cpuSuccessfulBlockCell:0, cpuSuccessfulBlockStreak:2, cpuSuccessfulBlockCooldown:0});
      cpuWholeDp = spec.engine === 'ready' ? this.dp : null;
      cpuWholeStatus = spec.engine;
      cpuWholeDecisions = cpuWholeLegacyDecisions = hardLegacyDecisions = hardDpDecisions = 0;
      this.available = [];
      for (let i=0; i<9; i++) if (!state.p2Marks[i]) this.available.push(i);
      const targetMarks = spec.role === 'break' ? state.p2Marks : state.p1Marks;
      const turnsTaken = spec.role === 'break' ? state.p2TurnsTaken : state.p1TurnsTaken;
      const reachable = assertCpuEqState(targetMarks,9-turnsTaken);
      const decision = {maskP1:spec.maskP1,maskP2:spec.maskP2,t};
      const policy = this.dp.analyze(decision);
      const needsPolicy = spec.name === 'hard-full' || spec.name === 'master-ready';
      const skip = needsPolicy && policy.terminal.isTerminal;
      if (!skip && needsPolicy && policy.attacker !== attacker) throw new Error('Role mismatch');
      this.expectedCell = null;
      return {t,attacker,remaining:9-turnsTaken,closedCount:reachable.opens.length,
        terminal:policy.terminal.isTerminal,skip,
        skipReason:skip ? 'READY full-game policy is terminal' : null};
    },
    loop(count) {
      let checksum = 0;
      let cell = null;
      const available = this.available;
      if (this.spec.role === 'break') {
        for (let i=0;i<count;i++) {
          cell = selectCpuBreakCell(available);
          checksum += cell + 1;
        }
      } else {
        for (let i=0;i<count;i++) {
          cell = selectCpuBlockCell(state.p1Marks,state.p1NumberLayout);
          checksum += cell + 1;
        }
      }
      return {checksum,lastCell:cell};
    },
    probe() {
      const answer = this.loop(1);
      const cell = answer.lastCell;
      const targetMarks = this.spec.role === 'break' ? state.p2Marks : state.p1Marks;
      if (!Number.isInteger(cell) || cell < 0 || cell > 8 || targetMarks[cell]) {
        throw new Error('Selector returned illegal cell: ' + cell);
      }
      if (cpuWholeStatus !== this.spec.engine) throw new Error('Selector unexpectedly fell back');
      this.expectedCell = cell;
      return {...answer,status:cpuWholeStatus,counters:counters(),memory:memory()};
    },
    warm(count) {
      const answer = this.loop(count);
      this.verify(answer,count);
      return answer;
    },
    sample(count) {
      const started = performance.now();
      const answer = this.loop(count);
      const elapsedMs = performance.now()-started;
      this.verify(answer,count);
      return {...answer,elapsedMs,msPerDecision:elapsedMs/count,
        status:cpuWholeStatus,counters:counters(),memory:memory()};
    },
    verify(answer,count) {
      if (answer.lastCell !== this.expectedCell || answer.checksum !== count*(this.expectedCell+1)) {
        throw new Error('Fixed-roll choices changed within a batch');
      }
      if (cpuWholeStatus !== this.spec.engine) throw new Error('Engine status changed during batch');
    },
    cleanup() {
      releaseWholeGameCpu();
      this.dp = null;
      cpuEqBundle = null;
      Math.random = nativeRandom;
    }
  };
  return {fallbackBuildMs,visibility:document.visibilityState,
    innerWidth,innerHeight,isStarting:state.isStarting};
}'''


PAIRED_SAMPLE = r'''({order,warmup,count}) => {
  const samples = {};
  for (const key of order) {
    const bench = document.getElementById('bench-'+key).contentWindow.__frameCpuBench;
    bench.warm(warmup);
    samples[key] = bench.sample(count);
  }
  return samples;
}'''


def median_interval(values):
    """Distribution-free central >=95% interval for the population median.

    Its coverage assumes independent exchangeable paired observations. Batch
    timings from one process may be dependent; expose that limitation in output.
    No observed noise is repurposed as a performance allowance.
    """
    ordered = sorted(values)
    n = len(ordered)
    rank = 0
    tail = 0.0
    for candidate in range(1, n // 2 + 1):
        candidate_tail = sum(math.comb(n, j) for j in range(candidate)) / 2 ** n
        if candidate_tail <= 0.025:
            rank, tail = candidate, candidate_tail
    if rank == 0:
        return {'boundsUs': [None, None], 'nominalCoverage': None,
                'classification': 'unconfirmed', 'reason': 'Too few independent observations'}
    low, high = ordered[rank - 1], ordered[n - rank]
    classification = 'negative' if high <= 0 else 'positive' if low > 0 else 'unconfirmed'
    return {'boundsUs': [low, high], 'nominalCoverage': 1 - 2 * tail,
            'orderStatisticRanksOneBased': [rank, n + 1 - rank],
            'classification': classification}


def summarize(samples):
    deltas = [(pair['after']['msPerDecision'] - pair['before']['msPerDecision']) * 1000
              for pair in samples]
    before = statistics.median(pair['before']['msPerDecision'] for pair in samples) * 1000
    after = statistics.median(pair['after']['msPerDecision'] for pair in samples) * 1000
    return {'beforeMedianUs': before, 'afterMedianUs': after,
            'pairedDeltasUs': deltas, 'pairedMedianDeltaUs': statistics.median(deltas),
            'interval95': median_interval(deltas)}


def equivalent_samples(before, after):
    return all(before[key] == after[key]
               for key in ['checksum', 'lastCell', 'status', 'counters', 'memory'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('before', type=Path)
    parser.add_argument('after', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--port', type=int, default=8007)
    args = parser.parse_args()
    paths = {key: getattr(args, key).resolve() for key in ['before', 'after']}
    for path in paths.values():
        if not path.is_file():
            parser.error(f'Missing HTML: {path}')
        try:
            path.relative_to(ROOT)
        except ValueError:
            parser.error('Both HTML files must be under /workspace')
    result = {
        'sources': {key: {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                    for key, path in paths.items()},
        'conditions': {
            'executable': '/usr/bin/chromium', 'topLevelViewport': [2560, 900],
            'frameViewports': [1280, 900], 'independentBrowserRuns': RUNS,
            'pairedBatchesPerRunAndPath': PAIRED_BATCHES, 'callsPerBatch': CALLS_PER_BATCH,
            'initialWarmupCalls': WARMUP_CALLS, 'untimedWarmupBeforeEachBatch': BATCH_WARMUP_CALLS,
            'layouts': LAYOUTS, 'scenarios': SCENARIOS, 'paths': PATHS,
            'measurement': 'Real selector plus integer checksum; available BREAK cells precomputed',
            'state': 'Fixed public marks/layouts, isStarting=true, cooldowns=0, no result-history updates',
            'pageModel': 'One foreground top-level page with two visible same-origin child realms',
            'run2Reverses': ['frame creation order', 'left/right placement', 'first paired batch order'],
            'timer': 'Each frame performance.now, normalized by batch count',
            'intervalMethod': 'Central binomial order-statistic interval for median paired delta; coverage >=95% under independent exchangeable batch observations',
            'intervalLimitations': 'Within-process batches can be correlated. Pooled intervals are conditional on the two observed processes; no device-wide or simultaneous all-path guarantee.',
            'zeroBoundary': 'negative: upper <=0; positive: lower >0; otherwise unconfirmed',
            'allowableRegressionUs': 0,
            'normalControl': 'Retained without subtracting its timing difference or treating noise as an allowed regression',
            'notMeasured': ['event-to-paint UI latency', 'history update cost', 'cold selector latency', 'startup/preparation performance'],
        },
        'runs': [], 'rows': [], 'skipped': [], 'functionalEquivalence': None,
    }

    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *unused):
            pass

        def do_GET(self):
            if self.path == '/__stage3_frame_bench__':
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', str(len(HOST_HTML)))
                self.end_headers()
                self.wfile.write(HOST_HTML)
            else:
                super().do_GET()

    server = http.server.ThreadingHTTPServer(('127.0.0.1', args.port),
        functools.partial(Handler, directory=str(ROOT)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    failed = False
    try:
        with sync_playwright() as playwright:
            for run in range(RUNS):
                browser = playwright.chromium.launch(executable_path='/usr/bin/chromium', headless=True,
                    args=['--no-sandbox', '--disable-dev-shm-usage'])
                try:
                    result['conditions']['browserVersion'] = browser.version
                    page = browser.new_page(viewport={'width': 2560, 'height': 900})
                    run_record = {'run': run + 1, 'creationAndPlacementOrder':
                                  ['before', 'after'] if run == 0 else ['after', 'before'],
                                  'pageErrors': [], 'selfTests': {}, 'frameSetup': {}, 'preparations': []}
                    result['runs'].append(run_record)
                    page.on('pageerror', lambda error, record=run_record:
                            record['pageErrors'].append(str(error)))
                    base_url = f'http://127.0.0.1:{args.port}'
                    page.goto(base_url + '/__stage3_frame_bench__', wait_until='load')
                    page.bring_to_front()
                    frames = {}
                    for key in run_record['creationAndPlacementOrder']:
                        url = base_url + '/' + quote(str(paths[key].relative_to(ROOT)), safe='/')
                        page.evaluate('''async ({key,url}) => {
                          const frame = document.createElement('iframe');
                          frame.id = 'bench-'+key; frame.name = 'bench-'+key;
                          const loaded = new Promise((resolve,reject) => {
                            frame.onload = resolve; frame.onerror = () => reject(new Error('Frame load failed'));
                          });
                          frame.src = url; document.body.appendChild(frame);
                          await loaded;
                        }''', {'key': key, 'url': url})
                        frame = page.frame(name='bench-' + key)
                        if frame is None:
                            raise RuntimeError('Missing benchmark frame: ' + key)
                        frames[key] = frame
                        tests = json.loads(frame.locator('#rule-test-results').text_content())
                        run_record['selfTests'][key] = tests
                        if tests['passed'] != tests['total'] or tests.get('failures'):
                            raise RuntimeError(f'{key}: automatic game self tests failed')
                        run_record['frameSetup'][key] = frame.evaluate(INSTALL_BENCH, LAYOUTS)
                    if page.evaluate('document.visibilityState') != 'visible':
                        raise RuntimeError('Top-level benchmark page is not visible')
                    for first_player in [1, 2]:
                        preparations = {}
                        for key in run_record['creationAndPlacementOrder']:
                            preparations[key] = frames[key].evaluate('first => window.__frameCpuBench.prepare(first)', first_player)
                        run_record['preparations'].append({'firstPlayer': first_player, **preparations})
                        if preparations['before']['stats'] != preparations['after']['stats']:
                            raise RuntimeError('Real Worker preparation statistics differ')
                        for scenario in SCENARIOS:
                            for role in ['break', 'block']:
                                for path in PATHS:
                                    if scenario.get('fallbackOnly') and path['name'] in ['normal-legacy', 'hard-legacy']:
                                        continue
                                    spec = {**scenario, **path, 'role': role}
                                    row = {'run': run + 1, 'firstPlayer': first_player,
                                           'scenario': scenario['name'], 'role': role, 'path': path['name'],
                                           'roll': path['roll'], 'decision': {}, 'samples': []}
                                    decisions = {key: frame.evaluate('spec => window.__frameCpuBench.configure(spec)', spec)
                                                 for key, frame in frames.items()}
                                    row['decision'] = decisions
                                    if decisions['before'] != decisions['after']:
                                        result['functionalEquivalence'] = False
                                        raise RuntimeError('Decision reachability/terminal classification differs')
                                    if decisions['before']['skip']:
                                        result['skipped'].append(row)
                                        print(f'run {run+1} P{first_player} {scenario["name"]} {role} {path["name"]}: terminal skip', flush=True)
                                        continue
                                    result['rows'].append(row)
                                    probes = {key: frame.evaluate('() => window.__frameCpuBench.probe()')
                                              for key, frame in frames.items()}
                                    row['probes'] = probes
                                    if probes['before'] != probes['after']:
                                        result['functionalEquivalence'] = False
                                        raise RuntimeError('Fixed-roll selection probe differs')
                                    for key in run_record['creationAndPlacementOrder']:
                                        frames[key].evaluate('count => window.__frameCpuBench.warm(count)', WARMUP_CALLS)
                                    for batch in range(PAIRED_BATCHES):
                                        order = ['before', 'after'] if (batch + run) % 2 == 0 else ['after', 'before']
                                        pair = page.evaluate(PAIRED_SAMPLE, {'order': order,
                                            'warmup': BATCH_WARMUP_CALLS, 'count': CALLS_PER_BATCH})
                                        pair['batch'] = batch + 1
                                        pair['order'] = order
                                        row['samples'].append(pair)
                                        if not equivalent_samples(pair['before'], pair['after']):
                                            result['functionalEquivalence'] = False
                                            raise RuntimeError('Choice checksum, memory or dispatch counters differ')
                                    row['summary'] = summarize(row['samples'])
                                    summary = row['summary']
                                    print(f'run {run+1} P{first_player} {scenario["name"]} {role} {path["name"]}: '
                                          f'{summary["beforeMedianUs"]:.3f} -> {summary["afterMedianUs"]:.3f} us; '
                                          f'paired {summary["pairedMedianDeltaUs"]:+.3f}, '
                                          f'{summary["interval95"]["classification"]}', flush=True)
                        for frame in frames.values():
                            frame.evaluate('() => { releaseWholeGameCpu(); window.__frameCpuBench.dp=null; }')
                    for frame in frames.values():
                        frame.evaluate('() => window.__frameCpuBench.cleanup()')
                    if run_record['pageErrors']:
                        raise RuntimeError('Uncaught browser errors occurred')
                finally:
                    browser.close()
        grouped = {}
        for row in result['rows']:
            key = (row['firstPlayer'], row['scenario'], row['role'], row['path'])
            grouped.setdefault(key, []).append(row)
        result['combined'] = []
        for key, rows in grouped.items():
            all_samples = [pair for row in rows for pair in row['samples']]
            combined = {'firstPlayer': key[0], 'scenario': key[1], 'role': key[2], 'path': key[3],
                        'runSummaries': [{'run': row['run'], **row['summary']} for row in rows],
                        'pooledConditionalSummary': summarize(all_samples)}
            classifications = [row['summary']['interval95']['classification'] for row in rows]
            combined['repeatedRunClassification'] = classifications[0] if len(rows) == RUNS and len(set(classifications)) == 1 else 'unconfirmed'
            result['combined'].append(combined)
        result['completed'] = True
        result['functionalEquivalence'] = True
        result['strictAllMeasuredPathsNonRegressionConfirmed'] = all(
            row['repeatedRunClassification'] == 'negative' for row in result['combined'])
    except Exception as error:
        failed = True
        result['completed'] = False
        result['failure'] = f'{type(error).__name__}: {error}'
        print(result['failure'], flush=True)
    finally:
        server.shutdown()
        server.server_close()
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2))
    print(f'Results saved to {args.output}', flush=True)
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
