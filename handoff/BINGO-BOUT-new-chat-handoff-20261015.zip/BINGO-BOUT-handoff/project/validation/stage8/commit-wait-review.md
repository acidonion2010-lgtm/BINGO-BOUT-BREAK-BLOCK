# Stage 8: Chromium commit 待ちの source / trace レビュー

主対象は添付原本側の `perf-pilot/samples/cdp-cue.before.02.json` という **1 回の traced trial**。加えて formal run2 の before / after 各 1 回の長い commit wait を確認した。既存試験 JSON・HTML は変更せず、保存済み source と trace / per-thread perf を読み取った。ブラウザー、ベンチマーク、負荷試験は起動していない。

この trial の first RAF → second RAF は wall **39.954 ms** に対して renderer main の thread CPU **2.600 ms**。その中に `LayerTreeHost::WaitForCommitCompletion` の wall **37.315 ms** / thread CPU **0.025 ms** と、同じ thread の OUT → IN **37.298787 ms** が重なる。したがって、この区間の長い wall を「main thread で CPU 判断 JavaScript を約 40 ms 計算した」と解釈する根拠はない。最も具体的に記録されているのは **renderer main が compositor の commit completion を待った時間**である。

さらに、今回 commit の ready → 実行には **37.120 ms** の隔たりがあり、その直前に **別の main frame pipeline の旧 tree が activation** する。Chromium の scheduler は pending tree が残っている間 commit を実行しないため、この観測列は旧 pending tree が空くのを待つ commit の保留と強く整合する。ただし、並行する個々の RasterTask が待ちを何 ms 延長したか、CPU raster / GPU readiness / 通知遅延のどれが限界条件だったかまでは確定しない。

## 参照資料と source の一致確認

- 原 trial: [samples/cdp-cue.before.02.json](perf-pilot/samples/cdp-cue.before.02.json)
- 元 trace: [traces/cdp-cue.before.02.json](perf-pilot/traces/cdp-cue.before.02.json)
- 既存解析: [perf-pilot-analysis.json](perf-pilot-analysis.json)
- 本レビューの抽出 event / marker / perf / hash: [commit-wait-evidence.json](commit-wait-evidence.json)
- source の取得成否・URL・元 SHA: [chromium-source/manifest.json](chromium-source/manifest.json)
- 保存 source の再 hash: [source-integrity-check.json](chromium-source/source-integrity-check.json)

受領時の manifest の成功 10 件は、すべて `requestedRef=154.0.8037.57`、raw GitHub URL にも同じ tag を含む。保存ファイルの bytes と SHA256 を再計算し **10 / 10 一致**した。後述の scheduler source / LICENSE を追加後も **12 / 12 一致**。manifest の失敗記録も保持して区別する。googlesource は proxy 403、`cc/raster/task_graph_runner.cc` は raw GitHub 404 であり、それらを取得済みとは扱わない。

同 tag の公開 `chrome/VERSION` を読み、`MAJOR=154 / MINOR=0 / BUILD=8037 / PATCH=57` を確認した（[tag-version-check.json](chromium-source/tag-version-check.json)）。GitHub API の tag → commit 問い合わせは proxy 403 だったため tag object 自体の独立解決は未確認。ただし元 trace の `metadata.revision` は `73c14f6228d7cd537c855007e8f88678969cc0eb-refs/branch-heads/8037@{#1293}` であり、その **commit SHA を直接指定して取得した主要 3 source** (`layer_tree_host.cc`, `proxy_main.cc`, `proxy_impl.cc`) は tag 保存版と bytes / SHA256 が全一致した（[browser-revision-check.json](chromium-source/browser-revision-check.json)）。関数の意味を最新版から類推したものではない。

追加で同 browser revision の `cc/scheduler/scheduler_state_machine.cc` を読み取り保存した。SHA256 は `d92c4e9f33a5943c8a74356c5f16edc3d93dc6e88745a1d12f9a5f62dddf79d3`（[scheduler-source-check.json](chromium-source/scheduler-source-check.json)）。元 trace 自体の SHA256 も試験 JSON の記録と一致した。

同 revision の [Chromium LICENSE](chromium-source/LICENSE) も原文のまま保存した。SHA256 は `368cca1106be99d39ecd32a38d8305585d802a475effb66380b91ffc9bcf709b`。scheduler / LICENSE の URL・revision・bytes・SHA256 を既存書式の成功 entry として manifest 末尾に追加し、元の取得失敗履歴・成功 10 entry を保持した。保存 source の copyright header も変更していない。

以下の行番号は `chromium-source/` 配下の保存ファイルを指す。主要 source の安定 URL は [Chromium browser revision 73c14f6](https://github.com/chromium/chromium/tree/73c14f6228d7cd537c855007e8f88678969cc0eb)。

## `WaitForCommitCompletion` が待つもの

1. `cc/trees/proxy_main.cc:471–477` で manual-reset の `CompletionEvent` を作り、`LayerTreeHost::WillCommit()` に渡す。`cc/trees/layer_tree_host.cc:501` が `commit_completion_event_` を保持する。
2. [`LayerTreeHost::WaitForCommitCompletion`, layer_tree_host.cc:526–535](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/cc/trees/layer_tree_host.cc#L526-L535) は main thread で `commit_completion_event_->Wait()` を呼び、その後 pointer を reset する。RasterWorker、GPU fence、画面表示をこの関数が直接待っているわけではない。
3. [`ProxyMain::BeginMainFrame`, proxy_main.cc:535–565](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/cc/trees/proxy_main.cc#L535-L565) は impl thread に `ProxyImpl::NotifyReadyToCommitOnImpl` を post し、blocking の場合 `WaitForProtectedSequenceCompletion()` を呼ぶ。source comment 自体が「main からは blocking、impl 上では Scheduler が調整して非同期実行」と説明している。この版に別の `ProxyMain::Commit` 実装はなく、該当 trace scope 名は `ProxyMain::BeginMainFrame::commit`。
4. [`ProxyImpl::NotifyReadyToCommitOnImpl`, proxy_impl.cc:425–483](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/cc/trees/proxy_impl.cc#L425-L483) は completion event と commit state を `DataForCommit` に保持し、scheduler に ready を通知する。**ready という通知と commit action の実行は別の段階**である。
5. [`ProxyImpl::ScheduledActionCommit`, proxy_impl.cc:868–898](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/cc/trees/proxy_impl.cc#L868-L898) が `BeginCommit()` → `FinishCommit()` を実行する。通常は `data_for_commit_.reset()` で holder が破棄され、[`ScopedCommitCompletionEvent::~ScopedCommitCompletionEvent`, proxy_impl.cc:97–103](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/cc/trees/proxy_impl.cc#L97-L103) の `Signal()` で main の待ちを解除する。

通常の completion は compositor の **post-commit 処理、raster 全部の完了、presentation の完了と同義ではない**。`proxy_impl.cc:901–906` は `LayerTreeHostImpl::CommitComplete()` を別の post-commit action として実行し、その処理で次の BeginMainFrame を遅らせないよう分離したと明記している。また `layer_tree_host.cc:556–570` は signal 済み event の非 blocking な後片付けでもこの wait 関数を呼ぶ場合があると説明する。event 名だけで blocking の長さを決めず、今回の wall / thread CPU / perf OUT–IN を併用する。

## 自分の activation を待つ分岐と、旧 pending tree を待つ分岐

**明示的な activation 延長:** `layer_tree_host.cc:420–421` の `SetNextCommitWaitsForActivation()` は `commit_waits_for_activation=true` を設定する。その場合のみ `proxy_impl.cc:889–895` で `HoldCommit` を記録して event holder を `activation_completion_event_` に移す。`proxy_impl.cc:660–666` の `DidActivateSyncTree()` は `ReleaseCommitbyActivation` を記録して holder を解放する。今回の renderer の元 trace 全体で両 event の件数は **0 / 0** だった。カテゴリ `cc` は有効であり、この trial では今回 commit 自身をこの分岐で activation まで延長した実行証拠はない。

**旧 pending tree が commit を阻む分岐:** [`SchedulerStateMachine::ShouldCommit`, scheduler_state_machine.cc:667–676](https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/cc/scheduler/scheduler_state_machine.cc#L667-L676) は `READY_TO_COMMIT` でも `has_pending_tree_` が true なら false を返す。comment は `We must not finish the commit until the pending tree is free.`。同ファイル `996–1011` の `WillActivate()` で `has_pending_tree_=false` となり、`738–746` の `NextAction()` は activation を commit より先に選ぶ。**通常 commit でも、以前の pending tree の activation を介して raster readiness の影響を間接に受け得る**。自分の commit event を activation まで保持する上の flag とは別の経路である。

## 今回の対応関係

時刻は trace の monotonic microseconds。main は PID/TID `27436/27436` (`CrRendererMain`)、compositor は TID `27451`。

| 記録 | ts (µs) | wall / thread CPU | 対応 |
|---|---:|---|---|
| first RAF mark | 14010507960 | — | first main frame 内 |
| `ProxyMain::BeginMainFrame::commit` 開始 | 14010509567 | 37.333 / 0.042 ms | main frame ID `12067455181810493947` |
| `WaitForCommitCompletion` 開始 | 14010509583 | 37.315 / 0.025 ms | 同じ main scope 内 |
| main perf OUT → IN | 14010509591.609 → 14010546890.396 | off-CPU 37.298787 ms | 全区間が wait 内、OUT の PREEMPT flag 無し |
| `ProxyImpl::ReadyToCommit` | 14010509644 | 0.016 / 0.013 ms | ID `12067455181810493947` |
| 2 回目 `SendBeginMainFrame` | 14010523890 | instant | ID `12067455181810493936` |
| 旧 tree `ProxyImpl::ReadyToActivate` | 14010546510 | instant | **別 ID `12067455181810493758`** |
| 旧 tree `ActivateSyncTree` | 14010546514 | 0.246 / 0.217 ms | 同じ旧 ID |
| 今回 `ProxyImpl::Commit` | 14010546764 | 0.094 / 0.084 ms | ID `12067455181810493947` |
| `WaitForCommitCompletion` 終了 | 14010546898 | — | 今回 commit の終了後 |
| 2 回目 `ProxyMain::BeginMainFrame` 開始 | 14010547083 | 1.688 / 1.663 ms | ID `12067455181810493936` |
| second RAF mark | 14010547914 | — | 2 回目 main frame 内 |

今回 ready → commit action は `14010546764 − 14010509644 = 37.120 ms`。旧 tree の activation が終わる `14010546760` の **4 µs 後**に今回 commit が始まる。これは scheduler の pending-tree 条件と強く整合する。`ShouldCommit()` の判定値や全 state を記録した debug event はないため、この順序だけから 37.120 ms のすべてを単一の raster task に帰属させない。

2 回目 frame の send → main 開始は **23.193 ms**。send は 1 回目 main task の commit wait 中に到着している。1 回目 top-level `ThreadControllerImpl::RunTask` は wall **40.201 ms** / thread CPU **2.821 ms** であり、「長い main task」という見た目と「その時間 main CPU を使って計算した」は区別が必要。この trial では main task が wait に入ったまま終わらず、次の main frame callback の開始が遅れるという説明を trace が支えている。

## Formal run2 の before / after にも現れた直接的な commit wait

[run2-analysis.json](run2-analysis.json) と元試験 / trace を照合した。対象は `task-response/run2/samples/cdp-cue.before.04.json` と `cdp-cue.after.04.json`。両方の `requestedDelayMs` は 13、renderer main PID/TID は `41177/41177`、browser revision も上記と一致する。元 trace SHA256 は各試験 JSON と一致、trace / perf clock 対応確認も両方 passed。抽出 event / hash / perf / boundary event は [commit-wait-formal-run2-evidence.json](commit-wait-formal-run2-evidence.json) に保存した。

| 観測値 (ms) | before.04 | after.04 |
|---|---:|---:|
| first → second RAF wall | 32.192 | 29.597 |
| 同じ区間の main thread CPU | 1.734 | 2.407 |
| commit wait wall | 30.300 | 27.163 |
| commit wait thread CPU | 0.030 | 0.029 |
| commit wait 内の perf OUT → IN 合計 | 30.287018 | 27.145764 |
| 2 回目 frame send → main 開始 | 16.215 | 13.983 |
| 2 回目 RAF callback lag (page 値) | 約 16.7 | 約 14.9 |

before は今回 pipeline ID `14850786983137962785` の `ReadyToCommit` (`36240819643 µs`) → 別 ID `14850786983137963003` の旧 tree activation (`36240849623 µs`, 173 µs) → 今回 `Commit` (`36240849799 µs`, 89 µs) という順序。after も今回 ID `14850786983137956476` の ready (`36245553755 µs`) → 別 ID `14850786983137956361` の activation (`36245580559 µs`, 206 µs) → 今回 commit (`36245580769 µs`, 89 µs) だった。旧 activation の終了から次の commit 開始までは両方 **3–4 µs**。`HoldCommit` / `ReleaseCommitbyActivation` は元 trace の renderer 全体で両方とも 0 件。

従って pilot の before に限定された現象ではなく、**formal run2 の両実装にも、CPU 実行の少ない長い commit completion 待ちと旧 tree activation → 今回 commit の並びを直接確認できる**。この 2 件の差から効果量を求めたり「refactor がこの待ちを除去した」とは判断しない。同じ requested delay は、実際の入力 phase や描画内容・全 scheduling 条件の同一を保証しない。

before.04 の trace 終了付近には未閉じ `B` scope が 3 件あるが、begin は全て response の second RAF mark より後で、当該 wait は完全な `X` event として記録される。新 parser はこれらを `boundaryScopeEventsOutsideResponseWindows` に保持しており、対象 response window と混同しない。after.04 の同 boundary list は空。これは trace 全体の全 scope が閉じたという主張ではなく、今回レビューした response window 内の解析範囲を示す。

## RasterTask の同時実行から言える範囲

元 trace では TID `27446` / `27448` の `ThreadPoolForegroundWorker` が `RasterTask` を実行する。たとえば source frame 51 / layer 58 の task は wall **27.711 ms** / thread CPU **27.643 ms**、別 worker の同 layer task は **26.018 / 25.890 ms**（いずれも task 全体の値で、wait 区間に切り出した CPU 値ではない）。main の wait 中に実際の CPU raster 作業が並行した証拠ではある。

source 上にも raster から activation への依存経路がある。

- `cc/tiles/tile_manager.cc:1330–1332`: `required_for_activation()` の tile raster task から activation 完了 task へ依存 edge を作る。
- 同 `615–623`: required-for-activation task の完了を signal に記録する。
- 同 `1827–1831`, `1881–1892`: required tile readiness と CPU task / GPU work の完了条件を確認して `NotifyReadyToActivate()` を送る。
- `cc/trees/layer_tree_host_impl.cc:2033–2042`: pending tree の paint が未完了なら activation ready を scheduler に転送しない。
- `cc/raster/gpu_raster_buffer_provider.cc:154–191` と `tile_manager.cc:2114–2188`: GPU resource readiness は別の callback / sync token で確認する。worker task の実行終了と GPU work の完了は同義ではない。

今回の順序は raster / tile readiness → 旧 tree activation → 今回 commit → main 復帰という依存経路と整合し、単に別 process の無関係な CPU activity を眺めている場合より具体的である。一方、保存された `RasterTask.tileData` に `required_for_activation` の値はなく、個々の tile が旧 pipeline の限界条件だったこと、35 個の重なった raster task のどれが critical だったことも直接記録していない。worker CPU の総和は並列実行を含むので main の wait wall から引いたり、そのまま wait 時間と足したりしない。`pending_gpu_work_tiles=0` の観測点もあるが、それだけで区間全体の GPU 状態を断定しない。

## CPU 判断処理・OS 待ち・過去試験への適用限界

- first → second RAF 全体の main CPU **2.600 ms** には JavaScript、Blink、cc、計測処理が含まれる。CPU 判断関数だけの時間ではない。wait の 37.315 ms は約 37 ms の CPU JavaScript 実行を意味せず、今回の observation から CPU 判断アルゴリズムのさらなる高速化で同じ 37 ms が消えるとは言えない。DOM / style 変更が raster 負荷へ間接に影響した可能性も、このレビューだけでは確認・否定しない。
- 同 thread の perf と trace clock の対応確認は既存解析で passed、mark は既知の running interval 内、trace / perf の当該記録に欠損等の integrity failure はない。一方、non-PREEMPT OUT は特定の sleep 原因の証明ではない。今回 source と trace が commit event の待ちを示すが、wakeup 時刻を取っていないので 37.298787 ms を blocked 時間と wakeup 後の runnable delay に厳密分離できない。
- `/proc/.../schedstat` の runqueue wait 増分 **1.860984 ms** は入力前 → callback 後という広い host bracket の累積であり、この wait のどこに配分すべきかは分からない。共有 cgroup の throttle 増分 0 も、この renderer だけの原因同定やあらゆる scheduling delay の否定には使わない。
- rAF callback の mark は物理画面への表示完了ではない。この診断は headless Chromium / SwiftShader を含む計測条件の selected traced trials。tracing / perf / observer 自体が条件を変えるため、before 対 after の性能 PASS や一般的な本番原因判定にはしない。
- **過去の外れ値へ原因を遡及して割り当てない。** Stage 5 / 6 の untraced 試行（Stage 7 の報告でも参照）には、今回と同じ wait event / thread CPU / perf OUT–IN / frame pipeline の同時記録がない。Stage 7 自身の traced response 試行には marker 間の thread CPU 記録はあるが、trace categories は `devtools.timeline`, `blink.user_timing`, `renderer.scheduler`, `v8` で、今回追加した `cc` / `toplevel` / `viz` と per-thread perf はない。従って Stage 7 の traced tail についても、同じ commit wait / 旧 pending tree の因果関係までは帰属できない。今回確認した機構が Chromium に存在することと、過去の各外れ値が同じ機構で生じたことは別である。

今回の結論は「pilot before と formal run2 の before / after で確認した長い RAF 間隔には、main CPU 計算より compositor commit completion 待ちが大きく現れ、旧 pending tree の activation による commit 保留と整合する」。個々の raster / GPU / scheduler の寄与率、untraced 試験の原因、全経路の non-regression は未確定のまま残す。
