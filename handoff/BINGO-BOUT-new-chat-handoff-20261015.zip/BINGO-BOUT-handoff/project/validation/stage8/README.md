# Verification 8: frame/commit waits

The production `index.html` remains byte-identical to the received stage5 GitHub
handoff. This round adds measurement tools, source review and reports. No game
code, rendering, audio, animation, browser settings or kernel settings changed.

The formal diagnostic consists of two independent browser launches, four visits
per launch, four trusted accepted HARD clicks per visit: 32 measured clicks and
eight separate warmups. The second run reverses both protocols' version order.
The two runs were collected across an interruption of the chat, approximately
six hours apart; they are diagnostic observations, not a continuous matched
speed benchmark. Two preceding four-click pilots and their four warmups remain
separate. Total: 40 measured clicks, 12 warmups; per-thread perf is present for
36 measured clicks (the second pilot and formal runs).

Use Linux x86_64, Python Playwright, `/usr/bin/chromium`, and Node/Python tools
already used for previous stages. Run browser jobs sequentially with no other
CPU-heavy job. Commands run from the `bingo-refactor` directory. Use new output
directories to retain previous raw captures.

```bash
# Small task/frame/proc pilot:
python3 validation/stage8/trace_tasks.py index.before.html index.html validation/stage8/task-pilot --protocol cdp-cue --trials 2 --order before-after
# Small per-thread perf pilot:
python3 validation/stage8/trace_tasks.py index.before.html index.html validation/stage8/perf-pilot --protocol cdp-cue --trials 2 --order after-before --perf-switches
# Formal diagnostic launches, one at a time:
python3 validation/stage8/trace_tasks.py index.before.html index.html validation/stage8/task-response/run1 --protocol both --trials 4 --normal-trials 4 --order reverse-second --perf-switches
python3 validation/stage8/trace_tasks.py index.before.html index.html validation/stage8/task-response/run2 --protocol both --trials 4 --normal-trials 4 --order inverse-reverse-second --perf-switches
python3 validation/stage8/analyse_tasks.py validation/stage8/task-response/run1 --output validation/stage8/run1-analysis.json
python3 validation/stage8/analyse_tasks.py validation/stage8/task-response/run2 --output validation/stage8/run2-analysis.json
```

`trace_tasks.py` reuses stage7's unchanged fixture, input transports, four
markers, real Blob Worker and behavior assertions. It adds `toplevel`, `cc` and
`viz` to the trace categories. Normal locator internal actionability/mouse move
remain inside tracing; CDP actionability/hover preparation precedes tracing.
Every requested delay and actual input phase is retained. No missed phase is
retried or removed. Sound/BGM processing and game animations remain active;
Playwright headless still uses `--mute-audio`. Physical presentation and speaker
output are not measured.

`perf_switch.py` uses a per-thread software DUMMY event, explicit CLOCK_MONOTONIC,
sample_id_all, TID/TIME/CPU, and a 64 KiB forward ring. It uses no CPU-wide
sampling, privilege change, process suspension or system setting change. The
collector enables before input, disables after observing the response, reads
the disabled ring, then closes the mmap and FD. Capture failures remain in JSON
and fail the selected diagnostic after preserving trace/raw data. A missing or
zero-record capture is not marked successful. This environment permitted the
renderer attachment; other environments can report it unavailable.

The analyzer verifies trace hashes, same renderer PID/TID and process start
ticks, explicit clock correspondence, capture brackets, alternating switch
directions, running state at all four marks, and reported loss/throttle/overflow/
truncation/closure. It clips complete OUT->IN pairs to each marker window and
records their overlap with commit-wait spans. It does not assign off-CPU time to
particular wakeup causes. Proc run_delay is cumulative across a wider host
bracket; its validity and enclosure are checked before exporting accounting
comparisons. It is not an exact physical sleep clock.

After review, analyzer/collector checks also reject unthrottle records and
near-capacity rings (112 bytes of reserve for the supported layouts). Existing
captures are retained unchanged and revalidated with the stricter analyzer.
Formal rings used at most 4,352/65,536 bytes, with zero reported lost/throttle/
unthrottle records. A short native self-thread smoke verified the hardened
collector and resource closure; no HTML/browser replay was needed for these
metadata checks.

The original stage7 parser rejected three unfinished synchronous B scopes in a
run2 trace. They all begin after the second response mark. Stage8's
`marker_windows.py` keeps those records explicitly and only accepts such B
starts after the response, or E ends before capture. Unsupported boundary scopes
that could intersect a response window still fail. Stage7 files and measured
data remain unchanged. The initial parser failure and resolution are retained
in `analysis-compatibility-issue.json`.

Frame matching uses the containing `ProxyMain::BeginMainFrame`, its exact
main_frame_id, matching `SendBeginMainFrame`, and the compositor's sequence ID.
The callback lag is described as frame-time->send, send->main start, and main
start->callback mark. Those intervals telescope but do not identify every
underlying scheduling/raster/GPU cause. Task/event wall intervals are unioned
within categories; nested categories must not be added.

`commit-wait-review.md` checks saved sources against Chromium 154.0.8037.57 and
browser revision `73c14f6228d7cd537c855007e8f88678969cc0eb`. The source manifest
retains successful hashes and failed URL attempts separately. Chromium source
copies and their original LICENSE are included as review evidence, not as game
dependencies. Scheduler accounting references, capability probes and limitations
are in `scheduler-capabilities.md` and `perf-review.md`.

See `../../未完了検証8結果.md` and `summary.json`. No A/A subtraction,
phase-adjusted speed, timing tolerance, universal non-regression PASS or
retroactive cause assignment to earlier trials is made.
