# 段階14の再現

対象は添付 `BINGO-BOUT-new-chat-handoff-20261015.zip` の原本・段階3.final・5・9。リポジトリmainの旧HTMLは計測しない。元ZIPを `/workspace/handoff/BINGO-BOUT-handoff/` に展開した同じ環境で行う。

Python3、Python Playwright、`/usr/bin/chromium`を使う。今回のブラウザーは154.0.8037.57。追加インストール・本体修正・カーネル設定変更は行っていない。

他のブラウザー・DP・性能ジョブと同時に走らせない。新しい出力先を使う。

```bash
python3 /workspace/handoff/BINGO-BOUT-handoff/verify_manifest.py
cd /workspace/bingo-stage14-20261015
mkdir -p reproduction
python3 capture_clicks.py --output reproduction/report.json
python3 analyze_clicks.py reproduction/report.json --output reproduction/analysis.json
```

計測器は既存reportとその隣のtracesディレクトリへの上書きを拒否する。分析器も既存JSON/CSVへの上書きを拒否する。保存済み原データはreport.jsonとtraces/、分析結果はanalysis.jsonとanalysis.csv。

期待する機能完了は16visit、288正式クリック・32warmup、32別監査、通常16読込×322件の自己テスト、16実Worker準備、16連続trace、320試行の1,280marker。音・BGM・演出を残したtrusted locator.click()を使用し、HARDのDP/従来分岐をcounterで検証する。時刻や差の符号が保存結果と同じことは再現の成功条件にしない。

計測器は入力4HTMLと4helperのhashを実行前に照合し、script/PLANのhashをreportへ保存する。計画の固定回数を増やしたり、遅い試行を除いたり、期待する符号が出るまで追加したりしない。失敗はpartial reportと回収できたtraceを保持する。

trace collectorはstream・loss・最終trialの4markを検証し、分析器が全試行のmarker・page対応・PID/TID・時計・分岐を検証する。分析には標準ライブラリだけを使い、ブラウザーは起動しない。CPUのttsがない場合はwallを残しCPUをnullにする。

新たにクリックを記録せず、同梱した生データだけを別名へ再解析することもできる。

```bash
python3 analyze_clicks.py report.json --output reanalysis.json
```

元のtrace絶対パスが存在しない場合はreport.jsonの隣のtraces/内の同名ファイルを使い、同じSHA-256を必ず要求する。そのためダウンロードした本一式の再解析だけなら元ZIPやPlaywrightを必要としない。新規クリック収集には元ZIPとブラウザー環境が必要。

CPU時計の3不整合の保存記録だけを再点検する（ブラウザーは起動しない）。

```bash
python3 audit_clocks.py report.json analysis.json --output rechecked-clocks.json
```

別native processでのOS時計512区間は、CLOCK_PLAN.mdの追加固定計画に基づく。新しい出力とbuild先を使う。ccが必要。ブラウザーを起動せず、元のクリック予算も増やさない。

```bash
python3 check_native_clocks.py --output reproduction/native-clocks.json
```

native-clocks.jsonは全512区間が外側wallに収まったが、Chromiumの3不整合を消す結果ではない。分析JSONの有限marker対応PASSとCPU会計の物理的整合性は別であり、CPU寄与率や待機量を確定しない。CLOCK_VALIDITY.mdに制約を記載した。

各visitのwarmup0だけを中央値から除外し、正式1〜9をすべて含める。比較は9クリックのvisit中央値間の差で、4runを記述的に報告する。旧試行との標本混合、位相補正、A/A差し引き、厳密性能PASSは行わない。

これは計装したHTTP/headless環境の診断であり、物理入力から提示/スピーカー出力までの時間、非計装の製品latency、cold click、実端末の性能ではない。同梱index.htmlは現在の段階9を無変更で保存したもの。元引き継ぎZIPの置き換えではない。
