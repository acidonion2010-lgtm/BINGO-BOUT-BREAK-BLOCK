#!/usr/bin/env python3
"""Finite paired explicit-unit capture; no retry or overwrite."""
import base64,csv,hashlib,http.server,json,math,subprocess,sys,threading,time
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parent
S16=Path('/workspace/bingo-stage16-20261015')
sys.path.insert(0,str(S16));import capture_proto as previous
import make_configs
old=previous.old;phase=old.phase
sha=previous.sha;write=previous.write

def run_logged(command,path):
 log={'argv':command}
 try:
  completed=subprocess.run(command,capture_output=True,text=True,timeout=120)
  log.update(returncode=completed.returncode,stdout=completed.stdout,stderr=completed.stderr)
  return completed
 except BaseException as error:
  log['failure']=repr(error)
  if isinstance(error,subprocess.TimeoutExpired):
   log.update(timeoutSeconds=error.timeout,stdout=(error.stdout or b'').decode('utf8',errors='replace'),stderr=(error.stderr or b'').decode('utf8',errors='replace'))
  raise
 finally:write(path,log)

def raw_gate(path,unit,pid,tid):
 output=R/f'raw-counter-{path.stem}.json';assert not output.exists()
 cmd=[sys.executable,str(S16/'raw_counter_check.py'),str(path),str(output)]
 p=run_logged(cmd,path.with_suffix('.raw-log.json'));assert p.returncode==0
 raw=json.loads(output.read_bytes());assert raw['status']=='limited_scope_complete'
 found=[c for row in raw['ledger'] for c in row['counters'] if c.get('descriptor_name')=='thread_time' and c.get('status')=='decoded' and c.get('sum_reliable') and (c['association_at_end'].get('pid'),c['association_at_end'].get('tid'))==(pid,tid)]
 assert found and {c['unit_multiplier'] for c in found}=={unit},'actual CPU counter unit differs from requested unit'
 assert all(c['is_incremental'] is True for c in found),'CPU counter not incremental'
 return {'path':str(output),'sha256':sha(output.read_bytes()),'targetCpuSamples':len(found),'actualMultipliers':sorted({c['unit_multiplier'] for c in found}),'diagnosticCounts':raw.get('diagnostic_counts')}

def preflight_config_health(path,unit):
 output=path.with_suffix('.config-check.json');assert not output.exists()
 command=[sys.executable,str(R/'check_effective_config.py'),str(path),'--config',str(R/f'trace-config.unit{unit}.pb'),'--output',str(output)]
 completed=run_logged(command,path.with_suffix('.config-check-log.json'));assert completed.returncode==0,'effective config gate failed'
 query='SELECT name,idx,severity,source,value FROM stats WHERE value != 0 ORDER BY name,idx'
 command=[str(S16/'trace_processor_shell'),'query',str(path),query]
 completed=run_logged(command,path.with_suffix('.health-log.json'));assert completed.returncode==0
 rows=list(csv.DictReader(completed.stdout.splitlines()));assert rows and {'name','severity','value'}<=set(rows[0])
 errors=[r for r in rows if r['severity'] in ['error','data_loss'] and int(r['value'])!=0];assert not errors,errors
 return {'effectiveConfigPath':str(output),'effectiveConfigSha256':sha(output.read_bytes()),'nonzeroStats':rows,'nonzeroErrorOrDataLossStats':errors}

class Proto(previous.Proto):
 def __init__(self,session,page,path,config):
  super().__init__(session,page,path);self.config=config
 def start(self):
  self.summary.update(requestedConfigSha256=sha(self.config),hostStartSendMonotonicNs=time.monotonic_ns())
  self.session.send('Tracing.start',{'perfettoConfig':base64.b64encode(self.config).decode(),'bufferUsageReportingInterval':100,'transferMode':'ReturnAsStream','streamFormat':'proto','streamCompression':'none'})
  self.active=True;self.summary.update(started=True,hostStartAcknowledgedMonotonicNs=time.monotonic_ns())

def validate_visit(visit,markers):
 path=R/f"run{visit['run']}.pftrace";conversion=previous.convert(path,markers);visit['conversion']=conversion
 pid,tid=conversion['rendererPidTid'];assert pid==tid
 snaps=([visit['before'],visit['after']] if visit['preflight'] else [s[k] for s in visit['samples'] for k in ['before','after']])
 identities=[];values=[]
 for s in snaps:
  candidates=[r for r in s['renderers'] if (r['pid'],r['tid'])==(pid,tid) and 'readError' not in r];assert len(candidates)==1
  target=candidates[0];fields=target['stat'][target['stat'].rfind(')')+2:].split();identities.append((target['comm'],fields[19]))
  m={x['name']:x['value'] for x in s['metrics']['metrics']}
  assert all(k in m and isinstance(m[k],(int,float)) and math.isfinite(m[k]) for k in ['ThreadTime','Timestamp']);values.append(m['ThreadTime'])
 assert len(set(identities))==1 and all(b>=a for a,b in zip(values,values[1:]))
 if visit['preflight']:assert values[-1]>values[0]
 groups=[{'markers':markers,'before':visit['before'],'after':visit['after']}] if visit['preflight'] else visit['samples']
 lookup={m['name']:m for m in conversion['markers']}
 for group in groups:
  lo=group['before']['metricSendMonotonicNs'];hi=group['after']['metricReturnMonotonicNs']
  for marker in group['markers']:
   for kind in ['mark','stamp']:assert lo<=lookup[marker['name']][kind]['ts']*1000<=hi
 names=[e.get('args',{}).get('name') for e in json.loads(path.with_suffix('.json').read_bytes())['traceEvents'] if e.get('ph')=='M' and e.get('name')=='thread_name' and (e.get('pid'),e.get('tid'))==(pid,tid)]
 assert 'CrRendererMain' in names
 visit.update(rendererIdentity={'comm':identities[0][0],'starttimeTicks':identities[0][1]},traceThreadNames=names,hostMarkerContainmentChecked=True,metricMonotonic=True)
 if visit['preflight']:
  visit['rawGate']=raw_gate(path,visit['unit'],pid,tid)
  visit['configHealthGate']=preflight_config_health(path,visit['unit'])

def main():
 report=R/'report.json';assert not report.exists()
 assert sha((S16/'capture_proto.py').read_bytes())=='b071059ac8d1f93a417f294cc143590ae2101bee8da4f6549f05d28774e3b6df'
 assert sha((S16/'raw_counter_check.py').read_bytes())=='91762a94d1e1e05305c2a11fbb237dd4b42bffd3ebb5162f48c4cec42b038c23'
 assert sha((S16/'trace_processor_shell').read_bytes())=='58042408e6cc861fb1a731c26bb082dc222285561eaa4e12a48a8b2b90dca7b9'
 assert sha(Path(old.__file__).read_bytes())=='df0c5fa77905d13ce492882e14338a5684e6670e1c5f0694f44b20d696092c77'
 raw=old.FILES['original'].read_bytes();assert sha(raw)==old.EXPECTED['original']
 for n,h in old.HELPERS.items():assert sha((old.PROJECT/'validation'/n).read_bytes())==h
 configs={unit:(R/f'trace-config.unit{unit}.pb').read_bytes() for unit in [1000,1]}
 for unit,cfg in configs.items():assert cfg==make_configs.build(unit)[0]
 result={'status':'running','scriptSha256':sha(Path(__file__).read_bytes()),'planSha256':sha((R/'PLAN.md').read_bytes()),'configGeneratorSha256':sha((R/'make_configs.py').read_bytes()),'stage16CollectorSha256':sha((S16/'capture_proto.py').read_bytes()),'helperCollectorSha256':sha(Path(old.__file__).read_bytes()),'htmlSha256':sha(raw),'configSha256':{str(u):sha(c) for u,c in configs.items()},'visits':[],'pageErrors':[]}
 write(report,result)
 class Handler(http.server.BaseHTTPRequestHandler):
  def do_GET(self):
   if self.path!='/original':self.send_error(404);return
   self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  def log_message(self,*a):pass
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
 try:
  with sync_playwright() as p:
   for browser_run in range(5):
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    try:
     bs=browser.new_browser_cdp_session();browser_info=bs.send('Browser.getVersion')
     units=[1000,1] if browser_run in [0,1,3] else [1,1000]
     for position,unit in enumerate(units):
      run=len(result['visits']);visit={'run':run,'browserRun':browser_run,'position':position,'unit':unit,'preflight':browser_run==0,'samples':[],'browserVersion':browser.version,'browserInfo':browser_info}
      result['visits'].append(visit);write(report,result)
      page=browser.new_page(viewport={'width':1280,'height':900})
      try:
       page.on('pageerror',lambda e:result['pageErrors'].append(str(e)));session=page.context.new_cdp_session(page)
       visit['categoryDiscovery']=session.send('Tracing.getCategories');visit['requestedConfigSha256']=sha(configs[unit])
       page.goto(f'http://127.0.0.1:{server.server_port}/original',wait_until='load',timeout=60000)
       visit['selfTests']=json.loads(page.locator('#rule-test-results').text_content());assert visit['selfTests']=={'passed':322,'total':322,'failures':[]}
       session.send('Performance.enable',{'timeDomain':'threadTicks'});page.evaluate(old.INSTALL_MARKER.replace('bingo.stage14.','bingo.stage17.'))
       if browser_run:
        visit['prepare']=page.evaluate(phase.PREPARE);assert visit['prepare']['status']=='ready'
        page.evaluate(old.stage7.TRACE_INSTRUMENT);page.evaluate(phase.INSTALL_MONITOR);visit['nativeFunctionSources']=page.evaluate(old.NATIVE_REFS)
       path=R/f'run{run}.pftrace';trace=Proto(session,page,path,configs[unit]);markers=[];error=None
       try:
        trace.start()
        if not browser_run:
         visit['before']=previous.snap(session,bs)
         markers=page.evaluate('''unit=>{traceResponseState.enabled=true;traceResponseState.token=`preflight.unit${unit}`;traceResponseMark('begin',performance.now());const start=performance.now();while(performance.now()-start<8){}traceResponseMark('end',performance.now());return traceResponseState.markers}''',unit)
         visit['after']=previous.snap(session,bs)
        else:
         branches=['dp','legacy'] if browser_run in [1,2] else ['legacy','dp'];visit['branchOrder']=branches;visit['audits']={}
         for branch in branches:
          fixture={'difficulty':'hard','roll':old.BRANCHES[branch]};page.evaluate(old.FIXTURE,fixture)
          audit=page.evaluate(old.AUDIT,old.BRANCHES[branch]);visit['audits'][branch]=audit
          assert audit['draws'] and all(v==old.BRANCHES[branch] for v in audit['draws'])
          assert audit['status']=='ready' and audit['counters']==({'whole':1,'legacy':0,'dp':1} if branch=='dp' else {'whole':0,'legacy':1,'dp':0})
          prior=[v['audits'][branch] for v in result['visits'] if v is not visit and branch in v.get('audits',{})]
          if prior:assert audit==prior[0],'untimed fixture/RNG/choice audit differs'
          for trial in range(4):
           record={'branch':branch,'trial':trial,'warmup':trial==0,'outcome':'preparing'};visit['samples'].append(record);write(report,result)
           page.evaluate(old.FIXTURE,fixture);record['descriptor']=page.evaluate(phase.DESCRIBE)
           assert record['descriptor']['visibility']=='visible' and not record['descriptor']['crossOriginIsolated']
           assert page.evaluate('()=>stage14CheckNativeRefs()')
           token=f'run{run}.unit{unit}.{branch}.trial{trial}';page.evaluate('''token=>{traceResponseState.enabled=true;traceResponseState.token=token;traceResponseState.markers=[]}''',token)
           record['before']=previous.snap(session,bs)
           page.locator('#board1 .cell:not([disabled])').first.click(timeout=10000);page.wait_for_function('uiResponseProbe.result !== null',timeout=10000)
           record['after']=previous.snap(session,bs)
           sample=page.evaluate('uiResponseProbe.result');old.assert_sample(sample,branch)
           current=page.evaluate('traceResponseState.markers');assert [m['label'] for m in current]==list(old.stage7.LABELS)
           record.update(sample=sample,markers=current,outcome='accepted');markers.extend(current);assert not result['pageErrors'];write(report,result)
         assert page.evaluate('()=>stage14CheckNativeRefs()')
       except BaseException as e:error=e;visit['failure']=repr(e);raise
       finally:
        try:
         if trace.active:trace.finish()
        except BaseException as e:
         visit['traceFailure']=repr(e)
         if error is None:raise
        finally:visit['trace']=trace.summary;write(report,result)
       validate_visit(visit,markers);assert not result['pageErrors']
       visit['completed']=True;write(report,result);print(f'run{run} browser{browser_run} unit{unit}: proto/JSON verified; {len(markers)} names',flush=True)
       if browser_run:page.evaluate('()=>{rafPhaseMonitor.running=false;cancelAnimationFrame(rafPhaseMonitor.handle);releaseWholeGameCpu()}')
      finally:page.close()
    finally:browser.close()
  samples=[s for v in result['visits'] for s in v['samples']]
  assert len(result['visits'])==10 and all(v.get('completed') for v in result['visits']) and len(samples)==64 and sum(not s['warmup'] for s in samples)==48
  result.update(status='completed',formalClicks=48,warmupClicks=16)
 except BaseException as e:result.update(status='failed',failure=repr(e));raise
 finally:write(report,result);server.shutdown();server.server_close()
if __name__=='__main__':main()
