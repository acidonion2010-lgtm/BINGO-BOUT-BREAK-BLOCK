#!/usr/bin/env python3
"""Summarize fixed native experiment, retaining every conditional run result."""
import argparse
import json
from pathlib import Path


def main():
    parser=argparse.ArgumentParser();parser.add_argument('input',type=Path);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();assert not args.output.exists(),'Refuse overwrite'
    csv_path=args.output.with_suffix('.csv')
    assert csv_path!=args.output and not csv_path.exists(),'Refuse overwrite CSV or JSON/CSV path collision'
    data=json.loads(args.input.read_text());assert data['status']=='completed' and len(data['rows'])==24
    groups={}
    for row in data['rows']:
        key=(row['firstPlayer'],row['scenario'],row['role'])
        groups.setdefault(key,[]).append(row)
    results=[]
    for (first,scenario,role),rows in sorted(groups.items()):
        assert len(rows)==6 and sorted(r['run'] for r in rows)==list(range(1,7))
        result={'firstPlayer':first,'scenario':scenario,'role':role,'comparisons':{}}
        for comparison in rows[0]['comparisons']:
            values=[{'run':r['run'],**r['comparisons'][comparison]} for r in sorted(rows,key=lambda r:r['run'])]
            labels=[v['interval']['classification'] for v in values]
            medians=[v['pairedMedianDeltaUs'] for v in values]
            counts={key:labels.count(key) for key in ['negative','unconfirmed','positive']}
            result['comparisons'][comparison]={'runs':values,'classificationCounts':counts,
                'repeatedClassification':labels[0] if len(set(labels))==1 else 'unconfirmed',
                'pairedMedianRangeUs':[min(medians),max(medians)]}
        results.append(result)
    output={'completed':True,'conditions':4,'independentBrowserRuns':6,'timedChoices':data['timedChoicesExecuted'],
        'primaryComparisons':data['primaryComparisons'],'diagnosticComparisons':data['diagnosticComparisons'],
        'functionalEquivalence':data['functionalEquivalence'],'old104ConditionRecordsReclassified':False,
        'strictAllPathsNonRegressionConfirmed':False,'results':results,
        'limitations':['Per-run intervals describe dependent within-browser batches.','No pooling with historical data or A/A subtraction.','Repeated classification is descriptive; it is not a simultaneous or all-path guarantee.']}
    args.output.write_text(json.dumps(output,ensure_ascii=False,indent=2))
    import csv
    with csv_path.open('w',newline='') as f:
        writer=csv.writer(f)
        writer.writerow(['firstPlayer','scenario','role','comparison','scope','run','deltaUs','lowUs','highUs','classification'])
        primary={'-to-'.join(pair) for pair in data['primaryComparisons']}
        for result in results:
            for comparison,value in result['comparisons'].items():
                for run in value['runs']:
                    low,high=run['interval']['boundsUs']
                    writer.writerow([result['firstPlayer'],result['scenario'],result['role'],comparison,
                        'primary' if comparison in primary else 'diagnostic',run['run'],run['pairedMedianDeltaUs'],
                        low,high,run['interval']['classification']])
    for r in results:
        print('P'+str(r['firstPlayer']),r['scenario'],r['role'])
        for c,v in r['comparisons'].items():print(c,v['classificationCounts'],'pairedMedianRangeUs',v['pairedMedianRangeUs'])


if __name__=='__main__':main()
