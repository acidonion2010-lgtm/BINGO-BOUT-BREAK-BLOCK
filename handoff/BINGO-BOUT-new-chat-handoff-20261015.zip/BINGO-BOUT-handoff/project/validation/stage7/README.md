# Verification 7: causal probes

The received production HTML is still the frozen stage5 HTML. The immutable
GitHub handoff commit is recorded in `../../github-handoff.json`; this round does
not replace it unless production HTML actually changes. Source snapshots and
earlier reports remain intact.

Use Node, Python Playwright and `/usr/bin/chromium`. Run browser/CPU measurements
sequentially without other CPU work. From the `bingo-refactor` directory:

```bash
# Raw DP binaries are excluded from delivery ZIPs. Regenerate if absent:
python3 validation/capture.py index.before.html validation/before --repeats 1 --port 8004
node validation/stage7/gap_causality.cjs --benchmark
python3 validation/stage7/chrome_gap.py
python3 validation/stage7/trace_response.py index.before.html index.html validation/stage7/traced-response --trials 8
python3 validation/stage7/analyse_trace.py validation/stage7/traced-response
```

The Node probe switches six methods on the same receiver, arrays and child value
tables. It verifies Object.is equality and benchmarks the real two-action late
BLOCK input along with synthetic inputs. This is a Node VM diagnostic, not an
application or Chrome selector benchmark. `certified` counts normal returns;
the added probe does not independently assert a gap upper bound for every case.
The small-count gap candidate remains probe code only.
The 66 solveState cases include 32 saved nonterminal fixtures plus a repeated
target fixture, each tested with and without a requested strategy. This is not
a count of 66 distinct public board states.

The Chromium method-swap probe loads the current HTML in two fresh browsers.
The production DP is prepared by a real Worker; one fixed nonterminal P1 late
BLOCK/HARD full-DP input is used. It times 3,600,000 selector calls across five
comparisons, including same-reference A/A. State, receiver, arrays, child tables
and random roll are shared within each run; six method references are installed
outside timing. Initial order and comparison order reverse on the second run.
Untimed Object.is policy equality, RNG consumption, checksum, branch counters
and history invariants are verified. Own method installation and JIT history
differ from unmodified production/earlier two-realm comparisons. This is a fixed
selector contract, not actual match progression, cold cost or trusted input.
Raw paired deltas are retained; mixed signs do not cancel earlier observations.

The trace harness records 32 trusted accepted clicks and four separate untraced
warmups. It uses one visible foreground headless page, ordinary HTTP, a real Blob
Worker, and the same HARD/first-player-1 middle fixture as previous diagnostics.
Normal locator input and RAF/timer/CDP input each visit both versions once.
Tracing begins after fixture/descriptor work and ends after the observed second
RAF callback. CDP trial actionability and hover preparation are before tracing;
the ordinary locator's internal actionability wait and mouse move are within
tracing. Trace timing is a separate diagnostic condition;
it must not be pooled with earlier untraced timings or treated as a speed PASS.

The game sound/BGM flags and AudioContext processing remain active. Playwright's
headless launch includes `--mute-audio`; speakers and physical presentation are
not verified. There is no production change to sound, animation or rendering.

`analyse_trace.py` verifies stored trace hashes, marker identity, clock domain,
same CrRendererMain pid/tid and monotonic wall/thread CPU windows. Trace `ts`
and `tts` are microseconds. Primary differences use matching PerformanceMark
events; console TimeStamp differences are retained separately. The two events
occur at different points and have measurable instrumentation/scheduling cost.
Of 128 page/trace startTime comparisons, 27 differ by one floating-point ULP
(at most 9.094947017729282e-13 ms) across their JSON paths. The initial strict
metadata equality failure is retained in `clock-serialization-review.json`.
The correspondence check allows one ULP and never adjusts ts/tts, application
timings or performance acceptance criteria.

Wall time minus renderer main-thread CPU time includes normal frame waiting,
blocking and time not scheduled. It does not identify which reason occurred,
measure other browser threads, or explain historical untraced differences.
Nested X event intervals are clipped and unioned; category totals overlap and
must not be added. There are no RunTask/OS scheduler-switch records in this
capture, so uncovered timeline intervals are not proof of idle. Shared cgroup
counter deltas are recorded outside click timing and are not per-browser CPU
attribution. No A/A subtraction or noise-based acceptance threshold is used.

See `../../未完了検証7結果.md`, `gap-findings.md`,
`trace-findings-review.md`, `trace-analysis.json` and `trace-analysis.csv`.
Functional verification exit status and universal non-regression status are
separate; the latter remains unconfirmed.
