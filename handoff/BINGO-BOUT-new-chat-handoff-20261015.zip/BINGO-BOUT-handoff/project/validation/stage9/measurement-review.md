# Selector measurement review (stage9)

This review reads the stage3/stage6 harnesses, their stored results, the frozen
HTML sources, and the stage7 method-swap diagnostic. It does not run a browser or
benchmark, modify production, or revise earlier results. Production SHA-256 was
rechecked as `fea09e995bfc1036515b92771925bd7968f3c453425ea5517b7a5b480293be64`;
the original is `e872443dc9764f3b9647f4797d1411ca98f865b9c2f69c6e694529e2685cd3a9`.

## Findings that change the next experiment

1. **One strict positive boundary is floating-point cancellation at the observed
   timer grid.** In `stage6/selector-performance.json`, P2 middle BREAK
   `hard-fallback-legacy-roll`, run1 batch2, the elapsed durations are
   `47.899999998509884` and `47.90000000037253` ms. Both are 479 apparent 0.1 ms
   ticks. Their paired difference is `9.313225746154786e-11` microseconds per
   decision. This observation becomes the pooled interval's lower endpoint
   (`9.313253293563584e-11` after the harness's normalization/subtraction order),
   which is classified as positive by `low > 0` at
   `stage3/frame_performance.py:212`. The same phenomenon occurs in the A/A
   control: P2 one-closed BLOCK `hard-fallback-legacy-roll`, run2 batch9,
   `36.79999999888241` versus `36.80000000074506` ms, both 368 apparent ticks.
   Its run2 lower endpoint is positive by about `9.3132e-11` microseconds.
   Thus these two strict-sign labels must not be read as resolved positive timer
   ticks. This explains a boundary label, not the median timing differences.
   The other four pooled-positive A/B lower endpoints are at least approximately
   one 0.1 ms batch tick (`0.005` microseconds per decision). Preserve every raw
   result and report this arithmetic limitation separately; it supplies no
   performance allowance and does not establish a non-regression PASS.

2. **No cooldown/history drift or counter boundary explains the five differences.**
   `configure` resets both cooldowns to zero and the six history fields once per
   condition (`stage3/frame_performance.py:96-107`). The loop only calls the
   selector and adds an integer checksum (`:123-138`); it does not update marks
   or call `rememberCpu*Result`. Selector cooldown operations decrement only
   positive values (`index.html:4471`, `:4530`, `:5688`). Counters deliberately
   accumulate through 1 probe + 20,000 initial warmup + 9 × (2,000 warmup +
   20,000 measured) = 218,001 calls. Stored focus-case counters and history agree
   with that count and stay far below integer representation boundaries. No
   counter-dependent selection branch was found.

3. **The four legacy cases have no differing legacy implementation to isolate.**
   `stage6/source-integrity.json` records identical dispatch/legacy functions.
   Direct source inspection additionally confirmed identical
   `getCellWeights`/`weightedRandomChoice`, `cpuSelectSmartCell` through the memory
   helpers, and `takeCpuEqMixRoll` through `selectCpuBlockCell` in both HTML files.
   The refactor changes preparation and the full-DP machinery, so global heap,
   code layout, receiver shape and optimization history can still differ. Text
   identity alone does not prove identical machine code or equal runtime cost.
   There is no evidence here identifying one of those mechanisms as the cause.

4. **Constant RNG is a narrow, correlated workload, not native RNG performance.**
   The same mutable closure supplies every `Math.random` call in a condition
   (`stage3/frame_performance.py:53-55`, `:93`). For hard legacy, `.3` selects
   legacy at the `.7` mixture threshold and also selects the sorted top pool at
   the hard `.48` threshold (`index.html:4423`, `:5720`). Middle/opening hard
   legacy never visits the no-sort branch. Retry and successful-block history
   branches are inactive because cooldowns are zero. The expected RNG consumption
   per decision in these fixtures is normal 3, hard legacy 4, hard full 2,
   master ready/fallback 1. Identical selected cells do not verify those call
   counts; an untimed trace can. Replacing RNG changes this benchmark's execution
   and optimization conditions relative to gameplay, equally in intended source
   form but potentially with separate per-realm feedback.

5. **Repeated batches can include GC/JIT effects without any application drift.**
   Legacy BREAK eagerly computes `getCellWeights` during candidate preparation
   even at zero cooldown (`index.html:4460-4469`), then computes it again for
   selection (`:4416`, `:5696`). Array/set creation, filtering, mapping and
   sorting recur. Full-DP selection reruns `analyze` and rewrites solver scratch
   arrays. The integer checksum has a small exact range (at most 180,000), so its
   arithmetic does not overflow; it does not remove allocation or collection.
   Warmup, verification-object creation and the other realm's prior allocation
   can affect subsequent samples. Alternation improves balance but does not
   isolate or identify such effects. No forced GC is recommended for the primary
   diagnostic because that would define another workload.

## Harness boundaries and limits

- Timing covers `loop(count)` and its returned checksum object; legality checks,
  counter/history serialization and equality checks occur afterwards
  (`stage3/frame_performance.py:156-168`). Worker and fallback preparation are
  outside the selector measurement. The timed result remains a hot repeated
  selector contract, not input-to-paint latency or match progression.
- Initial frame creation, left/right placement and first paired order reverse
  together between only two processes (`:296-318`, `:365-366`). These are aliased
  factors, not independently tested causes. Nine pairs give a 5/4 first-position
  imbalance per run; the second run reverses it. All scenario/path/first-player
  traversal orders remain fixed. The A/A focus harness also omits non-focus
  warmups/measurements, so its JIT and allocation history differs from the full
  A/B matrix. A/A cannot be subtracted from those historical A/B samples.
- The checksum plus last-cell test can miss different intermediate selections
  whose sums cancel (`:164-166`). Equality of final counters/history across
  versions likewise is weaker than asserting the intended per-call path. In
  these deterministic, zero-cooldown fixtures no actual violation was found.
  Strengthen untimed audits, without silently expanding timed-loop overhead.
- The median interval calculation is a correct order-statistic calculation
  under its stated independent/exchangeable observation assumption. Consecutive
  batches in one process do not establish that assumption. Eighteen pooled
  batches are not eighteen independent browser runs; selecting five cases after
  observing 104 pooled comparisons is exploratory. Existing files disclose
  these limitations. No revised acceptance threshold follows from this review.
- The readiness poll has no timeout in stage3 (`:79-85`); a stalled Worker can
  hang a future run. Add a finite diagnostic deadline to a new harness. This is
  a liveness issue, not an explanation of completed measurements.

## Finite causal follow-up

Prefer a new standalone diagnostic rather than rerunning the same two-realm A/A.
Keep earlier files and the production SHA frozen. Predeclare four fresh browser
runs: original HTML host, current HTML host, then both hosts with reversed
variant/fixture order. Use one normally loaded foreground realm in each run,
the five existing focus cases, a real preparation, and a fixed finite number of
balanced blocks. Stop at the declared count even if signs remain mixed.

1. Before timing, audit 16 individual decisions for each fixture. Assert every
   selected cell, marks/layout/reference invariants, all six history fields,
   exact expected dispatch-count increments and RNG-call counts. Reset counters,
   history and solver scratch arrays outside each measured arm, as stage7 does.
   Keep the same input arrays, receiver, value tables and RNG function object
   within a realm. Record arm/source/reference identity and reset evidence.

2. For the P1 late BLOCK hard-full case, make host source and six-method source
   separate factors. Compile original and current method bundles in each host
   realm and install each on that host's same prepared DP receiver, outside
   timing. Include a same-reference A/A arm. Check `Object.is` policy/gap/P/Q
   equality before measuring. Establish compatible fields (including
   `monotone=false`) before all arms, not during a sample. Both method versions
   must see identical own-property installation and warmup schedules. This
   extends stage7's current-host-only crossover to the original host, allowing
   a method effect, host effect, or interaction to be described separately.

3. For the four legacy cases, original/current source is identical. Use one
   canonical complete legacy dependency bundle with verified hashes, compiled
   twice inside each host realm, plus a same-reference control. Run both copies
   against that realm's same state and stable RNG function. This is explicitly
   a function-identity/compilation control, not two different algorithms. Include
   native untouched entry points as a distinct arm if comparing with historical
   production behavior. A foreign function reference keeps its originating
   lexical globals: copying it to another window does not make it read the
   target window's state. Compile locally or supply every dependency explicitly.

4. Use fixed balanced sequences such as ABBA then BAAB, reversing the initial
   sequence and bundle compilation order in the second run of each host. Keep
   per-run/per-host raw results; do not combine blocks into pretend process
   replication. A small prespecified batch-size pair (e.g. 2,000 and 20,000)
   can reveal dependence on sustained allocation cadence, but must be reported
   as a separate factor and included in the initial finite workload budget.
   If this would exceed that budget, prioritize the host × method crossover
   and leave the batch-size check explicitly unrun.

5. Store raw `performance.now()` start/end values, `performance.timeOrigin`,
   count and derived elapsed values. Document observed timer granularity in
   untimed setup. A separately named integer-unit/tick diagnostic can expose
   apparent ties and cancellation, preserving raw values and prespecifying its
   representation. It must not become an epsilon-based performance allowance,
   silently rewrite old intervals, or certify equality below timer resolution.

An effect following original/current methods within the same receiver provides
more specific evidence than a two-realm difference. An effect following the host
while identical legacy text and method arms do not follow implementation instead
narrows the issue to context/preparation/optimization conditions; it still does
not identify a particular GC or JIT mechanism. Any method crossover changes
property ownership and optimization history, so it remains a causal diagnostic
of the fixed selector workload, not a substitute for application validation.
Mixed or unresolved findings justify retaining the existing unconfirmed status,
not further repetition until a preferred sign appears. Stage8 commit waits and
physical presentation remain separate questions.
