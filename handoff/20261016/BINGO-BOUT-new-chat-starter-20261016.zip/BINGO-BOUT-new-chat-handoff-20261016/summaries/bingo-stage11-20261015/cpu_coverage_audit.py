#!/usr/bin/env python3
"""Audit saved candidate-event CPU coverage without changing formal analyses.

The upper envelope is a clock-model calculation, not a strict physical bound.
No browser, benchmark, classifier change or missing-duration imputation occurs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics


def merge_intervals(intervals):
    """Return the union of finite, ordered, positive-length intervals."""
    checked = []
    for interval in intervals:
        if len(interval) != 2:
            raise ValueError(f"Expected an interval pair: {interval!r}")
        start, end = interval
        if any(isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value)
               for value in (start, end)) or end < start:
            raise ValueError(f"Invalid interval: {interval!r}")
        if end > start:
            checked.append((start, end))
    result = []
    for start, end in sorted(checked):
        if result and start <= result[-1][1]:
            result[-1] = (result[-1][0], max(result[-1][1], end))
        else:
            result.append((start, end))
    return result


def subtract_intervals(source, covered):
    """Set difference of interval unions; touching endpoints have zero measure."""
    source = merge_intervals(source)
    covered = merge_intervals(covered)
    result = []
    first = 0
    for start, end in source:
        cursor = start
        while first < len(covered) and covered[first][1] <= cursor:
            first += 1
        index = first
        while index < len(covered) and covered[index][0] < end:
            cover_start, cover_end = covered[index]
            if cover_start > cursor:
                result.append((cursor, min(cover_start, end)))
            cursor = max(cursor, cover_end)
            if cursor >= end:
                break
            index += 1
        if cursor < end:
            result.append((cursor, end))
    return result


def duration_ms(intervals):
    return sum(end - start for start, end in intervals) / 1000


def audit_group(events, marker_cpu_bounds_valid):
    clocked = [event for event in events if event["cpuIntervalUnavailableReason"] is None]
    missing = [event for event in events if event["cpuIntervalUnavailableReason"] is not None]
    clocked_wall = merge_intervals(event["clippedWallIntervalUs"] for event in clocked)
    missing_wall = merge_intervals(event["clippedWallIntervalUs"] for event in missing)
    uncovered = subtract_intervals(missing_wall, clocked_wall)
    enclosed = [event for event in missing
                if not subtract_intervals([event["clippedWallIntervalUs"]], clocked_wall)]
    cpu = merge_intervals(event["clippedThreadCpuIntervalUs"] for event in clocked
                          if event["clippedThreadCpuIntervalUs"] is not None)
    # A known zero-length CPU interval is available even though it contributes
    # nothing to the positive-length interval union. Missing markers stay unknown.
    cpu_available = marker_cpu_bounds_valid and bool(clocked)
    observed_cpu_ms = duration_ms(cpu) if cpu_available else None
    uncovered_ms = duration_ms(uncovered)
    return {
        "candidateEventCount": len(events),
        "clockedCandidateEventCount": len(clocked),
        "missingClockCandidateEventCount": len(missing),
        "missingEventsFullyEnclosedByClockedWallUnion": len(enclosed),
        "missingEventsNotFullyEnclosedByClockedWallUnion": len(missing) - len(enclosed),
        "clockedWallUnionMs": duration_ms(clocked_wall),
        "missingClockWallUnionMs": duration_ms(missing_wall),
        "uncoveredWallMs": uncovered_ms,
        "observedCpuUnionMs": observed_cpu_ms,
        "modelBasedUpperEnvelopeMs": observed_cpu_ms + uncovered_ms if observed_cpu_ms is not None else None,
        "modelEnvelopeWidthMs": uncovered_ms if observed_cpu_ms is not None else None,
        "allMissingEventWallCovered": bool(events) and not uncovered,
        "markerCpuBoundsValid": marker_cpu_bounds_valid,
        "clockedWallUnionIntervalsUs": clocked_wall,
        "missingClockWallUnionIntervalsUs": missing_wall,
        "uncoveredWallIntervalsUs": uncovered,
        "observedCpuUnionIntervalsUs": cpu,
        "fullyEnclosedMissingEventTraceIndices": [event["traceIndices"] for event in enclosed],
    }


def _stats(values):
    present = [value for value in values if value is not None]
    return {"n": len(present), "missing": len(values) - len(present),
            "min": min(present) if present else None,
            "median": statistics.median(present) if present else None,
            "max": max(present) if present else None}


def audit_saved_results(results_path):
    results_path = Path(results_path)
    contents = results_path.read_bytes()
    formal = json.loads(contents)
    if formal.get("status") != "completed":
        raise ValueError("Coverage audit requires completed saved results")
    output = {
        "status": "completed", "input": str(results_path),
        "inputSha256": hashlib.sha256(contents).hexdigest(),
        "auditScriptSha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "formalAnalyserSha256": formal.get("analyserSha256"),
        "formalPlanSha256": formal.get("planSha256"),
        "method": {
            "classification": "Use only the formal selectedEventMetadata roles; no classifier expansion.",
            "clockedEvent": "Formal cpuIntervalUnavailableReason is null; zero CPU duration remains available.",
            "uncoveredWall": "Union of missing-clock candidate wall intervals minus union of clocked candidate wall intervals, on the same Worker thread.",
            "upperEnvelope": "Observed CPU interval union plus uncovered wall duration, calculated within each sample/group.",
            "interpretation": "Model-based upper envelope only, not a strict physical bound or an imputed event duration.",
        },
        "limitations": [
            "The model assumes monotonic aligned wall/thread-CPU clocks and CPU intervals nested consistently with wall intervals.",
            "Finite clock resolution and separate timestamp sampling can violate exact containment or CPU<=wall arithmetic at boundaries.",
            "Enclosure by clocked candidate wall intervals can avoid adding already-covered child work; it does not recover that child's missing CPU timestamps.",
            "The envelope covers only formally selected candidate intervals, not unrecorded GC/JIT, unsupported categories or background threads.",
            "Missing event clocks remain missing. Formal cpuUnionMs nulls and formal source/results/summary files are unchanged.",
            "These are diagnostic coverage descriptions, not performance comparisons, a tolerance or evidence of strict non-regression.",
        ],
        "samples": [],
    }
    for row in formal["samples"]:
        analysis = row["analysis"]
        selected = analysis["selectedEventMetadata"]
        groups = {
            "gc": [event for event in selected if "gc" in event["roles"]],
            "jit": [event for event in selected if "jit" in event["roles"]],
            "combined": [event for event in selected if set(event["roles"]) & {"gc", "jit"}],
        }
        output["samples"].append({
            **{key: row[key] for key in ("id", "run", "round", "arm") if key in row},
            "pid": analysis["pid"], "tid": analysis["tid"],
            "formalEventParsingComplete": analysis.get("eventParsingComplete"),
            "groups": {name: audit_group(events, analysis["availability"]["cpuBoundsValid"])
                       for name, events in groups.items()},
        })
    output["sampleCount"] = len(output["samples"])
    output["aggregateCoverageDescription"] = {
        name: {
            **{key: _stats([row["groups"][name][key] for row in output["samples"]])
               for key in ("uncoveredWallMs", "observedCpuUnionMs", "modelBasedUpperEnvelopeMs",
                           "missingClockCandidateEventCount", "missingEventsFullyEnclosedByClockedWallUnion")},
            "samplesWithAllMissingEventWallCovered": sum(row["groups"][name]["allMissingEventWallCovered"]
                                                         for row in output["samples"]),
        } for name in ("gc", "jit", "combined")
    }
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results_json", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = audit_saved_results(args.results_json)
    # Exclusive creation protects both existing audits and formal inputs.
    with args.output.open("x") as handle:
        handle.write(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"sampleCount": result["sampleCount"],
                      "coverage": result["aggregateCoverageDescription"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
