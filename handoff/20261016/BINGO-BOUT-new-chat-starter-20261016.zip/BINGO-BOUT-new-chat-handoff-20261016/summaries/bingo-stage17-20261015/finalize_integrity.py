#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(n):return json.loads((R/n).read_bytes())
def main():
 report=read('report.json');failed=read('preflight-failed-report.json');analysis=read('unit-analysis.json');configs=read('config-post-review.json');sql=read('official-sql-summary.json');independent=read('post-run-independent-check.json')
 assert report['status']=='completed' and report['formalClicks']==48 and report['warmupClicks']==16 and len(report['visits'])==10
 assert failed['status']=='failed' and len(failed['visits'])==2 and 'actual CPU counter unit differs from requested unit' in failed['failure']
 assert failed['scriptSha256']==sha(R/'capture_units.py') and failed['planSha256']==sha(R/'PLAN.md')
 assert report['priorAttempt']['reportSha256']==sha(R/'preflight-failed-report.json')
 assert report['scriptSha256']==sha(R/'resume_capture.py') and report['amendmentSha256']==sha(R/'PLAN_AMENDMENT.md') and report['planSha256']==sha(R/'PLAN.md')
 for v in report['visits']:
  run=v['run'];assert v['completed'] and v['selfTests']=={'passed':322,'total':322,'failures':[]}
  assert v['trace']['integrityChecksPassed'] and v['trace']['sha256']==sha(R/f'run{run}.pftrace') and v['trace']['bytes']==(R/f'run{run}.pftrace').stat().st_size
  assert v['conversion']['sha256']==sha(R/f'run{run}.json')
  expected=sha(R/('capture_units.py' if v['preflight'] else 'resume_capture.py'));assert v['captureScriptSha256']==expected
  if v['preflight']:
   prior=failed['visits'][run]
   for key in ['trace','conversion','before','after']:assert prior[key]==v[key]
   assert v['correctedPreflightGatePassed'] and v['rawGate']['effectiveMultipliers']==[v['unit']]
 assert not report['pageErrors']
 assert analysis['scriptSha256']==sha(R/'analyze_counter_units.py') and analysis['reportSha256']==sha(R/'report.json')
 assert analysis['analysisPlanSha256']==sha(R/'ANALYSIS_PLAN.md') and analysis['analysisAmendmentSha256']==sha(R/'ANALYSIS_AMENDMENT.md')
 assert configs['allGatesPass'] and configs['onlyKnownSettingDifferenceIsRequestedUnit'] and configs['sourceReportSha256']==sha(R/'report.json')
 assert configs['scriptSha256']==sha(R/'review_effective_config.py') and configs['checkerSha256']==sha(R/'check_effective_config.py')
 assert sql['reportSha256']==sha(R/'report.json') and sql['scriptSha256']==sha(R/'extract_sql.py') and sql['toolSha256']==sha(R/'tools/trace_processor_shell')
 assert independent['status']=='completed' and independent['reportSha256']==sha(R/'report.json')
 assert sha(R/'reference/raw_counter_check.py')=='91762a94d1e1e05305c2a11fbb237dd4b42bffd3ebb5162f48c4cec42b038c23'
 for v in analysis['visits']:
  run=v['run'];assert v['completed'] and v['counterMultisetsEqual'] and v['requestedMultiplierExact']
  assert v['counts']['jsonCompleteMissingSql']==0
  assert v['ledgerSha256']==sha(R/f'raw-counter-run{run}.json') and v['sqlSlicesSha256']==sha(R/f'official-sql/run{run}-slices.csv') and v['sqlCountersSha256']==sha(R/f'official-sql/run{run}-counters.csv')
 conditions={c['unit']:c for c in analysis['conditions'] if not c['preflight']}
 assert conditions[1000]['counts']['sqlCpuExcessOver1ms']==32 and conditions[1]['counts']['sqlCpuExcessOver1ms']==0
 assert conditions[1000]['rawPairCoverageLargeSql']['uniqueAcrossEpoch']==32 and conditions[1000]['rawPairCoverageLargeSql']['uniqueWithClearInside']==32
 assert sum(c['markerChecksPassed'] for c in conditions.values())==512
 assert 'Verified 480 files: all SHA-256 hashes match.' in (R/'original-preservation.log').read_text()
 lines=(R/'stage16-preservation.log').read_text().splitlines();assert len(lines)==269 and all(x.endswith(': OK') for x in lines)
 assert not (R/'repository-status.txt').read_text()
 assert sha(R/'index.original.html')=='e872443dc9764f3b9647f4797d1411ca98f865b9c2f69c6e694529e2685cd3a9' and sha(R/'index.html')=='59fff4685ff3f36e18d73fe9fa524ee57d81a348352e7b2912db4b7ecc1bb513'
 assert (R/'POST_RUN_REVIEW.md').is_file()
 sources=[{'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((R/'official-sources').rglob('*')) if p.is_file()]
 (R/'source-inventory.json').write_text(json.dumps(sources,indent=2)+'\n')
 out={'status':'completed','stage':17,'clientStartDate':'2026-10-15','freshBrowserProcesses':5,'preflightVisits':2,'preflightCapturesRepeatedAfterGateFailure':0,'formalVisits':8,'formalClicks':48,'warmupClicks':16,'normalLoads':10,'selfTestsPassed':3220,'realWorkerPreparations':8,'rawProtoFiles':10,'rawProtoBytes':sum(v['trace']['bytes'] for v in report['visits']),'sameProtoJsonBytes':sum(v['conversion']['bytes'] for v in report['visits']),'jsonEvents':sum(v['conversion']['events'] for v in report['visits']),'initialPreflightGateFailurePreserved':True,'rawZeroMultiplierMeansEffectiveOne':True,'formalSqlCpuSlicesByUnit':{str(u):c['counts']['sqlCompleteWithCpu'] for u,c in conditions.items()},'formalSqlStrictCpuExcessByUnit':{str(u):c['counts']['sqlStrictCpuGreaterThanWall'] for u,c in conditions.items()},'formalSqlCpuExcessOver1msByUnit':{str(u):c['counts']['sqlCpuExcessOver1ms'] for u,c in conditions.items()},'formalLargeUnit1000AcrossClear':32,'unit1AcrossClearUniqueRawCpuSlices':19,'unit1MaximumSqlCpuExcessNs':129988,'allCounterMultisetsEqual':True,'rawCpuSamplesMatched':sum(v['rawThreadTimeSamples'] for v in analysis['visits']),'allEffectiveConfigGatesPassed':True,'formalMarkerCpuEndpointsMatched':512,'formalMarkerWindows':288,'warmupMarkerWindows':96,'formalMarkerStrictExcessUnit1':2,'formalMarkerMaximumExcessUnit1Us':1,'markerWindowsCpuExcessOver1ms':0,'outerSnapshotsActions':66,'outerSnapshotCpuExcess':0,'strictCpuAccountingConfirmed':False,'historicalCpuExcessSoleCauseConfirmed':False,'applicationChanged':False,'originalManifestFilesUnchanged':480,'stage16ManifestFilesUnchanged':269,'mainRepositoryWorkingTreeClean':True,'old104ConditionsReclassified':False,'oldUnconfirmedConditions':62,'strictAllPathsNonRegressionConfirmed':False,'sourceInventoryFiles':len(sources)}
 (R/'integrity.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
