'use strict';
// Browser comparison oracle: the original functions from loader.cjs, without UI.
const fs = require('node:fs');
const {load, rng} = require('./loader.cjs');
const input = JSON.parse(fs.readFileSync(0, 'utf8'));
const {api, sha256} = load();
const rows = [];
for (const firstPlayer of [1, 2]) {
  const dp = new api.WholeGameDP({...input.config, firstPlayer});
  const stats = dp.solve();
  for (const fixture of input.fixtures.filter(x => x.firstPlayer === firstPlayer)) {
    const state = fixture.state;
    Object.assign(api.state, state);
    api.setDp(fixture.difficulty === 'normal' ? null : dp);
    api.setRandom(rng(fixture.seed));
    const opens = state.p2Marks.flatMap((x, i) => x ? [] : [i]);
    const cell = fixture.role === 'break'
      ? api.selectCpuBreakCell(opens)
      : api.selectCpuBlockCell(api.state.p1Marks, api.state.p1NumberLayout);
    rows.push({id: fixture.id, cell, counters: api.counters(), memory: {
      cpuBlockedCooldown: api.state.cpuBlockedCooldown,
      cpuSuccessfulBlockCooldown: api.state.cpuSuccessfulBlockCooldown,
    }});
  }
}
process.stdout.write(JSON.stringify({sha256, rows}));
