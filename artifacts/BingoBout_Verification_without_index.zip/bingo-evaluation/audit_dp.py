#!/usr/bin/env python3
"""Independent generic LP checks and final-two-turn game recursion.

Requires numpy and scipy; never imports or translates WholeGameDP's matrix solver.
"""
import json
import sys
import time
from functools import lru_cache
from itertools import combinations
from pathlib import Path

import numpy as np
import scipy
from scipy.optimize import linprog


def solve_matrix(a):
    a = np.asarray(a, dtype=float)
    n, m = a.shape
    # Affine normalization preserves strategies and avoids asking HiGHS to
    # resolve 1e-9 payoff differences atop an approximately 1000 offset.
    lower, upper = float(np.min(a)), float(np.max(a))
    scale = upper - lower
    if scale == 0:
        return lower, np.full(n, 1.0 / n)
    offset = lower + scale / 2
    normalized = (a - offset) / scale
    # Generic maximizer row-player LP: maximize v, A^T p >= v.
    c = np.r_[np.zeros(n), -1.0]
    result = linprog(c, A_ub=np.c_[-normalized.T, np.ones(m)], b_ub=np.zeros(m),
                     A_eq=np.array([np.r_[np.ones(n), 0.0]]), b_eq=[1.0],
                     bounds=[(0.0, None)] * n + [(None, None)], method="highs",
                     options={"dual_feasibility_tolerance": 1e-9,
                              "primal_feasibility_tolerance": 1e-9})
    if not result.success:
        raise RuntimeError(result.message)
    return float(result.x[-1]) * scale + offset, result.x[:-1]


def local_matrix(pay, stay):
    a = np.repeat(np.asarray(pay, float)[:, None], len(pay), axis=1)
    np.fill_diagonal(a, stay)
    return a


LINES = [(0, 1, 2), (3, 4, 5), (6, 7, 8), (0, 3, 6),
         (1, 4, 7), (2, 5, 8), (0, 4, 8), (2, 4, 6)]


def independent_tail(config):
    layouts = [config["layoutP1"], config["layoutP2"]]
    first = config["firstPlayer"]

    @lru_cache(None)
    def score(player, mask):
        scored = set()
        for line in LINES:
            if all(mask & (1 << cell) for cell in line):
                scored.update(line)
        return sum(layouts[player][cell] for cell in scored)

    @lru_cache(None)
    def upper(player, mask, taken):
        closed = [cell for cell in range(9) if not mask & (1 << cell)]
        available = min(9 - taken, max(0, len(closed) - 1))
        return max(score(player, mask | sum(1 << cell for cell in subset))
                   for size in range(available + 1)
                   for subset in combinations(closed, size))

    @lru_cache(None)
    def value(t, m1, m2):
        s1, s2 = score(0, m1), score(1, m2)
        taken1 = (t + 1) // 2 if first == 1 else t // 2
        taken2 = t - taken1
        hi1, hi2 = upper(0, m1, taken1), upper(1, m2, taken2)
        if t >= 18 or (t > 0 and (s1 > hi2 or s2 > hi1 or
                                  (s1 == s2 and hi1 == s1 and hi2 == s2))):
            margin = s2 - s1
            return 1000 * ((margin > 0) - (margin < 0)) + margin
        attacker = first if t % 2 == 0 else 3 - first
        mask = m2 if attacker == 2 else m1
        actions = [cell for cell in range(9) if not mask & (1 << cell)]
        stay = value(t + 1, m1, m2)
        pay = [value(t + 1, m1, m2 | (1 << cell)) if attacker == 2
               else value(t + 1, m1 | (1 << cell), m2) for cell in actions]
        a = local_matrix(pay, stay)
        return solve_matrix(a)[0] if attacker == 2 else -solve_matrix(-a)[0]

    return value


def main():
    start = time.monotonic()
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent / "results"
    records = json.loads((root / "matrix_cases.json").read_text())
    errors, differences, gaps, probability_errors = [], [], [], []
    by_kind = {}
    for index, case in enumerate(records):
        by_kind[case["kind"]] = by_kind.get(case["kind"], 0) + 1
        if "error" in case:
            errors.append({"index": index, "case": case})
            continue
        a = local_matrix(case["pay"], case["stay"])
        value, _ = solve_matrix(a)
        q_value, _ = solve_matrix(-a.T)
        p, q = np.array(case["p"]), np.array(case["q"])
        computed_gap = max(abs(float(np.min(p @ a)) - case["value"]),
                           abs(float(np.max(a @ q)) - case["value"]))
        differences.append(abs(value - case["value"]))
        gaps.append(computed_gap)
        probability_errors.append(max(abs(sum(p) - 1), abs(sum(q) - 1),
                                      max(0, -float(min(p))), max(0, -float(min(q)))))
        if abs(value - case["value"]) > 1e-5 or computed_gap > 1e-5 or abs(value + q_value) > 1e-5:
            errors.append({"index": index, "case": case, "lpValue": value,
                           "lpDualValue": -q_value, "computedGap": computed_gap})
    game_results = json.loads((root / "dp_game_audit.json").read_text())
    tails = []
    for game in game_results["games"]:
        independent = independent_tail(game["config"])
        for state in game["tailStates"]:
            v = independent(state["t"], state["maskP1"], state["maskP2"])
            tails.append({"config": game["config"]["id"], **state,
                          "independentLPValue": v, "absoluteError": abs(v - state["value"])})
    result = {
        "sourceSha256": game_results["sourceSha256"], "python": sys.version,
        "numpy": np.__version__, "scipy": scipy.__version__,
        "lpConditioning": "Affine shift and range normalization; constant matrices solved directly",
        "matrixCases": len(records), "matrixKinds": by_kind,
        "maxMatrixValueAbsoluteError": max(differences, default=0),
        "maxMatrixComputedGap": max(gaps, default=0),
        "maxProbabilityNormalizationError": max(probability_errors, default=0),
        "failuresAbove1eMinus5": errors,
        "independentTailStates": len(tails),
        "maxTailAbsoluteError": max((x["absoluteError"] for x in tails), default=0),
        "tailResults": tails, "seconds": time.monotonic() - start,
    }
    (root / "dp_independent_verification.json").write_text(json.dumps(result, indent=2))
    concise = {k: v for k, v in result.items() if k != "tailResults"}
    print(json.dumps(concise, indent=2))
    return 1 if errors or result["maxTailAbsoluteError"] > 1e-5 else 0


if __name__ == "__main__":
    raise SystemExit(main())
