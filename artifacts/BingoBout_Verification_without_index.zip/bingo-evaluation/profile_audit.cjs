#!/usr/bin/env node
'use strict';
// Exact evaluation of P2 actual/Nash policy against a P1 full-game Nash policy.
const fs=require('node:fs'),path=require('node:path');
const {loadAudit}=require('./audit_cases.cjs');
function fixedProfile(dp,transform){
  const started=performance.now(),layers=dp.layers.map(l=>({values:new Float64Array(l.values.length),wins:new Float64Array(l.values.length),losses:new Float64Array(l.values.length),margins:new Float64Array(l.values.length)}));
  let maxDelta=0;
  for(let t=18;t>=0;t--){
    const base=dp.layers[t],out=layers[t],attacker=dp.attacker[t];
    for(let i1=0;i1<base.n1;i1++)for(let i2=0;i2<base.n2;i2++){
      const m1=base.masks1[i1],m2=base.masks2[i2],ix=i1*base.n2+i2,s1=dp.score1[m1],s2=dp.score2[m2];
      if(dp.isTerminal(t,s1,s2,dp.max1[dp.turns1[t]][m1],dp.max2[dp.turns2[t]][m2])){
        out.values[ix]=dp.terminalValue(s1,s2);out.wins[ix]=s2>s1?1:0;out.losses[ix]=s2<s1?1:0;out.margins[ix]=s2-s1;continue;
      }
      const policy=dp.analyze({t,maskP1:m1,maskP2:m2}),actions=policy.legalActions;
      const cb=dp.layers[t+1],child=layers[t+1],stay=cb.index1[m1]*cb.n2+cb.index2[m2];
      const raw=attacker===2&&transform?transform(policy,dp.resultGap):null;
      const p=raw?actions.map(c=>raw[c]):policy.breakStrategy,q=policy.blockStrategy;
      for(let i=0;i<actions.length;i++){
        const c=actions[i],next=attacker===2?cb.index1[m1]*cb.n2+cb.index2[m2|(1<<c)]:cb.index1[m1|(1<<c)]*cb.n2+cb.index2[m2];
        const blocked=p[i]*q[i],opened=p[i]*(1-q[i]);
        for(const k of ['values','wins','losses','margins'])out[k][ix]+=blocked*child[k][stay]+opened*child[k][next];
      }
      maxDelta=Math.max(maxDelta,Math.abs(base.values[ix]-out.values[ix]));
    }
  }
  const root=layers[0];return {utility:root.values[0],pWin:root.wins[0],pDraw:1-root.wins[0]-root.losses[0],pLoss:root.losses[0],meanMargin:root.margins[0],deltaFromNashValue:root.values[0]-dp.layers[0].values[0],maxStateUtilityDifference:maxDelta,seconds:(performance.now()-started)/1000};
}
function main(){
  const outdir=process.argv[2]||path.join(__dirname,'results');
  const input=JSON.parse(fs.readFileSync(path.join(outdir,'dp_game_audit.json'),'utf8'));
  const {WholeGameDP,cpuBreakSelectionWeights,sourceSha256}=loadAudit(),results=[];
  for(const game of input.games.filter(g=>g.config.id.startsWith('benchmark-'))){
    const dp=new WholeGameDP({...game.config,earlyTermination:true});dp.solve();
    const nashVsNash=fixedProfile(dp,null),actualVsNash=fixedProfile(dp,cpuBreakSelectionWeights);
    const result={config:game.config,nashValue:dp.layers[0].values[0],nashVsNash,actualVsNash};results.push(result);
    process.stdout.write(JSON.stringify(result)+'\n');
    fs.writeFileSync(path.join(outdir,'fixed_profile_verification.json'),JSON.stringify({sourceSha256,description:'Exact expectation with both players using independent draws from fixed state-dependent policies; P1 is unchanged full-game Nash.',results},null,2));
  }
}
module.exports={fixedProfile};if(require.main===module)main();
