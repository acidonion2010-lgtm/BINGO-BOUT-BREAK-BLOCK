# Stage 3 validation

Use the existing checkout/files and installed Python Playwright, Chromium, and Node.
The game still needs only `index.html`; these are development tools, not production
dependencies. Commands below run from `/workspace`. Run browser jobs sequentially
so one job does not contaminate another job's performance samples.

```bash
node bingo-refactor/validation/equilibrium_edges.cjs
python3 bingo-refactor/validation/capture.py bingo-refactor/index.html bingo-refactor/validation/stage3/after --repeats 1 --port 8004
python3 bingo-refactor/validation/compare.py bingo-refactor/validation/before bingo-refactor/validation/stage3/after --output bingo-refactor/validation/stage3/comparison.json
python3 bingo-refactor/validation/worker_lifecycle.py bingo-refactor/index.html --out bingo-refactor/validation/stage3/worker.json
python3 bingo-refactor/validation/performance.py bingo-refactor/index.before.html bingo-refactor/index.html bingo-refactor/validation/stage3/startup-performance.json --port 8004
python3 bingo-refactor/validation/stage3/frame_performance.py bingo-refactor/index.before.html bingo-refactor/index.html bingo-refactor/validation/stage3/frame-performance.json --port 8007
python3 bingo-refactor/validation/stage3/ui_response.py bingo-refactor/index.before.html bingo-refactor/index.html bingo-refactor/validation/stage3/ui-response.json
python3 bingo-refactor/validation/stage3/ui_profile.py
```

If the original DP binary captures are absent after unpacking the ZIP, generate
them before comparison:

```bash
python3 bingo-refactor/validation/capture.py bingo-refactor/index.before.html bingo-refactor/validation/before --repeats 1 --port 8004
```

For real game smoke checks, start the local server in a separate terminal:

```bash
python3 -m http.server 8003 --bind 127.0.0.1 --directory /workspace/bingo-refactor
python3 bingo-refactor/validation/gameplay_smoke.py
```

The method-switch experiments below are exploratory counterfactuals with a single
DP receiver. They isolate solver code but change callsite feedback; final evidence
comes from normally loaded game HTML, not a patched production file.

```bash
python3 bingo-refactor/validation/stage3/isolate_solver.py
python3 bingo-refactor/validation/stage3/isolate_solver.py --output bingo-refactor/validation/stage3/solver-candidates.json --candidates aa,local,split,local_split --count 30000
```

`frame-performance.json` records 128 measured frames of comparison: 64 conditions
in two independent browser runs, plus 16 terminal READY exclusions. Frames here
mean measurement groups, not rendered animation frames. It uses two visible
same-origin iframe realms in one foreground page, reverses creation/placement
and sampling order, and preserves all paired samples, choice checksums, dispatch
counters, and memory/history snapshots. A zero exit status means the measurements
finished and functional assertions passed. The separate strict non-regression flag
is **false**, and must not be treated as a test pass for all performance conditions.

`ui-response.json` contains 108 measured trusted clicks and 12 separately recorded
warmup clicks. The first fixture failure is preserved in
`ui-response-fixture-failure.json`; the start-panel DOM synchronization was fixed
in the harness. Sound and animations remain enabled. Two RAF callbacks do not
measure physical screen presentation or input-device latency.

`ui-profile.json` and `ui-profile/*.cpuprofile` contain a targeted follow-up to the
HARD handler increase. Sampling itself changes timing, so these times are separate
from the unprofiled UI result. Sample attribution below `handleCellClick` is
approximate, not an exact wall-clock breakdown. CPU profiles may be imported into
Chromium DevTools. The direct cause of the +0.45 ms unprofiled handler median change
remains unconfirmed.

See `段階3比較結果.md` and `summary.json` for the current implementation, passed
functional checks, exact numerical/seeded-choice equality, improvements supported
by the measurements, and unresolved performance requirements. All-path or
all-device speed guarantees are not established.
