'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { performance } = require('node:perf_hooks');

const root = path.resolve(__dirname, '../..');
const oldHtml = fs.readFileSync(path.join(root, 'stages/index.stage3.final.html'), 'utf8');
const newHtml = fs.readFileSync(path.join(root, 'stages/index.stage4.html'), 'utf8');
function methodText(html, name, following) {
    const start = html.indexOf(`            ${name}(`);
    const end = html.indexOf(`            ${following}(`, start + 1);
    assert(start >= 0 && end > start);
    return html.slice(start, end).trimEnd();
}

// Both actual methods execute in one VM with one shared topology/workspace.
// Neither a WholeGameDP constructor nor its value-layer solver is invoked.
const realm = vm.createContext({ performance });
vm.runInContext(`
    const beforeMax = ({${methodText(oldHtml, 'buildMaxScores', 'buildLayer')}}).buildMaxScores;
    const afterMax = ({${methodText(newHtml, 'buildMaxScores', 'buildLayer')}}).buildMaxScores;
    const buildScores = ({${methodText(oldHtml, 'buildScores', 'buildMaxScores')}}).buildScores;
    const workspace = {
        lines: [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]],
        closedCount: new Uint8Array(512),
        closedCells: new Uint8Array(512 * 9)
    };
    for (let mask = 0; mask < 512; mask++) {
        for (let cell = 0; cell < 9; cell++) {
            if (!(mask & (1 << cell))) workspace.closedCells[mask * 9 + workspace.closedCount[mask]++] = cell;
        }
    }
    const layouts = [[1,2,3,4,5,6,7,8,9], [8,2,6,1,5,9,4,7,3]];
    const scoreTables = layouts.map(layout => buildScores.call(workspace, layout));
    let tableBuilds = 0;
    function batch(method, calls) {
        let checksum = 0;
        const begin = performance.now();
        for (let call = 0; call < calls; call++) {
            const table = method.call(workspace, scoreTables[call & 1]);
            // A deterministic sample keeps returned tables observable; complete
            // matrix equality is checked independently outside the timed batch.
            checksum += table[call % 10][(call * 37 + 19) & 511];
        }
        const elapsedMs = performance.now() - begin;
        tableBuilds += calls;
        return { elapsedMs, calls, checksum };
    }
    function allEqual() {
        let compared = 0;
        for (const scores of scoreTables) {
            const before = beforeMax.call(workspace, scores);
            const after = afterMax.call(workspace, scores);
            for (let turns = 0; turns < 10; turns++) {
                for (let mask = 0; mask < 512; mask++) {
                    if (!Object.is(before[turns][mask], after[turns][mask])) {
                        throw new Error('Matrix mismatch at turns ' + turns + ', mask ' + mask);
                    }
                    compared++;
                }
            }
        }
        return compared;
    }
    this.bench = { beforeMax, afterMax, batch, allEqual, layouts, getBuilds: () => tableBuilds };
`, realm);
const bench = realm.bench;
const pairs = 11;
const calls = 50;
const warmup = 20;
const started = performance.now();
const comparedBefore = bench.allEqual();
bench.batch(bench.beforeMax, warmup);
bench.batch(bench.afterMax, warmup);

function paired(firstMethod, secondMethod) {
    const results = [];
    for (let pair = 0; pair < pairs; pair++) {
        let first, second;
        if (pair & 1) {
            second = bench.batch(secondMethod, calls);
            first = bench.batch(firstMethod, calls);
        } else {
            first = bench.batch(firstMethod, calls);
            second = bench.batch(secondMethod, calls);
        }
        assert.equal(first.checksum, second.checksum, 'Checksum mismatch');
        assert.equal(first.calls, second.calls, 'Batch count mismatch');
        results.push({ pair: pair + 1, order: pair & 1 ? 'B,A' : 'A,B', aMs: first.elapsedMs, bMs: second.elapsedMs, calls, checksum: first.checksum, ratio: second.elapsedMs / first.elapsedMs });
    }
    return results;
}

// The control's two labels deliberately refer to the exact same function.
const aaControl = paired(bench.beforeMax, bench.beforeMax);
const abComparison = paired(bench.beforeMax, bench.afterMax);
const comparedAfter = bench.allEqual();
assert.equal(comparedBefore, 10240);
assert.equal(comparedAfter, comparedBefore);
assert.equal(bench.getBuilds(), warmup * 2 + pairs * calls * 4);

function median(values) {
    const sorted = values.slice().sort((a, b) => a - b);
    return sorted[sorted.length >> 1];
}
function summary(results) {
    return {
        aBatchMedianMs: median(results.map(row => row.aMs)),
        bBatchMedianMs: median(results.map(row => row.bMs)),
        aPerCallMedianMs: median(results.map(row => row.aMs)) / calls,
        bPerCallMedianMs: median(results.map(row => row.bMs)) / calls,
        pairedRatioMedian: median(results.map(row => row.ratio)),
        pairedRatioMin: Math.min(...results.map(row => row.ratio)),
        pairedRatioMax: Math.max(...results.map(row => row.ratio))
    };
}

const result = {
    passed: true,
    scope: 'Same VM, same workspace/topology, fixed buildScores results, actual old/new buildMaxScores methods only',
    clock: 'node:perf_hooks performance.now native monotonic timer',
    runtime: process.version,
    strictNonRegressionGuarantee: false,
    measuredWholeConstructorOrSolve: false,
    layouts: bench.layouts,
    warmupCallsPerVariant: warmup,
    pairedBatches: pairs,
    callsPerBatch: calls,
    measuredTableBuilds: pairs * calls * 4,
    totalTimedTableBuildsIncludingWarmup: bench.getBuilds(),
    comparedMatrixValuesBeforeAndAfter: comparedBefore + comparedAfter,
    matrixEquality: 'Object.is',
    checksumEquality: true,
    aaControlUsesSameFunctionReference: true,
    aaControl: { summary: summary(aaControl), pairs: aaControl },
    abComparison: { summary: summary(abComparison), pairs: abComparison },
    allocationCountsFromSourcePerCall: {
        note: 'Source-level array construction counts; not process heap or measured GC allocation',
        before: { retainedFloat64Arrays: 10, retainedFloat64Bytes: 40960, transientFloat64Arrays: 513, transientFloat64Bytes: 41040, regularArrays: 513 },
        after: { retainedFloat64Arrays: 10, retainedFloat64Bytes: 40960, transientFloat64Arrays: 0, transientFloat64Bytes: 0, regularArrays: 1 }
    },
    elapsedMs: performance.now() - started
};
const output = path.join(__dirname, 'max-scores-performance.json');
fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n');
process.stdout.write(JSON.stringify({
    output,
    passed: result.passed,
    aaControl: result.aaControl.summary,
    abComparison: result.abComparison.summary,
    totalTimedTableBuildsIncludingWarmup: result.totalTimedTableBuildsIncludingWarmup,
    comparedMatrixValuesBeforeAndAfter: result.comparedMatrixValuesBeforeAndAfter,
    allocationCountsFromSourcePerCall: result.allocationCountsFromSourcePerCall,
    elapsedMs: result.elapsedMs
}, null, 2) + '\n');
