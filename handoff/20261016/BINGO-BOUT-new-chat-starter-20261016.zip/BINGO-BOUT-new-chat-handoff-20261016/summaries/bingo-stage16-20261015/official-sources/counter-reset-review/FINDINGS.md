# Perfetto counter packet-sequence reset audit

Revision: `5dbeaad4ceb91470a835426b52e0cb43a3e5ef10` (google/perfetto).

Scope: read-only official source audit; no browser, DP, performance jobs, builds, or earlier-artifact edits. Newly fetched sources remain byte-for-byte intact with URLs, SHA-256, and license records in `MANIFEST.json`; repository `LICENSE` is retained. Stage15 source files cited below were read in place and all 13 manifest hashes verified unchanged. All 8 newly saved source/license hashes verified.

Paths below are relative to this directory unless prefixed `stage15:`, which means `/workspace/bingo-stage15-20261015/official-sources/perfetto-review/`.

## Counter state and reset boundaries

- `stage15:src__trace_processor__importers__proto__track_event_sequence_state.h:31-44`: track-event reference timestamps and incremental-counter running values belong to one packet sequence; defaults changes preserve them; incremental-state clear resets them. Persistent thread identity is separate.
- Same header `:52-57`: this custom state opts into destruction on packet loss (`ClearOnPacketLoss() == true`).
- Same header `:90-95`: the accumulator map is keyed by counter track UUID, inserts `0.0` on first use, and adds the new value. Since the owning object is per sequence, the effective key is `(packet_sequence_id, counter_track_uuid, reset interval)`.
- `src__trace_processor__importers__proto__packet_sequence_state_generation.cc:68-73`: a sequence starts with no defaults and invalid incremental state.
- Same file `:77-87`: packet loss makes a fresh invalid generation. Defaults are retained; `IncrementalState::CreateAfterPacketLoss` controls which custom state survives.
- `src__trace_processor__importers__proto__incremental_state.cc:45-58`: loss copies interned data and persistent thread descriptor and clears only custom-state slots that opt into `ClearOnPacketLoss`; TrackEventSequenceState does opt in, so its counter map starts empty afterward. Old state stays available to pre-loss buffered packets.
- `src__trace_processor__importers__proto__packet_sequence_state_generation.cc:91-101`: an incremental-state clear constructs fresh incremental state, drops defaults, and sets validity true; persistent thread descriptor survives. `incremental_state.cc:36-41` copies only that descriptor into the successor.
- `packet_sequence_state_generation.cc:105-113`: a defaults transition shares the same IncrementalState, preserving counter accumulators and current validity. Do not reset counters merely because defaults change.
- `src__trace_processor__importers__proto__packet_sequence_state_builder.h:52-63,71-74`: validity begins false, loss sets invalid, clear sets valid. The header names this invalidity `packet_loss_` even for a trace's initial sequence state.

## Wire flags and exact reader ordering

- `stage15:protos__perfetto__trace__trace_packet.proto:364-370`: trusted packet sequence field 10 identifies producer + writer; zero is invalid.
- Same proto `:383-412`: `sequence_flags` is uint32 field 13; clear bit = 1 and needs-state bit = 2. Legacy bool `incremental_state_cleared` remains field 41. Use bit tests, not equality tests.
- Same proto `:455-473`: `previous_packet_dropped` is uint32 field 42; every nonzero value indicates loss. It is now a reason bitmask, so `== 1` is insufficient. It can also mark the sequence's first packet.
- `src__trace_processor__importers__proto__proto_trace_reader.cc:340-347`: first apply `legacy_clear || (sequence_flags & 1)`; only `else if previous_packet_dropped != 0` applies loss. Clear wins if both occur in one packet. Apply this before decoding its payload.
- Same reader `:349-359`: then read packet defaults and interned data from this packet. A clear packet may immediately re-establish and consume fresh defaults/interned entries.
- Same reader `:397-425`: if needs-state bit is set, sequence ID zero is an error; if the sequence remains invalid the packet is skipped before normal timestamp/tokenization and counter accumulation. This is conditional on the bit; it is not a blanket drop of every packet while invalid.
- Same reader `:673-685`: defaults are updated even while invalid; this does not itself make state valid.
- Same reader `:688-711`: interned data is skipped while invalid.
- Same reader `:593-607,637-647`: clear and loss state changes require the sequence-ID field to be present; missing IDs are logged and the transition returns without changing state.
- Same reader `:610-615`: first-packet-on-sequence dispatches module notifications and does not itself establish valid incremental state. Proto `:475-488` also cautions that its absence does not prove loss for older producers.

## Decoder consequence

Maintain validity and the counter accumulator independently for every sequence. In input packet order, compute clear from modern clear bit or legacy bool; clear fresh sequence incremental data/defaults/counter sums and mark valid. Otherwise any nonzero loss marker discards sequence counter sums and marks invalid. Then apply this packet's defaults and, only when valid, interned data. Skip normal payloads requiring incremental state while invalid. Resolve counter values against these sequence-scoped sums before timestamp sorting. Defaults changes alone do not reset sums. A fresh sum's first delta is added to zero.

For exact Perfetto parity after loss, note that interned data and defaults are physically retained but are invalid for packets requiring state; they are removed by the next clear. The counter accumulator is discarded immediately at loss. Descriptor/unit conversion is outside this sub-audit.
