# Fixed positive control: source quantization plus incremental-state clear

This plan is saved **before** constructing the fixture or converting it.
It authorizes one fixed synthetic fixture and exactly one official JSON
conversion. No browser, application, DP, performance measurement, real-trace
decoding, existing fixture change, or frozen checker change is included.

## Construction and expected result

- One sequence, one thread track, one incremental `COUNTER_THREAD_TIME_NS`
  counter with multiplier 1000, and interned marker/noise names.
- True wall time starts at 1,000,000,000 ns and true CPU starts at 0 ns.
  Each of 20,001 steps advances both by exactly 1,500 ns, so true CPU elapsed
  equals true wall elapsed throughout the construction.
- Steps 1 through 19,999 emit noise instants; step 20,000 emits the named
  BEGIN. These 20,000 old-epoch events each encode the CPU difference
  `floor(1500 / 1000) = 1` unit and update the source's previous true CPU
  sample to the full, unrounded sample. Thus BEGIN has represented CPU
  20,000,000 ns although true CPU is 30,000,000 ns: exactly 10,000,000 ns
  of prior per-event quantization loss.
- Wall timestamp encoding follows the SDK's carry-forward rule:
  `delta_units = floor((true_wall - saved_wall_ns) / 1000)`;
  `saved_wall_ns += delta_units * 1000`. It must **not** imitate the CPU
  rule that discards every 500 ns remainder. The resulting deltas alternate
  1 and 2 units, and BEGIN's represented wall time is exactly the true
  1,030,000,000 ns value at the even-numbered step.
- Immediately after BEGIN, at the same true instant, emit clear + defaults
  + interning + valid clock snapshots and re-emit the same track/counter
  descriptors. The counter's represented accumulation resets to zero.
  The wall reference is explicitly reanchored at 1,030,000,000 ns.
- Step 20,001 emits END. Its true CPU and elapsed CPU/wall are respectively
  30,001,500 ns and 1,500 ns. The first post-clear CPU value is the absolute
  `floor(30001500 / 1000) = 30001` units, hence 30,001,000 represented ns.
  SDK wall carry emits one unit, so represented wall end is 1,030,001,000 ns.
- Expected official merged X: `dur = 1` microsecond;
  `tts = 20000` microseconds; `tdur = 10001` microseconds.
  Represented CPU duration is therefore 10,001,000 ns despite actual
  CPU/wall elapsed of only 1,500 ns. No physical clock anomaly is constructed.
- Include an explicit synthetic BOOTTIME6↔MONOTONIC3 snapshot and the
  sequence-local clock64 references, multiplier1000, primary clock3.
  Builtin equality is test data only, used to avoid unresolved default clocks.

## Fixed execution and evidence

1. Save an independent generator under the new `source-quantization-control/`
   subdirectory, reusing only the already-reviewed tiny wire encoding helpers.
   Preserve a copy of those helpers and relevant source hashes.
2. Generate exactly one file named `source-quantization-control.pftrace`
   with exclusive-create output; save intended numeric expectations and
   construction invariants separately.
3. Execute the official
   `/workspace/bingo-stage16-20261015/trace_processor_shell convert json`
   exactly once, to a new control JSON path. Preserve argv, exit status,
   stdout/stderr, tool version provenance and SHA-256.
4. Inspect that one JSON's target X event, clock/counter error statistics,
   `dur`, `tts`, and `tdur`; compare with the fixed values above. No additional
   SQL query is planned or needed. Save PASS/FAIL and artifact hashes.

If generation/conversion/inspection fails or differs from the prediction,
retain the evidence and report it. Do not retry, replace the fixture, change
parameters, or choose a stopping sign without a new discussion.

This is a constructed positive control for source encoding behavior, not
proof that actual traces have the same cause, and not a general decoder
correctness claim. It does not estimate that cause's contribution in an
actual recording.
