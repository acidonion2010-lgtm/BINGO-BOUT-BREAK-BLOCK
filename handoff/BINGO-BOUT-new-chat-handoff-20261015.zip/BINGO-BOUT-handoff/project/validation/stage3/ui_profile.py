"""Targeted sampling profile of the unresolved HARD trusted-click handler."""
import collections
import functools
import http.server
import json
from pathlib import Path
import statistics
import threading
from playwright.sync_api import sync_playwright
from ui_response import PREPARE, INSTRUMENT, FIXTURE, click_trial, assert_sample

ROOT = Path('/workspace/bingo-refactor')
OUT = ROOT/'validation/stage3/ui-profile'
TRIALS = 12

def main():
    OUT.mkdir(exist_ok=True)
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *unused): pass
    server = http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    rows=[]
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1280,'height':900})
        errors=[]; page.on('pageerror',lambda error:errors.append(str(error)))
        try:
            for run,order in enumerate([['before','after'],['after','before']],1):
                for version in order:
                    name='index.before.html' if version=='before' else 'index.html'
                    page.goto(f'http://127.0.0.1:{server.server_port}/{name}')
                    assert json.loads(page.locator('#rule-test-results').text_content())['passed']==322
                    page.evaluate(PREPARE); page.evaluate(INSTRUMENT)
                    click_trial(page,'hard')
                    cdp=page.context.new_cdp_session(page)
                    cdp.send('Profiler.enable'); cdp.send('Profiler.setSamplingInterval',{'interval':100})
                    samples=[]; node_counts=collections.Counter(); handler_us=collections.Counter()
                    for trial in range(TRIALS):
                        page.evaluate(FIXTURE,'hard')
                        cdp.send('Profiler.start')
                        page.locator('#board1 .cell:not([disabled])').first.click(timeout=10000)
                        page.wait_for_function('uiResponseProbe.result !== null')
                        profile=cdp.send('Profiler.stop')['profile']
                        sample=page.evaluate('uiResponseProbe.result'); assert_sample(sample,'hard')
                        samples.append(sample)
                        nodes={n['id']:n for n in profile['nodes']}
                        parents={child:n['id'] for n in profile['nodes'] for child in n.get('children',[])}
                        def inside_handler(node_id):
                            while node_id in nodes:
                                if nodes[node_id]['callFrame']['functionName']=='handleCellClick':return True
                                node_id=parents.get(node_id)
                            return False
                        for node_id,delta in zip(profile.get('samples',[]),profile.get('timeDeltas',[])):
                            if inside_handler(node_id):
                                function=nodes[node_id]['callFrame']['functionName'] or '(anonymous/builtin)'
                                node_counts[function]+=1; handler_us[function]+=delta
                        (OUT/f'run{run}-{version}-{trial+1}.cpuprofile').write_text(json.dumps(profile))
                    row={'run':run,'version':version,'trials':TRIALS,'samples':samples,
                         'handlerMedianMs':statistics.median(x['handlerMs'] for x in samples),
                         'insideHandleCellClickSelfSampleCount':dict(node_counts),
                         'insideHandleCellClickApproxSampleMs':{k:v/1000 for k,v in handler_us.items()}}
                    rows.append(row)
                    print(json.dumps({k:v for k,v in row.items() if k!='samples'}),flush=True)
                    cdp.send('Profiler.disable'); cdp.detach()
                    page.evaluate('() => {state.turnToken++;discardThinkTimer();releaseWholeGameCpu();}')
            assert not errors,errors
        finally:
            browser.close(); server.shutdown();server.server_close()
    summary={'conditions':{'samplingIntervalUs':100,'scope':'stack samples below handleCellClick only',
                          'runs':2,'trialsPerVersionRun':TRIALS,'difficulty':'hard-full',
                          'instrumentation':'native CDP CPU profiler; game functions unchanged',
                          'limitation':'Sampling perturbs timing; sample deltas approximate attribution and are not exact wall-clock costs.'},
             'rows':rows,'browserErrors':errors}
    (OUT.parent/'ui-profile.json').write_text(json.dumps(summary,indent=2)+'\n')

if __name__=='__main__':main()
