#!/usr/bin/env node
'use strict';
const fs=require('node:fs');
const path=require('node:path');
const {load,rng,seed}=require('./loader.cjs');
const outdir=process.argv[2]||path.join(__dirname,'results');
const data=JSON.parse(fs.readFileSync(path.join(outdir,'dp_game_audit.json'),'utf8'));
const {api,sha256}=load();
const N=100000,results=[];
function sample(label,full,mask,streamSeed,metadata){
  const r=rng(streamSeed),counts=Array(9).fill(0);
  for(let i=0;i<N;i++)counts[api.sampleCpuEqDistribution(full,mask,r())]++;
  const expected=Array.from(full),observed=counts.map(x=>x/N);
  const absolute=expected.map((p,i)=>Math.abs(p-observed[i]));
  const z=expected.map((p,i)=>p>0&&p<1?(observed[i]-p)/Math.sqrt(p*(1-p)/N):0);
  results.push({label,...metadata,mask,seed:streamSeed,n:N,expected,counts,observed,
    totalVariation:sum(absolute)/2,maxAbsoluteError:Math.max(...absolute),
    maxAbsoluteZ:Math.max(...z.map(Math.abs)),zeroProbabilityHits:sum(counts.filter((_,i)=>expected[i]===0))});
}
function sum(a){return a.reduce((s,x)=>s+x,0)}
for(const game of data.games.filter(g=>g.config.id==='benchmark-layout0-first1')){
  const changed=game.topLocalLoss.filter(x=>x.totalVariation>1e-10).slice(0,3);
  for(let index=0;index<changed.length;index++){
    const s=changed[index],full=(dist)=>{const a=new Float64Array(9);s.legalActions.forEach((c,j)=>a[c]=dist[j]);return a;};
    const metadata={config:game.config.id,t:s.t,maskP1:s.maskP1,maskP2:s.maskP2,transformationTV:s.totalVariation,localUtilityLoss:s.loss};
    sample(`actual_break_${index}`,full(s.pActual),s.maskP2,seed('bingo-v1','sampler','break',index),metadata);
    sample(`nash_break_${index}`,full(s.p),s.maskP2,seed('bingo-v1','sampler','nash-break',index),metadata);
    sample(`nash_block_distribution_${index}`,full(s.q),s.maskP2,seed('bingo-v1','sampler','block',index),metadata);
  }
}
// Direct CPU BLOCK distributions with P1 attacking, independent of BREAK samples.
const game=data.games[0],dp=new api.WholeGameDP({...game.config,earlyTermination:true});dp.solve();
const r=rng(seed('bingo-v1','sampler','actual-block-states'));
let count=0;
for(let attempt=0;attempt<2000&&count<3;attempt++){
  const t=2+2*Math.floor(r()*8),layer=dp.layers[t],m1=layer.masks1[Math.floor(r()*layer.n1)],m2=layer.masks2[Math.floor(r()*layer.n2)];
  const p=dp.analyze({t,maskP1:m1,maskP2:m2});
  if(p.terminal.isTerminal||p.attacker!==1||p.legalActions.length<2||Array.from(p.blockStrategy).filter(x=>x>0).length<2)continue;
  const full=new Float64Array(9);p.legalActions.forEach((c,j)=>full[c]=p.blockStrategy[j]);
  sample(`actual_cpu_block_${count}`,full,m1,seed('bingo-v1','sampler','cpu-block',count),{config:game.config.id,t,maskP1:m1,maskP2:m2});count++;
}
const result={sourceSha256:sha256,description:'Original sampleCpuEqDistribution; no resampling, fitted weights, or modified draw code',results};
fs.writeFileSync(path.join(outdir,'sampler_verification.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify({sourceSha256:sha256,distributions:results.length,draws:N*results.length,
  maxTotalVariation:Math.max(...results.map(x=>x.totalVariation)),maxAbsoluteZ:Math.max(...results.map(x=>x.maxAbsoluteZ)),
  zeroProbabilityHits:sum(results.map(x=>x.zeroProbabilityHits))},null,2));
