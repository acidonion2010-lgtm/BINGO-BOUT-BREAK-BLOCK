# Fixed source-quantization positive control

**PASS:** exactly one fixture was generated and exactly one official JSON conversion was executed after `../CONTROL_PLAN.md` was saved. No retries, replacements, SQL queries, browser/application/performance execution, or real-trace decoding occurred.

The construction keeps true CPU elapsed equal to true wall elapsed at every step. Each step is 1,500 ns; 20,000 old-epoch CPU differences independently round down to 1,000 ns each. The old BEGIN therefore has represented CPU 20,000,000 ns versus true CPU 30,000,000 ns, accumulating 10,000,000 ns of quantization loss. Wall encoding carries residual nanoseconds according to the SDK, with 10,000 deltas of one microsecond and 10,000 deltas of two microseconds.

A clear/snapshot is explicitly placed at the same true instant as BEGIN, with the same track UUID and no intervening CPU sample. The next END is 1,500 ns later; its new-epoch first CPU value is the absolute floor of 30,001,500 ns, namely 30,001,000 represented ns. The wall snapshot/carry model yields 1,030,001,000 represented wall ns.

| Quantity | Fixed prediction | Official JSON |
|---|---:|---:|
| True interval CPU and wall | 1,500 ns | Constructed truth, not measured |
| BEGIN represented CPU / `tts` | 20,000,000 ns | 20,000 microseconds |
| END represented CPU | 30,001,000 ns | `tts + tdur` = 30,001 microseconds |
| Represented wall duration / `dur` | 1,000 ns | 1 microsecond |
| Represented CPU duration / `tdur` | 10,001,000 ns | 10,001 microseconds |

The official target is a single X event. All seven fixed prediction checks passed, and the saved relevant nonzero clock/counter/slice error-stat list is empty. The fixture contains 20,008 packets and 20,001 TrackEvents. `result.json`, `expected.json`, `generation.json` and `official-command.json` retain the exact values, execution count, command, stdout/stderr and tool hash.

The child `control_math_review` independently reviewed the arithmetic and pinned producer/importer paths before generation. It found no conceptual/arithmetic blocker and confirmed the same-time snapshot, same UUID and no intermediate CPU sample as necessary construction assumptions. It did not execute or edit anything.

This is a constructed positive control showing that the reviewed source encoding and a clear can produce CPU duration greater than wall duration even when underlying CPU equals wall. It does **not** prove that actual recordings have this cause, its contribution in any recording, or absence of actual clock anomalies. The clear timing is an explicit synthetic condition; it does not assert that every deferred SDK reset is materialized at that time. The official oracle is the saved v58.2 release, not a binary built from Chromium's pinned Perfetto source commit.

`generate_control.py` and `run_once.py` are preserved, as is the reused wire-helper source snapshot. `MANIFEST.json` records every artifact hash, the immutable official source URLs/hashes, license location and exact official binary identity. No frozen checker, root script, prior fixture or prior result was modified.
