# ParseHTML exact emit site, Chromium 73c14f6228d7cd537c855007e8f88678969cc0eb

Static official-source follow-up only. No browser, jobs, performance measurements, installation, or system changes. New originals are under `parsehtml-extra/`; `PARSEHTML_EXTRA_MANIFEST.json` records full immutable raw GitHub URLs, SHA-256 and bytes. The earlier `MANIFEST.json` and earlier source originals were not changed.

- `third_party/blink/renderer/core/html/parser/html_document_parser.cc:683` defines `HTMLDocumentParser::PumpTokenizer`; line **712** constructs `probe::ParseHTML probe(GetDocument(), this)` within that scope.
- `third_party/blink/renderer/core/probe/core_probes.pidl:207` declares `ParseHTML(Document* document, HTMLDocumentParser* parser)`.
- **Exact begin emission:** `third_party/blink/renderer/core/inspector/inspector_trace_events.cc:243–250`, `InspectorTraceEvents::Will(const probe::ParseHTML& probe)`, calls `TRACE_EVENT_BEGIN("devtools.timeline", "ParseHTML", "beginData", lambda)`. The lambda obtains current document and line number for the event data. **No explicit timestamp or explicit track is supplied.**
- **Exact end emission:** same source **253–258**, `InspectorTraceEvents::Did(const probe::ParseHTML& probe)`, calls `TRACE_EVENT_END("devtools.timeline", "endData", lambda)`. **No explicit timestamp or explicit track is supplied.** Lines 259–264 then emit UpdateCounters on its disabled-by-default category.
- Perfetto `track_event.h:373–376` / `:386–389` map BEGIN / END to `TraceForCategory` with TYPE_SLICE_BEGIN / TYPE_SLICE_END. The string `"beginData"` or `"endData"` is the annotation key, not a timestamp.
- Thus these exact ParseHTML emit calls use the **default** wall-clock acquisition path established in the earlier review: `track_event_data_source.h:1082` captures GetTraceTime before WriteTrackEventImpl; `:996–997` may reset incremental state; `:1008–1010` calls WriteEvent; `track_event_internal.cc:591–603` creates the packet then samples thread CPU. They do not use ProbeBase's optional CaptureStartTime/CaptureEndTime values and they do not backdate the wall timestamp at these callsites.

This establishes source provenance, not the cause of the reported raw ParseHTML example (`wall=132 us`, `CPU=5419 us`, subsequent ParseHTML begins 40 us later). A custom wall timestamp hypothesis is not supported by these callsites. A variable delay between a default wall read and the later CPU read must also remain consistent with subsequent same-thread default wall timestamps; the source finding alone does not resolve the sample or prove the runtime clock behavior and raw reconstruction are correct.

Exact begin/end line link: https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/third_party/blink/renderer/core/inspector/inspector_trace_events.cc#L243-L258

Parser line link: https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/third_party/blink/renderer/core/html/parser/html_document_parser.cc#L683-L712
