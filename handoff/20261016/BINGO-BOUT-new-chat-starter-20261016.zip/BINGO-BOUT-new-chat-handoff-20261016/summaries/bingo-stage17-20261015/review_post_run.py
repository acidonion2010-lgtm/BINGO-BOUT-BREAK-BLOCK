#!/usr/bin/env python3
"""Independent saved-data review; starts no browser, decoder or measurement."""
import hashlib, json, math, statistics
from collections import Counter, defaultdict
from decimal import Decimal
from pathlib import Path

R = Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name): return json.loads((R / name).read_text(), parse_float=Decimal)
def summary(values):
    return {'min': min(values), 'median': statistics.median(values), 'max': max(values)}
def numbers(value):
    if isinstance(value, Decimal): return str(value)
    raise TypeError(type(value).__name__)

def main():
    output = R / 'post-run-independent-check.json'
    assert not output.exists()
    report = read('report.json'); failed = read('preflight-failed-report.json')
    assert report['status'] == 'completed' and len(report['visits']) == 10
    assert failed['status'] == 'failed' and len(failed['visits']) == 2
    assert report['priorAttempt']['reportSha256'] == sha(R / 'preflight-failed-report.json')
    assert report['priorAttempt']['capturesRepeated'] == 0
    assert failed['scriptSha256'] == sha(R / 'capture_units.py')
    assert report['scriptSha256'] == sha(R / 'resume_capture.py')
    assert failed['planSha256'] == report['planSha256'] == sha(R / 'PLAN.md')
    assert report['amendmentSha256'] == sha(R / 'PLAN_AMENDMENT.md')
    assert not report['pageErrors']
    formal = Counter(); warmup = Counter(); rows = []; actions = []; windows = []
    reference = report['visits'][2]['nativeFunctionSources']; retained = []
    for index, v in enumerate(report['visits']):
        assert v['run'] == index and v['completed']
        assert v['selfTests'] == {'passed':322, 'total':322, 'failures':[]}
        assert v['requestedConfigSha256'] == sha(R / f"trace-config.unit{v['unit']}.pb")
        if v['preflight']:
            original = failed['visits'][index]
            for key in ['trace', 'conversion', 'selfTests', 'before', 'after']:
                assert v[key] == original[key], ('preflight changed', index, key)
            assert v['captureScriptSha256'] == failed['scriptSha256']
            assert v['correctedPreflightGatePassed']
            retained.append(index)
        else:
            expected_units = [1000,1] if v['browserRun'] in [1,3] else [1,1000]
            assert v['unit'] == expected_units[v['position']]
            assert v['branchOrder'] == (['dp','legacy'] if v['browserRun'] in [1,2] else ['legacy','dp'])
            assert v['prepare']['status'] == 'ready' and v['nativeFunctionSources'] == reference
            assert v['captureScriptSha256'] == report['scriptSha256'] and len(v['samples']) == 8
        p = R / f'run{index}.pftrace'; j = R / f'run{index}.json'
        assert sha(p) == v['trace']['sha256'] and p.stat().st_size == v['trace']['bytes']
        assert sha(j) == v['conversion']['sha256'] and j.stat().st_size == v['conversion']['bytes']
        assert v['trace']['streamEOF'] and v['trace']['integrityChecksPassed']
        assert v['trace']['tracingComplete']['dataLossOccurred'] is False
        assert all(0 <= d['percentFull'] < 1 for d in v['trace']['bufferUsage'])
        assert read(f'run{index}.convert-log.json')['returncode'] == 0
        events = json.loads(j.read_text(), parse_float=Decimal)['traceEvents']
        assert len(events) == v['conversion']['events']
        pid, tid = v['conversion']['rendererPidTid']; assert pid == tid
        complete = [e for e in events if e.get('ph') == 'X' and (e.get('pid'),e.get('tid')) == (pid,tid)]
        cpu = [e for e in complete if all(k in e for k in ['dur','tts','tdur'])]
        row = {'run':index, 'preflight':v['preflight'], 'unit':v['unit'], 'allMainX':len(complete),
            'withCpu':len(cpu), 'missingCpu':len(complete)-len(cpu),
            'strictPositive':sum(e['tdur'] > e['dur'] for e in cpu),
            'over1ms':sum(e['tdur']-e['dur'] > 1000 for e in cpu),
            'negativeCpu':sum(e['tdur'] < 0 for e in cpu), 'zeroCpu':sum(e['tdur'] == 0 for e in cpu),
            'events':len(events), 'protoBytes':p.stat().st_size, 'jsonBytes':j.stat().st_size}
        rows.append(row)
        markers = {m['name']:m for m in v['conversion']['markers']}
        groups = [{'before':v['before'], 'after':v['after'], 'markers':v['conversion']['markers'], 'preflight':True}] if v['preflight'] else v['samples']
        identities = []
        for sample in groups:
            pre = v['preflight']; unit = v['unit']
            if not pre:
                s=sample['sample']; branch=sample['branch']; trial=sample['trial']
                assert sample['outcome']=='accepted' and sample['warmup']==(trial==0)
                assert all(s[k] is True for k in ['trusted','messageVisible','selectedCellAccepted','selectedCellDisabled','documentVisible','processingAtHandlerEnd','processingAtTwoRaf'])
                assert s['clickedIndex']==s['selectedBreakCell']==2 and s['turns']==[4,4]
                assert s['audioState']=='running' and s['soundMuted'] is False and s['bgmOff'] is False
                assert s['wholeStatus']=='ready' and s['messageAtHandlerEnd']==s['messageAtTwoRaf']=='REVEALING PICKS...'
                assert (s['wholeDecisions'],s['hardDpDecisions'],s['hardLegacyDecisions']) == ((1,1,0) if branch=='dp' else (0,0,1))
                (warmup if sample['warmup'] else formal)[(unit,branch)] += 1
            b, a = sample['before'], sample['after']; metrics=[]; procs=[]
            for endpoint in [b,a]:
                m={m['name']:m['value'] for m in endpoint['metrics']['metrics']}
                assert all(isinstance(m[k],(int,Decimal)) and math.isfinite(m[k]) for k in ['Timestamp','ThreadTime','TaskDuration'])
                metrics.append(m)
                choices=[r for r in endpoint['renderers'] if (r['pid'],r['tid'])==(pid,tid) and 'readError' not in r]
                assert len(choices)==1; proc=choices[0]; f=proc['stat'][proc['stat'].rfind(')')+2:].split()
                identities.append((proc['comm'],f[19])); procs.append((proc,f))
            wall=a['metricReturnMonotonicNs']-b['metricSendMonotonicNs']
            thread=(metrics[1]['ThreadTime']-metrics[0]['ThreadTime'])*10**9
            task=(metrics[1]['TaskDuration']-metrics[0]['TaskDuration'])*10**9
            before_proc,after_proc=procs[0][0],procs[1][0]
            sb=[int(x) for x in before_proc['schedstat'].split()]; sa=[int(x) for x in after_proc['schedstat'].split()]
            assert all(y>=x for x,y in zip(sb,sa)) and thread>=0 and task>=0
            proc_wall=after_proc['hostAfterReadNs']-before_proc['hostBeforeReadNs']
            action={'run':index,'unit':unit,'preflight':pre,'warmup':sample.get('warmup'), 'branch':sample.get('branch'),
                'metricOuterWallNs':wall,'threadTimeDeltaNs':thread,'taskDurationDeltaNs':task,
                'threadPositive':thread>wall,'taskPositive':task>wall,'procRuntimeDeltaNs':sa[0]-sb[0],
                'procOuterWallNs':proc_wall,'procRuntimePositive':sa[0]-sb[0]>proc_wall,
                'lastCpuBookendDifferent':procs[0][1][36]!=procs[1][1][36]}
            actions.append(action)
            names=[m['name'] for m in sample['markers']]
            for name in names:
                for kind in ['mark','stamp']:
                    event=markers[name][kind]
                    assert 'tts' in event and b['metricSendMonotonicNs'] <= event['ts']*1000 <= a['metricReturnMonotonicNs']
            start=markers[names[0]]
            for name in names[1:]:
                for kind in ['mark','stamp']:
                    end=markers[name][kind]; begin=start[kind]
                    wall_us=end['ts']-begin['ts']; cpu_us=end['tts']-begin['tts']
                    assert wall_us>=0 and cpu_us>=0
                    windows.append({'run':index,'unit':unit,'preflight':pre,'warmup':sample.get('warmup'), 'branch':sample.get('branch'),
                        'end':name,'kind':kind,'wallUs':wall_us,'cpuUs':cpu_us,'strictPositive':cpu_us>wall_us,'over1ms':cpu_us-wall_us>1000})
        assert len(set(identities))==1
    assert sum(formal.values())==report['formalClicks']==48 and sum(warmup.values())==report['warmupClicks']==16
    assert set(formal.values())=={12} and set(warmup.values())=={4}
    result={'status':'completed','scriptSha256':sha(Path(__file__)),'reportSha256':sha(R/'report.json'),
        'preflightFailedReportSha256':sha(R/'preflight-failed-report.json'),'originalPreflightCapturesUnchanged':retained,
        'sourceNotes':'Read-only static source/plan verification; no decoder or measurement execution.',
        'selfTestsPassed':sum(v['selfTests']['passed'] for v in report['visits']), 'pageErrors':report['pageErrors'],
        'formalByUnitBranch':{str(k):v for k,v in formal.items()},'warmupByUnitBranch':{str(k):v for k,v in warmup.items()},
        'jsonMainX':rows,'actions':actions,'markerWindows':windows}
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2,default=numbers)+'\n')
    print(json.dumps({'status':'completed','visits':len(rows),'actions':len(actions),'markerWindows':len(windows),
        'mainXByUnit':{str(u):{k:sum(r[k] for r in rows if r['unit']==u and not r['preflight']) for k in ['allMainX','withCpu','missingCpu','strictPositive','over1ms']} for u in [1000,1]},
        'markerPositive':sum(w['strictPositive'] for w in windows)},ensure_ascii=False))

if __name__=='__main__': main()
