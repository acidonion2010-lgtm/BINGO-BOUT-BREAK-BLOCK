'use strict';
const fs=require('node:fs');
const assert=require('node:assert/strict');
const {load,rng,seed}=require('./loader.cjs');
const {game}=require('./simulate.cjs');
const design=require('./design.json');
const {api,sha256}=load();assert.equal(sha256,design.source_sha256);
api.setRandom(rng(seed('bingo-v1','layout',0)));
const layouts=api.createIndividualNumberLayouts(),p1=Array.from(layouts.p1),p2=Array.from(layouts.p2);
const dp=new api.WholeGameDP({layoutP1:p1,layoutP2:p2,firstPlayer:1}),stats=dp.solve();
const eq=[api.buildCpuEqTable(p1),api.buildCpuEqTable(p2)];
let scores=0,maxima=0;
for(const [j,layout] of [p1,p2].entries())for(let mask=0;mask<512;mask++){
  const marks=Array.from({length:9},(_,i)=>Boolean(mask&(1<<i)));
  assert.equal(api.calculateScore(marks,layout),j?dp.score2[mask]:dp.score1[mask]);scores++;
  for(let t=0;t<10;t++){
    assert.equal(api.calculateHighestReachableScore(marks,layout,t),(j?dp.max2:dp.max1)[t][mask]);maxima++;
  }
}
const cond={pair:0,swap:0,firstPlayer:1,p1,p2};
let replayed=0;const traces=[];
for(const opponent of design.opponents)for(const diff of design.difficulties){
  const a=game(api,dp,eq,cond,diff,opponent,17,true);
  const b=game(api,dp,eq,cond,diff,opponent,17,true);
  assert.deepEqual(a,b);replayed++;traces.push(a);
}
// Forbidden shared/global entropy: loader throws if code calls RNG before a
// seeded stream is explicitly assigned. Decisions use all original RNG calls.
const summary={sourceSha256:sha256,scoreMasksChecked:scores,reachabilityStatesChecked:maxima,
  deterministicReplayGames:replayed,dpStats:stats,allPassed:true};
fs.writeFileSync('results/harness_validation.json',JSON.stringify(summary,null,2));
fs.writeFileSync('results/replay_traces.json',JSON.stringify(traces,null,2));
console.log(JSON.stringify(summary));
