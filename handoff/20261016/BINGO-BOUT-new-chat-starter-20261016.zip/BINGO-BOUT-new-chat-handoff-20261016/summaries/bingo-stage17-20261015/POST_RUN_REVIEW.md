# 段階17 保存データ独立レビュー

2026-10-15 JST。実ブラウザー収集の完了連絡後に、保存JSON、report、公式SQL CSV、限定raw ledgerを別スクリプトで再集計した。ブラウザー、DP、性能試験、公式変換器、protobuf decoderは起動していない。主解析スクリプトをimport/実行せず、元データや既存解析結果を変更していない。主要件数・符号・保存関係に不一致は見つからなかった。

## 失敗記録と固定予算

初回 `capture_units.py` のreportはfailedで2preflightを含み、unit1のraw multiplierを要求値1へ直接比較したgateが停止理由だった。`preflight-failed-report.json` の現物hashはresume reportの参照値と一致。初期collectorとPLANのhashも一致した。初回の2visitについてproto/JSONのhash・bytes、およびreport内のtrace/conversion/selfTests/before/afterがresume後も全て同じであることを確認した。失敗を成功例へ差し替えるための再取得はない。

PLAN/ANALYSIS_PLANと両AMENDMENT、ZERO_UNIT_REVIEWの固定公式ソースも静的確認した。CounterTrack serializerは倍率1のfield4を省略し、proto accessorのraw0をimporterと凍結checkerは乗算なし、すなわちeffective1として扱う。raw0を残してeffective1を別列にする改訂はソースに沿う。閾値、符号判定、元の実ブラウザー予算を変更していない。

最終reportはcompleted、visit0–9が全件completed。preflight2visitと、その後の4browser×2visitで、正式48・暖機16クリック。unit順はAB/BA/AB/BA、branch順も事前指定どおりだった。各unitの各branchは正式12・暖機4。全10ロードの自己テストは322/322、合計3,220成功、正式8visitの実Workerは全てready。pageErrorsは空だった。

全64クリックでtrusted入力、セル2、REVEAL状態、可視性、選択受付・無効化、turns=[4,4]、sound/BGM有効、audio running、ready状態と各branchのDP/legacy counterを確認した。7個のゲーム関数ソースは全正式visitで同一。実クリック中のローカルCPU選択cellを直接観測したものではない。

## 元ファイルと独立再集計

全10proto/JSONの現物hashとbytesがreportに一致し、変換ログは全件returncode0。stream EOF・dataLossOccurred=false・buffer-fullなしを確認した。保存量はproto82,645,720 bytes、JSON175,101,690 bytes、699,582 events。以下は**preflightを除く**各4visit全体の集計であり、正式クリックの瞬間だけを抜き出したものではない。暖機・fixture・auditもtrace内に含む。

| 指標 | unit1000 | unit1 |
| --- | ---: | ---: |
| main JSON X全件 | 77,677 | 81,065 |
| JSON XのCPU時計付き | 69,054 | 81,065 |
| JSON XのCPU時計欠測 | 8,623 | 0 |
| JSON Xの厳密CPU超過 | 1,335 | 3,140 |
| JSON Xの超過>1ms | 32 | 0 |
| SQL complete slice全件 | 85,349 | 85,434 |
| SQL completeのCPU時計付き | 71,877 | 83,817 |
| SQL completeのCPU時計欠測 | 13,472 | 1,617 |
| SQL nsでの厳密CPU超過 | 1,347 | 27,879 |
| SQL nsでの超過>1ms | 32 | 0 |

unit1000の>1msはrun2/5/6/9で6/6/11/9、unit1はrun3/4/7/8の全て0。SQL最大差はunit1000が7,261,455ns、unit1が129,988nsだった。欠測を超過なしとして分母へ加算していない。SQL complete sliceとJSON Xは対象範囲が異なり、nsから整数µsへの表現も異なるため、両集計のstrict件数差を全て丸め差とみなさない。全JSON CPU付きXのtuple多重集合が公式SQLの整数µs tupleに包含され、未一致0を独立確認した。入れ子イベントの件数を独立事象数とは扱わない。

preflightは別枠。unit1000はCPU付きX16・strict0、unit1はCPU付きX16・strict1。SQL complete CPU付きは各20でstrictは0/7、>1msは両方0。これらを正式visitへ混ぜていない。

## raw counterとclearの照合

全10保存ledgerの信頼可能なrenderer-main thread_time counterを抽出し、公式SQLのUUID/absolute-ns多重集合と独立に比較した。329,549 samplesが全数一致した。正式unit1000は164,595 samples、unit1は164,882 samples。全対象counterはincrementalで、raw倍率は各条件1000/0、effective倍率は1000/1だった。

正式unit1000のraw差分0は30,722件、unit1は0件、負のencoded差分は双方0。これは限定ledgerの採用counterについての件数であり、全TrackEventにCPU fieldが必ずあるという証明ではない。全diagnostic19,342件も保持されており、限定decoderを完全なPerfetto実装として扱わない。

32件の大超過は全て一意raw CPU pairを持った。保存ledgerからBEGIN/ENDのCPU端点・同一sequence/track・異なるepoch・内部clearを別確認した。SQLのCPU長と元端点の差は一致し、全例で記録されたemission数による `N×(m−1)` の条件付き正側上限式と整合した。限定ledgerの全slice stackを再実装して完全性を証明したわけではなく、wall clock mappingも独立復号していない。

主解析の全runのJSON/SQL主要件数と、この独立集計は一致した。32件全てがclearを跨ぎ上限内であることは量子化機構との整合性を示すが、端数損失の実値や各超過の単独原因を確定しない。unit1では当該整数除算の剰余上限が0であり、strict超過はなお残った。

## marker区間と外側CPU記録

正式48クリック×6区間=288、暖機16×6=96、preflight4区間を、mark/stamp端点から独立再計算した。全388区間にCPU時計があり、負のwall/CPU長は0。正式unit1000の144区間は超過0、unit1の144区間は厳密超過2、双方>1msは0。暖機96・preflight4の超過は0だった。

| 正式unit1の区間 | 種類 | wall µs | CPU µs |
| --- | --- | ---: | ---: |
| run7 legacy trial3 capture→handler-end | mark | 3,316 | 3,317 |
| run8 DP trial1 capture→handler-end | stamp | 3,424 | 3,425 |

全66操作・132端点でCDP ThreadTime/TaskDurationとprocの対象identityを確認し、全markerがhost外側範囲内にあった。各操作のCDP ThreadTime差・TaskDuration差・proc runtime差がそれぞれのhost外側wallを超えた例は0、負のcounter差も0。正式の最後CPU両端値の変化はunit1000で4・unit1で7操作。これは完全なmigration履歴や原因を示さない。

| 正式24操作ずつ、単位ms | unit1000範囲 | unit1範囲 |
| --- | --- | --- |
| CDP ThreadTime差 | 12.435–21.234 | 12.975–18.254 |
| CDP metric外側wall | 60.374–80.552 | 59.776–76.378 |
| proc runtime差 | 12.400–18.989 | 13.005–18.222 |
| proc読取の外側wall | 59.294–76.649 | 59.039–75.377 |

CDP/procはtrace exportを経ないが、独立した物理CPU時計ではない。CDPのCPU/wall読み取りは同時でなく、schedstatの更新鮮度は不明。広い外側区間の整合性を、狭いイベントやmarkerのCPU補正・正確性証明へ読み替えない。

## 結論の範囲と再現資料

この固定対照ではunit1で>1msの超過は観測されず、unit1000の32件は全てclearを跨いだ。一方、unit1にも小さなstrict超過と2markerの+1µs超過が残る。CPUとwall両方の記録単位・負荷・イベント数・欠測率が変わるため、ゲームの高速化や全CPU時計の完全妥当性を結論しない。旧62/104条件や段階14/15の未確定原因を今回の結果で解消したとは扱わない。

独立スクリプトは `review_post_run.py`、`review_sql_saved.py`、`review_raw_saved.py`。いずれも既存出力を上書きせず、スクリプトと入力のhashを対応する結果JSONへ保存する。過去stage・元handoff・repoの保全と最終ZIPはrootの別監査範囲。

最終RESULTSの主要数値と限定も照合し、不一致は見つからなかった。unit1の一意raw CPU pairでclearを跨ぐ19件は、unit-analysisのrun3/4/7/8が7/6/3/3件、内部clearありも同数と一致する。全unit1の>1msが0なので、この集合にも大超過はない。32件の条件付き上限範囲7.757235–14.748237msも保存proofから一致を確認した。19件は保存された対応集計の照合であり、本レビューが各raw stackを別途完全復元したという意味ではない。

| 入力・独立出力 | SHA-256 |
| --- | --- |
| report.json | `7672a26d0216e043b2fe4c141f5408dd2a7ca90f375722fc58a1ad5e5f967df7` |
| preflight-failed-report.json | `c8ec3472d0082b0b47c99a3936074dbc9f2543fddadb509ec46529dc0a97fecd` |
| unit-analysis.json | `053cc069970fe2bbfa1bcabe8101197e7692b260a0fcabe2c3d59b1b8e57aa1e` |
| post-run-independent-check.json | `2982e83992b1453aa80b068af3562ee751b1595cca02a81e8f303767091f9988` |
| post-run-independent-sql.json | `03a1d76b3ec9cff3c5a74f49d0833d8736dd75ed16b69762f4550138601ce7e5` |
| post-run-independent-raw.json | `99db6845dfc93ce3d78473e5ca04e5ee79ef1f4cde3a27147b1c0dcd0d71d44b` |
