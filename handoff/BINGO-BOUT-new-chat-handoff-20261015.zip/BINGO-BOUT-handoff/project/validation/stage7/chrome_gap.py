#!/usr/bin/env python3
"""Fixed-selector method-swap diagnostic, not a trusted-click latency test.

The production HTML loads normally over ordinary HTTP, including automatic
self-tests and one real Blob Worker preparation per fresh browser. Only six
solver methods on the same DP receiver are replaced outside timed regions.
Run this diagnostic sequentially, with no other benchmark active.
"""
import argparse
import functools
import hashlib
import http.server
import json
from pathlib import Path
import statistics
import threading

from playwright.sync_api import sync_playwright


ROOT = Path(__file__).resolve().parents[2]
LAYOUTS = {'p1': [8, 1, 6, 3, 5, 7, 4, 9, 2],
           'p2': [5, 9, 1, 7, 2, 6, 3, 8, 4]}
COMPARISONS = [
    ('currentAA', 'current', 'current'),
    ('oldGap_to_current', 'currentOldGap', 'current'),
    ('current_to_smallGap', 'current', 'currentSmallGap'),
    ('original_to_current', 'original', 'current'),
    ('oldSolve_to_current', 'currentOldSolve', 'current'),
]


def class_source(path):
    source = path.read_text()
    start = source.index('        class WholeGameDP')
    end = source.index('        function wholeGameWorkerSource()', start)
    return source[start:end]


INSTALL = r'''async ({originalSource,layouts}) => {
  const nativeRandom = Math.random;
  const methodNames = ['solveState','packStrategy','equilibrium',
    'sanitizePair','sanitize','strategyGap'];
  // The original declaration is evaluated, but its constructor is not run:
  // every method below uses the already prepared production DP receiver.
  const Original = (new Function(originalSource+'\nreturn WholeGameDP;'))();
  const original = Object.fromEntries(methodNames.map(name =>
    [name,Original.prototype[name]]));
  const current = Object.fromEntries(methodNames.map(name =>
    [name,WholeGameDP.prototype[name]]));
  function smallCountGap(count,pay,stay,value) {
    const p=this.probP, q=this.probQ;
    let minCol=Infinity, maxRow=-Infinity;
    if (count<=2) {
      for (let col=0;col<count;col++) {
        let expected=0;
        for (let row=0;row<count;row++)
          expected+=p[row]*(row===col?stay:pay[row]);
        if(expected<minCol) minCol=expected;
      }
    } else {
      for (let col=0;col<count;col++) {
        let expected=0;
        for(let row=0;row<col;row++) expected+=p[row]*pay[row];
        expected+=p[col]*stay;
        for(let row=col+1;row<count;row++) expected+=p[row]*pay[row];
        if(expected<minCol) minCol=expected;
      }
    }
    for(let row=0;row<count;row++) {
      const expected=pay[row]+q[row]*(stay-pay[row]);
      if(expected>maxRow) maxRow=expected;
    }
    return Math.max(Math.abs(minCol-value),Math.abs(maxRow-value));
  }
  const variants={original,current,
    currentOldGap:{...current,strategyGap:original.strategyGap},
    currentSmallGap:{...current,strategyGap:smallCountGap},
    currentOldSolve:{...current,solveState:original.solveState}};
  const marks=mask=>Array.from({length:9},(_,i)=>Boolean(mask&(1<<i)));
  Object.assign(state,{gameMode:'cpu',cpuDifficulty:'master',seatChosen:true,
    isStarting:true,gameEnded:false,isProcessing:false,firstPlayer:1,
    p1Marks:marks(0),p2Marks:marks(0),p1TurnsTaken:0,p2TurnsTaken:0,
    p1NumberLayout:layouts.p1.slice(),p2NumberLayout:layouts.p2.slice()});
  const prepareStarted=performance.now();
  startWholeGameCpu();
  await new Promise((resolve,reject)=>{
    const deadline=performance.now()+45000;
    const poll=()=>{
      if(cpuWholeStatus==='ready') return resolve();
      if(cpuWholeStatus==='fallback') return reject(new Error(cpuWholeFailure));
      if(performance.now()>deadline) return reject(new Error('Worker ready timeout'));
      setTimeout(poll,5);
    }; poll();
  });
  const dp=cpuWholeDp;
  const preparation={elapsedMs:performance.now()-prepareStarted,
    stats:{...cpuWholeStats}};
  Object.assign(state,{gameMode:'cpu',cpuDifficulty:'hard',seatChosen:true,
    isStarting:true,gameEnded:false,isProcessing:false,phase:'block',firstPlayer:1,
    p1Marks:marks(508),p2Marks:marks(502),p1TurnsTaken:7,p2TurnsTaken:7,
    selectedBreakCell:null});
  const decision={maskP1:508,maskP2:502,t:14};
  if(dp.attacker[14]!==1 || dp.closedCount[508]!==2)
    throw new Error('Unexpected target attacker/action count');
  const refs={dp,pay:dp.pay,p:dp.probP,q:dp.probQ,order:dp.order,
    p1Marks:state.p1Marks,p2Marks:state.p2Marks,
    p1Layout:state.p1NumberLayout,p2Layout:state.p2NumberLayout,
    layers:dp.layers,values:dp.layers.map(layer=>layer.values)};
  const fixedRandom=()=>0.8;
  Math.random=fixedRandom;
  function install(name) {
    for(const method of methodNames) dp[method]=variants[name][method];
  }
  function reset() {
    cpuWholeDecisions=cpuWholeLegacyDecisions=hardLegacyDecisions=hardDpDecisions=0;
    Object.assign(state,{cpuBlockedBreakCell:0,cpuBlockedBreakStreak:2,
      cpuBlockedCooldown:0,cpuSuccessfulBlockCell:0,cpuSuccessfulBlockStreak:2,
      cpuSuccessfulBlockCooldown:0});
    dp.pay.fill(0);dp.probP.fill(0);dp.probQ.fill(0);dp.order.fill(0);
    dp.monotone=false;
  }
  function counters() {return {whole:cpuWholeDecisions,
    fallback:cpuWholeLegacyDecisions,hardLegacy:hardLegacyDecisions,
    hardFull:hardDpDecisions};}
  function memory() {return {breakCell:state.cpuBlockedBreakCell,
    breakStreak:state.cpuBlockedBreakStreak,breakCooldown:state.cpuBlockedCooldown,
    blockCell:state.cpuSuccessfulBlockCell,blockStreak:state.cpuSuccessfulBlockStreak,
    blockCooldown:state.cpuSuccessfulBlockCooldown};}
  function assertRefs() {
    if(cpuWholeDp!==refs.dp || dp.pay!==refs.pay || dp.probP!==refs.p ||
       dp.probQ!==refs.q || dp.order!==refs.order || dp.layers!==refs.layers ||
       state.p1Marks!==refs.p1Marks || state.p2Marks!==refs.p2Marks ||
       state.p1NumberLayout!==refs.p1Layout || state.p2NumberLayout!==refs.p2Layout ||
       dp.layers.some((layer,i)=>layer.values!==refs.values[i]))
      throw new Error('Receiver, workspace, input or value-table reference changed');
  }
  function exact(a,b) {
    if(typeof a!==typeof b) return false;
    if(a===null || b===null) return a===b;
    if(typeof a!=='object') return Object.is(a,b);
    if(ArrayBuffer.isView(a)||Array.isArray(a)) {
      if(!(ArrayBuffer.isView(b)||Array.isArray(b))||a.length!==b.length) return false;
      for(let i=0;i<a.length;i++) if(!exact(a[i],b[i])) return false;
      return true;
    }
    const keys=Object.keys(a);
    return keys.length===Object.keys(b).length &&
      keys.every(key=>Object.hasOwn(b,key)&&exact(a[key],b[key]));
  }
  function choices(count) {
    let checksum=0,lastCell=null;
    for(let i=0;i<count;i++) {
      lastCell=selectCpuBlockCell(state.p1Marks,state.p1NumberLayout);
      checksum+=lastCell+1;
    }
    return {checksum,lastCell};
  }
  function verifyBatch(answer,count,expectedCell) {
    assertRefs();
    const c=counters();
    if(answer.lastCell!==expectedCell || answer.checksum!==(expectedCell+1)*count ||
       cpuWholeStatus!=='ready' || c.whole!==count || c.hardFull!==count ||
       c.fallback!==0 || c.hardLegacy!==0 || state.cpuBlockedCooldown!==0 ||
       state.cpuSuccessfulBlockCooldown!==0)
      throw new Error('Timed selector/checksum/dispatch/history mismatch');
  }
  const equivalence=[];
  let baseline=null;
  for(const name of Object.keys(variants)) {
    install(name);reset();
    const solved=dp.solveState(1,508,502,dp.layers[15],true);
    reset();
    const policy=dp.analyze(decision);
    if(policy.terminal.isTerminal || policy.attacker!==1)
      throw new Error('Target is not a nonterminal P1 BLOCK policy');
    const workspace={pay:dp.pay.slice(0,2),p:dp.probP.slice(0,2),q:dp.probQ.slice(0,2)};
    reset();
    const randomTrace=[];
    Math.random=()=>{randomTrace.push(0.8);return 0.8;};
    const selected=choices(8);
    Math.random=fixedRandom;
    const captured={solved,policy,workspace,selected,randomTrace,
      counters:counters(),memory:memory(),status:cpuWholeStatus};
    if(randomTrace.length!==16) throw new Error('Expected mix+sample RNG per decision');
    verifyBatch(selected,8,selected.lastCell);
    if(baseline===null) baseline=captured;
    else if(!exact(baseline,captured)) throw new Error('Object.is contract mismatch: '+name);
    equivalence.push({name,exact:true,rngCalls:randomTrace.length,
      selectedCell:selected.lastCell,counters:captured.counters});
  }
  const expectedCell=baseline.selected.lastCell;
  window.__stage7ChromeGap={
    warm(name,count) {
      install(name);reset();
      const answer=choices(count);
      verifyBatch(answer,count,expectedCell);
      return answer;
    },
    comparison({aName,bName,pairs,count,batchWarmup,run}) {
      const rows=[];
      for(let pair=0;pair<pairs;pair++) {
        const order=(pair+run)%2?['b','a']:['a','b'];
        const sampled={};
        for(const key of order) {
          const name=key==='a'?aName:bName;
          install(name);reset();
          const warm=choices(batchWarmup);
          verifyBatch(warm,batchWarmup,expectedCell);
          reset();
          const started=performance.now();
          const answer=choices(count);
          const elapsedMs=performance.now()-started;
          verifyBatch(answer,count,expectedCell);
          sampled[key]={elapsedMs,usPerCall:elapsedMs*1000/count,
            ...answer,status:cpuWholeStatus,counters:counters(),memory:memory()};
        }
        if(!exact(sampled.a.checksum,sampled.b.checksum)||
           !exact(sampled.a.counters,sampled.b.counters)||
           !exact(sampled.a.memory,sampled.b.memory)) throw new Error('Pair contract mismatch');
        rows.push({pair:pair+1,order,a:sampled.a,b:sampled.b});
      }
      return rows;
    },
    cleanup() {
      install('current');Math.random=nativeRandom;releaseWholeGameCpu();
    }
  };
  return {preparation,equivalence,baseline,visibility:document.visibilityState,
    target:{firstPlayer:1,role:'block',difficulty:'hard',engine:'ready',mixRoll:0.8,
      sampleRoll:0.8,...decision,attacker:1,closedCount:2},
    methodNames,variants:Object.keys(variants),sameReceiverAndArrays:true,
    crossOriginIsolated};
}'''


def summarize(rows):
    deltas = [pair['b']['usPerCall'] - pair['a']['usPerCall'] for pair in rows]
    return {'aMedianUs': statistics.median(pair['a']['usPerCall'] for pair in rows),
            'bMedianUs': statistics.median(pair['b']['usPerCall'] for pair in rows),
            'pairedMedianDeltaUs': statistics.median(deltas),
            'pairedRangeDeltaUs': [min(deltas), max(deltas)],
            'pairedDeltasUs': deltas,
            'positivePairs': sum(delta > 0 for delta in deltas),
            'negativePairs': sum(delta < 0 for delta in deltas)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--before', type=Path, default=ROOT / 'index.before.html')
    parser.add_argument('--current', type=Path, default=ROOT / 'index.html')
    parser.add_argument('--output', type=Path, default=ROOT / 'validation/stage7/chrome-gap.json')
    parser.add_argument('--runs', type=int, default=2)
    parser.add_argument('--pairs', type=int, default=9)
    parser.add_argument('--calls', type=int, default=20000)
    parser.add_argument('--warmup', type=int, default=20000)
    parser.add_argument('--batch-warmup', type=int, default=2000)
    args = parser.parse_args()
    if min(args.runs, args.pairs, args.calls, args.warmup, args.batch_warmup) <= 0:
        parser.error('All measurement counts must be positive')
    before, current = args.before.resolve(), args.current.resolve()
    current.relative_to(ROOT)
    result = {'sources': {key: {'path': str(path),
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        for key, path in [('original', before), ('production', current)]},
        'conditions': {'productionModified': False,
            'pageModel': 'one visible foreground top-level Chromium page per fresh browser',
            'transport': 'ordinary HTTP, no COOP/COEP timer enhancement',
            'worker': 'real production Blob Worker; firstPlayer=1 prepared once per browser',
            'runs': args.runs, 'pairedBatchesPerComparison': args.pairs,
            'callsPerBatch': args.calls, 'initialWarmupCallsPerVariant': args.warmup,
            'untimedWarmupBeforeEachBatch': args.batch_warmup,
            'comparisons': [{'name': name, 'a': a, 'b': b} for name, a, b in COMPARISONS],
            'run2Reverses': ['comparison order', 'first paired batch order', 'initial warmup variant order'],
            'state': 'fixed public marks/layouts/t=14, isStarting=true, history restored outside batches; no outcome updates',
            'methodSwap': 'six own properties on the same production DP; oldGap/smallGap/oldSolve change only the named method',
            'sourceDiffIsolation': 'original solveState retains unused maxPay initialization and per-payoff comparisons; current solveState removes only that unused tracking',
            'timing': 'real selectCpuBlockCell plus integer checksum with constant Math.random=0.8',
            'equivalence': 'untimed Object.is recursive policies/value/gap/P/Q; RNG trace, dispatch counters, selections, history',
            'notMeasured': ['trusted clicks', 'event-to-paint latency', 'fresh selector cold cost',
                'outcome/history updates', 'other 103 selector conditions'],
            'inference': 'paired raw deltas only; no performance PASS, tolerance, or A/A subtraction'},
        'runs': [], 'pooled': [], 'completed': False}

    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *unused):
            pass

    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0),
        functools.partial(Handler, directory=str(ROOT)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        with sync_playwright() as playwright:
            for run in range(args.runs):
                browser = playwright.chromium.launch(executable_path='/usr/bin/chromium',
                    headless=True, args=['--no-sandbox', '--disable-dev-shm-usage'])
                record = {'run': run + 1, 'browserVersion': browser.version,
                          'pageErrors': [], 'rows': []}
                result['runs'].append(record)
                try:
                    page = browser.new_page(viewport={'width': 1280, 'height': 900})
                    page.on('pageerror', lambda error, rec=record: rec['pageErrors'].append(str(error)))
                    page.goto(f'http://127.0.0.1:{server.server_port}/{current.relative_to(ROOT).as_posix()}',
                              wait_until='load')
                    page.bring_to_front()
                    tests = json.loads(page.locator('#rule-test-results').text_content())
                    record['selfTests'] = tests
                    if tests['passed'] != tests['total'] or tests.get('failures'):
                        raise RuntimeError('Production automatic self-tests failed')
                    record['setup'] = page.evaluate(INSTALL, {
                        'originalSource': class_source(before), 'layouts': LAYOUTS})
                    if record['setup']['visibility'] != 'visible':
                        raise RuntimeError('Benchmark page is not foreground-visible')
                    if record['setup']['crossOriginIsolated']:
                        raise RuntimeError('Unexpected fine-clock cross-origin isolation')
                    variants = record['setup']['variants']
                    warm_order = variants if run % 2 == 0 else list(reversed(variants))
                    record['warmOrder'] = warm_order
                    for name in warm_order:
                        page.evaluate('({name,count})=>__stage7ChromeGap.warm(name,count)',
                                      {'name': name, 'count': args.warmup})
                    comparisons = COMPARISONS if run % 2 == 0 else list(reversed(COMPARISONS))
                    record['comparisonOrder'] = [entry[0] for entry in comparisons]
                    for name, a_name, b_name in comparisons:
                        pairs = page.evaluate('config=>__stage7ChromeGap.comparison(config)',
                            {'aName': a_name, 'bName': b_name, 'pairs': args.pairs,
                             'count': args.calls, 'batchWarmup': args.batch_warmup, 'run': run})
                        row = {'name': name, 'aName': a_name, 'bName': b_name,
                               'pairs': pairs, 'summary': summarize(pairs)}
                        record['rows'].append(row)
                        print(f'run {run+1} {name}: paired delta '
                              f'{row["summary"]["pairedMedianDeltaUs"]:+.6f} us', flush=True)
                    page.evaluate('__stage7ChromeGap.cleanup()')
                    if record['pageErrors']:
                        raise RuntimeError(f'Browser errors: {record["pageErrors"]}')
                finally:
                    browser.close()
        for name, a_name, b_name in COMPARISONS:
            rows = [row for run in result['runs'] for row in run['rows'] if row['name'] == name]
            pairs = [pair for row in rows for pair in row['pairs']]
            result['pooled'].append({'name': name, 'aName': a_name, 'bName': b_name,
                'runSummaries': [row['summary'] for row in rows], 'summary': summarize(pairs)})
        result['conditions']['timedChoices'] = args.runs * len(COMPARISONS) * args.pairs * 2 * args.calls
        result['conditions']['warmupChoices'] = (args.runs * 5 * args.warmup +
            args.runs * len(COMPARISONS) * args.pairs * 2 * args.batch_warmup)
        result['completed'] = True
    except Exception as error:
        result['failure'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        server.shutdown()
        server.server_close()
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')


if __name__ == '__main__':
    main()
