#!/usr/bin/env python3
"""Freeze checksums and archive; verify every archived byte against that manifest."""
import hashlib,json,time,zipfile
from pathlib import Path
R=Path(__file__).resolve().parent
DEST=R.parent/'BINGO-BOUT-stage16-20261015.zip'
def digest_file(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def main():
 assert not DEST.exists(),'refuse overwrite bundle'
 assert json.loads((R/'integrity.json').read_text())['status']=='completed'
 files=sorted(p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.tmp') and p.name!='SHA256SUMS')
 hashes={p.relative_to(R).as_posix():digest_file(p) for p in files}
 manifest=R/'SHA256SUMS';manifest.write_text(''.join(f'{h}  {n}\n' for n,h in hashes.items()))
 prefix='BINGO-BOUT-stage16-20261015/'
 with zipfile.ZipFile(DEST,'x',zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
  for p in files+[manifest]:z.write(p,prefix+p.relative_to(R).as_posix())
 with zipfile.ZipFile(DEST) as z:
  assert len(z.namelist())==len(hashes)+1
  assert z.read(prefix+'SHA256SUMS')==manifest.read_bytes()
  for n,expected in hashes.items():
   h=hashlib.sha256()
   with z.open(prefix+n) as f:
    for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
   assert h.hexdigest()==expected,n
 result={'status':'verified','zip':str(DEST),'files':len(files)+1,'uncompressedBytes':sum(p.stat().st_size for p in files+[manifest]),'zipBytes':DEST.stat().st_size,'zipSha256':digest_file(DEST),'allArchiveContentsHashVerified':True}
 DEST.with_suffix('.zip.sha256').write_text(f"{result['zipSha256']}  {DEST.name}\n")
 DEST.with_suffix('.bundle.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
