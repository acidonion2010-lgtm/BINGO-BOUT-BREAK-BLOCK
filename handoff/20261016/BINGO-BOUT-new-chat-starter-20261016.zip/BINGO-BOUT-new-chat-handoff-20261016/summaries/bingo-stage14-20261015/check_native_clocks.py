#!/usr/bin/env python3
"""Run the predeclared finite native-clock bracket check; no browser jobs."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    assert not args.output.exists(),'Refuse overwrite'
    root=Path(__file__).resolve().parent;build=args.output.parent/'native-clock-build'
    assert not build.exists(),'Refuse existing native build directory'
    build.mkdir(parents=True);binary=(build/'native-clocks').resolve()
    command=['cc','-std=c11','-O2','-Wall','-Wextra','-Werror',str(root/'native_clocks.c'),'-o',str(binary)]
    result={'status':'running','sourceSha256':hashlib.sha256((root/'native_clocks.c').read_bytes()).hexdigest(),
            'planSha256':hashlib.sha256((root/'CLOCK_PLAN.md').read_bytes()).hexdigest(),
            'scriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'compileCommand':command,'runs':[],'strictChromiumCpuAccountingConfirmed':False}
    try:
        compile_result=subprocess.run(command,capture_output=True,text=True,timeout=30)
        result['compiler']={'exitCode':compile_result.returncode,'stdout':compile_result.stdout,'stderr':compile_result.stderr}
        assert compile_result.returncode==0,'Compiler failure'
        result['binarySha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
        for run in range(1,5):
            capture=subprocess.run([str(binary)],capture_output=True,text=True,timeout=30)
            record={'run':run,'exitCode':capture.returncode,'stderr':capture.stderr,'stdout':capture.stdout}
            result['runs'].append(record);assert capture.returncode==0,'Native helper failed'
            rows=json.loads(capture.stdout);record['samples']=rows;assert len(rows)==128
            for index,row in enumerate(rows):
                assert row['sample']==index and row['scenario']==index%4
                assert row['wall0Ns']<=row['wall1Ns']<=row['wall2Ns']<=row['wall3Ns']
                assert row['cpu1Ns']>=row['cpu0Ns']
                row['outerWallNs']=row['wall3Ns']-row['wall0Ns'];row['threadCpuNs']=row['cpu1Ns']-row['cpu0Ns']
                row['cpuWithinOuterWall']=row['threadCpuNs']<=row['outerWallNs']
        all_rows=[s for run in result['runs'] for s in run['samples']]
        result.update({'status':'completed','samples':len(all_rows),'cpuExceedsOuterWallSamples':sum(not x['cpuWithinOuterWall'] for x in all_rows),
                       'coreChangedSamples':sum(x['coreBefore']!=x['coreAfter'] for x in all_rows)})
        assert len(all_rows)==512
    except BaseException as error:result.update({'status':'failed','failure':repr(error)});raise
    finally:
        with args.output.open('x') as f:f.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['status','samples','cpuExceedsOuterWallSamples','coreChangedSamples']}))


if __name__=='__main__':main()
