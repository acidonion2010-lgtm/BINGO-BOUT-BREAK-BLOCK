# Native負荷下時計診断の独立レビュー

2026-10-15。`NATIVE_PLAN.md`、`native_clock_load.c`、`check_clock_load.py`、`native-load.json`と保存binaryを読み取り点検した。追加のcompile・binary実行・ブラウザー・性能測定は行っていない。再計算は`review_native.py`、結果は`native-independent-review.json`へ保存した。元source/plan/dataは変更していない。

**保存された4,608区間の端点・集計・入力hashは整合し、今回のnative診断を記述するうえでblockerはない。** ChromiumのCPU時計や元169件の原因を承認する結果ではない。

## 仕様・実行順・hash

- 記録されたplan、C source、Python runner、保存binaryのSHA-256が現在の各ファイルと一致した。compile commandもC11/O2/Wall/Wextra/Werror/pthreadと保存source/binary pathへ一致し、compilerはreturnCode0、stdout/stderr空だった。
- process順は(run1,1thread)→(run1,8thread)→(run2,8thread)→(run2,1thread)→(run3,1thread)→(run3,8thread)→(run4,8thread)→(run4,1thread)の事前計画どおり。
- 8processすべてreturnCode0・stderr空。C sourceは1thread時にmain自身、8thread時にmain＋7pthreadを使い、全参加threadで同じbarrierに到達してから試行を開始する。各threadは別のWorker配列要素とローカルvolatile演算値を使い、測定中のprintfはない。全36 TIDは正で重複しない。
- 各thread128件、scenario=(sample+thread index)%4、各条件32件を確認した。全体は各条件1,152件、総4,608件。削除・追加sampleは見つからない。

## 時計端点・bracket実装

C sourceの読み取り順はcore0→wall0→CPU0→wall1→work→wall2→条件3だけ追加busy→CPU1→wall3→core1である。CPU0/CPU1は同じ実行threadの`CLOCK_THREAD_CPUTIME_ID`、wallは`CLOCK_MONOTONIC`。`clock_gettime`は成功を要求し、異なる原点の絶対値を引かず、それぞれのclock内の差だけを使う。

この順序ではCPU区間をwall0〜wall3が外側から包む。wall0〜wall2はCPU1の読み取りより先に終わるため、同時区間とは扱えない。条件3はそこへ明示的な追加busyを挟む対照であり、外側bracketの必要性を調べる実装として妥当である。

Pythonに保存された全端点を元stdoutのJSONと照合し、全derived fieldを独立再計算した。全4,608件でwall0≤wall1≤wall2≤wall3、CPU0≤CPU1、0≤CPU差≤wall3−wall0だった。各threadの次試行も前試行のwall3/CPU1以降に始まり、core番号は非負だった。外側超過を0へclampする実装はなく、保存された符号付き差を再計算して一致した。

`busy(1ms/4ms)`はwall時計の期限までvolatile演算を繰り返す。特に8thread条件で、一定量のCPU時間を全sampleへ投入した証明ではない。条件2のnanosleepはEINTR時に残時間で再開し、他のAPI失敗は停止する。barrier・pthread join・destroyの順も整合している。

## 集計の再計算

| scenario | 件数 | 外側CPU超過 | 非同時wall0→wall2のCPU超過 | うち1µs超 |
|---|---:|---:|---:|---:|
| 0: busy1ms | 1,152 | 0 | 939 | 19 |
| 1: yield＋busy4ms | 1,152 | 0 | 483 | 51 |
| 2: busy1ms＋sleep2ms | 1,152 | 0 | 0 | 0 |
| 3: wall2後に追加busy1ms | 1,152 | 0 | 1,151 | 1,151 |

条件3の残る1件も保存されており、成功するまでの再試行や除外はない。意図的な遅延がなくても条件0/1では小さな非同時超過が出ており、非同時のwall窓だけをCPU時計の整合性判定に使えない。1µsという区切りは記録の規模を示すもので、合否許容差ではない。

各processのcontext switch before/afterは単調で、thread全体のrusage deltasとして保存されている。これらはbarrier待機等も含む128試行の外側記録であり、各区間のCPU/待機原因へ割り振らない。共有cgroup before/afterも再差分を計算でき、個々のthreadやゲームの負荷と同一視しない。

## 解釈の境界

外側bracketで違反が出なかったのは、この8process・4,608区間のnative経路に限る。Chromium/Perfettoのイベント採取・明示timestamp・packet変換・renderer負荷の再現ではない。意図的1ms遅延で非同時超過を作れたことは、元169件でその遅延が起きた証拠にならない。

特に保存traceには大きいCPU超過の直後へ短いwall gapで次eventが続く例があり、非同時取得の一般論だけではその細部を説明できない。今回のnative記録はその不整合を補正せず、段階14のCPU寄与率や全経路性能PASSを復活させない。`chromiumCpuAccountingConfirmed=false`の保存値は適切である。
