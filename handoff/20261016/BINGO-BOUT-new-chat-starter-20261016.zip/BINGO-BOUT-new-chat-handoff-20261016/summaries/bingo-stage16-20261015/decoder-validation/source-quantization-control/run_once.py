#!/usr/bin/env python3
"""Execute the fixed control plan once; retain failure evidence, never retry."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
STAGE = ROOT.parents[1]
TOOL = STAGE / "trace_processor_shell"
FIXTURE = ROOT / "source-quantization-control.pftrace"
OUTPUT = ROOT / "official-control.json"
KNOWN_TOOL_SHA256 = "58042408e6cc861fb1a731c26bb082dc222285561eaa4e12a48a8b2b90dca7b9"


def exclusive_json(path, value):
    with path.open("x") as f:
        f.write(json.dumps(value, indent=2) + "\n")


def main():
    assert not FIXTURE.exists() and not OUTPUT.exists(), "Fixed outputs already exist; no rerun allowed"
    tool_hash = hashlib.sha256(TOOL.read_bytes()).hexdigest()
    assert tool_hash == KNOWN_TOOL_SHA256, "Tool differs from saved release evidence"
    generation = subprocess.run([sys.executable, str(ROOT / "generate_control.py")],
                                text=True, capture_output=True, timeout=30)
    generation_record = {"argv": generation.args, "returncode": generation.returncode,
                         "stdout": generation.stdout, "stderr": generation.stderr}
    exclusive_json(ROOT / "generation.json", generation_record)
    if generation.returncode:
        exclusive_json(ROOT / "result.json", {"status": "generation_failed", "generation": generation_record})
        return 1
    argv = [str(TOOL), "convert", "json", str(FIXTURE), str(OUTPUT)]
    # Exactly one official conversion. No version execution, SQL, retries or
    # automatic replacement follows this call.
    conversion = subprocess.run(argv, text=True, capture_output=True, timeout=30)
    record = {"argv": argv, "returncode": conversion.returncode,
              "stdout": conversion.stdout, "stderr": conversion.stderr,
              "tool_sha256": tool_hash,
              "tool_version_provenance": str(ROOT.parent / "version.stdout.txt"),
              "official_conversion_count": 1}
    exclusive_json(ROOT / "official-command.json", record)
    result = {"official_conversion_count": 1, "tool_sha256": tool_hash,
              "scope": "Constructed source quantization positive control; not actual-trace same-cause proof."}
    if conversion.returncode:
        result["status"] = "conversion_failed"
        exclusive_json(ROOT / "result.json", result)
        return 1
    try:
        expected = json.loads((ROOT / "expected.json").read_text())
        official = json.loads(OUTPUT.read_text())
        matches = [event for event in official["traceEvents"]
                   if event.get("name") == expected["expected_json_marker"]]
        checks = {"one_target_event": len(matches) == 1}
        if len(matches) == 1:
            target = matches[0]
            for key, field in [("ph", "expected_json_ph"), ("ts", "expected_json_ts_us"),
                               ("dur", "expected_json_dur_us"), ("tts", "expected_json_tts_us"),
                               ("tdur", "expected_json_tdur_us")]:
                checks[key + "_matches_fixed_prediction"] = target.get(key) == expected[field]
            checks["represented_cpu_gt_represented_wall"] = target.get("tdur", -1) > target.get("dur", 0)
            result["official_target"] = target
        stats = official.get("metadata", {}).get("trace_processor_stats", {})
        error_stats = {name: value for name, value in stats.items()
                       if value and (name.startswith("clock_sync_failure")
                                     or name == "invalid_clock_snapshots"
                                     or name == "invalid_cpu_times"
                                     or name == "clock_sync_unrelatable_clock_domains"
                                     or name.startswith("track_event_")
                                     or name in ["misplaced_end_event", "slice_negative_duration"])}
        result.update(expected=expected, checks=checks, relevant_nonzero_error_stats=error_stats,
                      status=("passed_with_diagnostics" if error_stats else "passed") if all(checks.values()) else "prediction_failed")
    except Exception as error:
        result.update(status="inspection_failed", error={"type": type(error).__name__, "message": str(error)})
    exclusive_json(ROOT / "result.json", result)
    print(json.dumps({"status": result["status"], "target": result.get("official_target"),
                      "official_conversion_count": 1, "errors": result.get("relevant_nonzero_error_stats")}))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    sys.exit(main())
