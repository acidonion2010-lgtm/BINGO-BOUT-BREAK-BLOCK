# Bingo Bout: 添付 HTML の CPU 評価

対象はこのフォルダーの `source.html`。GitHub 上の旧版ではなく、今回添付された 483,598 bytes のファイルをそのまま保存したものです。SHA-256 は `6fd67e3b4faf0417635ab4eff1ee66130b570c5411e4ba93703e2ae9389ada24`。

`report_ja.md` が評価報告、`results/tables.md` と `results/summary*.csv` が統計表、`results/pair-*.jsonl` が全対戦結果です。事前に固定した評価設計は `design.json` にあります。元ゲームのルール、CPU 関数、難易度パラメーターを変更していません。

## 再現

必要環境: Node.js 24、Python 3.12、NumPy、SciPy。ブラウザ照合だけ追加で Python Playwright と Chromium が必要です。このクラウド環境では利用できます。ベンチマーク本体に npm パッケージは不要です。

使用版はNode v24.19.0、Python 3.12.14、NumPy 2.3.5、SciPy 1.17.0、Playwright 1.62.0、Chromium 154.0.8037.57。Python依存は `requirements-eval.txt` に固定しました。グラフの再描画にはMatplotlibも使います。

```bash
cd /workspace/bingo-evaluation
node validate.cjs
python3 browser_validation.py
python3 run.py --jobs 3 --out rerun_results
python3 run.py --check-only --out rerun_results
node audit_cases.cjs results
python3 audit_dp.py
node sampler_audit.cjs
node profile_audit.cjs
node theory_examples.cjs
```

既存の主評価データの完全性は次で確認できます。

```bash
python3 run.py --check-only --out results
python3 analyze.py --input-dir results
MPLCONFIGDIR=/tmp/bingo-mpl python3 plot_results.py
```

個別盤面の再実行は `BINGO_OUT=replay BINGO_REPS=64 node simulate.cjs 0 1`。任意の1局の全手順は `node replay.cjs 0 0 1 master greedy 17`（引数は盤面ペア・交換有無・先攻プレイヤー・CPU難易度・相手・反復番号）。この例は既存の検証済み履歴と全手一致を確認済みです。`BINGO_REPS=1 BINGO_SMOKE=1` とすると少数の対戦の全手順を結果に記録できます（主評価とは別データ）。主評価の64回を変更した結果を主評価と同一視しないでください。

`run.py` は新しい出力先に固定設計の全196,608局を再生成します。集計は `analyze.py` のヘルプを参照してください。並列数は結果に影響しません。実行時間は CPU 性能・並列負荷に依存します。DP 表は1条件約18.3 MBで、同じ配置と席順について繰り返し利用します。

## 読み込みと乱数

`loader.cjs` は添付 HTML の唯一のインライン script を抽出し、末尾の DOM 初期化・イベント登録だけを実行対象から外します。その前の CPU/得点/到達可能性/終了判定/DP 関数は本文をそのまま Node VM で実行します。UI・音・アニメーションを動かさず、対戦の選択とルールだけを実行します。ソースの SHA が異なれば主評価は停止します。

Mulberry32 を使用。seed は `SHA256(parts.join('|'))` の先頭32bit little endian。盤面は `('bingo-v1','layout',pair)` で本体の `createIndividualNumberLayouts()` を呼びます。意思決定は `('bingo-v1','action',pair,swap,firstPlayer,rep,t,actor)`。難易度・相手名をseedに含めないことで共通乱数を割り当て、実装内での乱数呼び出し順序は保ちます。CPU と相手の stream は独立であり、相手は選択された秘密の手を参照しません。実ブラウザで音を鳴らす通常プレイの乱数消費列を丸ごと再現するものではありません。

## ファイル

- `simulate.cjs`: 元 CPU の呼び出し、共通相手、対戦ループ。元の終了判定と DP の終了判定を毎手照合。
- `validate.cjs`: 得点1024状態・到達可能点10240状態と再実行24局の検証。
- `browser_validation.py`, `browser_expected.cjs`: 実 Chromium/Worker と VM の選択288件照合。
- `audit_cases.cjs`, `audit_dp.py`: 局所ゲームの独立 LP、終盤再帰、固定政策への完全ゲーム最適応答。
- `sampler_audit.cjs`: 元抽選関数の頻度検証。
- `analyze.py`: 盤面ペアを単位にした95% cluster bootstrap。
- `logs/`, `results/`: 検証・実行ログ、設定別DP統計、対戦生データ、解析出力。

詳しい数学監査は [DP_AUDIT.md](DP_AUDIT.md)。全状態期待値の比較は `results/dp_exact_best_response.csv` と `results/dp_exact_fixed_nash.csv`、統計を図示したPNG/SVGは `results/difficulty_comparison.*` にあります。`CHECKSUMS.sha256` は配布時点の各成果物のチェックサムです。

主評価は DP が正常準備できた場合を評価します。MASTER の fallback は盤面単体 DP、HARD の fallback は従来方式100%であり、主評価には混ぜません。ブラウザ照合では実際の Worker が ready になることを別途確認します。思考時間切れ、反応速度、人間の学習、対戦中のUI操作、音響、連戦の心理効果は評価対象外です。
