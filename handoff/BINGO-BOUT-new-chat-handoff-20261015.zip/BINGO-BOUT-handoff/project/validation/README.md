# CPU comparison harness

Latest implementation and evidence: `stage9/README.md` and `../段階9比較結果.md`.
Production now adopts stage9 single-decision BREAK weight reuse. The received stage5
HTML and its GitHub URL remain frozen as historical handoffs. Earlier records below
refer to their corresponding historical stages, not the current four-function change.

The game HTML is served without modification and evaluated in `/usr/bin/chromium`
using the Python Playwright package already installed in this cloud environment.
This is development validation; no library or network service is added to the
standalone game. All HTTP traffic remains on localhost.

Run from `/workspace`:

```bash
python bingo-refactor/validation/capture.py bingo-refactor/index.before.html bingo-refactor/validation/before --repeats 5
python bingo-refactor/validation/capture.py bingo-refactor/index.html bingo-refactor/validation/after --repeats 5
python bingo-refactor/validation/compare.py bingo-refactor/validation/before bingo-refactor/validation/after --output bingo-refactor/validation/comparison.json
python bingo-refactor/validation/performance.py bingo-refactor/index.before.html bingo-refactor/index.html bingo-refactor/validation/performance.json
python bingo-refactor/validation/hand_performance.py bingo-refactor/index.before.html bingo-refactor/index.html bingo-refactor/validation/hand-performance.json
```

`capture.py` starts and stops its own local server on port 8001. Do not run other
browser/DP jobs while measuring performance. `performance.py` interleaves the
before and after versions, reverses their order on alternating rounds, and reports
five-sample medians for startup (including the existing automatic self tests) and
MASTER preparation using identical layouts.

`hand_performance.py` uses two loaded pages in the same browser, solves each first
player configuration once, then alternates original/refactored timed batches.
It warms each difficulty/role path for 20,000 calls, measures nine paired batches
of 20,000 calls, and reverses version order between batches. The original game
functions and standalone Blob Worker are used throughout.

The delivered evidence includes two independent one-step runs:
`hand-performance.json` and `hand-performance-repeat.json`. Both runs are retained;
`hand-performance-combined.json` pools all 18 batches per path without discarding
samples. Some path medians increase and others decrease, and several signs reverse
on the second run. The largest single-run increase was 0.390 microseconds. These
measurements do not prove universal per-step non-regression or a statistically
significant change across devices.

`selection-source-control.json` records that 21 legacy selection and dispatch
functions have exactly identical source in the original and final HTML. In
particular, NORMAL never calls the shared equilibrium solver; its small timing
differences cannot be ascribed to an algorithm change in that solver.

`validated-summary.json` combines the functional comparisons and controlled
timings. `comparison.json`'s snapshot-capture timings are retained as reference;
the controlled `performance.json` and paired hand timing files should be used for
the final performance report.

Each snapshot contains:

- Automatic 322-case self-test results on every fresh load, plus a separately timed
  explicit self-test run in freshly loaded initial menu state.
- Whole-game value tables for both first-player settings, each containing
  2,290,622 Float64 values (18,324,976 bytes), saved as raw binary for complete
  numerical comparison.
- 36 representative policies covering beginning/middle/end, both BREAK/BLOCK
  roles, both first players, scoring, crossing lines, one/two closed cells, and
  losing-action classification. Terminal decisions are recorded and skipped in
  ready-DP selection tests.
- Complete board-only fallback tables: 2,816 rows per layout, including 512
  terminal score rows and 2,304 reachable decision states with both probability
  distributions. In total, 4,608 decision states and 1,024 terminal score states
  are compared.
- 416 fixed-random-stream scenarios, with four consecutive picks each (1,664
  total picks), including NORMAL/HARD/MASTER, ready/fallback paths, exact draws
  consumed in sequence, per-pick draw counts, and BREAK/BLOCK history updates.
- Seven direct equilibrium boundary cases: single candidate, zero gains, positive
  gains, negative gains, mixed gains, tied actions, and near-zero numerical gains.
- Warmed per-decision timings (3,000 warmup calls and seven batches of 1,000 calls)
  for all difficulty/role/first-player combinations. Random stream is held at 0.8;
  HARD therefore measures its whole-game branch, while normal legacy timings are
  separate.

`compare.py` keeps exact random-stream/choice/history equality distinct from
numeric equivalence. Whole-game values and fallback values use an absolute
1e-9 tolerance; probability arrays use 1e-8. Exact matches and maximum differences
are reported separately. The final pass also requires all automatic and explicit
self-tests to pass and no uncaught browser exceptions.

Worker failures and stale-result lifecycle tests are supplied separately by the
worker lifecycle harness; this harness tests genuine Blob Worker preparation
success and compares its entire transferred tables.

Timings are measurements on this cloud machine, not a guarantee for all devices.
Absolute differences of a few microseconds in decision batches can reflect JIT,
garbage collection, and scheduler variation. No process-wide memory metric is
claimed; value-table buffer sizes and avoided allocations are separate facts.

Additional checks from /workspace:

```bash
node bingo-refactor/validation/equilibrium_edges.cjs
python bingo-refactor/validation/worker_lifecycle.py bingo-refactor/index.html --out bingo-refactor/validation/worker_after.json
python3 -m http.server 8003 --bind 127.0.0.1 --directory /workspace/bingo-refactor
# In a separate terminal while that server runs:
python bingo-refactor/validation/gameplay_smoke.py
```

The original Worker defect tests intentionally fail six target criteria; the final
Worker runner exits 0 only when every check passes. gameplay_smoke.py checks seven
real control flows, and equilibrium_edges.cjs compares 4,617 signed or boundary
equilibria exactly. See 比較結果.md for unresolved strict per-decision performance
verification: the repeated microbenchmarks contain small increases as well as decreases.
