#!/usr/bin/env python3
"""Stage8 response-marker windows, retaining unfinished scopes outside them.

Trace diagnostics only: neither a normal-input benchmark nor a latency PASS.
Uncovered timeline intervals are not asserted to be idle or off-CPU intervals.
"""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics


def union_us(intervals, lo, hi):
    clipped = sorted((max(a, lo), min(b, hi)) for a, b in intervals
                     if b > lo and a < hi)
    total = 0
    end = lo
    for a, b in clipped:
        total += max(0, b - max(a, end))
        end = max(end, b)
    return total


def clock_window(start, end):
    wall = (end['ts'] - start['ts']) / 1000
    cpu = (end['tts'] - start['tts']) / 1000
    assert wall >= 0 and 0 <= cpu <= wall + 0.1, (wall, cpu)
    return {'traceWallMs': wall, 'rendererMainThreadCpuMs': cpu,
            'wallMinusThreadCpuMs': wall - cpu}


def analyse(folder):
    rows = []
    for file in sorted((folder / 'samples').glob('*.json')):
        sample = json.loads(file.read_text())
        if not sample['traced']:
            continue
        trace_meta = sample['trace']
        assert trace_meta['integrityChecksPassed']
        path = Path(trace_meta['path'])
        raw = path.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == trace_meta['sha256']
        trace = json.loads(raw)
        assert trace['metadata']['clock-domain'] == 'LINUX_CLOCK_MONOTONIC'
        events = trace['traceEvents']
        marks, stamps = {}, {}
        for marker in sample['markers']:
            perf = [e for e in events if e['name'] == marker['name']
                    and e.get('cat') == 'blink.user_timing']
            stamp = [e for e in events if e['name'] == 'TimeStamp'
                     and e.get('args', {}).get('data', {}).get('message') == marker['name']]
            assert len(perf) == len(stamp) == 1
            trace_start = perf[0]['args']['data']['startTime']
            page_start = marker['performanceMarkStartTimeMs']
            # Two JSON serialization paths differ by one floating-point ULP
            # for some markers. This correspondence check is not a timing
            # tolerance or a non-regression rule. ts/tts remain unchanged.
            assert abs(trace_start - page_start) <= max(math.ulp(trace_start), math.ulp(page_start))
            marks[marker['label']], stamps[marker['label']] = perf[0], stamp[0]
        threads = {(e['pid'], e['tid']) for e in [*marks.values(), *stamps.values()]}
        assert len(threads) == 1
        pid, tid = next(iter(threads))
        assert any(e['name'] == 'thread_name' and e['pid'] == pid and e['tid'] == tid
                   and e['args']['name'] == 'CrRendererMain' for e in events)
        main = [e for e in events if e.get('pid') == pid and e.get('tid') == tid]
        # Chromium exports completed duration scopes as X, but a scope still
        # open at Tracing.end may be exported as B. Such starts after the
        # second callback cannot intersect any response window. An E before
        # capture likewise ends outside every response window. Preserve these
        # boundary records explicitly; reject an unsupported boundary scope
        # that could affect any measured response window.
        boundaries = [e for e in main if e.get('ph') in ('B', 'E')]
        lo, hi = marks['capture']['ts'], marks['second-raf']['ts']
        assert all((e['ph'] == 'B' and e['ts'] >= hi)
                   or (e['ph'] == 'E' and e['ts'] <= lo) for e in boundaries), {
                       'unsupportedSynchronousScopeWithinResponse': boundaries}
        complete = [e for e in main if e.get('ph') == 'X' and e.get('dur', 0) > 0]
        windows = {}
        for name, a, b in [('handler', 'capture', 'handler-end'),
                           ('handlerToFirstRaf', 'handler-end', 'first-raf'),
                           ('firstToSecondRaf', 'first-raf', 'second-raf'),
                           ('captureToSecondRaf', 'capture', 'second-raf')]:
            lo, hi = marks[a]['ts'], marks[b]['ts']
            row = clock_window(marks[a], marks[b])
            row['consoleTimeStampClockWindow'] = clock_window(stamps[a], stamps[b])
            row['recordedXIntervalUnionMs'] = union_us(
                [(e['ts'], e['ts'] + e['dur']) for e in complete], lo, hi) / 1000
            row['intervalUnionByCategoryMs'] = {}
            groups = {'styleLayout': {'UpdateLayoutTree', 'Layout'},
                      'paintPreparation': {'PrePaint', 'Paint', 'Layerize'},
                      'functionCall': {'FunctionCall'},
                      'eventDispatch': {'EventDispatch'},
                      'animationCallback': {'FireAnimationFrame'},
                      'garbageCollection': {e['name'] for e in complete
                                            if 'GC' in e['name']}}
            for category, names in groups.items():
                row['intervalUnionByCategoryMs'][category] = union_us(
                    [(e['ts'], e['ts'] + e['dur']) for e in complete
                     if e['name'] in names], lo, hi) / 1000
            row['functionCalls'] = [
                {'function': e.get('args', {}).get('data', {}),
                 'clippedWallMs': (min(hi, e['ts'] + e['dur']) - max(lo, e['ts'])) / 1000,
                 'fullEventWallMs': e['dur'] / 1000,
                 'fullEventThreadCpuMs': e.get('tdur', 0) / 1000}
                for e in complete if e['name'] == 'FunctionCall'
                and e['ts'] + e['dur'] > lo and e['ts'] < hi]
            windows[name] = row
        deltas = {k: sample['cpuGroupAfterCallbacks']['cpu.stat'][k]
                  - sample['cpuGroupBeforeInput']['cpu.stat'][k]
                  for k in ('usage_usec', 'nr_throttled', 'throttled_usec')}
        rows.append({'sample': file.name, 'sourceSample': str(file),
                     'rendererThread': {'pid': pid, 'tid': tid},
                     'boundaryScopeEventsOutsideResponseWindows': boundaries,
                     'pageMetrics': {key: sample['sample'][key] for key in
                                     ('handlerMs', 'twoRafMs', 'clickPhaseMs',
                                      'firstRafCallbackLagMs', 'secondRafCallbackLagMs')},
                     'performanceMarkToConsoleTimeStampMs': {
                         key: (stamps[key]['ts'] - marks[key]['ts']) / 1000 for key in marks},
                     'sharedEnvironmentCpuCounterDeltas': deltas,
                     'windows': windows})
    groups = {}
    for key in sorted({r['sample'].rsplit('.', 2)[0] for r in rows}):
        selected = [r for r in rows if r['sample'].startswith(key + '.')]
        groups[key] = {'samples': len(selected),
                       'pageMedian': {metric: statistics.median(r['pageMetrics'][metric] for r in selected)
                                      for metric in selected[0]['pageMetrics']},
                       'firstToSecondRafMedian': {
                           metric: statistics.median(r['windows']['firstToSecondRaf'][metric]
                                                      for r in selected)
                           for metric in ('traceWallMs', 'rendererMainThreadCpuMs',
                                          'wallMinusThreadCpuMs')}}
    return {'interpretation': {
        'clocks': 'Trace ts is monotonic wall microseconds; tts is cumulative CPU microseconds of the same CrRendererMain thread. Differences use matching PerformanceMark events; console TimeStamp windows are retained separately.',
        'limits': 'Marks and tracing perturb execution. CPU clock excludes idle, blocking and time not scheduled; it does not identify which occurred. Normal frame waiting is also included. No cause is assigned to historical untraced samples.',
        'intervals': 'X intervals are clipped and unioned within each category; categories overlap and must not be added. Missing RunTask/scheduler/OS-switch records mean uncovered timeline time is not proof of idle.',
        'cgroup': 'Shared environment counter deltas span input preparation/dispatch and callback collection, not exactly marker windows; they are not per-browser CPU attribution.',
        'performancePass': False}, 'groups': groups,
        'largestCallbackLag': sorted(rows, key=lambda r: r['pageMetrics']['secondRafCallbackLagMs'], reverse=True)[:4],
        'allSharedThrottleDeltasZero': all(r['sharedEnvironmentCpuCounterDeltas']['nr_throttled'] == 0
                                         and r['sharedEnvironmentCpuCounterDeltas']['throttled_usec'] == 0
                                         for r in rows), 'samples': rows}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('folder', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = analyse(args.folder)
    output = args.output or args.folder.parent / 'trace-analysis.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    csv_path = output.with_suffix('.csv')
    with csv_path.open('w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['sample', 'handlerMs', 'twoRafMs', 'secondRafCallbackLagMs',
                         'firstToSecondWallMs', 'firstToSecondMainCpuMs', 'wallMinusMainCpuMs'])
        for row in result['samples']:
            window = row['windows']['firstToSecondRaf']
            writer.writerow([row['sample'], *[row['pageMetrics'][k] for k in
                             ('handlerMs', 'twoRafMs', 'secondRafCallbackLagMs')],
                             *[window[k] for k in ('traceWallMs', 'rendererMainThreadCpuMs',
                                                   'wallMinusThreadCpuMs')]])
    print(json.dumps({'samples': len(result['samples']), 'groups': result['groups'],
                      'allSharedThrottleDeltasZero': result['allSharedThrottleDeltasZero']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
