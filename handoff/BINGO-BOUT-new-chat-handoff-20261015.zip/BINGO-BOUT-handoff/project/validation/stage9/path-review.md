# Causal review of the five focused selector cases

This is a read-only source review. No browser or benchmark was run for this
review, and no production file was edited. The sources checked were
`index.before.html` SHA-256
`e872443dc9764f3b9647f4797d1411ca98f865b9c2f69c6e694529e2685cd3a9` and
`index.html` SHA-256
`fea09e995bfc1036515b92771925bd7968f3c453425ea5517b7a5b480293be64`.

The four legacy cases execute unchanged code and do not read the DP receiver,
value tables, or ready/fallback status during their timed selections. The full
case reaches the refactored solver with two legal actions. This rules out a
direct solver-work explanation for the four legacy increases, but does not
prove their observed wall-clock differences are zero or establish a VM cause.

## Fixture and exact paths

The case list is `validation/stage6/selector_control.py:12`. Its implementation
reuses `validation/stage6/selector_performance.py`, which extends
`validation/stage3/frame_performance.py`. The latter installs the benchmark
inside each normally loaded HTML realm and keeps automatic self-tests enabled.
It constructs board-only equilibrium tables, prepares a real Worker/DP for each
first player, and subsequently sets the engine to ready or fallback per case.
Configure calls `this.dp.analyze(decision)` even for legacy/fallback cases. This
analysis is outside the timed selector loop. A fallback case has
`cpuWholeDp = null`, while the fixture still retains its prepared `this.dp`.

Every case uses HARD settings, fixed public marks/layouts, and one fixed random
value for every RNG call: 0.3 for the legacy cases and 0.8 for full. The timed
calls omit the optional `rolls` object, so both mix and sample/choice input are
obtained through the fixture's replacement `Math.random`. Marks and layouts are
created during configure, then retained through warmup and all timed batches.
BREAK availability is precomputed outside the loop. Both cooldowns are zero,
both remembered cells are 0, both streaks are 2, and result-history update
functions are never called between selections.

| Focused case | Fixture decision and target | Timed branch | Probe cell |
| --- | --- | --- | --- |
| P1 late BLOCK hard-legacy | t=14; masks 508/502; P1 closed [0,1] | HARD mix 0.3 < 0.7; legacy BLOCK | 0 |
| P1 late BLOCK hard-full | t=14; masks 508/502; P1 closed [0,1] | HARD mix 0.8; ready full-game BLOCK | 0 |
| P2 middle BREAK hard-fallback-legacy-roll | t=8; masks 3/24; P2 closed [0,1,2,5,6,7,8] | HARD mix 0.3 < 0.7; legacy BREAK | 5 |
| P2 middle BLOCK hard-legacy | t=9; masks 3/24; P1 closed [2,3,4,5,6,7,8] | HARD mix 0.3 < 0.7; legacy BLOCK | 2 |
| P2 one-closed BLOCK hard-fallback-legacy-roll | t=17; masks 510/509; P1 closed [0] | HARD mix 0.3 < 0.7; legacy BLOCK | 0 |

The last case is a legal board-selector contract but a terminal full-game state;
it does not model an actual interaction after the match has ended. The source
and stage6 recorded probes agree on all entries above. Per legacy call the
counter delta is `{whole:0, fallback:0, hardLegacy:1, hardFull:0}`. Per full call
it is `{whole:1, fallback:0, hardLegacy:0, hardFull:1}`. The `fallback` counter is
the MASTER fallback counter; it is correctly zero in HARD fallback cases.

## Legacy hot functions, allocations, and state

BLOCK executes:

```
selectCpuBlockCell(marks, layout)
  getCpuDifficultyId()                    // HARD; scans marks to first closed
  selectCpuEquilibriumCell('block', undefined)
    selectHardMixedCell('block', undefined)
      takeCpuEqMixRoll(undefined)           // Math.random() = 0.3
      selectHardLegacyCell('block')         // builds opens; early return skips status
        selectCpuLegacyCell('block', opens)
          cpuSelectSmartCell(state.p1Marks, state.p1NumberLayout)
            prepareCpuBlockCandidates(available)
              getCpuBlockCandidatePool(..., Math.random(), settings)
            getCpuSelectionWeights(marks, layout, settings)
              getCellWeights(marks, layout)
            chooseCpuCandidate(candidates, weights, settings)
              getCpuChoicePool(..., Math.random())
              weightedRandomChoice(...)
      hardLegacyDecisions++
```

There are four RNG calls per legacy BLOCK: mix, remembered-block pool bias,
top-pool bias, weighted choice. `selectHardLegacyCell` builds `opens`, although
the BLOCK branch then builds a second `available` array and ignores `opens`.
The original `numberLayout` argument is passed into `selectCpuBlockCell`, but
HARD selection reads the layout from state. The mark argument is used for the
initial closed-cell guard. Pool functions receive remembered cell/streak and
the fixed bias roll, but cooldown=0 short-circuits before any remembered-cell
filter or streak-dependent chance. `prepareCpuBlockCandidates` checks cooldown
again and performs no state write. The only per-call state mutation is the
lexical `hardLegacyDecisions` counter increment.

BREAK executes the same HARD dispatch before entering:

```
selectHardLegacyCell('break')              // builds opens from state.p2Marks
  selectCpuLegacyCell('break', opens)
    prepareCpuBreakCandidates(opens, state.p2Marks, state.p2NumberLayout)
      getCellWeights(marks, layout)        // calculated even at cooldown=0
      getCpuBreakCandidatePool(..., Math.random(), settings, rawWeights)
    getCpuSelectionWeights(marks, layout, settings)
      getCellWeights(marks, layout)        // calculated a second time
    chooseCpuCandidate(...) -> getCpuChoicePool -> weightedRandomChoice
hardLegacyDecisions++
```

`selectCpuBreakCell` ignores its precomputed `available` argument on this HARD
branch and recomputes opens. RNG count is again four: mix, retry, top pool,
weighted choice. The retry chance function is not reached at cooldown=0.
`prepareCpuBreakCandidates` checks cooldown but does not write it. Marks,
layouts, remembered cells, streaks, and `selectedBreakCell` remain unchanged.

`getCellWeights` always creates a 9-entry weight array, obtains a scored-cell
Set, calculates the current score through another Set, and creates eight
`line.filter` arrays. For each closed cell it slices the marks and calculates a
trial score; scoring creates another completed-line array, scored-cell Set, and
spread array. HARD then maps the raw weights through power 1.85. All of these
operations are shared unchanged by both sources.

For n closed cells, a source-level count for one `getCellWeights` execution is
12+3n ordinary array-producing operations and n+2 `new Set` operations. This
counts arrays returned by filter/map/slice/spread, including empty arrays. It
does not count callback closures, iterator objects, internal backing stores, or
VM escape elimination, and is not a measurement of physical heap allocations.

| Legacy case | Weight passes | Other array-producing operations | Total source-level arrays / Sets per call |
| --- | --- | --- | --- |
| P1 late BLOCK, n=2 | 1 | HARD opens, smart available, candidate slice, HARD weight map, choice-pool slice | 23 / 4 |
| P2 middle BREAK, n=7 | 2 | HARD opens, candidate slice, HARD weight map, ranked slice, final top slice | 71 / 18 |
| P2 middle BLOCK, n=7 | 1 | HARD opens, smart available, candidate slice, HARD weight map, ranked slice, final top slice | 39 / 9 |
| P2 one-closed BLOCK, n=1 | 1 | HARD opens, smart available, candidate slice, HARD weight map, choice-pool slice | 20 / 3 |

With <=2 candidates, choice-pool returns a slice immediately. With 7 candidates,
0.3 is below HARD's top-pool chance 0.48: it ranks a copied array by weights and
keeps `max(2, ceil(7*0.42)) = 3` candidates in another slice. Those are actual
branch differences between these fixture cases, not between original/current.

Relevant shared globals are `state`, `CONFIG` (9 cells, eight winning lines),
`CPU_DIFFICULTY.hard`, `CPU_HARD_LEGACY_RATE`, `Math`/`Math.random`, and the
`hardLegacyDecisions` binding. The HARD early mix return does not access
`cpuWholeStatus`, `cpuWholeDp`, `cpuEqBundle`, turns taken, or first player.
The latter fixture fields affect reachability/probing outside the timer only.

## Full-game case

The P1 late full case has two RNG calls, mix and equilibrium sampling. It runs
the same BLOCK guard and HARD dispatch, then reads ready status and calls
`selectWholeGameCpuCell('block', undefined)`. This creates `{maskP1,maskP2,t}`
from state marks and turns; `analyze` reads score/max/turn/attacker tables,
checks terminal state, and calls `solveState(1,508,502,layers[15],true)`.

There are two closed actions. `solveState` fills the shared pay workspace from
the child value table, changes sign for attacker 1, and calls `equilibrium`.
Current code inherits this from `CpuEquilibriumSolver`; original had it directly
on `WholeGameDP`. Refactored `solveState` removes the unused `maxPay` work.
The shared solver changes scratch-array ownership/initialization and method
lookup shape, and `strategyGap` has a changed loop organization. These methods
are reached here, unlike the four legacy cases. Shared pay/probP/probQ/order
arrays are mutated but not allocated afresh per call.

`packStrategy` creates legalActions and two length-2 typed-array strategy slices.
`analyze` creates policy and terminal objects. `wholeGameCpuSelectionWeights`
creates a length-9 Float64Array and a length-2 loss-marker array. Its result
filter checks opened results against score/max/turn tables through
`cpuLossIndexesToDrop` and `cpuOpenedBreakerResult`, whose bodies are unchanged.
Loss-index arrays are allocated even when none are dropped. BLOCK copies the
remaining `blockStrategy` entries and normalizes; it does not run the BREAK
gain-class mixing code. Sampling validates the nine probabilities and allocates
a positive-cell array. The role cooldown check finds zero and performs no
write. Successful selection increments `cpuWholeDecisions` and
`hardDpDecisions`. No exception/fallback/release path should run; stage6 probes
verify that none did.

The stage7 same-receiver six-method swap is already a direct diagnostic for this
solver-method difference. Its scope and results should be retained; its output
does not establish cold-call or trusted-click latency.

## What is byte-identical, and what could still change runtime

Stage6 source integrity records all ten dispatch/legacy functions as identical.
This review additionally compared the complete source spans for the following
24 helpers and found all identical: weightedRandomChoice, getCpuDifficultyId,
getCpuDifficultySettings, getCpuChoicePool, getCpuRetryChance,
getCpuBreakCandidatePool, getCpuBlockBiasChance, getCpuBlockCandidatePool,
prepareCpuBlockCandidates, takeCpuEqMixRoll, takeCpuEqSampleRoll,
consumeCpuEqCooldown, selectCpuEquilibriumCell, getCompletedLines,
getScoredCellIndices, calculateScore, selectWholeGameCpuCell,
wholeGameCpuSelectionWeights, cpuOpenedBreakerResult,
cpuCanClassifyOpenedResults, cpuLossIndexesToDrop, assertCpuEqDistribution,
drawCpuEqDistribution, and sampleCpuEqDistribution.

Unchanged source does not imply identical machine-code or allocation schedules.
The HTML has a changed script size and declaration order, a different solver
class/prototype chain, different automatic-test execution, and different table
construction histories before measurements. Separate realms have separate
function objects, intrinsic objects, lexical contexts, type feedback, and code
compilation histories. Different call history can affect inlining/tiering;
different allocation history can put GC within a batch; code and heap placement
can affect caches. Some changes may affect the actual production runtime as
well as the benchmark context. None of those mechanisms has been identified as
the cause by this source review. A/A realm controls measure context sensitivity
without authorizing subtraction of their deltas from an A/B result.

The many source-level allocations make GC placement a concrete candidate for
investigation in the legacy cases. They are pre-existing allocations, not new
refactor allocations. The source provides no basis for editing those hot paths
to fix these five observed increases: doing so would introduce another change
before the cause is isolated.

## Concrete same-realm experiment

1. Load one normally initialized current production page, prepare one real DP
   per required first player, and retain the same `state`, mark/layout arrays,
   DP receiver, child value tables, scratch arrays, and RNG function across all
   variants. Keep installation, resets, and assertions outside timed regions.
2. Extract original/current legacy dispatch plus complete helper dependency
   closures into the same JavaScript realm with an identical factory signature.
   Assert their full source identity first. Give both closures the same state,
   CONFIG/settings objects, fixed RNG, and counter-holder shape. Construct two
   independent current-source closures as an A/A companion. These are controls
   for code-instance/context effects because the legacy source has no A/B
   implementation difference. They do not reproduce the original HTML's full
   top-level lexical environment.
3. Measure the unchanged real production legacy selector in that same realm
   under two labels with matched state. Its identical implementation and
   inputs are the strongest label/order control. Compare it with the extracted
   closures to detect extraction/call-boundary cost; do not pool those
   different call shapes into one implementation estimate.
4. For full DP, retain the single real production selector and swap the six
   original/current methods on the same DP receiver outside the timer, as
   stage7 does. Hold `monotone=false`, value-table bytes, scratch references and
   contents, marks, layouts, turns, and RNG sequence equal. Include current to
   current and duplicate-current-function controls, since replacing a method
   can itself invalidate inline-cache assumptions.
5. Balance A/B order, reverse code-instance construction order in independent
   browser runs, use fixed warmup/batch counts chosen before observations, and
   run sequentially. Record exact choices/checksum, RNG count/order, dispatch
   counter deltas, all memory fields, ready status, and Object.is-compatible
   solver/policy values. Assert stable object references and value-table bytes.
   Report individual-run distributions and paired deltas in microseconds;
   assess independent browser runs separately from correlated within-run
   batches. Do not use an A/A delta as a regression allowance or correction.

This separates changed full-solver methods from unchanged data/dispatch under
one runtime context. A remaining separate-realm legacy difference can still be
real in that context, but cannot be assigned to solver arithmetic by this test.
The extraction is a mechanism diagnostic and cannot replace the normally
loaded-page or trusted-click comparisons.

## Meaningful first-call latency follow-up

A useful follow-up is the first actual selector decision after a fresh page
load and real Worker readiness, repeated across fresh browser processes with
balanced original/current order. Perform no selector probe, target warmup, or
`dp.analyze` fixture probe before that observation. Keep ordinary page load and
automatic self-tests intact; label it **first decision after READY**, because
automatic self-tests already execute these functions and it is not a VM-cold
function measurement. Test the real P1 late nonterminal BLOCK decision only
after a legitimate state transition or clearly label a fixed-state fixture.
Do not call the one-closed terminal fixture a cold user interaction.

Record a trusted click and the selector boundary independently from
event-to-paint/task timing. A browser trace around the synchronous selector can
provide finer timestamps than ordinary-HTTP `performance.now`; instrumentation
overhead and an empty-boundary companion must be exposed rather than silently
subtracted. Keep trace/instrumented and uninstrumented results separate, and
verify selector state/counters after timing. Report timer precision and raw
single-call values: ordinary-HTTP timer quantization can exceed these tiny
selector differences. Aggregating many calls improves timer resolution but
turns this into another warm-throughput measurement.

If measuring a genuinely unexecuted function's first call is necessary, an
extracted fresh closure can be timed once per fresh code instance/realm. That
answers a compiler cold-function question, not production first-click latency.
Neither first-decision evidence nor the warm same-realm experiment alone proves
strict zero increase for every production interaction.

## Review of the local raw-weight reuse candidate

The subsequent candidate at `stages/index.stage9.candidate.html` has a narrower
purpose than changing the unchanged legacy code to account for historical noise:
it removes the identified duplicate weight calculation within one BREAK decision.
The parent task retains the candidate as a separate snapshot for validation.
The intended four changes are an optional fourth raw-weight argument to
`getCpuSelectionWeights` and `prepareCpuBreakCandidates`, one local raw-weight
calculation in legacy BREAK passed to both helpers, and NORMAL BREAK delegating
to that common legacy helper. No cache persists across decisions. BLOCK and the
full solver remain outside this change.

For the normal product contract, this preserves numeric results. `getCellWeights`
reads Boolean mark arrays, numeric permutation layouts and the static board
configuration, creates its own score/weight/trial objects, and writes only its
own arrays. It consumes no RNG, reads no CPU history, and performs no DOM or
other external operation. The only history write between the old two calls is
the cooldown decrement, which is not an input to the weight calculation. The
selection helper maps HARD/MASTER weights into another array; NORMAL uses the
raw array without mutating it. Candidate pools use raw weights for relative
retry chance without mutating them. Therefore one locally reused raw array
supplies the same values as both old calculations.

The order does change: the original evaluates the retry `Math.random()` before
the first `getCellWeights` call, while the candidate calculates raw weights
before entering candidate preparation and its retry RNG. Mark/layout getters,
Proxies, or an injected RNG that mutates marks or global configuration can make
that order observable. Those are outside the ordinary array/native RNG product
contract; the candidate should not be described as equivalent for arbitrary
JavaScript objects or mutation hooks. There is no such hook in the reviewed
production code or the fixed-stream selector benchmark. The count/order of RNG
calls relative to each other remains unchanged. With no candidates, weighted
choice returns before drawing its sample; equivalence checks must compare the
actual consumed stream instead of assuming three/four draws in every case.

The prepared `validation/stage9/legacy_equivalence.cjs` harness extracts the real
source dependency group, checks that only the four authorized functions differ,
and compiles two independent state closures in one VM realm. It generates all
512 masks with 16 permutation layouts and three legacy difficulty settings, then
adds an explicit history/pool/threshold matrix, public NORMAL/HARD-fallback
entry checks, BLOCK controls, and supplied-raw helper checks. Frozen ordinary
inputs and raw arrays expose unintended mutation. It compares Object.is values,
actual RNG traces, Math call counts, selection, counters, input references and
all memory fields, and verifies the BREAK raw-weight count changes from two to
one. Empty pools and both HARD fallback mix branches are included. MASTER is
tested through the direct legacy helper with MASTER settings, without entering
its board-equilibrium dispatch.

Only `node --check validation/stage9/legacy_equivalence.cjs` was run by the
reviewer. The harness was deliberately left unexecuted so the parent can run CPU
validation jobs sequentially. Its intended 36,672 source-pair comparisons are
semantic checks, not timing evidence, and do not replace the existing Chromium
capture/self-tests or full-game solver comparisons.
