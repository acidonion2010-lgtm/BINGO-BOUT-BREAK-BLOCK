# Stage16 実行前の静的レビュー

2026-10-15 JST。PLANとcollectorを読み、構文、元HTML・凍結helper・公式toolの保存hashを確認した。ブラウザー・Worker・性能ジョブは実行していない。**最終版に致命的な静的blockerはない。固定予算のpreflightを実行し、その明示gateが成功した場合だけformalへ進む設計として整合している。**

レビュー対象のSHA-256:

| ファイル | SHA-256 |
|---|---|
| PLAN.md | `532d60296329a05ad4d2d3d5d3d1b774fe6e5a0e4dfb8d7ee30bac9e686ba487` |
| capture_proto.py | `b071059ac8d1f93a417f294cc143590ae2101bee8da4f6549f05d28774e3b6df` |
| 凍結stage14 capture_clicks.py | `df0c5fa77905d13ce492882e14338a5684e6670e1c5f0694f44b20d696092c77` |
| trace_processor_shell（14,897,560 bytes） | `58042408e6cc861fb1a731c26bb082dc222285561eaa4e12a48a8b2b90dca7b9` |

## 予算・停止・機能

loopはrun0のpreflightとrun1〜4のfresh formal browserだけ。preflightは通常原本読込と322自己テスト後、Workerを準備せず、2markを置く8msの単一busy loopでprotocol/clock capabilityを調べる。formalは各browserで実Workerを1回準備し、2分岐×(warmup1＋正式3)で8click。総24正式・8warmup、8回の計時外selector監査、5trace、mark/stampの対応名はpreflight2＋click128＝130を予定する。

run1/3はDP→legacy、run2/4は逆。再試行・代替sample・符号に応じる追加loopはない。preflightのdecode/identity/metric/page-error gateの失敗はtop-levelへ伝わり、formalへ進まない。formal失敗も停止し、reportとtrace/変換partialを保持する。

原本HTML、stage14 collector、stage3/5/6/7 helper4ファイル、公式toolは実行時に期待hashへ照合する。元HTMLの既知SHAとhelper4個の実ファイルも今回再検証した。stage14のfixtureとtrusted locator入力、native参照検査、DP/legacy別counter、REVEAL/可視性/audio/BGMなどの機能assertを再利用する。新wrapperでゲームselectorを交換していない。監査のRNG列と全体辞書は前runへ照合するが、これは正式click内部のlocal CPU BLOCK値を直接保存した証拠ではない。

## Protoと同一入力の変換

CDPはReturnAsStream/proto/noneを明示し、categoryは列挙結果にフィルターせず凍結リストを要求する。Tracing.end、完了通知、IO.readのEOFまで、有限read上限、stream close、byte数/SHAを保持し、dataLossOccurred=falseとbuffer未充満を要求する。既存traceファイルはexclusive createで上書きしない。

変換は保存したその`.pftrace`を公式toolへ渡し、新規JSONを出す。バイナリは正式名`trace_processor_shell`で使用する最終版であり、旧basename `traceconv-bin`に依存したmulti-call CLIの挙動を避けている。toolのSHAは保存manifestに対応する公式releaseと一致するが、Chromium内蔵exporterと完全同一buildとは主張しない。

変換成功/失敗/timeoutのstdout・stderr・returncodeまたはexception、partial JSONのbyte数/hashをfinallyで保存する。すべての予定markとconsole TimeStampを一意名で照合し、共通PID/TIDを導く。raw decoderのincremental state、counter UUID、clock domain等の完全性は別の事後解析で検証し、unsupported stateを0に置き換えないというPLANを維持する。

## 外側CPU対照・identity

Performance(threadTicks)は同一page/sessionで一度enableし、snapshot間でresetしない。ThreadTime/Timestampの有限数値、ThreadTimeの前後単調性、preflightの増加をgateにする。page errorは全visit完了前にも明示検査する。

SystemInfoにある全rendererを収集してから、trace markerで得た実PID/TIDへ対応させる。mainのPID=TID、同一proc comm/stat field22 starttime、全snapshotでの読取り成功とidentity継続、trace metadataのCrRendererMain名を確認する。事前に「最初のrendererが対象」と仮定していない。

各snapshotはhost MONOTONICのmetric send/return時刻とproc IO bracket、元metric応答とproc文字列を保持する。対応marker/stampがbefore metric-send〜after metric-returnのhost外包に入ることも検査する。この外側envelopeとThreadTimeの差は、command/周辺処理を含む広い対照である。marker内部へ費用を配賦しない。

ThreadTimeはtrace exportと別のserialization経路だが、同じOS ThreadTicks/CPU会計基盤を共有する。schedstatはsum_exec_runtimeのreadで、ns表記でもendpoint鮮度を保証しない。proc差を厳密CPU上限と解釈しないというPLANの制約は妥当である。clock domain/namespaceの対応を事後にも保存値から照合する必要は残る。

## 結論の範囲

今回のpreflightは利用可否の検査であり、CPU>wallという符号が出たことをsampleの除外条件にしない。formalの全符号と大きさを保持し、1ms binは説明用に限定する。新しいtraceが正常に見えても、旧169件・旧HARD差・過去62条件の原因解消や全経路性能PASSにしない。

静的指摘だったpreflight page-error gate、metric数値/増加、host marker外包、helper SHA pin、変換timeoutログ、renderer identity/metadataは最終版で対応済み。レビュー文書だけを追加し、collector/PLAN/元成果物へ編集していない。
