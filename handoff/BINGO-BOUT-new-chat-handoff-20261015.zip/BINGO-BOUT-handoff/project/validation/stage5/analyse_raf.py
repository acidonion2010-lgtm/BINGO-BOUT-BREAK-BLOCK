#!/usr/bin/env python3
"""Describe RAF timestamps without correcting latency or assigning a speed PASS."""
import argparse
import collections
import json
import math
from pathlib import Path
import statistics


def analyse(data):
    output = {
        'measurementChecksPassed': data['behaviorChecksPassed'],
        'scope': 'Descriptive additive timestamp decomposition; not a corrected latency PASS',
        'comparisons': [],
    }
    for kind in ('aa', 'ab'):
        arms = {}
        for version in ('before', 'after'):
            samples = [sample for row in data['rows']
                       if row['kind'] == kind and row['version'] == version
                       for sample in row['samples']]
            components = [{
                'twoRafMs': sample['twoRafMs'],
                'frameSpanMs': sample['secondRafTimestampMs'] - sample['previousRafTimestampMs'],
                'negativeClickPhaseMs': -sample['clickPhaseMs'],
                'secondCallbackLagMs': sample['secondRafCallbackLagMs'],
            } for sample in samples]
            arms[version] = {
                'sampleCount': len(samples),
                'meansMs': {key: statistics.mean(c[key] for c in components)
                            for key in components[0]},
                'frameSpanHistogramMs': dict(collections.Counter(
                    round(c['frameSpanMs'], 1) for c in components)),
                'maxIdentityResidualMs': max(abs(c['twoRafMs'] - (
                    c['frameSpanMs'] + c['negativeClickPhaseMs'] + c['secondCallbackLagMs']))
                    for c in components),
            }
            pairs = [(s['clickPhaseMs'], s['twoRafMs']) for s in samples]
            mean_x = statistics.mean(x for x, _ in pairs)
            mean_y = statistics.mean(y for _, y in pairs)
            denominator = math.sqrt(sum((x - mean_x) ** 2 for x, _ in pairs)
                                    * sum((y - mean_y) ** 2 for _, y in pairs))
            arms[version]['pearsonPhaseVsTwoRaf'] = (
                sum((x - mean_x) * (y - mean_y) for x, y in pairs) / denominator
                if denominator else None)
        delta = {key: arms['after']['meansMs'][key] - arms['before']['meansMs'][key]
                 for key in arms['before']['meansMs']}
        output['comparisons'].append({
            'kind': kind, 'arms': arms, 'meanDifferencesMs': delta,
        })
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    data = json.loads(args.input.read_text())
    if not data['behaviorChecksPassed'] or data['pageErrors']:
        raise ValueError('Only completed measurements without browser errors can be analysed')
    result = {'source': args.input.name, **analyse(data)}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({c['kind']: c['meanDifferencesMs'] for c in result['comparisons']}))


if __name__ == '__main__':
    main()
