# 段階8: Linux scheduler観測能力

取得日時: 2026-10-14 19:14–19:24 UTC。受領済み `index.html` と既存検証コードは変更していない。ブラウザー、ベンチマーク、システム設定変更、sudo、権限昇格は実施していない。今回の環境で新たに読み取った値のみを使う。

## 確認できること

`/proc/<pid>/task/<tid>/schedstat` と `status` は同UIDの既存プロセスで読める。`schedstat` の3値は、累積CPU実行時間(ns)、累積runqueue待ち時間(ns)、CPU上で走った回数(pcount)。`/proc/config.gz` は `CONFIG_SCHED_INFO=y`、`CONFIG_SCHEDSTATS=n` と報告している。詳細schedstatsが無くても、SCHED_INFOの基本run_delay/pcountは取得できる。

短時間しか動いていない自分のPythonは `24772405 0 1` だったが、これだけでrunqueue待ちが未サポートとは判断できない。既存PID738の自然な進行を2回読むと、runqueue値が `507216345` → `507222084` ns、CPU実行時間が+7,733,410 ns、pcountが+116だった。runqueueカウンタが実際に更新されることを確認した。これはブラウザーの遅延の測定ではなく、観測方法の能力確認である。

入力前とコールバック観測後に、**同じrenderer main thread** のスナップショットを取り、差分からCPU時間とrunqueue待ちの累積増分を分けられる。`SystemInfo.getProcessInfo` のrenderer候補から、完成したtraceのcapture markerのpid/tidと照合する。`Pid/Tgid/NSpid/NStgid` と `/proc/.../stat` のstarttimeも保存し、PID namespaceの違いやPID再利用を誤照合しない。thread idが対応しなければ、その測定の補助値は欠測にする。

読み取り例:

```python
from pathlib import Path
from time import monotonic_ns

def snapshot_thread(pid, tid):
    base = Path(f"/proc/{int(pid)}/task/{int(tid)}")
    started = monotonic_ns()
    runtime_ns, runqueue_ns, pcount = map(int, (base / "schedstat").read_text().split())
    schedstat_finished = monotonic_ns()
    status = dict(line.split(":", 1) for line in (base / "status").read_text().splitlines() if ":" in line)
    return {
        "pid": int(pid), "tid": int(tid),
        "schedstatReadStartHostMonotonicNs": started,
        "schedstatReadEndHostMonotonicNs": schedstat_finished,
        "runtimeNs": runtime_ns, "runqueueNs": runqueue_ns, "pcount": pcount,
        "state": status.get("State", "").strip(),
        "nspid": status.get("NSpid", "").strip(),
        "nstgid": status.get("NStgid", "").strip(),
        "voluntarySwitches": status.get("voluntary_ctxt_switches", "").strip(),
        "involuntarySwitches": status.get("nonvoluntary_ctxt_switches", "").strip(),
        "snapshotEndHostMonotonicNs": monotonic_ns(),
    }
```

実運用ではread errorを記録し、starttimeとstatus読み取りの別時刻も保存する。host monotonic時刻をpage `performance.now()`やtraceの時刻から直接引かない。全renderer候補を読み、trace解析後に正しいthreadだけを選ぶ場合も、候補ごとの読み取り時刻を残す。

## 取得できない明細と注意点

前後差分の区間はcapture→secondRAFと完全一致しない。入力前の読み取り完了から実入力まで、secondRAFから読み取りまでの追加時間を含む。aggregate値にはその追加区間の仕事も含まれる。進行中の待ちやCPU会計が区間末の時点でまだ反映されていない可能性もある。`Δrunqueue=0`だけを根拠に、厳密なmarker区間全体の待ちを完全に否定しない。

`wall - CPU - runqueue`を正確な睡眠時間や特定の待ち原因と呼ばない。frame/vsync待ち、イベント待ち、timer、futex、I/O、別プロセスの仕事などの区別には個別wakeup/switchまたは待ちAPIの証拠が必要。`State`は読み取り時点の状態、voluntary/nonvoluntary context switch値は累積回数であり、待ちの原因や長さそのものではない。

20既存PIDの`wchan`は全て0だった。`kptr_restrict=0`でも、この観測では待ち関数名は得られない。`/proc/sys/kernel/yama/ptrace_scope`は存在しないが、これだけでptraceが利用可とは判断しない。

## 非特権scheduler eventの利用可否

- `perf`、`trace-cmd`、`bpftrace`、`bpftool`、`pidstat`は見つからない。`strace`は6.13。`taskset`と`chrt`は存在するが設定変更には使っていない。
- `CONFIG_FTRACE=n`。`/sys/kernel/tracing`、`/sys/kernel/debug/tracing`、sched tracepoint enable/format、tracepoint event sourceは存在しない。現在のアクセスからftraceでsched_switch/sched_wakeupを記録する経路はない。
- `CONFIG_PERF_EVENTS=y`、software event source type=1、`perf_event_paranoid=2`。自分のthreadだけを対象にkernel/hypervisorを除外するsoftware eventは候補だが、`perf_event_open`の実利用は未確認。rootが許可した可逆的な自己thread診断でDUMMY/CPU_CLOCK ×context_switch false/trueの4通りをdisabled open→closeし、全て成功した。続けてDUMMYの時刻付きcontext switch collectorを実装し、自己threadで3×3msの通常sleepを観測する軽いsmokeで6件のout/in recordを取得した。sampling、CPU-wide attach、システム設定変更は無い。CLOCK_MONOTONICのuse_clockidとsample_id_allを指定し、全レコードのTID、時計範囲、順序、方向、サイズを検査した。lost/throttle/overflow/truncationは0で、map/FDをcloseしFD数も復元した。renderer targetのattachとChromium traceとの時計対応はrootの別pilotで確認する。perfツール無しでもsyscall経路は利用できた。
- `CONFIG_BPF=y`、`CONFIG_BPF_SYSCALL=y`、`unprivileged_bpf_disabled=0`と報告されるが、scheduler tracepointやBPFツールは無い。これだけでeBPF scheduler tracingができるとは判断できない。
- effective/permitted/bounding capabilityは全て0、NoNewPrivs=1、Seccomp=2。proc/cgroup2はread-only mount。設定を緩和したり追加権限を取得したりしていない。
- `strace`でepoll/poll/futex等を追う方法は考えられるが、attach許可とChromiumへの影響は未確認。syscall停止を挟むため通常クリックの性能比較には使えない。仮に使うなら別の診断条件として扱う。

## cgroupとCPU圧力

今回読んだ `cpu.max` は `400000 100000` (4CPU分/100ms)、affinityは0–4。`cpu.stat` は取得できるので同一試行前後の `nr_throttled/throttled_usec` 差分を補助として保存できる。ただし共有cgroup全体の値であり、rendererや当該クリックへの直接帰属ではない。

今回の初回値は `nr_periods=47480`、`nr_throttled=27`、`throttled_usec=647801`。過去の段階7の数値との差分は性能結論に使わない。`cpu.pressure`と`/proc/pressure/cpu`は存在せず、kernel configは `CONFIG_PSI=y, CONFIG_PSI_DEFAULT_DISABLED=y` だった。CPU圧力の時系列は今回のreadonly経路では取得できていない。

根拠の詳細と読み取りエラーは `scheduler-capabilities.json` に保存した。perf open結果は `perf-open-capability.json`、時刻付きrecordとclosure smokeは `perf-switch-smoke.json` / `perf-switch-smoke-closure.json`。collectorは `perf_switch.py` の `PerfSwitchCollector(tid).start()` と `finish()`。finishはdisable→ring読取→map/FDcloseで、失敗時もerror/errnoを保存する。`integrityChecksPassed`だけで0 recordを収録成功とせず、`switchRecordCount>0`も必要。
