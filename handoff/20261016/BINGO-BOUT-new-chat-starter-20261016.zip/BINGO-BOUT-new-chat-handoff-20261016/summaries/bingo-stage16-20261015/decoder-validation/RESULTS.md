# Independent synthetic CPU-counter decoder validation

**Passed:** the final raw checker (`91762a94d1e1e05305c2a11fbb237dd4b42bffd3ebb5162f48c4cec42b038c23`) matches independently stated arithmetic expectations and official Perfetto SQL/JSON for eight marker endpoints, eleven events and all eleven thread-time counter values. The verification has 48 passing checks; raw diagnostics are empty.

The final fixture is `counter_fixture_clock_mapped.pftrace` (1,264 bytes, 21 packets). It uses two interleaved sequences, interned event names/categories, default thread/counter UUIDs, incremental thread-time counters with unit multiplier 1,000, BEGIN/END/INSTANT events, intervening non-marker increments, and a sequence-1 clear/re-emission. It imports with zero nonzero error/data_loss stats.

| Endpoint | Expected = official = raw CPU ns |
|---|---:|
| seq1 start | 1,000,000 |
| seq2 start | 5,000,000 |
| seq1 span BEGIN | 1,007,000 |
| seq1 span END | 1,031,000 |
| seq2 end | 5,020,000 |
| seq1 after | 1,036,000 |
| seq1 after reset start | 50,000,000 |
| seq1 after reset end | 50,021,000 |

The official merged span has thread duration 24,000 ns. Non-marker CPU increments of 13/17/19 microseconds are retained in the accumulation. After the clear, the first 50,000 microseconds is an absolute value relative to zero; it does not add the old 1,036 microseconds. Separate sequences do not mix accumulators.

`make_fixture.py` generates the initial independently encoded wire fixture. Its official CPU numbers also match, but the loader reports one unrelated missing BOOTTIME↔MONOTONIC relationship. That original fixture and all outputs are preserved. `make_clock_mapped_fixture.py` adds one explicit **synthetic** builtin-clock snapshot to form the final fixture; equal builtin values are constructed test data, not an assertion about a real system. No runtime measurement is involved.

Evidence: `expected_clock_mapped.json`, `verification_final.json`, `raw_ledger_final.json` (identical preserved copy at requested `raw_ledger_clock_mapped_final.json`), `mapped_slice_query.stdout.txt`, `mapped_counter_query.stdout.txt`, `mapped_health_query.stdout.txt`, and `official_clock_mapped.json`. Official commands/stdout/stderr are preserved. `raw_counter_check_executed.py` freezes the exact tested checker. SOURCE_MANIFEST.json preserves official schema URLs/hashes/licenses; MANIFEST.json lists output hashes and the exact tool hash.

The official binary is the downloaded Perfetto v58.2 release (`add693d8b338ba9599dbcbc3e300b1ab8c000897`), **not** a build of Chromium's pinned Perfetto source commit. Invocation sets argv[0] to `trace_processor_shell` while executing the same `traceconv-bin` bytes, avoiding basename-selected convert behavior; this is recorded in the command JSON. The fixture's schema is sourced from pinned `5dbeaad4ceb91470a835426b52e0cb43a3e5ef10`.

This validates finite synthetic happy-path arithmetic and the listed reset/sequence/encoding cases. It does not establish full importer/exporter equivalence, arbitrary counter/double/conflict/loss/legacy support, actual clock accuracy, or a cause for CPU > wall. It does not test TimeStamp data.message extraction; separate focused checker regressions cover that path. No browser, application, DP, performance experiment or real-trace decoding was run for this validation.
