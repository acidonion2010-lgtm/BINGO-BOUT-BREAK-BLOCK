#!/usr/bin/env python3
"""Summarize retained formal diagnostic data; never rerun or trim samples."""
import argparse
import json
import statistics
from pathlib import Path


def stats(values):
    present=[v for v in values if v is not None]
    if not present:return {'n':0,'missing':len(values),'median':None,'min':None,'max':None,'raw':values}
    return {'n':len(present),'missing':len(values)-len(present),'median':statistics.median(present),
            'mean':statistics.mean(present),'min':min(present),'max':max(present),'raw':values}


def metrics(row):
    a=row['analysis'];s=row['scheduler']
    return {'wallMs':a['solveWallMs'],'cpuMs':a['solveThreadCpuMs'],'nonCpuMs':a['nonCpuMs'],
        'cpuSharePercent':a['solveThreadCpuMs']/a['solveWallMs']*100 if a['availability']['cpuBoundsValid'] else None,
        'gcWallMs':a['gc']['wallUnionMs'],'jitWallMs':a['jit']['wallUnionMs'],
        'gcJitWallMs':a['gcJitCombined']['wallUnionMs'],
        'gcCpuCompleteMs':a['gc']['cpuUnionMs'],'jitCpuCompleteMs':a['jit']['cpuUnionMs'],
        'gcObservedCpuMs':a['gc']['observedCpuUnionMs'],'jitObservedCpuMs':a['jit']['observedCpuUnionMs'],
        'schedulerEnvelopeCpuMs':s.get('runtimeMs'),'schedulerEnvelopeWaitMs':s.get('runnableWaitMs'),
        'envelopeCpuMinusSolveCpuMs':s['runtimeMs']-a['solveThreadCpuMs'] if s.get('available') and a['availability']['cpuBoundsValid'] else None}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('directory',type=Path)
    args=parser.parse_args();data=json.loads((args.directory/'results.json').read_text())
    assert data['status']=='completed' and len(data['samples'])==16
    rows=data['samples'];result={'sampleCount':len(rows),'all':{},'runs':{},'variationExamples':[]}
    ms=[metrics(r) for r in rows]
    result['all']={k:stats([r[k] for r in ms]) for k in ms[0]}
    result['integrity']={'validMarkerCpuBounds':sum(r['analysis']['availability']['cpuBoundsValid'] for r in rows),
        'parseComplete':sum(r['analysis']['eventParsingComplete'] for r in rows),
        'noDataLoss':sum(r['traceCapture']['complete'].get('dataLossOccurred') is False for r in rows),
        'matchedSchedulerSnapshots':sum(r['scheduler']['available'] for r in rows),
        'nonnegativeSchedulerCounters':sum(r['scheduler'].get('nonnegativeCounters') is True for r in rows),
        'gcCpuComplete':sum(r['analysis']['gc']['cpuCoverageComplete'] for r in rows),
        'jitCpuComplete':sum(r['analysis']['jit']['cpuCoverageComplete'] for r in rows),
        'fixedLayoutSha256':data['fixedLayoutSha256']}
    for run in [1,2]:
        selected=[r for r in rows if r['run']==run];arms={}
        for arm in ['stage5','stage9']:
            values=[metrics(r) for r in selected if r['arm']==arm]
            arms[arm]={k:stats([r[k] for r in values]) for k in values[0]}
            ordered=sorted([r for r in selected if r['arm']==arm],key=lambda r:r['analysis']['solveWallMs'])
            fastest=ordered[0];slowest=ordered[-1];a=metrics(fastest);b=metrics(slowest)
            result['variationExamples'].append({'run':run,'arm':arm,'fastestId':fastest['id'],'slowestId':slowest['id'],
                'description':'Exploratory same-arm fastest/slowest range; all samples retained',
                'slowMinusFast':{k:b[k]-a[k] if a[k] is not None and b[k] is not None else None for k in a}})
        differences=[]
        for round_number in [1,2,3,4]:
            pair={r['arm']:metrics(r) for r in selected if r['round']==round_number}
            differences.append({k:pair['stage9'][k]-v if v is not None and pair['stage9'][k] is not None else None for k,v in pair['stage5'].items()})
        result['runs'][str(run)]={'arms':arms,'pairedStage9Minus5':{k:stats([r[k] for r in differences]) for k in differences[0]}}
    (args.directory/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print('Integrity',json.dumps(result['integrity']))
    for k,v in result['all'].items():print(k,'median',v['median'],'range',[v['min'],v['max']],'missing',v['missing'])
    for run,v in result['runs'].items():
        print('run',run,'paired medians',{k:round(v['pairedStage9Minus5'][k]['median'],4) if v['pairedStage9Minus5'][k]['median'] is not None else None for k in ['wallMs','cpuMs','nonCpuMs','gcWallMs','jitWallMs','schedulerEnvelopeWaitMs']})
    print('Exploratory ranges',json.dumps(result['variationExamples'],ensure_ascii=False))


if __name__=='__main__':main()
