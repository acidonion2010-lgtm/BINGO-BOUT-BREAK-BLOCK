# Stage9 final selector measurement review

Read-only review of `selector_performance.py`, `selector-performance.json`,
`break_candidate.py`, `break-candidate.json`, and source-integrity records. No
browser, benchmark or HTML edit was performed during this review. Numerical
counts and clock calculations were independently checked by a second reviewer.

## The two comparisons answer different questions

| Dataset | Before | After | Scope |
| --- | --- | --- | --- |
| `selector-performance.json` | Original `e872443d…` | Stage9 candidate `59fff468…` | 104 selector conditions in two visible HTML realms, two fresh browsers |
| `break-candidate.json` | Frozen stage5 `fea09e99…` | Four candidate functions from `59fff468…` | Same loaded stage5 realm, same inputs/DP receiver, function-bundle crossover |

The first comparison includes the earlier DP refactor as well as stage9. The
second isolates the four-function legacy BREAK change under the diagnostic's
compilation/reset conditions. Their raw samples must not be pooled with each
other or with previous stages. A difference against the original does not by
itself identify which refactor caused it.

At review time, `index.html` and `stages/index.handoff-20261015.html` still hash
to `fea09e995bfc1036515b92771925bd7968f3c453425ea5517b7a5b480293be64`.
The measured candidate hashes to
`59fff4685ff3f36e18d73fe9fa524ee57d81a348352e7b2912db4b7ecc1bb513`.
`candidate-source-integrity.json` and the crossover harness confirm that only
the four expected CPU function declarations differ from the frozen stage5 HTML.

## Full 104-condition result

The real-HTML run completed 208 condition/run rows with 9 paired batches of
20,000 decisions, for 74,880,000 measured decisions. There are 16 explicit
terminal-policy exclusions across the two runs, representing eight excluded
conditions. Both HTMLs passed all 322 automatic tests in each browser, with no
page errors. Recorded selector equivalence checks passed.

Here `negative` means the conditional interval's upper endpoint is at most zero;
`positive` means its lower endpoint is strictly greater than zero. These remain
conditional batch classifications, with the harness's stated dependence and
multiple-comparison limitations.

| Summary | Negative | Unconfirmed | Positive |
| --- | ---: | ---: | ---: |
| Run1 (104 conditions) | 54 | 50 | 0 |
| Run2 (104 conditions) | 55 | 46 | 3 |
| Same classification in both runs | 42 | 62 | 0 |
| Pooled, conditional on these two processes | 58 | 45 | 1 |

The 42 repeated-negative conditions consist of 37 BREAK and 5 BLOCK conditions.
All 32 legacy BREAK conditions are repeated-negative: NORMAL, HARD legacy,
HARD fallback legacy-roll and HARD fallback DP-roll, each covering both first
players and all four board scenarios. Their pooled paired median differences
range from approximately -0.9225 to -1.445 microseconds per decision.

The sole pooled-positive condition is **P2 opening BREAK, master-fallback**:

| Summary | Paired median delta (microseconds) | Conditional interval (microseconds) |
| --- | ---: | --- |
| Run1 | +0.005 | [-0.020, +0.015] |
| Run2 | +0.040 | [+0.025, +0.090] |
| Pooled | +0.025 | [+0.005, +0.040] |

This lower endpoint corresponds to one observed 0.1 ms batch increment divided
by 20,000 calls. It survives integer endpoint arithmetic and is not the tiny
floating cancellation boundary found in the earlier stage6 review. It remains
an unresolved positive observation under this benchmark; its size, occurrence
among many comparisons, or lack of repetition is not an allowance for dismissing
it. The board-only MASTER fallback path does not use the stage9 reused legacy
BREAK weights, and the original-to-candidate comparison does not isolate stage9
as its cause.

Run2 also has positive intervals for P2 opening BLOCK hard-legacy
(median +0.060, interval [+0.015,+0.170] microseconds) and P2 opening BLOCK
hard-fallback-dp-roll (median +0.050, interval [+0.015,+0.175]). Neither is
repeated-positive or pooled-positive. Preserve these observations too.

`strictAllMeasuredPathsNonRegressionConfirmed` is correctly **false**. No
positive condition repeated in both runs, but 62 unconfirmed conditions and the
positive observations prevent a universal non-regression claim.

## Clock arithmetic review

The wrapper retains the raw absolute-within-realm `performance.now()` start/end
readings, floating elapsed values and the old floating summary. It also rounds
each exposed endpoint to an integer nanosecond representation, subtracts those
integers, subtracts paired integer durations, and only then normalizes by the
call count. This avoids amplifying cancellation residue into a strict sign.
All encoded endpoints are safe integers; their differences are safe at these
observed magnitudes. The representation does not improve clock resolution or
accuracy. The full two-realm harness does not record frame time origins, so its
absolute endpoint values should only be interpreted within their own realm;
its duration comparison does not require a shared time origin.

All 4,212 measured sample arms across both datasets were checked: endpoint
encoding, raw end-minus-start duration, integer end-minus-start duration, and
normalization agree with the stored results. All encoded endpoints fall on the
observed 100,000 ns grid. That empirical grid is descriptive and is never used
as a performance tolerance.

The full matrix contains 55 paired equal integer durations. Floating arithmetic
reports 39 as exactly zero, 6 as tiny positive and 10 as tiny negative. Despite
these arithmetic differences, **all 208 run-row and 104 pooled classifications
match between the raw floating and integer representations**, as do the
repeated classifications. Integer arithmetic has not hidden the outstanding
pooled-positive condition. Existing earlier results remain unchanged.

## Same-realm BREAK mechanism and timing

The crossover completed its declared 9,360,000 measured decisions: 10 A/B
fixtures and 3 same-reference A/A fixtures, two fresh browsers, nine paired
20,000-call batches per comparison. Both baseline page loads passed 322/322
automatic tests with no page errors. The candidate HTML itself is loaded and
tested separately in the full matrix; the crossover compiles its four function
declarations inside the loaded baseline realm.

All 16-call-per-variant untimed audits passed exact selected-cell, RNG draw/value,
public state, history and dispatch checks. The separate untimed instrumentation
shows BREAK `getCellWeights` calls fall from **2 to 1** with matching raw weights;
legacy BLOCK remains 1 to 1 and HARD full-DP remains 0 to 0. This supports the
specific removed-duplicate-work mechanism.

Every measured pair in each of the five BREAK fixtures is negative: 18/18 per
fixture, 90/90 total. Paired median differences in microseconds are:

| Fixture | Run1 | Run2 | Pooled descriptive median |
| --- | ---: | ---: | ---: |
| P2 middle NORMAL BREAK | -1.0050 | -0.9400 | -0.9650 |
| P2 middle HARD legacy BREAK | -0.9550 | -0.9800 | -0.9725 |
| P2 middle HARD fallback legacy BREAK | -0.8700 | -0.9800 | -0.9475 |
| P1 opening NORMAL BREAK | -0.9750 | -0.9350 | -0.9625 |
| P1 late HARD legacy BREAK | -1.5450 | -1.4050 | -1.4925 |

The integer-endpoint differences support the same substantial negative result.
This diagnostic therefore provides evidence of a hot legacy BREAK improvement
against frozen stage5 in the five selected fixtures. It does not establish cold
cost, match latency, native-RNG cost, or all-device performance.

Controls do not support a blanket improvement claim. P1 late legacy BLOCK and
P2 middle legacy BLOCK change median sign across runs; P2 one-closed fallback
BLOCK has small positive medians in both runs (+0.005 and +0.010 microseconds).
P2 middle NORMAL BLOCK is approximately tied and HARD full BLOCK changes sign.
Same-reference A/A observations also have mixed timing, including negative
medians. A/A is retained as a diagnostic, with strict equal function references;
it is not subtracted from A/B or used to excuse a positive difference. The
stored `configured.audits` in A/A rows contains the fixture's earlier baseline
and candidate audits; it does not mean the A/A timed arms use different bundles.
Both actual A/A timed arm names are baseline and reference equality is true.

The crossover checks marks/layout/available contents and stable input, DP,
scratch-array and value-table references. It does not scan value-table contents
after every batch; repeated function swaps, compiled identities and allocation
cadence remain diagnostic limitations. Counters/history/scratch are reset before
each measured arm, unlike the older accumulating-counter matrix. These design
differences are recorded and prevent treating crossover and full-matrix samples
as interchangeable.

## Reporting conclusion

It is supported to report that the candidate removes one redundant raw-weight
calculation per ordinary legacy BREAK decision, passes the recorded functional
checks, improves all five measured same-realm BREAK fixtures, and has
repeated-negative intervals in all 32 legacy BREAK conditions of the new
original-to-candidate matrix. It is not supported to report universal CPU
non-regression or a whole-game/user-latency speed PASS. Retain the MASTER
fallback positive observation, the 62 repeated-unconfirmed conditions and the
separate Worker/gameplay/UI validation results. No measured noise, clock grid,
A/A subtraction or historical reclassification supplies an acceptance margin.
