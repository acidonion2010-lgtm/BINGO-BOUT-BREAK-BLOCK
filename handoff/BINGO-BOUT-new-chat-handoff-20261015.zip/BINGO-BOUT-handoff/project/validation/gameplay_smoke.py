"""Exercise real controls, animations, CPU turns and the two-player handoff.

Starts its own temporary localhost server; no persistent preview server is needed.
"""
import argparse
import functools
import http.server
import json
from pathlib import Path
import threading
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--file', type=Path, default=root.parent / 'index.html')
parser.add_argument('--out', type=Path, default=root / 'gameplay-smoke.json')
args = parser.parse_args()
target = args.file.resolve(strict=True)
class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *unused):
        pass
server = http.server.ThreadingHTTPServer(('127.0.0.1', 0),
    functools.partial(Handler, directory=str(target.parent)))
threading.Thread(target=server.serve_forever, daemon=True).start()
url = f'http://127.0.0.1:{server.server_port}/{target.name}'
results = []
errors = []
with sync_playwright() as playwright:
    browser = playwright.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
    page = browser.new_page(reduced_motion='reduce', viewport={'width': 1280, 'height': 900})
    page.on('pageerror', lambda error: errors.append(str(error)))
    for difficulty in ('normal', 'hard', 'master'):
        for first in (1, 2):
            page.goto(url)
            page.evaluate('''first => {
                window.smokeNativeRandom = Math.random;
                let initial = true;
                Math.random = () => {
                    if (initial) {initial = false; return first === 1 ? 0.1 : 0.9;}
                    return window.smokeNativeRandom();
                };
            }''', first)
            page.locator(f'#btn-cpu-{difficulty}').click()
            page.evaluate('Math.random = window.smokeNativeRandom')
            assert page.evaluate('state.firstPlayer') == first
            page.wait_for_function('!state.isStarting && !cpuWholeWaiting()', timeout=15000)
            if first == 1:
                page.wait_for_function('canHumanInteractWithBoard(1)')
                page.locator('#board1 .cell:not([disabled])').first.click()
                page.wait_for_function("state.p1TurnsTaken === 1 && state.phase === 'block' && canHumanInteractWithBoard(2)", timeout=15000)
                page.locator('#board2 .cell:not([disabled])').first.click()
            else:
                page.wait_for_function("state.phase === 'block' && canHumanInteractWithBoard(2)", timeout=15000)
                page.locator('#board2 .cell:not([disabled])').first.click()
                page.wait_for_function('state.p2TurnsTaken === 1 && canHumanInteractWithBoard(1)', timeout=15000)
                page.locator('#board1 .cell:not([disabled])').first.click()
            page.wait_for_function('state.p1TurnsTaken === 1 && state.p2TurnsTaken === 1 && state.inning === 2', timeout=15000)
            assert page.evaluate('cpuWholeStatus') == ('inactive' if difficulty == 'normal' else 'ready')
            result = {'difficulty': difficulty, 'firstPlayer': first, 'passed': True, 'inning': 2}
            results.append(result)
            print(json.dumps(result), flush=True)
    page.goto(url)
    page.locator('#btn-format-2p').click()
    page.locator('#btn-2p-start').click()
    page.wait_for_function('!state.isStarting && !state.isProcessing')
    owner = page.evaluate('getCurrentPlayer()')
    page.locator(f'#board{owner} .cell:not([disabled])').first.click()
    page.wait_for_function('state.isHandoffPending')
    page.locator('#handoff-ready-btn').click()
    page.wait_for_function('!state.isHandoffPending && !isOverlayPointerGuardActive()')
    page.locator(f'#board{owner} .cell:not([disabled])').first.click()
    page.wait_for_function('state.p1TurnsTaken + state.p2TurnsTaken === 1', timeout=15000)
    results.append({'mode': '2p', 'passed': True, 'handoff': 'BREAK, handoff READY, BLOCK, turn resolved'})
    browser.close()
assert not errors, errors
server.shutdown()
report = {'passed': len(results), 'total': 7, 'results': results, 'pageErrors': errors}
args.out.parent.mkdir(parents=True, exist_ok=True)
args.out.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
