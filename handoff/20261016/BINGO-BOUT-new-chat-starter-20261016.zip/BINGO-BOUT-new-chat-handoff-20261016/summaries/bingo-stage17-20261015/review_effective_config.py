#!/usr/bin/env python3
"""After completed capture only: read preflight checks and check 8 formal protos once."""
import hashlib, json, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
CHECKER_SHA='5b254cda6ddf8a44ccbc295aa252ea1f9ca6e3de5e843f900ac84f4449185b17'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_new(path,data):
    with path.open('x') as output:
        json.dump(data,output,indent=2,ensure_ascii=False,allow_nan=False)
        output.write('\n')

def unknown_fields(value,path=''):
    found=[]
    if isinstance(value,dict):
        for key,item in value.items():
            child=f'{path}.{key}' if path else key
            if key in ('unparsedFields','wrapperUnparsedFields') and item:
                found.append({'path':child,'fields':item})
            else:
                found.extend(unknown_fields(item,child))
    elif isinstance(value,list):
        for index,item in enumerate(value):
            found.extend(unknown_fields(item,f'{path}[{index}]'))
    return found

def main():
    assert sha(ROOT/'check_effective_config.py')==CHECKER_SHA
    source_report=ROOT/'report.json'
    report=json.loads(source_report.read_bytes())
    assert report['status']=='completed','wait until all capture finishes'
    assert len(report['visits'])==10 and all(v['completed'] for v in report['visits'])
    assert [v['run'] for v in report['visits']]==list(range(10))
    result={'scope':'Existing preflight config checks plus exactly one independent settings/snapshot check per formal saved proto. No new browser measurement.',
        'scriptSha256':sha(Path(__file__)),'checkerSha256':CHECKER_SHA,
        'sourceReportSha256':sha(source_report),'visits':[]}
    assert not (ROOT/'config-post-review.json').exists()
    assert not (ROOT/'CONFIG_POST_REVIEW.md').exists()
    for visit in report['visits']:
        run=visit['run'];unit=visit['unit'];trace=ROOT/f'run{run}.pftrace'
        output=ROOT/f'run{run}.config-check.json'
        record={'run':run,'unit':unit,'preflight':visit['preflight'],
            'traceSha256':sha(trace),'configCheckPath':str(output)}
        assert record['traceSha256']==visit['trace']['sha256']
        if run<2:
            assert output.exists()
            record['action']='read existing preflight check'
        else:
            assert not output.exists(),'refuse repeated formal check'
            command=[sys.executable,str(ROOT/'check_effective_config.py'),str(trace),
                '--config',str(ROOT/f'trace-config.unit{unit}.pb'),'--output',str(output)]
            completed=subprocess.run(command,capture_output=True,text=True,timeout=120)
            log={'argv':command,'returncode':completed.returncode,
                'stdout':completed.stdout,'stderr':completed.stderr}
            write_new(ROOT/f'run{run}.config-post-check-log.json',log)
            record.update(action='one new check of saved formal proto',returncode=completed.returncode)
        check=json.loads(output.read_bytes())
        assert check['scriptSha256']==CHECKER_SHA
        assert check['traceSha256']==record['traceSha256']
        assert check['requestedConfigSha256']==sha(ROOT/f'trace-config.unit{unit}.pb')
        record.update(configCheckSha256=sha(output),allGatesPass=check['allGatesPass'],
            allEchoedKnownSemanticsMatch=check['allEchoedKnownSemanticsMatch'],
            primaryClockValues=check['primaryClockValues'],
            allIncrementalClock64UnitsMatch=check['allIncrementalClock64UnitsMatch'],
            allPacketDefaultClocks64=check['allPacketDefaultClocks64'],
            echoedConfigCount=len(check['traceConfigs']),
            packetDefaultsCount=len(check['packetDefaults']),
            clockKinds=check['clockKinds'],unparsedFields=unknown_fields(check),
            requestedDecoded=check['requestedDecoded'])
        result['visits'].append(record)
    units=[]
    for unit in (1000,1):
        visits=[v for v in result['visits'] if v['unit']==unit]
        units.append({'unit':unit,'visits':len(visits),
            'preflightVisits':sum(v['preflight'] for v in visits),
            'formalVisits':sum(not v['preflight'] for v in visits),
            'allGatesPass':all(v['allGatesPass'] for v in visits),
            'clock64Snapshots':sum(k['count'] for v in visits for k in v['clockKinds'] if k['clockId']==64),
            'packetDefaults':sum(v['packetDefaultsCount'] for v in visits),
            'echoedConfigs':sum(v['echoedConfigCount'] for v in visits)})
    settings=[]
    for v in result['visits']:
        config=json.loads(json.dumps(v['requestedDecoded']))
        track=next(s['track_event_config'] for s in config['data_sources'] if s['name']=='track_event')
        track['timestamp_unit_multiplier']=1
        settings.append(config)
    result.update(units=units,
        onlyKnownSettingDifferenceIsRequestedUnit=all(c==settings[0] for c in settings),
        allGatesPass=all(v['allGatesPass'] and v.get('returncode',0)==0 for v in result['visits']))
    write_new(ROOT/'config-post-review.json',result)
    paragraphs=['# 段階17: 実効設定の事後確認','',
        f"保存済み10 trace (preflight2 + formal8) を確認し、全設定gate結果は `{result['allGatesPass']}`。preflightの既存検算結果を読み取り、formal8 traceへ同じ固定検算器を各1回実行した。新規browser計測は行っていない。",'',
        '| 要求倍率 | preflight / formal | clock64 snapshots | packet defaults | config echo | 全gate |',
        '|---:|---:|---:|---:|---:|---|']
    for unit in units:
        paragraphs.append(f"| {unit['unit']} | {unit['preflightVisits']} / {unit['formalVisits']} | {unit['clock64Snapshots']} | {unit['packetDefaults']} | {unit['echoedConfigs']} | {unit['allGatesPass']} |")
    paragraphs.extend(['',
        '全10 traceで、echoed TraceConfig の既知設定が要求値と一致すること、primary trace clockがCLOCK_MONOTONIC=3、incremental clock64がincremental=trueかつ各要求倍率、TracePacketDefaults timestamp clockが64であることを検算した。',
        '',
        '要求設定はclear_period_ms=500、track_eventとorg.chromium.trace_metadata2の2 sources、200MiB+256KiBのDISCARD buffers、旧8 categoriesと__metadata、CPU sampling=true / subsampling0。各traceのechoも一致する。clear500は通知要求間隔の設定確認であり、各eventのreset実時刻が厳密に500ms間隔であるという保証ではない。',
        '',
        f"倍率を1に正規化した既知設定の全visit比較: `{result['onlyKnownSettingDifferenceIsRequestedUnit']}`。未知fieldsは各config-checkとconfig-post-review.jsonのunparsedFieldsへ保存した。理解していないfieldを削除したり、設定比較に含めたと主張したりしていない。",'',
        '対象CPU CounterDescriptorのincremental属性・実効倍率とeventへの適用は別のfrozen raw counter gateが確認する。倍率1でdescriptor field4が省略され、raw accessor値0 / 実効倍率1になる点はZERO_UNIT_REVIEW.mdとzero-unit-evidence.jsonを参照。CPUとwallの物理的整合性やゲームの速度差は、この設定検算の結論に含まれない。','',
        f"検算器SHA256: `{CHECKER_SHA}`。元report・各proto・要求config・検算結果のSHA256をconfig-post-review.jsonへ保存した。",''])
    with (ROOT/'CONFIG_POST_REVIEW.md').open('x') as output:
        output.write('\n'.join(paragraphs))
    print(json.dumps({'units':units,'allGatesPass':result['allGatesPass'],
        'onlyKnownSettingDifferenceIsRequestedUnit':result['onlyKnownSettingDifferenceIsRequestedUnit']}))
    if not result['allGatesPass']:
        raise SystemExit(1)

if __name__=='__main__':
    main()
