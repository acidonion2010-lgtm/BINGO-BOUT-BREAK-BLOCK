# 段階16 保存データ独立レビュー

2026-10-15。ブラウザー、ゲーム、DP、性能ジョブは起動せず、固定済みソースと保存 JSON / protobuf の読み取りだけで確認した。`analyze_proto_json.py` を呼び出さず別の集計で照合し、JSON 内の十進数を `Decimal` として読んだ符号判定も確認した。既存成果物は変更していない。

## 結果と適用範囲

主解析の件数・符号・外側区間の算術に不一致は見つからなかった。公式 converter で同一 protobuf から生成した JSON にも main thread の `tdur > dur` は残る。一方、実クリックの marker 区間は正式144・warmup48の全192区間で CPU 時計があり、厳密な `CPU > wall` は0だった。これは、main thread の個々の trace event の異常をクリックの handler / RAF 区間の CPU 超過へ直接読み替えられないことを示す。

CDP `ThreadTime` / `TaskDuration` と schedstat の外側比較にも超過はなかった。ただし正式の host 外側区間は59.525–82.823 msあり、より狭い trace event の時刻を検証・補正した結果ではない。アプリの変更前後比較、最適化の根拠、過去の条件に対する性能非劣化判定にはならない。過去の観測と未確認条件は維持する。

## 完了・同一性・欠測

- `report.status == completed`、5 visit 全件 `completed`。preflight 1件、正式ブラウザー4件、正式クリック24、warmup8。各ブラウザーの各 branch は trial0のみ warmup、trial1–3が正式。run1/3は DP→legacy、run2/4は逆順。
- 全5 visit で自己テスト322/322、正式4 visit で実 Worker の準備が `ready`。全32クリックで trusted / accepted / visible / 選択セル受付・無効化 / engine ready を確認した。DP は `(whole, dp, legacy)=(1,1,0)`、legacy は `(0,0,1)` だった。`selectedBreakCell` を実 CPU 局所選択と同一視していない。
- `pageErrors` は空。全66 CDP endpoint で `ThreadTime` / `Timestamp` / `TaskDuration` が有限。trace の `(pid,tid)` は renderer main の `pid==tid`、`CrRendererMain` metadata があり、対応する `/proc` の comm / starttime は visit 内で安定していた。
- 全5 protobuf と全5変換 JSON の SHA-256 / byte 数を保存 report と照合した。変換ログの returncode は全5件0、event 数も一致した。収集記録は全件 EOF / `integrityChecksPassed`、`dataLossOccurred:false`、buffer full 通知なし。このレビュー自体は protobuf の全 counter を復号していない。
- main の全 `X` event は78,837件。そのうち9,461件は `tdur` と `tts` がなく、主解析の69,376件には含まれない。正式 marker192区間では `tts` 欠測・負の wall・負の CPU はいずれも0。preflight の mark / stamp の endpoint にも欠測はない。欠測を超過なしとして加算していない。

## 主解析の独立再集計

対象は visit 全 trace の同一 main thread、`ph:X`、`dur` と `tdur` のある event。fixture / untimed audit を含む trace 全体の件数であり、クリック32件だけの集計ではない。入れ子 event を含むので、独立した task / 操作の件数でもない。

| visit | CPU時計付き X | `tdur > dur` | 差が1 ms超 | 最大差 µs |
|---|---:|---:|---:|---:|
| run0 preflight | 16 | 0 | 0 | 0 |
| run1 | 16,999 | 391 | 12 | 6,966 |
| run2 | 17,359 | 378 | 6 | 6,309 |
| run3 | 17,466 | 337 | 3 | 5,294 |
| run4 | 17,536 | 362 | 5 | 7,892 |
| 合計 | 69,376 | 1,468 | 26 | 7,892 |

厳密な符号判定を保持した。1 ms超は別の記述的集計であり、許容差・合格閾値ではない。正の event には Layout / UpdateLayoutTree / FunctionCall 等があるが、これだけで DP / handler の原因とは断定できない。

各クリックの `capture → handler-end / first-raf / second-raf` × mark / stamp の6区間を、保存 marker endpoint から再計算した。正式144/144、warmup48/48で `CPU <= wall`、主解析の各 window の符号と一致した。preflight の別集計は mark が wall8,258 µs・CPU8,230 µs（差−28 µs）、stamp が wall8,125 µs・CPU8,122 µs（差−3 µs）。

## CDP と schedstat の外側区間

`ThreadTime` の差は before の protocol 送信前から after の応答受信後までの host monotonic 区間と比較している。renderer の各読み取りがその区間内にあるという外側包含であり、CDP `Timestamp` を CPU 読み取りと同時の wall endpoint として扱っていない。schedstat は別の `/proc` 読み取りを囲む host 区間と比較している。

以下は正式24クリック、単位 ms、表示は丸めた値。超過の判定自体は丸め前の厳密な符号による。

| 項目 | 最小 | 中央値 | 最大 |
|---|---:|---:|---:|
| CDP ThreadTime 差 | 12.160 | 15.446 | 18.854 |
| CDP TaskDuration 差 | 11.500 | 14.648 | 17.973 |
| metric host 外側 wall | 59.525 | 73.645 | 82.823 |
| ThreadTime − 同外側 wall | −66.860 | −57.727 | −45.459 |
| TaskDuration − 同外側 wall | −67.667 | −58.488 | −46.164 |
| schedstat runtime 差 | 12.013 | 15.201 | 18.829 |
| schedstat runqueue 差 | 0 | 0.307 | 4.674 |
| schedstat 自身の外側 wall | 58.338 | 72.398 | 81.411 |

正式24、warmup8とも ThreadTime / TaskDuration / schedstat runtime がそれぞれの外側 wall を超えた件数は0、各 counter 差の負値も0。warmup の ThreadTime は14.423–45.226 ms、外側 wall は62.265–152.083 ms。preflight は ThreadTime9.716 ms、TaskDuration9.622 ms、metric 外側 wall20.405269 ms、schedstat runtime9.708033 ms、schedstat 外側 wall17.536115 msだった。

`TaskDuration` は主解析に集計欄がないため本レビューで保存 endpoint から追加算出した。正式の `ThreadTime − TaskDuration` は0.620–1.085 ms（中央値0.8025 ms）。公式ソース上、両値は同一瞬間の atomic snapshot ではなく、TaskDuration は観測 task と実行中 task の prefix を含む。この差を特定の処理・scheduler 待ちへ割り当てない。

CDP API は trace exporter を経由しないが、Linux の underlying thread CPU clock を trace と共有し得る。独立した物理時計による確認ではない。schedstat は自身の更新時点が読み取り直前とは限らず、正式2件の runqueue 差0も「待ちなし」を証明しない。実装・時計・精度の区別は [CDP_CPU_REVIEW.md](CDP_CPU_REVIEW.md) に記録した。

## 追加照合：固定 origin モデルに矛盾するか

新しい計測をせず、全260 marker record の `tts` と全33 action の CDP before / after を照合した。marker の CPU 値を `M`、CDP `ThreadTime` を `T` とし、同じ CPU 座標で `T = CPU − O`、その marker の CPU 採取が CDP before 採取後・after 採取前にあると仮定すると、各 action の origin 候補は次になる。

`[ max(M) − T_after, min(M) − T_before ]`

marker は action 内の全 mark / stamp を用いた。収集コードは before 応答・proc 読み取り完了後に action を実行し、終了を確認してから after を送信している。保存 marker の wall timestamp が外 host envelope 内にあることも確認済み。ただし、これらは CPU 採取順序と同一座標を仮定する整合性検査であり、その仮定そのものの証明ではない。

保存数値を十進数のまま秒→ns、`tts` の µs→nsへ換算し、許容差を足さず算術した。全33 action の候補区間と、同一 visit 内の共通部分はすべて非空だった。

| visit | action 数 | marker record 数 | 共通下端 ns | 共通上端 ns | 幅 ns |
|---|---:|---:|---:|---:|---:|
| run0 | 1 | 4 | 4,001,550,000 | 4,002,993,000 | 1,443,000 |
| run1 | 8 | 64 | 3,766,581,000 | 3,766,816,000 | 235,000 |
| run2 | 8 | 64 | 3,817,720,000 | 3,818,194,000 | 474,000 |
| run3 | 8 | 64 | 3,786,097,000 | 3,787,137,000 | 1,040,000 |
| run4 | 8 | 64 | 3,699,349,000 | 3,701,249,000 | 1,900,000 |

visit ごとに renderer と CDP origin が異なるため visit 間では交差させない。結果はこの広さの区間で固定 origin モデルに矛盾しないというだけである。ThreadTicks / JSON は µs 単位化・秒の double 表現を経る。さらに SDK の差分を整数除算して積む量子化損失や incremental-state reset / epoch 境界による回復の可能性を、この検査は除外しない。原 counter と JSON の一致は別担当の復号監査であり、単なる保存値の一致から kernel 時計の正確性や event 単位の物理的 CPU 時間を保証しない。

## 静的レビューと補足件数

主解析の outer envelope と window 境界に修正を必要とする問題は見つからなかった。解析コードは未完 visit を除外するため、集計だけを見ると完了状態が分からないが、今回は元 report で5件完了を確認した。主解析が窓に `tts` 欠測を許す点も、今回は別集計で0件と確認した。

主解析を変更せずに追加した保存データ照合は4項目：① marker と main X の欠測分母、② preflight の2 marker 区間、③ TaskDuration の外側比較、④固定 origin 候補の visit 内共通部分。追加のブラウザー・性能計測は0件。

## ハッシュ

レビュー時の SHA-256。report の collector / plan / helper / HTML の記録値、analysis の report / analyzer の記録値は現物と一致した。

| ファイル | SHA-256 |
|---|---|
| report.json | `6c181c8c2300795f32814c8752f19a7463647b23cf99ef3604503566cc268169` |
| analysis.json | `d1e2fac34ccad5064c8d9968de4399a3456ba1aa998f98d727dc68a24a7327d4` |
| capture_proto.py | `b071059ac8d1f93a417f294cc143590ae2101bee8da4f6549f05d28774e3b6df` |
| analyze_proto_json.py | `6c08868c3131fd84389b3b7665d8bb17eed79e90eacb4e6a16973d36aa71cd2e` |
| PLAN.md | `532d60296329a05ad4d2d3d5d3d1b774fe6e5a0e4dfb8d7ee30bac9e686ba487` |
| trace_processor_shell | `58042408e6cc861fb1a731c26bb082dc222285561eaa4e12a48a8b2b90dca7b9` |
| 段階14 capture_clicks.py | `df0c5fa77905d13ce492882e14338a5684e6670e1c5f0694f44b20d696092c77` |
| 原本 HTML | `e872443dc9764f3b9647f4797d1411ca98f865b9c2f69c6e694529e2685cd3a9` |

## 追補：量子化・clear モデルの独立確認

後から作成された `verify_quantization_resets.py` と `cpu-quantization-model-check.json` を静的に確認し、元 ledger から別の集計で26件の begin / end、epoch、emission 数、上限を照合した。新しい計測は0件。公式 SDK の保存ソースも独立の補助レビューで照合した。

SDK は前回の正確な CPU ns との差を取り、正確な ns の baseline を更新してから倍率 `m` で整数除算する。clear は baseline を0にする。このため、真の CPU サンプル差分が非負であることを仮定すると、epoch 内の表現値は `Q=C−L`、`0≤L≤N(m−1)` となる。clear を跨ぐ区間では `ΔQ−ΔC=L_begin−L_end` なので正側の誤差は `N_begin(m−1)` 以下となる。script の `m=1000`、`N_begin×999 ns` という式はこのモデルと一致する。同一 epoch では損失が非減少なので、この丸めだけから正側の差分増大は生じない。

26/26件で同じ sequence / counter の異なる epoch を跨ぎ、begin 後・end 以前に clear があり、SQL の正の超過は当該上限内だった。内訳はrun1/2/3/4が12/6/3/5件。保存された `emissionsSinceClear` と上限を独立再計算して一致を確認した。これは source 上の機構と観測の整合性を強めるが、単独原因の確定ではない。

留保は次の通り。

- JSON の説明文の「nonnegative CPU samples」は、導出上は**真のサンプル差分も非負**という前提を要する。encoded 負値0という観測だけでは、整数除算で0になる微小な負差分まで排除できない。
- SDK の subsampling による zero emission は CPU を再読取せず baseline も更新しない。これも `N` に数えるため、この上限は緩い。真の ns・各剰余・正確な損失合計は保存されていない。
- CPU 採取と wall timestamp 採取は同時ではない。`CPU > wall` の超過へこの上限を当てるのは、その採取時点の違いを別問題として残す必要条件の検査である。reset 前後の時計が正確であることや、26件の超過全量が丸めだけで生じたことを証明しない。
- 原 protobuf / 公式 SQL / JSON の一致と、量子化モデルへの適合は異なる検証である。保存値の再現性から kernel 時計の障害や正常性を断定しない。

追補の入力識別：`verify_quantization_resets.py` SHA-256 は `77ef926c7202cc1edc7acc4c83480b4889553204c1fc86b1a49b6eeedd7f1503`、`cpu-quantization-model-check.json` は `cff7b8bb2e5dff756a7534899297e56e2e55b76474f1d82e5cf5a6a0f58043bd`、参照する `raw-counter-official-check.json` は `378957fba43c0c778b3d80399a57bfc135ad414aa6946171706a30d189c620ed`。script / 入力 check の記録 hash は現物と一致した。
