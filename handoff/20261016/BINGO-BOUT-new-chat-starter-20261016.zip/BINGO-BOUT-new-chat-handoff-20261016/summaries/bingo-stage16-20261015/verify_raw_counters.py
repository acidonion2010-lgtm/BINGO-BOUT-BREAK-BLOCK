#!/usr/bin/env python3
"""Pure-data check of frozen raw counter ledgers versus official SQL/JSON."""
from collections import Counter, defaultdict
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CHECKER_SHA = '91762a94d1e1e05305c2a11fbb237dd4b42bffd3ebb5162f48c4cec42b038c23'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(value):
    return None if value in (None, '[NULL]', '') else int(Decimal(value))


def main():
    assert digest(ROOT / 'raw_counter_check.py') == CHECKER_SHA
    report = json.loads((ROOT / 'report.json').read_bytes())
    result = {
        'scope': 'Frozen raw-counter ledgers versus official conversion of the same saved proto. No new measurement, wall-clock conversion, or CPU validity claim.',
        'limits': 'Raw slice candidates use packet-order BEGIN/END stacks of retained accepted-CPU events on a renderer thread track. Matching uses name and exact CPU endpoints, not independently converted wall timestamps. Uniqueness is reported explicitly.',
        'scriptSha256': digest(Path(__file__)), 'checkerSha256': CHECKER_SHA,
        'sourceReportSha256': digest(ROOT / 'report.json'), 'runs': [],
    }
    for visit in report['visits']:
        run = visit['run']
        ledger_path = ROOT / f'raw-counter-run{run}.json'
        ledger = json.loads(ledger_path.read_bytes())
        assert ledger['script_sha256'] == CHECKER_SHA
        assert ledger['input']['sha256'] == digest(ROOT / f'run{run}.pftrace')
        assert ledger['status'] == 'limited_scope_complete'
        pid, tid = visit['conversion']['rendererPidTid']

        def on_main(association):
            return association.get('status') == 'thread' and (association.get('pid'), association.get('tid')) == (pid, tid)

        rows = [row for row in ledger['ledger'] if on_main(row['event_association_at_end'])]
        events = json.loads((ROOT / f'run{run}.json').read_bytes())['traceEvents']
        events = [event for event in events if (event.get('pid'), event.get('tid')) == (pid, tid)]
        marks = defaultdict(list)
        console = defaultdict(list)
        for event in events:
            name = event.get('name', '')
            if name.startswith('bingo.stage16.'):
                marks[name].append(event)
            if name == 'TimeStamp':
                message = event.get('args', {}).get('data', {}).get('message')
                if isinstance(message, str) and message.startswith('bingo.stage16.'):
                    console[message].append(event)
        marker_checks = []
        raw_marker_names = Counter()
        for row in rows:
            if not row['target_marker']:
                continue
            is_console = row['name'] == 'TimeStamp'
            name = row.get('data_message') if is_console else row['name']
            raw_marker_names[(name, is_console)] += 1
            candidates = (console if is_console else marks)[name]
            match = len(candidates) == 1 and row['cpu_ns'] is not None and row['cpu_ns'] // 1000 == candidates[0].get('tts')
            marker_checks.append({'name': name, 'console': is_console, 'packetIndex': row['packet_index'],
                'packetTraceOffset': row['packet_trace_offset'], 'rawCpuNs': row['cpu_ns'],
                'jsonCandidates': len(candidates), 'jsonTtsUs': candidates[0].get('tts') if len(candidates) == 1 else None,
                'passed': match})
        expected_markers = {(name, False) for name in marks} | {(name, True) for name in console}
        coverage = set(raw_marker_names) == expected_markers and all(v == 1 for v in raw_marker_names.values())
        with (ROOT / f'official-sql/run{run}-counters.csv').open() as file:
            official_counters = list(csv.DictReader(file))
        official_multiset = Counter((str(number(row['uuid']) & ((1 << 64) - 1)), number(row['value']))
            for row in official_counters if row['name'] == 'thread_time')
        raw_multiset = Counter()
        for row in ledger['ledger']:
            for entry in row['counters']:
                if entry.get('descriptor_name') == 'thread_time' and entry.get('status') == 'decoded' and entry.get('sum_reliable') and on_main(entry['association_at_end']):
                    raw_multiset[(entry['counter_uuid'], int(entry['absolute_value']))] += 1

        stacks = defaultdict(list)
        raw_pairs = defaultdict(list)
        unmatched_end = 0
        for row in rows:
            if row['cpu_ns'] is None:
                continue
            key = (row['sequence_id'], row['event_track_uuid'])
            if row['type'] == 1:
                stacks[key].append(row)
            elif row['type'] == 2:
                if not stacks[key]:
                    unmatched_end += 1
                    continue
                begin = stacks[key].pop()
                raw_pairs[(begin['name'], begin['cpu_ns'], row['cpu_ns'])].append((begin, row))
        with (ROOT / f'official-sql/run{run}-slices.csv').open() as file:
            official_slices = list(csv.DictReader(file))
        large_checks = []
        for row in official_slices:
            start, duration, wall = number(row['thread_ts']), number(row['thread_dur']), number(row['dur'])
            if start is None or duration is None or wall is None or wall < 0 or duration - wall <= 1_000_000:
                continue
            candidates = raw_pairs.get((row['name'], start, start + duration), [])
            proof = []
            for begin, end in candidates:
                proof.append({'beginPacketIndex': begin['packet_index'], 'endPacketIndex': end['packet_index'],
                    'beginPacketTraceOffset': begin['packet_trace_offset'], 'endPacketTraceOffset': end['packet_trace_offset'],
                    'sequenceId': begin['sequence_id'], 'trackUuid': begin['event_track_uuid'],
                    'counterUuid': begin.get('cpu_counter_uuid'), 'endCounterUuid': end.get('cpu_counter_uuid'),
                    'beginCpuNs': begin['cpu_ns'], 'endCpuNs': end['cpu_ns'],
                    'beginCounters': begin['counters'], 'endCounters': end['counters']})
            large_checks.append({'sliceId': number(row['id']), 'name': row['name'], 'sqlTsNs': number(row['ts']),
                'sqlDurNs': wall, 'sqlThreadTsNs': start, 'sqlThreadDurNs': duration,
                'excessNs': duration - wall, 'rawPairCandidates': len(candidates), 'uniqueMatch': len(candidates) == 1,
                'rawProof': proof})
        record = {'run': run, 'protoSha256': ledger['input']['sha256'], 'ledgerSha256': digest(ledger_path),
            'officialSlicesSha256': digest(ROOT / f'official-sql/run{run}-slices.csv'),
            'officialCountersSha256': digest(ROOT / f'official-sql/run{run}-counters.csv'),
            'diagnosticCounts': ledger['diagnostic_counts'], 'markerCoverageExact': coverage,
            'markerRows': len(marker_checks), 'markerChecksPassed': sum(c['passed'] for c in marker_checks),
            'markerChecks': marker_checks, 'rawThreadTimeSamples': raw_multiset.total(),
            'officialThreadTimeSamples': official_multiset.total(), 'counterMultisetsEqual': raw_multiset == official_multiset,
            'rawOnlyCounterSamples': list((raw_multiset - official_multiset).items())[:20],
            'officialOnlyCounterSamples': list((official_multiset - raw_multiset).items())[:20],
            'rawBeginEndPairs': sum(map(len, raw_pairs.values())), 'unmatchedRawEnds': unmatched_end,
            'unclosedRawBegins': sum(map(len, stacks.values())), 'largeCpuExcessSlices': len(large_checks),
            'largeSlicesWithUniqueRawCpuPair': sum(c['uniqueMatch'] for c in large_checks), 'largeSliceChecks': large_checks}
        result['runs'].append(record)
        print(json.dumps({k: v for k, v in record.items() if k in ('run', 'markerCoverageExact', 'markerRows', 'markerChecksPassed', 'rawThreadTimeSamples', 'officialThreadTimeSamples', 'counterMultisetsEqual', 'largeCpuExcessSlices', 'largeSlicesWithUniqueRawCpuPair') }), flush=True)
    result['summary'] = {
        'allMarkerCoverageExact': all(row['markerCoverageExact'] for row in result['runs']),
        'markerRows': sum(row['markerRows'] for row in result['runs']),
        'markerChecksPassed': sum(row['markerChecksPassed'] for row in result['runs']),
        'allCounterMultisetsEqual': all(row['counterMultisetsEqual'] for row in result['runs']),
        'rawThreadTimeSamples': sum(row['rawThreadTimeSamples'] for row in result['runs']),
        'largeCpuExcessSlices': sum(row['largeCpuExcessSlices'] for row in result['runs']),
        'largeSlicesWithUniqueRawCpuPair': sum(row['largeSlicesWithUniqueRawCpuPair'] for row in result['runs']),
    }
    with (ROOT / 'raw-counter-official-check.json').open('x') as file:
        json.dump(result, file, ensure_ascii=False, indent=2)
        file.write('\n')
    print(json.dumps(result['summary']), flush=True)


if __name__ == '__main__':
    main()
