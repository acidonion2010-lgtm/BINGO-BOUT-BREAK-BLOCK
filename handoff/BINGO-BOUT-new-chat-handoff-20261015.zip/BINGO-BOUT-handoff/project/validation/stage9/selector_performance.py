#!/usr/bin/env python3
"""104-condition real-HTML comparison with retained absolute clock readings.

Observed performance.now timestamps are also encoded as integer nanoseconds.
This is arithmetic representation, not nanosecond clock accuracy or a speed
allowance. Raw floating durations/summaries are retained alongside it.
"""
import json
from pathlib import Path
import statistics
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'stage6'))
import selector_performance as extended


def main():
    bench = extended.benchmark
    old_summary = bench.summarize
    anchor = '      const elapsedMs = performance.now()-started;\n'
    assert bench.INSTALL_BENCH.count(anchor) == 1
    bench.INSTALL_BENCH = bench.INSTALL_BENCH.replace(anchor, '''      const ended = performance.now();
      const elapsedMs = ended-started;
      const observedStartNs = Math.round(started*1000000);
      const observedEndNs = Math.round(ended*1000000);
      if (!Number.isSafeInteger(observedStartNs) || !Number.isSafeInteger(observedEndNs))
        throw new Error('Clock encoding exceeds safe integer range');
''', 1)
    anchor = '      return {...answer,elapsedMs,msPerDecision:elapsedMs/count,\n'
    assert bench.INSTALL_BENCH.count(anchor) == 1
    bench.INSTALL_BENCH = bench.INSTALL_BENCH.replace(anchor, '''      return {...answer,elapsedMs,msPerDecision:elapsedMs/count,
        observedStartMs:started,observedEndMs:ended,observedStartNs,observedEndNs,
        observedDurationNs:observedEndNs-observedStartNs,callCount:count,
''', 1)

    def summarize(samples):
        counts = {side['callCount'] for pair in samples for side in (pair['before'], pair['after'])}
        assert len(counts) == 1
        count = next(iter(counts))
        assert count > 0
        for pair in samples:
            for side in (pair['before'], pair['after']):
                assert side['observedDurationNs'] == side['observedEndNs'] - side['observedStartNs']
                assert side['observedDurationNs'] >= 0
        differences = [pair['after']['observedDurationNs'] - pair['before']['observedDurationNs']
                       for pair in samples]
        deltas = [value / count / 1000 for value in differences]
        return {'beforeMedianUs': statistics.median(pair['before']['observedDurationNs'] for pair in samples) / count / 1000,
                'afterMedianUs': statistics.median(pair['after']['observedDurationNs'] for pair in samples) / count / 1000,
                'pairedDurationDifferencesNs': differences,
                'pairedDeltasUs': deltas, 'pairedMedianDeltaUs': statistics.median(deltas),
                'interval95': bench.median_interval(deltas),
                'legacyFloatSummary': old_summary(samples)}

    bench.summarize = summarize
    status = extended.main()
    output = Path(sys.argv[3])
    if output.exists():
        data = json.loads(output.read_text())
        data['conditions']['verification'] = 'stage9 candidate: one-decision legacy BREAK weight reuse'
        data['conditions']['clockArithmetic'] = {
            'primary': 'Round each absolute exposed timestamp to integer ns, then subtract timestamps and paired integer durations before normalization.',
            'unitMeaning': 'Integer encoding of exposed browser timestamps; not nanosecond measurement accuracy.',
            'retained': 'Raw absolute performance.now readings, floating elapsed/duration summaries, integer endpoints and integer duration differences.',
            'inference': 'No epsilon, noise allowance, A/A subtraction, or phase correction. Conditional batch intervals retain all prior dependence/multiple-comparison limitations.'}
        data['conditions']['productionModifiedDuringCapture'] = False
        output.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    return status


if __name__ == '__main__':
    raise SystemExit(main())
