# 段階17: 実効設定の事後確認

保存済み10 trace (preflight2 + formal8) を確認し、全設定gate結果は `True`。preflightの既存検算結果を読み取り、formal8 traceへ同じ固定検算器を各1回実行した。新規browser計測は行っていない。

| 要求倍率 | preflight / formal | clock64 snapshots | packet defaults | config echo | 全gate |
|---:|---:|---:|---:|---:|---|
| 1000 | 1 / 4 | 310 | 310 | 5 | True |
| 1 | 1 / 4 | 368 | 368 | 5 | True |

全10 traceで、echoed TraceConfig の既知設定が要求値と一致すること、primary trace clockがCLOCK_MONOTONIC=3、incremental clock64がincremental=trueかつ各要求倍率、TracePacketDefaults timestamp clockが64であることを検算した。

要求設定はclear_period_ms=500、track_eventとorg.chromium.trace_metadata2の2 sources、200MiB+256KiBのDISCARD buffers、旧8 categoriesと__metadata、CPU sampling=true / subsampling0。各traceのechoも一致する。clear500は通知要求間隔の設定確認であり、各eventのreset実時刻が厳密に500ms間隔であるという保証ではない。

倍率を1に正規化した既知設定の全visit比較: `True`。未知fieldsは各config-checkとconfig-post-review.jsonのunparsedFieldsへ保存した。理解していないfieldを削除したり、設定比較に含めたと主張したりしていない。

対象CPU CounterDescriptorのincremental属性・実効倍率とeventへの適用は別のfrozen raw counter gateが確認する。倍率1でdescriptor field4が省略され、raw accessor値0 / 実効倍率1になる点はZERO_UNIT_REVIEW.mdとzero-unit-evidence.jsonを参照。CPUとwallの物理的整合性やゲームの速度差は、この設定検算の結論に含まれない。

検算器SHA256: `5b254cda6ddf8a44ccbc295aa252ea1f9ca6e3de5e843f900ac84f4449185b17`。元report・各proto・要求config・検算結果のSHA256をconfig-post-review.jsonへ保存した。
