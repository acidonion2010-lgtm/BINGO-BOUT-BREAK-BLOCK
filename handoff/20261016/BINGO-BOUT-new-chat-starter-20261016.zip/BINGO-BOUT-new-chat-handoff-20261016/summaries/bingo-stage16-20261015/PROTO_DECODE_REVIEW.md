# 段階16 Protobuf時計・CPU counter復元の事前レビュー

対象はChromium `73c14f6228d7cd537c855007e8f88678969cc0eb` がDEPSでpinするPerfetto **`5dbeaad4ceb91470a835426b52e0cb43a3e5ef10`**。段階15保存済みの公式ソースを読み、欠けていたschema/decoder原本を同commitの公式repositoryから補った。ブラウザー、DP、性能ジョブは起動していない。元成果物は変更していない。

**現Chromiumのthread CPUは、旧 `TrackEvent.thread_time_delta_us` だけを読む方法では復元できない。** 通常の経路は `extra_counter_values` とCounterDescriptor/UUID/defaultsを使う。wall timestampの増分状態とCPU counterの増分状態は別である。第一選択は既存の `trace_processor_shell` / `traceconv` / Perfetto Python TraceProcessor APIによる同一protoの読込・JSON/SQL変換とし、限定decoderはその検算または利用不能時の補助にする。

## 原本と付随資料

- [基本schema・name/annotation schema・LICENSEのmanifest](/workspace/bingo-stage16-20261015/official-sources/proto-decode-review/MANIFEST.json)
- [clock schema詳細](/workspace/bingo-stage16-20261015/CLOCK_SCHEMA_REVIEW.md)
- [counter schema詳細](/workspace/bingo-stage16-20261015/COUNTER_SCHEMA_REVIEW.md)

manifestは固定commit URL、保存先、SHA256、サイズを保持する。段階15からcopyした原本はcopy前にhash一致を確認した。Chromium/PerfettoのLICENSEも原文のまま新dirに保持した。これらは実行用ソフトウェアの追加ではなく、読み取り用原本である。

基本schema、clock、counter、counter-resetの各保存manifestについて、この担当も全原本のhash/サイズを再照合し [proto-source-manifest-audit.json](/workspace/bingo-stage16-20261015/proto-source-manifest-audit.json) に記録した。

## 必要fieldとwire形式

下表のfield番号は上記固定revisionのproto2 schemaに対応する。`uint64/int64/uint32/bool/enum` はwire type 0、message/string/bytesは2、doubleは1（little-endian fixed64）。通常の `int64` はZigZagではなく、64bit two's-complementをvarintへ載せた値である。負のint64を `sint64` として読むと別の値になる。

| message | field番号と型 | 用途 |
|---|---|---|
| Trace | packet=1 repeated message | 保存用wrapper。packet長は各length-delimited fieldから読む |
| TracePacket | timestamp=8 uint64、timestamp_clock_id=58 uint32 | packet時刻。ns/絶対と決め打ちせずclock定義へ従う |
| TracePacket | trusted_packet_sequence_id=10 uint32 | producer+writer sequence。0はinvalid |
| TracePacket | sequence_flags=13 uint32 | 値1=`SEQ_INCREMENTAL_STATE_CLEARED`、値2=`SEQ_NEEDS_INCREMENTAL_STATE`のbitmask |
| TracePacket | previous_packet_dropped=42 uint32、incremental_state_cleared=41 bool | loss/incremental invalidation。41は旧clear flag |
| TracePacket | trace_packet_defaults=59 message、interned_data=12 message | 同sequenceの既定値とinterning state |
| TracePacket | clock_snapshot=6、track_event=11、track_descriptor=60 | 時刻定義、イベント、track定義（各message） |
| TracePacket | trusted_pid=79 int32、machine_id=98 uint32 | track/sequenceの意味を識別する補助。sequence IDをthread IDとみなさない |
| TracePacket | compressed_packets=50 bytes、zstd_compressed_packets=133 bytes | 観測時は展開経路を別途実装・検証するか未対応として停止。byte payloadを通常packetとして直接読まない |
| TracePacketDefaults | timestamp_clock_id=58 uint32、track_event_defaults=11 message | timestamp clockとTrackEventの既定値 |
| ClockSnapshot | clocks=1 repeated message、primary_trace_clock=2 enum | 同時対応clock組とtrace clock情報 |
| ClockSnapshot.Clock | clock_id=1 uint32、timestamp=2 uint64、is_incremental=3 bool、unit_multiplier_ns=4 uint64 | clock referenceとpacket値の解釈 |
| TrackDescriptor | uuid=1 uint64、parent_uuid=5 uint64、thread=4、process=3、counter=8 message | event trackとCPU counter trackの関連付け |
| TrackEvent | type=9 enum、track_uuid=11 uint64 | BEGIN=1、END=2、INSTANT=3、COUNTER=4。省略trackはdefaults、さらに省略時0 |
| TrackEvent | name_iid=10 uint64 / name=23 string | event名oneof。name IIDはsequence/generation内で解決 |
| TrackEvent | category_iids=3 repeated uint64、categories=22 repeated string | interned / literal category |
| TrackEvent | extra_counter_track_uuids=31 repeated uint64、extra_counter_values=12 repeated int64 | 整数counterのUUIDと値をindexで対応 |
| TrackEvent | extra_double_counter_track_uuids=45 repeated uint64、extra_double_counter_values=46 repeated double | 浮動小数counterの別のUUID/値list |
| TrackEvent | counter_value=30 int64 / double_counter_value=44 double | COUNTER eventのoneof値 |
| TrackEvent | debug_annotations=4 repeated message、legacy_event=6 message | console message等と旧phase情報 |
| TrackEventDefaults | track_uuid=11、extra_counter_track_uuids=31、extra_double_counter_track_uuids=45 | trackとcounter UUID listの既定値 |
| CounterDescriptor | type=1 enum、unit=3 enum、unit_multiplier=4 int64、is_incremental=5 bool | THREAD_TIME_NS type=1、TIME_NS unit=1。unit_multiplierは正値の場合のみ適用する実装 |

repeated数値はschemaに `[packed=true]` がなく、このpinのprotozero generated accessorはpacked/unpackedを自動で相互受理しない。限定decoderは観測したwire形式を保存し、packedを見たら明示対応・検証するかunsupportedとして報告する。packed payload全体を1個のvarint値として読んではならない。

## wall clockの復元

状態のkeyには少なくともpacket sequenceを含める。clock ID 64–127はsequence-scopedの範囲で、64はSDKのincremental timestamp、65はcustom unitのabsolute timestampに使われる。数値64だけを全trace共通clockとして累積してはいけない。builtin CLOCK_MONOTONICなどのclockと、snapshotの同時対応組を区別する。

通常packetは非0の明示 `timestamp_clock_id`、同sequenceの非0のdefaults、最後にformat/trace defaultの順でclock IDを選ぶ。Chromiumの標準設定がMONOTONICでも、省略値を無条件にMONOTONICへ置き換えない。

ClockSnapshotの `Clock.timestamp` はincremental clockでも **絶対reference** であり、通常packetのdeltaではない。snapshotでclock単位（省略時ns、multiplier=1）と `last_ns=reference_timestamp×unit_multiplier_ns` を登録する。通常packetの該当clockがincrementalなら、`last_ns += packet.timestamp×unit_multiplier_ns` を一度だけ行う。非incrementalは `packet.timestamp×unit_multiplier_ns`。同clockのunit/incremental属性変更など固定parserがrejectする条件にも従い、referenceへ二重にdeltaを加算しない。

特に固定 `proto_trace_reader.cc` は同packetのclear/drop、defaults、interned dataを扱い、ClockSnapshotを処理したらreturnする。**snapshot packet自体のTracePacket.timestampを、別の通常イベントdeltaとして再加算しない。**

clock accumulatorはTrackEventだけでなく、同sequence・同clockを参照する通常TracePacket.timestamp全件についてpacket順で進める。clock stateはClockSynchronizerの別層にあり、sequenceのclearだけを理由に0へ戻さない。snapshotを新たなreferenceとして扱う。CPU counter/resetとclock referenceのresetを同じ辞書1個で処理しない。

最初の段階では出力に「source clock ID・sequence・raw timestamp・clock unit・復元ns」を併記する。複数clockから共通MONOTONIC/trace clockへ変換するにはsnapshot対応が必要で、異なるdomainをoffsetなしで引かない。対応がなければtimestampを未解決のまま残す。unsigned uint64 deltaと、旧TrackEventのsigned int64 deltaは別処理である。

## thread CPU counterの復元

1. TrackDescriptorからcounter UUID、parent thread、counter名/type、unit multiplier、incremental設定を読む。eventのthreadとcounter parentのthreadを照合する。`trusted_pid` やsequence IDだけでtidを決めない。
2. 整数/浮動小数counterごとに、eventに明示されたUUID listがあればそのlistを用い、なければ同sequenceのTrackEventDefaultsを使う。明示listとdefault listを連結しない。valuesよりUUIDが多いことは許されるが、逆は不正として扱う。
3. `scaled=value×unit_multiplier`（正のmultiplierがある場合）を得る。incremental counterは固定実装と同じsequence/UUID状態で累積、非incrementalはその値をabsoluteとして扱う。例: 現SDKがCPU差分をus単位の整数で送りcounter unit multiplier=1000なら、復元値の単位はnsになる。
4. current eventに対応した復元counter値と、その値を得たraw fieldを両方保存する。counterの省略を新しい0 snapshotで補わない。producerがsubsampling時に0差分を送る場合もあるので、0差分の存在だけでCPUを新規採取したと断言しない。
5. CPUの2marker差、B/E差は復元後のCPU ns同士から取る。対応するwall nsとの差も元単位を保って計算し、`CPU>wall` をclampしない。exporterに合わせたus整数化は別columnで行う。

固定importerはresolved counter名 `thread_time` をslice用thread timestampへコピーし、double→int64変換する。CPU counter type enumだけを見てJSONと同じassociationになると決めない。CounterDescriptorによるname生成、thread parent、UUIDとnameの整合を確認する。数値がdouble内部表現へ入る既存processorと、integer raw値を保持する限定decoderの結果は並べて比較できる。

incremental counterはpacket loss、clear、sequenceの所属と関連する。clearではcounter custom stateとdefaults/internedをfreshにして有効化する。lossの任意非0 bitmaskではcounter custom stateを破棄・無効化するが、defaults/internedは物理的に保持される。両方が同packetにあればclearが優先し、その後に同packetのdefaults/internedを取り込む。defaults更新だけではcounter現在値は消えない。初期stateは無効で、無効時にNEEDS_INCREMENTAL_STATEのある通常payloadをskipするが、無効時の全packetを一律skipしない。first_packet_on_sequenceだけでは有効化しない。必要stateがなければCPUを未解決とし、詳細はcounter詳細レビュー/固定parserに従う。

## marker名・sliceの対応

`InternedData.event_categories=1`、`event_names=2`、`debug_annotation_names=3` はmessageで、それぞれのIID/nameは通常1/2。`debug_annotation_string_values=29` もある。interningは同packetのeventより前に取り込み、sequence/generation別に保持する。別sequenceの同じIIDを共有しない。

PerformanceMarkはevent名でmarkerを拾える。console TimeStampはevent名が `TimeStamp` で、marker名はdebug annotation内の `data.message` を解決する。`DebugAnnotation` はname_iid=1/name=10、uint=3/int=4/double=5/string=6、dict_entries=11、array_values=12、string_value_iid=17。nested dictionaryとinterned annotation名を無視すると同じmarkerを対応付けられない。

通常のTrackEventにはcomplete X型がなく、BEGIN/ENDからsliceになる。raw decoderはまずpacketのBEGIN/ENDをそのまま保持し、同trackのstackとpacket順を用いて対応させる。wall順へのsortをcounter累積より先にしてはいけない。JSONのXと直接1packet同士で対応すると誤る。旧legacy phase Xの場合だけ、LegacyEvent phase=2、duration_us=3、thread_duration_us=4を読む。旧thread CPUはTrackEvent thread_time_delta_us=2 / thread_time_absolute_us=17で、ThreadDescriptorのreferenceに従う別経路である。

## 既存tool優先と限定decoderの範囲

rootが公式releaseからbinaryを取得し、`trace_processor_shell` **v58.2-add693d8b** のversion/convert json/query利用を確認した。初期保存名traceconv-binから、正式basename **[trace_processor_shell](/workspace/bingo-stage16-20261015/trace_processor_shell)** へ同一内容のcopyを作成した。basenameが動作モード選択に影響するため、collectorとSQLは正式名を用いる。binaryは固定sourceの `tools/traceconv` に内蔵されたlinux-amd64 manifestのSHA256 **`58042408e6cc861fb1a731c26bb082dc222285561eaa4e12a48a8b2b90dca7b9`**、14,897,560 bytesに一致する。この担当も初期保存binaryでhash/サイズ一致を再確認した。取得経路は公式GitHub release `https://github.com/google/perfetto/releases/download/v58.2/linux-amd64.zip`、記録は [tool-download.json](/workspace/bingo-stage16-20261015/tool-download.json)。binaryのversion commit `add693d8b` はproducerにpinされたsource commit `5dbeaad4…` と区別する。

したがって同じ保存protoからのJSON変換・SQLによるslice/counter/stats照合は、この正規processorを第一選択とする。実行command・出力hashとraw proto hashを残す。ここでいう正規toolの使用は、同一protoに対する変換であり、ブラウザーの再計測は不要である。

限定decoderは完全なtrace_processor互換を目標にせず、正規processorの**原CPU counter確認用**へ限定する。[raw_counter_check.py](/workspace/bingo-stage16-20261015/raw_counter_check.py) はSHA256 **`91762a94d1e1e05305c2a11fbb237dd4b42bffd3ebb5162f48c4cec42b038c23`** で凍結した。packet index/file offset、sequence/reset、flags/loss、raw clock/timestamp、raw counter差分、descriptor/default選択、倍率・累積CPU ns、name、track/threadのledgerを出す。wall clockの共通化・sliceの対応は正規processorへ委ねる。将来toolが使えない場合も、wall変換やBEGIN/END組立を足すには別途上記の全clock規則とvalidationが必要である。

syntax・独立静的レビュー・[合成回帰30件](/workspace/bingo-stage16-20261015/RAW_COUNTER_SYNTHETIC_CHECKS_v2.json)と、別担当が作成した[公式processorとの合成照合48件](/workspace/bingo-stage16-20261015/decoder-validation/verification_final.json)は成功した。後者は8端点・11counter値、非markerの差分、2sequence、reset、倍率1000、BEGIN/END/INSTANTを含む。有限の検証であり全形式互換の証明ではない。

初期受入条件は、必要descriptor/default/clock/internerが全て解決し、unknown wire form・overflow・truncated varint/length・unsupported compression・lossに依存するstate欠損を明示すること。未解決を0や前値で埋めず、解析可否を出力する。全traceのunknown fieldを無差別に失敗扱いにはせず、skipしたfield番号/wire型/件数を記録し、clock/counter/対象markerの意味に関わる未対応機能は成功判定から外す。

この方法で検証できるのは、保存protoのCPU counter値・clock定義・JSON変換前後の対応である。**raw protobufの値まで同じ超過を示しても、Linux CPU clock自体の物理的正確さが証明されたことにはならない。** 非同時snapshotと取得順序の制約、別途同時記録する独立CPU counterのclock domain/分解能/観測包絡は引き続き区別する。

## 保存済み実データへの適用

収集完了後のrun0–4を凍結decoderで一度ずつ読み、[実行記録](/workspace/bingo-stage16-20261015/raw-counter-execution.json)と全ledgerを保存した。[独立照合結果](/workspace/bingo-stage16-20261015/raw-counter-official-check.json)では、対象rendererの167,205 thread_time counter samplesが公式SQLと(UUID,value)多重集合で一致、全260markerのCPU nsは同protoJSONのttsへ一致した。1ms超過26sliceも、同名・同CPU begin/endを持つraw packet対へ全件一意に対応した。

全5ledgerに `legacy_nested_annotation_unsupported` 診断があり、decoderの全形式対応PASSではない。対象markerのCPU欠落は0で、counter値/端点の上記一致と未対応annotationを分けて報告する。補助decoderがwall clock変換を検算したとはしない。詳細は [RAW_COUNTER_POST_REVIEW.md](/workspace/bingo-stage16-20261015/RAW_COUNTER_POST_REVIEW.md)。

その後、CPUの毎回切捨てとwallの余り持越しの非対称性を明確化し、26件全てのclear跨ぎ・floor損失上限との整合を確認した。rawのCPU値一致だけではこのproducer符号化の効果を除外できない。[CPU_QUANTIZATION_REVIEW.md](/workspace/bingo-stage16-20261015/CPU_QUANTIZATION_REVIEW.md) を参照。
