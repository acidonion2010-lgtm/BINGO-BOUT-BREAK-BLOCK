#!/usr/bin/env python3
"""All saved unit1 formal-capture marker windows, including warmup.

The saved raw CPU and official SQL nanosecond wall endpoints are compared with
the same-proto official JSON integer-microsecond endpoints. No new measurement.
"""
from collections import Counter, defaultdict
import json
from boundary_census import OLD, ROOT, RUNS, DECODER_SHA, integer, read_csv, sha, sign, clock_kind


def main():
    report_path = OLD / 'report.json'
    report = json.loads(report_path.read_bytes())
    result = {'scriptSha256': sha(ROOT / 'marker_ns_census.py'),
              'helperScriptSha256': sha(ROOT / 'boundary_census.py'),
              'report': {'path': str(report_path), 'sha256': sha(report_path)},
              'scope': 'All 192 unit1 formal-capture marker windows in runs3/4/7/8; 144 formal, 48 warmup; no new measurements',
              'limits': ['Raw CPU and SQL wall values are saved ns counter endpoints, not simultaneous physical CPU truth.',
                         'Overlapping windows are not independent observations.',
                         'Every missing or ambiguous marker/counter match is retained and excluded from numerical comparison without selecting a candidate.'],
              'visits': []}
    totals = Counter()
    groups = defaultdict(Counter)
    for visit in report['visits']:
        run = visit['run']
        if run not in RUNS:
            continue
        assert visit['completed'] and visit['unit'] == 1 and not visit['preflight']
        ledger_path = OLD / f'raw-counter-run{run}.json'
        counter_path = OLD / f'official-sql/run{run}-counters.csv'
        ledger = json.loads(ledger_path.read_bytes())
        assert ledger['script_sha256'] == DECODER_SHA
        pid, tid = visit['conversion']['rendererPidTid']
        marker_index = {m['name']: m for m in visit['conversion']['markers']}
        raw_markers = defaultdict(list)
        for row in ledger['ledger']:
            assoc = row['event_association_at_end']
            if assoc.get('status') != 'thread' or (assoc.get('pid'), assoc.get('tid')) != (pid, tid):
                continue
            name = row.get('data_message') if row['name'] == 'TimeStamp' else row['name']
            if name in marker_index:
                raw_markers[(name, row['name'] == 'TimeStamp')].append(row)
        wall_map = defaultdict(list)
        for row in read_csv(counter_path):
            if row['name'] == 'thread_time':
                wall_map[(str(integer(row['uuid']) & ((1 << 64) - 1)), integer(row['value']))].append(integer(row['ts']))

        def endpoint(name, kind):
            candidates = raw_markers[(name, kind == 'stamp')]
            output = {'name': name, 'kind': kind, 'rawCandidates': len(candidates),
                      'json': marker_index.get(name, {}).get(kind)}
            if len(candidates) == 1:
                raw = candidates[0]
                cpu = integer(raw['cpu_ns'])
                walls = wall_map[(raw['cpu_counter_uuid'], cpu)] if cpu is not None else []
                output.update({'packetIndex': raw['packet_index'], 'cpuNs': cpu, 'wallCandidatesNs': walls,
                               'wallNs': walls[0] if len(walls) == 1 else None,
                               'clockKind': clock_kind(raw), 'packetClockIdRaw': raw.get('packet_clock_id_raw'),
                               'defaultClockIdRaw': raw.get('default_clock_id_raw'),
                               'sequenceId': raw['sequence_id'], 'epoch': raw['sequence_epoch']})
                event = output['json']
                output['cpuFloorToJsonUsExact'] = event is not None and cpu is not None and cpu // 1000 == event.get('tts')
                output['wallFloorToJsonUsExact'] = event is not None and output['wallNs'] is not None and output['wallNs'] // 1000 == event.get('ts')
            return output

        windows = []
        counts = Counter()
        for sample in visit['samples']:
            labels = {m['label']: m['name'] for m in sample['markers']}
            for kind in ('mark', 'stamp'):
                start = endpoint(labels['capture'], kind)
                for label in ('handler-end', 'first-raf', 'second-raf'):
                    end = endpoint(labels[label], kind)
                    window = {'branch': sample['branch'], 'trial': sample['trial'], 'warmup': sample['warmup'],
                              'kind': kind, 'to': label, 'start': start, 'end': end}
                    group = groups[('warmup' if sample['warmup'] else 'formal', sample['branch'], kind)]
                    for counter in (counts, totals, group):
                        counter['allWindows'] += 1
                    complete = all(p.get('rawCandidates') == 1 and p.get('cpuNs') is not None and p.get('wallNs') is not None
                                   and p.get('json') is not None and 'tts' in p['json'] and 'ts' in p['json'] for p in (start, end))
                    window['completeUniqueSavedEndpoints'] = complete
                    if complete:
                        cpu = end['cpuNs'] - start['cpuNs']
                        wall = end['wallNs'] - start['wallNs']
                        jcpu = (end['json']['tts'] - start['json']['tts']) * 1000
                        jwall = (end['json']['ts'] - start['json']['ts']) * 1000
                        excess = cpu - wall
                        jexcess = jcpu - jwall
                        window.update({'savedNs': {'cpuNs': cpu, 'wallNs': wall, 'excessNs': excess, 'sign': sign(excess)},
                                       'jsonUsMultipliedBy1000': {'cpuNs': jcpu, 'wallNs': jwall, 'excessNs': jexcess, 'sign': sign(jexcess)},
                                       'jsonExcessMinusSavedNsExcess': jexcess - excess,
                                       'savedMinusJsonCpuNs': cpu - jcpu, 'savedMinusJsonWallNs': wall - jwall})
                        for counter in (counts, totals, group):
                            counter['completeUniqueSavedEndpoints'] += 1
                            counter[f'savedNs.{sign(excess)}'] += 1
                            counter[f'jsonUs.{sign(jexcess)}'] += 1
                            counter[f'signPair.{sign(excess)}->{sign(jexcess)}'] += 1
                            counter['bothCpuFloorsToJsonExact'] += start['cpuFloorToJsonUsExact'] and end['cpuFloorToJsonUsExact']
                            counter['bothWallFloorsToJsonExact'] += start['wallFloorToJsonUsExact'] and end['wallFloorToJsonUsExact']
                    else:
                        for counter in (counts, totals, group):
                            counter['missingOrAmbiguousEndpoints'] += 1
                    windows.append(window)
        result['visits'].append({'run': run, 'inputs': {'rawLedger': {'path': str(ledger_path), 'sha256': sha(ledger_path)},
                                                       'officialCounters': {'path': str(counter_path), 'sha256': sha(counter_path)}},
                                 'counts': dict(counts), 'windows': windows})
    result['counts'] = dict(totals)
    result['groups'] = [{'warmup': g[0] == 'warmup', 'branch': g[1], 'kind': g[2], 'counts': dict(c)} for g, c in sorted(groups.items())]
    assert totals['allWindows'] == 192
    with (ROOT / 'marker-ns-census.json').open('x') as file:
        json.dump(result, file, indent=2)
        file.write('\n')
    print(json.dumps({'counts': result['counts'], 'groups': result['groups']}, indent=2), flush=True)


if __name__ == '__main__':
    main()
