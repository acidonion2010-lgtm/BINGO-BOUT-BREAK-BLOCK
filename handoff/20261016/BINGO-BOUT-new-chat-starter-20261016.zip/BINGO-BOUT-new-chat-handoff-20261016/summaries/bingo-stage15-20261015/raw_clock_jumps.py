#!/usr/bin/env python3
"""Supplementary pure-data clock boundaries; no new benchmark or trace capture."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

from raw_clock_review import finite, record, require, bins, overlaps


def main():
    report_path, output_path = map(Path, sys.argv[1:])
    require(not output_path.exists(), 'Refuse to overwrite output')
    source = report_path.read_bytes()
    report = json.loads(source)
    result = {'sourceReportSha256': hashlib.sha256(source).hexdigest(),
              'scriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'scope': 'All sixteen existing main-thread traces. Full-X ms excesses are nested observations, not independent jumps. X ends below are inferred as ts+dur, tts+tdur and identified explicitly.',
              'traces': []}
    for visit in report['visits']:
        path = Path(visit['trace']['path'])
        path = path if path.is_absolute() else report_path.parent / path
        raw = path.read_bytes(); require(hashlib.sha256(raw).hexdigest() == visit['trace']['sha256'], 'Hash mismatch')
        events = json.loads(raw)['traceEvents']
        lookup = {e['name']: e for e in events if e.get('name', '').startswith('bingo.stage14.')}
        marker = lookup[visit['samples'][0]['markers'][0]['name']]
        thread = (marker['pid'], marker['tid'])
        main_events = [(i, e) for i, e in enumerate(events) if (e.get('pid'), e.get('tid')) == thread]
        windows = []
        for sample in visit['samples']:
            m = {entry['label']: lookup[entry['name']] for entry in sample['markers']}
            windows.append({'id': f"run{visit['run']}.{visit['version']}.{sample['branch']}.{sample['trial']}",
                            'startUs': m['capture']['ts'], 'endUs': m['second-raf']['ts']})
        full_ms = []
        snapshots = []
        starts = []
        for index, e in main_events:
            if e.get('ph') in ('I', 'X') and finite(e.get('ts')) and finite(e.get('tts')):
                snapshot = {'wallUs': e['ts'], 'cpuUs': e['tts'], 'kind': 'recordedStart', 'event': record(e, index)}
                snapshots.append(snapshot); starts.append(snapshot)
                if e['ph'] == 'X' and finite(e.get('dur')) and finite(e.get('tdur')):
                    snapshots.append({'wallUs': e['ts'] + e['dur'], 'cpuUs': e['tts'] + e['tdur'],
                                      'kind': 'inferredCompleteXEnd', 'event': record(e, index)})
                    excess = e['tdur'] - e['dur']
                    if excess > 1000:
                        full_ms.append({'event': record(e, index), 'excessUs': excess,
                                        'overlappingResponseSamples': overlaps(e, windows)})
        starts.sort(key=lambda e: (e['wallUs'], e['event']['rawEventIndex']))
        jumps = []
        for i, (a, b) in enumerate(zip(starts, starts[1:])):
            wall, cpu = b['wallUs'] - a['wallUs'], b['cpuUs'] - a['cpuUs']
            if cpu - wall > 1000:
                jumps.append({'excessUs': cpu - wall, 'wallDeltaUs': wall, 'ttsDeltaUs': cpu,
                              'localSequence': starts[max(0, i-3):i+6]})
        snapshots.sort(key=lambda e: (e['wallUs'], e['event']['rawEventIndex'], e['kind']))
        backwards = []
        for a, b in zip(snapshots, snapshots[1:]):
            if b['wallUs'] > a['wallUs'] and b['cpuUs'] < a['cpuUs']:
                backwards.append({'wallDeltaUs': b['wallUs'] - a['wallUs'],
                                  'cpuDropUs': a['cpuUs'] - b['cpuUs'], 'before': a, 'after': b})
        outside = [e for e in full_ms if not e['overlappingResponseSamples']]
        result['traces'].append({
            'run': visit['run'], 'version': visit['version'], 'traceSha256': visit['trace']['sha256'],
            'mainThread': {'pid': thread[0], 'tid': thread[1]},
            'fullXExcessOver1msCount': len(full_ms),
            'fullXExcessOver1msNames': dict(Counter(e['event']['name'] for e in full_ms)),
            'fullXExcessOver1msEntirelyOutsideResponses': len(outside),
            'fullXExcessOver1msWithinResponses': len(full_ms) - len(outside),
            'fullXExcessOver1msMinUs': min((e['excessUs'] for e in full_ms), default=None),
            'fullXExcessOver1msMaxUs': max((e['excessUs'] for e in full_ms), default=None),
            'largestFullXExcessOver1ms': sorted(full_ms, key=lambda e: e['excessUs'], reverse=True)[:3],
            'largestOutsideResponsesOver1ms': sorted(outside, key=lambda e: e['excessUs'], reverse=True)[:2],
            'ixStartOver1msAdjacentJumpCount': len(jumps),
            'largestIxStartLocalSequences': sorted(jumps, key=lambda e: e['excessUs'], reverse=True)[:2],
            'inferredXEndsAndRecordedStarts': {
                'snapshots': len(snapshots),
                'ttsBackwardAcrossDistinctWallTimestamps': len(backwards),
                'cpuDropDistribution': bins([e['cpuDropUs'] for e in backwards]),
                'largestBackwardExamples': sorted(backwards, key=lambda e: e['cpuDropUs'], reverse=True)[:2]}})
        print(json.dumps({'run': visit['run'], 'version': visit['version'], 'fullXOver1ms': len(full_ms),
                          'outside': len(outside), 'computedEndBacksteps': len(backwards)}), flush=True)
    traces = result['traces']; names = Counter()
    for trace in traces: names.update(trace['fullXExcessOver1msNames'])
    result['summary'] = {
        'traces': len(traces), 'tracesWithFullXExcessOver1ms': sum(t['fullXExcessOver1msCount'] > 0 for t in traces),
        'fullXExcessOver1ms': sum(t['fullXExcessOver1msCount'] for t in traces),
        'fullXExcessOver1msEntirelyOutsideResponses': sum(t['fullXExcessOver1msEntirelyOutsideResponses'] for t in traces),
        'fullXExcessOver1msNames': dict(names.most_common()),
        'ixStartOver1msAdjacentJumps': sum(t['ixStartOver1msAdjacentJumpCount'] for t in traces),
        'inferredEndBackstepDistribution': {key: sum(t['inferredXEndsAndRecordedStarts']['cpuDropDistribution'][key] for t in traces)
                                            for key in traces[0]['inferredXEndsAndRecordedStarts']['cpuDropDistribution']}}
    with output_path.open('x') as file: file.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result['summary']), flush=True)


if __name__ == '__main__': main()
