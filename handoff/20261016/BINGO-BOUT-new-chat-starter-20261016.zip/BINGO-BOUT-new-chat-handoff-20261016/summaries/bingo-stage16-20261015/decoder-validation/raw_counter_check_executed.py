#!/usr/bin/env python3
"""Bounded, independent raw-counter supplement; not a Trace Processor replacement.

CLI: raw_counter_check.py input.proto output.json (output must not exist).
No decompression, timestamp conversion, JSON export, or slice matching.
"""
import hashlib
import json
import math
from pathlib import Path
import struct
import sys
from collections import Counter

REV = "5dbeaad4ceb91470a835426b52e0cb43a3e5ef10"
MAX_INPUT = 512 * 1024 * 1024
MAX_MESSAGE = 64 * 1024 * 1024
MAX_PACKETS = 2_000_000
MAX_FIELDS = 20_000_000
MAX_LEDGER = 2_000_000
MAX_DIAGNOSTICS = 10_000


class DecodeError(Exception):
    pass


def varint(buf, pos):
    value = 0
    for n in range(10):
        if pos >= len(buf):
            raise DecodeError("truncated varint")
        octet = buf[pos]
        pos += 1
        if n == 9 and octet > 1:
            raise DecodeError("uint64 varint overflow")
        value |= (octet & 127) << (7 * n)
        if octet < 128:
            return value, pos
    raise DecodeError("unterminated varint")


def signed(value, bits=64):
    return value - (1 << bits) if value & (1 << (bits - 1)) else value


class Checker:
    def __init__(self):
        self.result = {
            "schema": "stage16.raw-counter-ledger.v1", "perfetto_revision": REV,
            "scope": "Independent limited raw counter ledger, not official importer parity. No wall-clock conversion or slice semantics.",
            "status": "running", "packets_seen": 0, "events_seen": 0,
            "ledger": [], "descriptors": {}, "transitions": [],
            "diagnostics": [], "diagnostic_counts": {}, "unhandled_fields": {},
        }
        self.sequences = {}
        self.descriptors = {}
        self.counts = Counter()
        self.unhandled = Counter()
        self.field_count = 0
        self.packet = None
        self.packet_offset = None
        self.conflicting_uuids = set()

    def diag(self, kind, **details):
        self.counts[kind] += 1
        if len(self.result["diagnostics"]) < MAX_DIAGNOSTICS:
            self.result["diagnostics"].append({"kind": kind, "packet_index": self.packet, **details})

    def fields(self, buf, container=False):
        if len(buf) > (MAX_INPUT if container else MAX_MESSAGE):
            raise DecodeError("message size limit exceeded")
        pos = 0
        while pos < len(buf):
            offset = pos
            tag, pos = varint(buf, pos)
            number, wire = tag >> 3, tag & 7
            if not 0 < number < (1 << 29):
                raise DecodeError("invalid field number")
            self.field_count += 1
            if self.field_count > MAX_FIELDS:
                raise DecodeError("field count limit exceeded")
            if wire == 0:
                value, pos = varint(buf, pos)
            elif wire in (1, 5):
                end = pos + (8 if wire == 1 else 4)
                if end > len(buf):
                    raise DecodeError("truncated fixed-width field")
                value, pos = buf[pos:end], end
            elif wire == 2:
                size, pos = varint(buf, pos)
                end = pos + size
                if size > MAX_MESSAGE or end > len(buf):
                    raise DecodeError("invalid length-delimited field")
                value, pos = buf[pos:end], end
            else:
                raise DecodeError("unsupported protobuf wire type %s" % wire)
            yield number, wire, value, offset

    def message(self, buf, path, handled):
        fields = list(self.fields(buf))
        for number, wire, _, _ in fields:
            if number not in handled:
                self.unhandled[f"{path}.{number}/wire{wire}"] += 1
        return fields

    def last(self, fields, number, wire=0, default=None):
        found = [f for f in fields if f[0] == number]
        if not found:
            return default
        if len(found) > 1:
            self.diag("duplicate_singular_field_last_used", field=number, count=len(found))
        f = found[-1]
        if f[1] != wire:
            self.diag("unexpected_wire_type", field=number, expected=wire, observed=f[1])
            return default
        return f[2]

    def repeated(self, fields, number, wire=0):
        result, good = [], True
        for _, seen_wire, value, _ in (f for f in fields if f[0] == number):
            if seen_wire != wire:
                self.diag("packed_numeric_rejected" if seen_wire == 2 else "unexpected_repeated_wire_type",
                          field=number, expected=wire, observed=seen_wire,
                          payload_bytes=len(value) if isinstance(value, bytes) else None)
                good = False
            else:
                result.append(value)
        return result, good

    def text(self, data):
        if data is None:
            return None
        if len(data) > 16384:
            self.diag("text_length_limit", bytes=len(data))
            return None
        try:
            return data.decode("utf-8")
        except UnicodeDecodeError:
            self.diag("invalid_utf8", preview_hex=data[:32].hex())
            return None

    def state(self, seq):
        return self.sequences.setdefault(seq, {"valid": False, "epoch": 0, "defaults": {},
            "names": {}, "annotation_names": {}, "strings": {}, "sums": {}, "tainted": False})

    def defaults(self, data):
        f = self.message(data, "TracePacketDefaults", {11, 58})
        d = {"clock_id": self.last(f, 58)}
        nested = self.last(f, 11, 2)
        if nested is not None:
            t = self.message(nested, "TrackEventDefaults", {11, 31, 45})
            d["track_uuid"] = self.last(t, 11)
            for field in (31, 45):
                values, ok = self.repeated(t, field)
                d[str(field)] = values if ok else None
        return d

    def interned(self, data, state):
        f = self.message(data, "InternedData", {2, 3, 29})
        for field, target in ((2, "names"), (3, "annotation_names"), (29, "strings")):
            entries, _ = self.repeated(f, field, 2)
            for entry in entries:
                v = self.message(entry, "InternedString", {1, 2})
                iid, text = self.last(v, 1), self.text(self.last(v, 2, 2))
                if iid is None or text is None:
                    self.diag("invalid_interned_entry", field=field)
                elif iid in state[target] and state[target][iid] != text:
                    self.diag("conflicting_interned_entry", field=field, iid=iid)
                else:
                    state[target][iid] = text

    def descriptor(self, data):
        f = self.message(data, "TrackDescriptor", {1, 2, 3, 4, 5, 8, 10, 13})
        uuid = self.last(f, 1)
        if uuid is None:
            self.diag("descriptor_missing_uuid")
            return
        name_fields = [v for v in f if v[0] in (2, 10, 13)]
        name = self.text(name_fields[-1][2]) if name_fields and name_fields[-1][1] == 2 else None
        d = {"uuid": str(uuid), "parent_uuid": str(self.last(f, 5, default=0)), "name": name,
             "packet_index": self.packet, "thread": None, "process": None, "counter": None}
        for field, target in ((3, "process"), (4, "thread")):
            value = self.last(f, field, 2)
            if value is not None:
                t = self.message(value, target + "Descriptor", {1, 2, 5, 6})
                pid = self.last(t, 1)
                d[target] = {"pid": signed(pid & 0xffffffff, 32) if pid is not None else None}
                if target == "thread":
                    tid = self.last(t, 2)
                    d[target]["tid"] = signed(tid) if tid is not None else None
        value = self.last(f, 8, 2)
        if value is not None:
            c = self.message(value, "CounterDescriptor", {1, 2, 3, 4, 5, 6, 7})
            multiplier = self.last(c, 4, default=0)
            d["counter"] = {"type": self.last(c, 1, default=0), "unit": self.last(c, 3, default=0),
                "unit_multiplier": signed(multiplier), "is_incremental": bool(self.last(c, 5, default=0)),
                "unit_name": self.text(self.last(c, 6, 2))}
            if name is None:
                d["name"] = {1: "thread_time", 2: "thread_instruction_count"}.get(d["counter"]["type"])
        old = self.descriptors.get(uuid)
        if old is not None:
            comparable = lambda v: {k: value for k, value in v.items() if k not in ("packet_index", "repeat_packet_indices")}
            if comparable(old) != comparable(d):
                self.diag("descriptor_conflict_first_kept", uuid=str(uuid))
                self.conflicting_uuids.add(uuid)
            old.setdefault("repeat_packet_indices", []).append(self.packet)
        else:
            self.descriptors[uuid] = d

    def annotation(self, data, state, depth=0):
        if depth > 8:
            self.diag("annotation_depth_limit")
            return None, None
        f = self.message(data, "DebugAnnotation", {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 17})
        name = self.text(self.last(f, 10, 2))
        if name is None:
            name = state["annotation_names"].get(self.last(f, 1))
        children = [v for v in f if v[0] == 11]
        if children:
            value = {}
            for _, wire, child, _ in children:
                if wire != 2:
                    self.diag("invalid_annotation_dict_wire")
                    continue
                key, v = self.annotation(child, state, depth + 1)
                if key is not None:
                    value[key] = v
            return name, value
        raw = self.last(f, 6, 2)
        if raw is not None:
            return name, self.text(raw)
        iid = self.last(f, 17)
        if iid is not None:
            return name, state["strings"].get(iid)
        legacy = self.last(f, 9, 2)
        if legacy is not None:
            text = self.text(legacy)
            try:
                def invalid_constant(value):
                    raise ValueError("nonfinite JSON constant " + value)
                return name, json.loads(text, parse_constant=invalid_constant) if text is not None else None
            except (ValueError, RecursionError):
                self.diag("invalid_legacy_json_annotation")
        if any(v[0] == 8 for v in f):
            self.diag("legacy_nested_annotation_unsupported")
        return name, None

    def convert(self, uuid, raw, state, seq, kind):
        d = self.descriptors.get(uuid)
        entry = {"kind": kind, "counter_uuid": str(uuid), "raw_value": raw,
                 "descriptor_packet_index": d["packet_index"] if d else None}
        if d is None or d["counter"] is None or uuid in self.conflicting_uuids:
            entry["status"] = "conflicting_counter_descriptor" if uuid in self.conflicting_uuids else "unknown_or_non_counter_descriptor"
            self.diag(entry["status"], uuid=str(uuid))
            state["tainted"] = True
            return entry
        c = d["counter"]
        value = float(raw)
        if c["unit_multiplier"] > 0:
            value *= c["unit_multiplier"]
        if not math.isfinite(value):
            entry.update(status="nonfinite_counter_rejected", raw_value=repr(raw))
            self.diag(entry["status"], uuid=str(uuid))
            state["tainted"] = True
            return entry
        scaled = value
        if c["is_incremental"]:
            if not state["valid"]:
                self.diag("incremental_counter_without_valid_state", uuid=str(uuid))
                state["tainted"] = True
            value += state["sums"].get(uuid, 0.0)
            if not math.isfinite(value):
                entry["status"] = "nonfinite_sum_rejected"
                self.diag(entry["status"], uuid=str(uuid))
                state["tainted"] = True
                return entry
            state["sums"][uuid] = value
        entry.update(status="decoded", scaled_value=scaled, absolute_value=value,
            is_incremental=c["is_incremental"], unit_multiplier=c["unit_multiplier"],
            descriptor_name=d["name"], builtin_type=c["type"],
            sum_reliable=not state["tainted"], sequence_id=seq)
        return entry

    def event(self, data, state, seq, packet_fields):
        f = self.message(data, "TrackEvent", {1, 2, 4, 6, 9, 10, 11, 12, 16, 17, 23, 30, 31, 44, 45, 46})
        self.result["events_seen"] += 1
        names = [v for v in f if v[0] in (10, 23)]
        name = None
        name_iid = None
        if names:
            n = names[-1]
            if n[0] == 23 and n[1] == 2:
                name = self.text(n[2])
            elif n[0] == 10 and n[1] == 0:
                name_iid = n[2]
        legacy = self.last(f, 6, 2)
        phase = None
        if legacy is not None:
            lf = self.message(legacy, "LegacyEvent", {1, 2})
            phase = self.last(lf, 2)
            if name is None and name_iid is None:
                name_iid = self.last(lf, 1)
        if name is None and name_iid is not None:
            name = state["names"].get(name_iid)
            if name is None:
                self.diag("unknown_event_name_iid", iid=name_iid)
        row = {"packet_index": self.packet, "packet_trace_offset": self.packet_offset,
            "sequence_id": seq, "sequence_epoch": state["epoch"],
            "incremental_state_valid": state["valid"], "name": name, "name_iid": name_iid,
            "type": self.last(f, 9), "legacy_phase": phase,
            "event_track_uuid": str(self.last(f, 11, default=state["defaults"].get("track_uuid") or 0)),
            "packet_timestamp_raw": self.last(packet_fields, 8),
            "packet_clock_id_raw": self.last(packet_fields, 58),
            "default_clock_id_raw": state["defaults"].get("clock_id"),
            "event_timestamp_delta_us_raw": self.last(f, 1),
            "event_timestamp_absolute_us_raw": self.last(f, 16),
            "cpu_ns": None, "counters": []}
        args = {}
        for annotation in [v for v in f if v[0] == 4 and v[1] == 2]:
            key, value = self.annotation(annotation[2], state)
            if key is not None:
                args[key] = value
        if isinstance(args.get("data"), dict):
            message = args["data"].get("message")
            row["data_message"] = message if isinstance(message, str) else None
            if message is not None and not isinstance(message, str):
                self.diag("nonstring_data_message_unparsed")
        row["target_marker"] = any(isinstance(v, str) and
            (v.startswith("bingo.stage16.") or v in ("preflight.begin", "preflight.end"))
            for v in (name, row.get("data_message")))
        if any(v[0] in (2, 17) for v in f):
            row["legacy_thread_time_fields_raw"] = {str(n): signed(self.last(f, n)) for n in (2, 17) if self.last(f, n) is not None}
        if seq is None or seq == 0:
            self.diag("event_sequence_missing_or_zero")
            row["status"] = "unsupported_sequence"
        else:
            if row["type"] == 4:
                scalar = [v for v in f if v[0] in (30, 44)]
                uuid = int(row["event_track_uuid"]) if row["event_track_uuid"] != "None" else 0
                if scalar and ((scalar[-1][0] == 30 and scalar[-1][1] == 0) or (scalar[-1][0] == 44 and scalar[-1][1] == 1)):
                    sf = scalar[-1]
                    raw = signed(sf[2]) if sf[0] == 30 else struct.unpack("<d", sf[2])[0]
                    row["counters"].append(self.convert(uuid, raw, state, seq, "scalar"))
                else:
                    self.diag("missing_or_invalid_scalar_counter")
            extras_count = 0
            for vf, uf, wire, kind in ((12, 31, 0, "integer_extra"), (46, 45, 1, "double_extra")):
                values, ok = self.repeated(f, vf, wire)
                explicit = any(v[0] == uf for v in f)
                uuids, uok = self.repeated(f, uf) if explicit else (state["defaults"].get(str(uf), []), True)
                if uuids is None:
                    uok = False
                    uuids = []
                if not ok or not uok:
                    state["tainted"] = True
                if values and len(uuids) < len(values):
                    self.diag("extra_counter_uuid_shortage", values=len(values), uuids=len(uuids), field=vf)
                    state["tainted"] = True
                for i, v in enumerate(values):
                    extras_count += 1
                    if extras_count > 8 or i >= len(uuids) or not uuids[i] or not ok or not uok:
                        self.diag("extra_counter_unresolved", field=vf, index=i)
                        state["tainted"] = True
                        continue
                    raw = signed(v) if wire == 0 else struct.unpack("<d", v)[0]
                    entry = self.convert(uuids[i], raw, state, seq, kind)
                    entry.update(raw_index=i, uuid_source="event" if explicit else "defaults")
                    row["counters"].append(entry)
            cpu = [v for v in row["counters"] if v.get("kind") != "scalar" and v.get("descriptor_name") == "thread_time"]
            if cpu:
                candidate = cpu[-1]
                value = candidate.get("absolute_value")
                if value is not None and -(1 << 63) <= value < (1 << 63) and not state["tainted"]:
                    row["cpu_ns"] = int(value)
                    row["cpu_counter_uuid"] = candidate["counter_uuid"]
                else:
                    self.diag("cpu_counter_value_unusable")
            row["status"] = "tainted_counter_state" if state["tainted"] else "limited_scope_decoded"
        if row["target_marker"] or row["counters"] or name == "TimeStamp" or "legacy_thread_time_fields_raw" in row or any(v[0] in (12, 46) for v in f):
            if len(self.result["ledger"]) >= MAX_LEDGER:
                raise DecodeError("ledger limit exceeded")
            self.result["ledger"].append(row)

    def packet_message(self, data):
        f = self.message(data, "TracePacket", {8, 10, 11, 12, 13, 41, 42, 50, 58, 59, 60, 87, 133})
        if any(v[0] in (50, 133) for v in f):
            self.diag("compressed_packets_unsupported")
            raise DecodeError("compressed packet payload unsupported; stopped before dependent state")
        seq = self.last(f, 10)
        state = self.state(seq)
        flags = self.last(f, 13, default=0)
        clear = bool(self.last(f, 41, default=0) or flags & 1)
        loss = self.last(f, 42, default=0)
        if clear or loss:
            if seq is None or seq == 0:
                self.diag("reset_sequence_missing_or_zero")
            else:
                state["epoch"] += 1
                state["sums"] = {}
                state["tainted"] = False
                state["valid"] = clear
                if clear:
                    state.update(defaults={}, names={}, annotation_names={}, strings={})
                self.result["transitions"].append({"packet_index": self.packet, "sequence_id": seq,
                    "epoch": state["epoch"], "action": "clear" if clear else "loss", "loss_mask": loss})
        defaults = self.last(f, 59, 2)
        if defaults is not None:
            state["defaults"] = self.defaults(defaults)
        interned = self.last(f, 12, 2)
        if interned is not None:
            if state["valid"]:
                self.interned(interned, state)
            else:
                self.diag("interned_data_skipped_invalid_state")
        if flags & 2 and (not state["valid"] or seq is None or seq == 0):
            self.diag("payload_skipped_needs_invalid_state", sequence_id=seq)
            return
        descriptor = self.last(f, 60, 2)
        if descriptor is not None:
            self.descriptor(descriptor)
        event = self.last(f, 11, 2)
        if event is not None:
            self.event(event, state, seq, f)

    def resolve(self, uuid, seen=()):
        if uuid in seen or len(seen) > 16:
            return {"status": "cycle_or_depth_limit"}
        d = self.descriptors.get(uuid)
        if d is None:
            return {"status": "unknown_descriptor", "uuid": str(uuid)}
        if d["thread"] is not None:
            return {"status": "thread", "track_uuid": str(uuid), **d["thread"]}
        if d["process"] is not None:
            return {"status": "process", "track_uuid": str(uuid), **d["process"]}
        parent = int(d["parent_uuid"])
        if parent:
            return self.resolve(parent, seen + (uuid,))
        return {"status": "global"}

    def finish(self):
        for uuid, d in self.descriptors.items():
            self.result["descriptors"][str(uuid)] = {**d, "conflicting": uuid in self.conflicting_uuids,
                "association_at_end": self.resolve(uuid)}
        for row in self.result["ledger"]:
            for entry in row["counters"]:
                uuid = int(entry["counter_uuid"])
                entry["association_at_end"] = self.resolve(uuid)
                if uuid in self.conflicting_uuids:
                    entry["sum_reliable"] = False
                    entry["descriptor_conflicting_at_end"] = True
                    if row.get("cpu_counter_uuid") == str(uuid):
                        row["cpu_ns"] = None
                        row["status"] = "conflicting_counter_descriptor_at_end"
            track = row["event_track_uuid"]
            row["event_association_at_end"] = self.resolve(int(track)) if track != "None" else {"status": "missing"}
        self.result["diagnostic_counts"] = dict(self.counts)
        self.result["unhandled_fields"] = dict(self.unhandled)
        self.result["fields_decoded"] = self.field_count
        rows = self.result["ledger"]
        reliable = sum(row["cpu_ns"] is not None for row in rows)
        unresolved = sum(row["cpu_ns"] is None for row in rows)
        markers = [row for row in rows if row["target_marker"]]
        self.result["cpu_summary"] = {"reliable_cpu_rows": reliable, "rows_without_accepted_cpu": unresolved,
            "ledger_rows": len(rows), "has_relevant_diagnostics": bool(self.counts),
            "limited_scope_supported": self.result["status"] == "limited_scope_complete" and not self.counts,
            "target_marker_rows": len(markers), "target_marker_rows_without_cpu": sum(row["cpu_ns"] is None for row in markers),
            "note": "Reliability is limited to supported counter arithmetic, not clock sampling/physical CPU bounds. Parse completion is separate from CPU coverage; non-CPU counter rows may legitimately lack CPU."}
        self.result["limitations"] = ["Descriptors use first consistent definition; conflicts flagged; full name-merging rules omitted.",
            "Association is resolved after input; no PID namespaces, TID reuse, legacy track association or slice reconstruction.",
            "Wall values are raw; clock snapshots, custom/sequence/incremental clocks and legacy wall deltas are not converted.",
            "Packed numeric repeats and compression rejected. Legacy thread_time fields retained but not reconstructed.",
            "Debug annotations support modern dictionaries, strings and legacy JSON only; other values unparsed.",
            "Unknown/non-counter fields are counted, not interpreted. Diagnostics and global bounds are finite.",
            "cpu_ns follows supported extra counter named thread_time; independent corroboration only, not official validation."]
        self.result["sequence_summary"] = {str(k): {"valid": s["valid"], "epoch": s["epoch"],
            "tainted": s["tainted"], "final_sums": {str(u): v for u, v in s["sums"].items()}} for k, s in self.sequences.items()}


def source_evidence(root):
    evidence = []
    for folder in ("counter-review", "counter-reset-review", "proto-decode-review"):
        manifest = root / "official-sources" / folder / "MANIFEST.json"
        doc = json.loads(manifest.read_text())
        rows = doc if isinstance(doc, list) else doc["files"]
        for row in rows:
            if row.get("repository", "google/perfetto") != "google/perfetto" or row.get("revision", REV) != REV:
                continue
            p = Path(row["savedPath"]) if "savedPath" in row else manifest.parent / row["local_file"]
            data = p.read_bytes()
            sha = hashlib.sha256(data).hexdigest()
            if sha != row["sha256"] or len(data) != row["bytes"]:
                raise DecodeError("source evidence hash/size mismatch: " + str(p))
            evidence.append({"path": str(p.relative_to(root)), "url": row["url"], "bytes": len(data), "sha256": sha})
    return evidence


def main(argv=None):
    args = sys.argv[1:] if argv is None else argv
    if len(args) != 2:
        print("usage: raw_counter_check.py input.proto output.json (output must not exist)", file=sys.stderr)
        return 2
    source, output = map(Path, args)
    try:
        handle = output.open("x", encoding="utf-8")
    except OSError as error:
        print(str(error), file=sys.stderr)
        return 2
    checker = Checker()
    code = 0
    try:
        checker.result["script_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        checker.result["source_evidence"] = source_evidence(Path(__file__).resolve().parent)
        size = source.stat().st_size
        checker.result["input"] = {"path": str(source), "bytes": size}
        if size > MAX_INPUT:
            raise DecodeError("input size limit exceeded")
        raw = source.read_bytes()
        checker.result["input"]["sha256"] = hashlib.sha256(raw).hexdigest()
        if raw.startswith(b"\x1f\x8b") or raw.startswith(b"\x28\xb5\x2f\xfd"):
            raise DecodeError("compressed file unsupported")
        for number, wire, payload, offset in checker.fields(raw, container=True):
            if number != 1 or wire != 2:
                raise DecodeError("expected Trace.packet field 1 length-delimited framing")
            if checker.result["packets_seen"] >= MAX_PACKETS:
                raise DecodeError("packet limit exceeded")
            checker.packet = checker.result["packets_seen"]
            checker.packet_offset = offset
            checker.result["packets_seen"] += 1
            checker.result["last_packet_trace_offset"] = offset
            checker.packet_message(payload)
        if not checker.result["packets_seen"]:
            raise DecodeError("empty trace: no Trace.packet fields")
        checker.result["status"] = "limited_scope_complete"
    except (Exception, KeyboardInterrupt) as error:
        checker.result["status"] = "failed_partial_ledger_preserved"
        checker.result["failure"] = {"type": type(error).__name__, "message": str(error), "packet_index": checker.packet}
        code = 1
    finally:
        checker.finish()
        with handle:
            json.dump(checker.result, handle, ensure_ascii=False, allow_nan=False, indent=2)
            handle.write("\n")
    return code


if __name__ == "__main__":
    raise SystemExit(main())
