async () => {
  const layouts = {
    p1: [8, 1, 6, 3, 5, 7, 4, 9, 2],
    p2: [5, 9, 1, 7, 2, 6, 3, 8, 4]
  };
  const out = {layouts, preparations: [], policies: [], selections: [], ruleEdges: [], equilibriumCases: [], handTimings: []};
  const marks = mask => Array.from({length: 9}, (_, i) => Boolean(mask & (1 << i)));
  const plain = policy => ({terminal: policy.terminal.isTerminal, attacker: policy.attacker, gap: policy.gap,
    legalActions: policy.legalActions, breakStrategy: Array.from(policy.breakStrategy), blockStrategy: Array.from(policy.blockStrategy),
    actionValues: policy.actionValues ? Array.from(policy.actionValues) : null, stayValue: policy.stayValue ?? null});
  const memory = () => ({breakCell: state.cpuBlockedBreakCell, breakStreak: state.cpuBlockedBreakStreak,
    breakCooldown: state.cpuBlockedCooldown, blockCell: state.cpuSuccessfulBlockCell,
    blockStreak: state.cpuSuccessfulBlockStreak, blockCooldown: state.cpuSuccessfulBlockCooldown});
  const configure = (firstPlayer, m1, m2, t, difficulty) => {
    Object.assign(state, {gameMode: 'cpu', cpuDifficulty: difficulty, seatChosen: true, isStarting: true,
      gameEnded: false, phase: 'break', firstPlayer, p1Marks: marks(m1), p2Marks: marks(m2),
      p1NumberLayout: layouts.p1.slice(), p2NumberLayout: layouts.p2.slice(),
      p1TurnsTaken: firstPlayer === 1 ? (t + 1) >> 1 : t >> 1,
      p2TurnsTaken: firstPlayer === 2 ? (t + 1) >> 1 : t >> 1,
      cpuBlockedBreakCell: 0, cpuBlockedBreakStreak: 2, cpuBlockedCooldown: 2,
      cpuSuccessfulBlockCell: 0, cpuSuccessfulBlockStreak: 2, cpuSuccessfulBlockCooldown: 2});
  };
  const p1Table = buildCpuEqTable(layouts.p1), p2Table = buildCpuEqTable(layouts.p2);
  cpuEqBundle = {p1: p1Table, p2: p2Table};
  const fallbackRows = table => {
    const rows = [];
    for (let r = 0; r <= 9; r++) for (let mask = 0; mask < 512; mask++) {
      if (!Number.isFinite(table.values[r][mask])) continue;
      rows.push({r, mask, value: table.values[r][mask],
        breakStrategy: r ? Array.from(table.breakProbs[r][mask]) : null,
        blockStrategy: r ? Array.from(table.blockProbs[r][mask]) : null});
    }
    return rows;
  };
  out.fallbackTables = {p1: fallbackRows(p1Table), p2: fallbackRows(p2Table)};
  for (const caseData of [
      ['one', [4], 2], ['zero', [2,2,2], 2], ['positive', [7,5,3], 2],
      ['negative', [-5,-3,-4], -2], ['mixed', [4,-3,1], 0],
      ['ties', [5,5,5,2], 1], ['tiny', [1 + 1e-13,1,1 - 1e-13], 1]
  ]) {
    const dp = new WholeGameDP({layoutP1: layouts.p1, layoutP2: layouts.p2});
    const pay = Float64Array.from(caseData[1]);
    const answer = dp.equilibrium(pay.length, pay, caseData[2]);
    out.equilibriumCases.push({name: caseData[0], pay: Array.from(pay), stay: caseData[2], value: answer.value,
      gap: answer.gap, breakStrategy: Array.from(dp.probP.slice(0, pay.length)), blockStrategy: Array.from(dp.probQ.slice(0,pay.length))});
  }
  for (const firstPlayer of [1,2]) {
    configure(firstPlayer, 0, 0, 0, 'master');
    const started = performance.now();
    startWholeGameCpu();
    await new Promise((resolve, reject) => {
      const poll = () => {
        if (cpuWholeStatus === 'ready') return resolve();
        if (cpuWholeStatus === 'fallback') return reject(new Error(cpuWholeFailure));
        setTimeout(poll, 5);
      }; poll();
    });
    out.preparations.push({firstPlayer, elapsedMs: performance.now() - started, stats: {...cpuWholeStats}});
    const dp = cpuWholeDp;
    await fetch(`/__snapshot__/whole-first${firstPlayer}.bin`, {method: 'POST', body: new Blob(dp.layers.map(layer => layer.values))});
    out.layerShapes = dp.layers.map(layer => ({n1: layer.n1,n2: layer.n2, bytes: layer.values.byteLength}));
    const scenarios = [
      ['opening',0,0,0], ['middle',3,24,8], ['late',195,234,12],
      ['two-closed',508,502,14], ['one-closed',510,509,16],
      ['score-p1',7,24,12], ['score-p2',3,448,12], ['cross-lines',79,195,12],
      ['loss-classification',502,508,14]
    ];
    for (const [name,m1,m2,baseT] of scenarios) for (const role of ['break','block']) {
      const attacker = role === 'break' ? 2 : 1;
      const t = dp.attacker[baseT] === attacker ? baseT : baseT + 1;
      const decision = {maskP1:m1,maskP2:m2,t};
      const policy = dp.analyze(decision);
      const descriptor = {firstPlayer,name,role,...decision};
      out.policies.push({...descriptor,value:dp.getValue(decision),...plain(policy),
        selectionWeights: policy.terminal.isTerminal ? null : Array.from(wholeGameCpuSelectionWeights(dp,role,policy,decision,role === 'break' ? policy.breakStrategy : policy.blockStrategy))});
      for (const difficulty of ['normal','hard','master']) for (const engine of ['ready','fallback']) {
        if (engine === 'ready' && difficulty !== 'normal' && policy.terminal.isTerminal) continue;
        for (const stream of [
          [0.01,0.2,0.7,0.99,0.3,0.6,0.8,0,0.999999,0.42,0.699999,0.7],
          [0.7,0.99,0.01,0.2,0.699999,0.4,0.85,0.5,0.75,0.95,0.1,0.65]
        ]) {
          configure(firstPlayer,m1,m2,t,difficulty);
          cpuWholeDp = engine === 'ready' ? dp : null;
          cpuWholeStatus = engine;
          let cursor = 0;
          const draws = [];
          const nativeRandom = Math.random;
          Math.random = () => {const value = stream[cursor++ % stream.length]; draws.push(value); return value;};
          const choices = [];
          try {
            for (const blocked of [true,false,true,false]) {
              const beforeCalls = draws.length;
              const cell = role === 'break'
                ? selectCpuBreakCell(state.p2Marks.map((opened,i) => opened ? -1 : i).filter(i => i >= 0))
                : selectCpuBlockCell(state.p1Marks,state.p1NumberLayout);
              if (role === 'break') rememberCpuBreakResult(cell,blocked);
              else rememberCpuBlockResult(cell,blocked);
              choices.push({cell,blocked,calls:draws.length-beforeCalls,memory:memory()});
            }
          } finally {Math.random = nativeRandom;}
          out.selections.push({...descriptor,difficulty,engine,stream,draws,choices});
        }
      }
    }
    // A batch avoids the timer granularity dominating sub-millisecond decisions.
    for (const role of ['break','block']) for (const difficulty of ['normal','hard','master']) {
      const t = dp.attacker[8] === (role === 'break' ? 2 : 1) ? 8 : 9;
      configure(firstPlayer,3,24,t,difficulty);
      cpuWholeDp = dp; cpuWholeStatus = 'ready';
      const nativeRandom = Math.random;
      Math.random = () => 0.8;
      try {
        for (let count=0; count<3000; count++) {
          if (role === 'break') selectCpuBreakCell([0,1,2,3,4,5,6,7,8].filter(i => !state.p2Marks[i]));
          else selectCpuBlockCell(state.p1Marks,state.p1NumberLayout);
        }
        const batches = [];
        for (let batch=0; batch<7; batch++) {
          const start = performance.now();
          for (let count=0; count<1000; count++) {
            if (role === 'break') selectCpuBreakCell([0,1,2,3,4,5,6,7,8].filter(i => !state.p2Marks[i]));
            else selectCpuBlockCell(state.p1Marks,state.p1NumberLayout);
          }
          batches.push((performance.now()-start)/1000);
        }
        out.handTimings.push({firstPlayer,role,difficulty,msPerDecision:batches});
      } finally {Math.random=nativeRandom;}
    }
    releaseWholeGameCpu();
  }
  for (const mask of [0,7,79,195,234,508,510,511]) {
    out.ruleEdges.push({mask,score:calculateScore(marks(mask),layouts.p1),scoredCells:Array.from(getScoredCellIndices(marks(mask))),
      maxScores:[0,4,7,8,9].map(turns => calculateHighestReachableScore(marks(mask),layouts.p1,turns))});
  }
  out.endings = [];
  for (const firstPlayer of [1,2]) for (const inning of [1,5,8,9]) for (const half of ['top','bottom']) {
    const context = {p1Marks:marks(79),p2Marks:marks(195),p1NumberLayout:layouts.p1,p2NumberLayout:layouts.p2,
      p1TurnsTaken:inning-1,p2TurnsTaken:inning-1,firstPlayer,inning,half,
      p1Score:calculateScore(marks(79),layouts.p1),p2Score:calculateScore(marks(195),layouts.p2)};
    out.endings.push({firstPlayer,inning,half,result:evaluateEndState(context)});
  }
  return out;
}
