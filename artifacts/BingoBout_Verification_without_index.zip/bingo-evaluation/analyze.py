#!/usr/bin/env python3
"""Fixed-design, layout-pair cluster analysis of the unmodified Bingo Bout CPU.

Full run: python3 analyze.py --input-dir results
Computational smoke only (does not publish inferential results):
    python3 analyze.py --smoke smoke/pair-0.jsonl

The bootstrap sampling unit is the independent generated layout *pair*, not a
game, player seat, swap, or a turn. Every bootstrap draw retains all observations
and matched conditions in the sampled pair. No results-based exclusions occur.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import platform

import numpy as np

ROOT = Path(__file__).resolve().parent
BOOTSTRAP_SEED = 20261014
BOOTSTRAP_RESAMPLES = 4000
FIELDS = ("games", "win", "draw", "loss", "win_half", "margin", "utility",
          "scoreCPU", "scoreOpponent", "defBlocks", "defN", "atkBlocked",
          "atkN", "turns", "early", "hardLegacy", "hardDp")
F = {name: i for i, name in enumerate(FIELDS)}
METRICS = {
    "win_rate": ("win", "games"),
    "draw_rate": ("draw", "games"),
    "loss_rate": ("loss", "games"),
    "win_plus_half_draw": ("win_half", "games"),
    "mean_margin": ("margin", "games"),
    "mean_utility": ("utility", "games"),
    "mean_score_cpu": ("scoreCPU", "games"),
    "mean_score_opponent": ("scoreOpponent", "games"),
    "defense_block_rate": ("defBlocks", "defN"),
    "attack_blocked_rate": ("atkBlocked", "atkN"),
    "mean_turns": ("turns", "games"),
    "early_end_rate": ("early", "games"),
}


def metrics(totals):
    """Last axis: additive totals; return last axis: named ratio estimands."""
    return np.stack([totals[..., F[num]] / totals[..., F[den]]
                     for num, den in METRICS.values()], axis=-1)


def load_records(files, design, smoke=False):
    pairs = design["layout_pairs"]
    diffs, opps = design["difficulties"], design["opponents"]
    reps = design["replicates_per_cell"]
    shape = (pairs, len(diffs), len(opps), 2, 2)
    totals = np.zeros(shape + (len(FIELDS),), dtype=np.float64)
    seen = np.zeros(shape + (reps,), dtype=np.bool_)
    hashes, row_count = {}, 0
    for path in files:
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for line_number, line in enumerate(stream, 1):
                digest.update(line)
                if not line.strip():
                    raise ValueError(f"Unexpected blank record: {path}:{line_number}")
                r = json.loads(line)
                pair, di, oi = r["pair"], diffs.index(r["difficulty"]), opps.index(r["opponent"])
                assert 0 <= pair < pairs and r["firstPlayer"] in (1, 2) and r["swap"] in (0, 1)
                assert 0 <= r["rep"] < reps
                # CPU is P2: firstPlayer=2 means CPU moves first.
                idx = (pair, di, oi, r["firstPlayer"] - 1, r["swap"])
                key = idx + (r["rep"],)
                if seen[key]:
                    raise ValueError(f"Duplicate condition/replicate: {path}:{line_number}: {key}")
                seen[key] = True
                assert r["win"] + r["draw"] + r["loss"] == 1
                assert r["margin"] == r["scoreCPU"] - r["scoreOpponent"]
                assert (r["win"], r["draw"], r["loss"]) == (int(r["margin"] > 0), int(r["margin"] == 0), int(r["margin"] < 0))
                assert r["utility"] == 1000 * int(np.sign(r["margin"])) + r["margin"]
                assert 0 <= r["defBlocks"] <= r["defN"] <= 9
                assert 0 <= r["atkBlocked"] <= r["atkN"] <= 9
                assert r["turns"] == r["defN"] + r["atkN"]
                vals = dict(r, games=1, win_half=r["win"] + 0.5 * r["draw"])
                totals[idx] += [vals[name] for name in FIELDS]
                row_count += 1
        hashes[str(path.name)] = digest.hexdigest()
    if not smoke and not np.all(seen):
        missing = np.argwhere(~seen)
        raise ValueError(f"Incomplete fixed design: {len(missing)} missing games; first keys {missing[:6].tolist()}")
    if smoke:
        active = np.flatnonzero(totals[..., F["games"]].sum(axis=(1, 2, 3, 4)))
        totals = totals[active]
    return totals, row_count, hashes


def bootstrap_counts(n_pairs):
    """Explicit algorithm/seed, independent of the order of table generation."""
    random = np.random.Generator(np.random.PCG64(BOOTSTRAP_SEED))
    return random.multinomial(n_pairs, np.full(n_pairs, 1 / n_pairs),
                              size=BOOTSTRAP_RESAMPLES)


def ratio_summary(pair_totals, counts):
    """pair_totals has shape (pair, group, additive field)."""
    point_totals = pair_totals.sum(axis=0)
    point = metrics(point_totals)
    draws = np.einsum("bp,pgf->bgf", counts, pair_totals, optimize=True)
    boot = metrics(draws)
    lo, hi = np.quantile(boot, [0.025, 0.975], axis=0, method="linear")
    return point_totals, point, lo, hi, boot


def make_row(labels, totals, point, lo=None, hi=None):
    row = dict(labels)
    for name in ("games", "win", "draw", "loss", "defBlocks", "defN", "atkBlocked", "atkN", "hardLegacy", "hardDp"):
        row[name] = int(totals[F[name]])
    for mi, name in enumerate(METRICS):
        row[name] = float(point[mi])
        if lo is not None:
            row[name + "_ci_low"] = float(lo[mi])
            row[name + "_ci_high"] = float(hi[mi])
    return row


def summarize(pair_totals, labels, counts):
    point_totals, point, lo, hi, boot = ratio_summary(pair_totals, counts)
    rows = [make_row(label, point_totals[i], point[i], lo[i], hi[i])
            for i, label in enumerate(labels)]
    return rows, point, boot


def difference_rows(point_a, point_b, boot_a, boot_b, labels):
    difference = point_a - point_b
    lo, hi = np.quantile(boot_a - boot_b, [0.025, 0.975], axis=0, method="linear")
    rows = []
    for i, label in enumerate(labels):
        row = dict(label)
        for mi, name in enumerate(METRICS):
            row[name + "_difference"] = float(difference[i, mi])
            row[name + "_ci_low"] = float(lo[i, mi])
            row[name + "_ci_high"] = float(hi[i, mi])
        rows.append(row)
    return rows


def cluster_correlations(x, y, counts, labels):
    """Pearson r of condition means, preserving all four conditions per pair.

    x: (pair, condition=4); y: (pair, group, condition=4, outcome).
    Bootstrap uncertainty includes finite independent layouts; correlation with
    noisy Monte Carlo condition means is descriptive and may be attenuated.
    """
    xx = x[:, None, :, None] + np.zeros_like(y)
    moments = np.stack([np.ones_like(y).sum(axis=2), xx.sum(axis=2), y.sum(axis=2),
        (xx * xx).sum(axis=2), (y * y).sum(axis=2), (xx * y).sum(axis=2)], axis=-1)

    def correlation(sums):
        n, sx, sy, sxx, syy, sxy = np.moveaxis(sums, -1, 0)
        return (sxy - sx * sy / n) / np.sqrt((sxx - sx * sx / n) * (syy - sy * sy / n))

    point = correlation(moments.sum(axis=0))
    boot_sums = np.einsum("bp,pgmf->bgmf", counts, moments, optimize=True)
    lo, hi = np.quantile(correlation(boot_sums), [0.025, 0.975], axis=0, method="linear")
    rows = []
    for g, label in enumerate(labels):
        row = dict(label)
        for m, name in enumerate(("win_plus_half_draw", "mean_margin", "mean_utility")):
            row[name + "_pearson_r"] = float(point[g, m])
            row[name + "_ci_low"] = float(lo[g, m])
            row[name + "_ci_high"] = float(hi[g, m])
        rows.append(row)
    return rows


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def fmt_interval(row, name, percentage=False, difference=False):
    factor, digits = (100, 1) if percentage else (1, 2)
    estimate = row[name + "_difference"] if difference else row[name]
    lo, hi = row[name + "_ci_low"], row[name + "_ci_high"]
    return f"{estimate * factor:.{digits}f} [{lo * factor:.{digits}f}, {hi * factor:.{digits}f}]"


def tables_markdown(main, seats, seat_diff, swap_diff, comparisons, layout_spread, correlations, symmetry, row_count):
    lines = ["# 固定計画による自動対戦の統計表", "",
        f"実測 {row_count:,} 試合。CPU は常に P2。32 個の独立盤面ペア × 配置交換 2 × 先後 2 × 各 64 回。各難易度・対手につき 8,192 試合。",
        "95% 区間は盤面ペア単位の percentile cluster bootstrap（4,000 回、PCG64 seed=20261014）。各対戦・BLOCK機会を独立とみなす区間ではない。",
        "勝率は引分を除外しない。勝点率=勝率+0.5×引分率。BLOCK率は全成功数÷全機会数。角括弧は 95% CI。率の単位は %、差の単位は percentage points。",
        "utility は 1000×sign(得点差)+得点差。これを最大化するDPは勝点率だけを最大化するとは限らない。", "",
        "## 共通対戦相手ごとの成績", "",
        "|難易度|対手|勝/分/負|勝率 % [95% CI]|勝点率 % [95% CI]|得点差 [95% CI]|utility [95% CI]|防御BLOCK % [95% CI]|機会数|攻撃被BLOCK % [95% CI]|機会数|",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for r in main:
        lines.append("|" + "|".join([r["difficulty"], r["opponent"], f'{r["win"]}/{r["draw"]}/{r["loss"]}',
            fmt_interval(r, "win_rate", True), fmt_interval(r, "win_plus_half_draw", True), fmt_interval(r, "mean_margin"), fmt_interval(r, "mean_utility"),
            fmt_interval(r, "defense_block_rate", True), str(r["defN"]),
            fmt_interval(r, "attack_blocked_rate", True), str(r["atkN"])]) + "|")
    lines.extend(["", "## 先攻・後攻", "", "|難易度|対手|CPU席|勝点率 % [95% CI]|得点差 [95% CI]|", "|---|---|---|---:|---:|"])
    for r in seats:
        lines.append(f'|{r["difficulty"]}|{r["opponent"]}|{r["cpu_seat"]}|{fmt_interval(r,"win_plus_half_draw",True)}|{fmt_interval(r,"mean_margin")}|')
    for title, data in [("先攻−後攻の対応差", seat_diff), ("配置交換 swap=1−swap=0 の対応差", swap_diff)]:
        lines.extend(["", "## " + title, "", "|難易度|対手|勝点率差 pp [95% CI]|得点差の差 [95% CI]|防御BLOCK率差 pp [95% CI]|攻撃被BLOCK率差 pp [95% CI]|", "|---|---|---:|---:|---:|---:|"])
        for r in data:
            lines.append(f'|{r["difficulty"]}|{r["opponent"]}|{fmt_interval(r,"win_plus_half_draw",True,True)}|{fmt_interval(r,"mean_margin",False,True)}|{fmt_interval(r,"defense_block_rate",True,True)}|{fmt_interval(r,"attack_blocked_rate",True,True)}|')
    lines.extend(["", "## 難易度の対応比較（同じ盤面・席・乱数ストリーム）", "", "|比較（左−右）|対手|勝点率差 pp [95% CI]|得点差の差 [95% CI]|utility差 [95% CI]|", "|---|---|---:|---:|---:|"])
    for r in comparisons:
        lines.append(f'|{r["policy_a"]}−{r["policy_b"]}|{r["opponent"]}|{fmt_interval(r,"win_plus_half_draw",True,True)}|{fmt_interval(r,"mean_margin",False,True)}|{fmt_interval(r,"mean_utility",False,True)}|')
    lines.extend(["", "## 盤面ペア差（記述統計）", "", "各ペア内の配置・席を平均した勝点率の分布。min/max は測定ノイズを含み、母集団の最悪/最良盤面の推定ではない。", "", "|難易度|対手|ペア別勝点率 min/median/max %|ペア間SD pp|", "|---|---|---:|---:|"])
    for r in layout_spread:
        lines.append(f'|{r["difficulty"]}|{r["opponent"]}|{100*r["pair_win_half_min"]:.1f}/{100*r["pair_win_half_median"]:.1f}/{100*r["pair_win_half_max"]:.1f}|{100*r["pair_win_half_sd"]:.2f}|')
    lines.extend(["", "## 配置ごとの違い（席を平均した pair×swap の64条件）", "", "|難易度|対手|配置別勝点率 min/median/max %|配置間SD pp|配置別平均得点差 min/max|", "|---|---|---:|---:|---:|"])
    for r in layout_spread:
        lines.append(f'|{r["difficulty"]}|{r["opponent"]}|{100*r["layout_swap_win_half_min"]:.1f}/{100*r["layout_swap_win_half_median"]:.1f}/{100*r["layout_swap_win_half_max"]:.1f}|{100*r["layout_swap_win_half_sd"]:.2f}|{r["layout_swap_margin_min"]:.2f}/{r["layout_swap_margin_max"]:.2f}|')
    lines.extend(["", "## Nash root utility と条件平均の相関", "", "各条件は pair×swap×席の128条件。Pearson r の区間も32ペアを単位に再標本化。条件平均に行動乱数の測定ノイズが残るため相関は記述値。", "", "|難易度|対手|勝点率とのr [95% CI]|得点差とのr [95% CI]|utilityとのr [95% CI]|", "|---|---|---:|---:|---:|"])
    for r in correlations:
        cells = [f'{r[n+"_pearson_r"]:.3f} [{r[n+"_ci_low"]:.3f}, {r[n+"_ci_high"]:.3f}]' for n in ("win_plus_half_draw", "mean_margin", "mean_utility")]
        lines.append(f'|{r["difficulty"]}|{r["opponent"]}|' + "|".join(cells) + "|")
    lines.extend(["", f'Nash root の対称性検算: 配置を交換し先後を反転した値の和の最大絶対値={symmetry["max_abs_reflected_root_sum"]:.3g}。許容誤差 1e-5 以下: {symmetry["passed"]}。'])
    lines.extend(["", "## 解釈の制限", "", "- 事前固定した対戦相手別の評価。総合順位や人間全般への勝率を定義しない。nash_control は元ゲームの難易度ではなく、DP混合をそのまま実行する診断用対照。", "- 共通乱数を使うが、方策により乱数消費と訪問状態は異なる。対応比較は難易度変更の因果効果をこの対戦集団で測るもので、同じ展開を保証しない。", "- 区間は有限盤面・行動乱数の不確実性の近似。32クラスタのみであり、各比較の marginal 95% CI。多重比較の同時95%区間ではない。", "- swap の元/交換は乱数生成時のラベル。集団平均差が小さくても個別配置の有利不利が小さいとは限らない。詳細は summary_layout_conditions.csv を参照。", "- 早期終了が機会数を変える。BLOCK率単独で強さを順位づけできない。比率は機会で重みづけした記述値。", "- 試行数・seedを結果に応じて変更せず、不利な盤面・対戦を除外していない。", ""])
    return "\n".join(lines)


def full_analysis(totals, design, hashes, row_count, input_dir):
    npairs, nd, no = totals.shape[:3]
    diffs, opps = design["difficulties"], design["opponents"]
    labels = [{"difficulty": d, "opponent": o} for d in diffs for o in opps]
    counts = bootstrap_counts(npairs)
    main_totals = totals.sum(axis=(3, 4)).reshape(npairs, nd * no, len(FIELDS))
    main, main_point, main_boot = summarize(main_totals, labels, counts)

    seat_totals = totals.sum(axis=4).reshape(npairs, nd * no * 2, len(FIELDS))
    seat_labels = [dict(label, cpu_seat=seat) for label in labels for seat in ("second", "first")]
    seats, seat_point, seat_boot = summarize(seat_totals, seat_labels, counts)
    sp, sb = seat_point.reshape(nd * no, 2, -1), seat_boot.reshape(BOOTSTRAP_RESAMPLES, nd * no, 2, -1)
    seat_diff = difference_rows(sp[:, 1], sp[:, 0], sb[:, :, 1], sb[:, :, 0], labels)

    swap_totals = totals.sum(axis=3).reshape(npairs, nd * no * 2, len(FIELDS))
    swap_labels = [dict(label, swap=swap) for label in labels for swap in (0, 1)]
    swaps, swap_point, swap_boot = summarize(swap_totals, swap_labels, counts)
    xp, xb = swap_point.reshape(nd * no, 2, -1), swap_boot.reshape(BOOTSTRAP_RESAMPLES, nd * no, 2, -1)
    swap_diff = difference_rows(xp[:, 1], xp[:, 0], xb[:, :, 1], xb[:, :, 0], labels)

    orientation_labels = [dict(label, cpu_seat=seat, swap=swap)
        for label in labels for seat in ("second", "first") for swap in (0, 1)]
    orientations, _, _ = summarize(totals.reshape(npairs, nd * no * 4, len(FIELDS)), orientation_labels, counts)

    point = main_point.reshape(nd, no, -1)
    boot = main_boot.reshape(BOOTSTRAP_RESAMPLES, nd, no, -1)
    comparisons = []
    for a, b in [("hard", "normal"), ("master", "normal"), ("master", "hard"),
                 ("normal", "nash_control"), ("hard", "nash_control"), ("master", "nash_control")]:
        ia, ib = diffs.index(a), diffs.index(b)
        comparison_labels = [{"policy_a": a, "policy_b": b, "opponent": o} for o in opps]
        comparisons.extend(difference_rows(point[ia], point[ib], boot[:, ia], boot[:, ib], comparison_labels))

    pair_rows, spread, layout_rows, pair_swap_rows = [], [], [], []
    pair_metrics = metrics(main_totals)
    pair_swap_metrics = metrics(swap_totals.reshape(npairs, nd * no, 2, len(FIELDS)))
    mi = list(METRICS).index("win_plus_half_draw")
    margin_mi = list(METRICS).index("mean_margin")
    for g, label in enumerate(labels):
        v = pair_metrics[:, g, mi]
        lv = pair_swap_metrics[:, g, :, mi].flatten()
        lm = pair_swap_metrics[:, g, :, margin_mi].flatten()
        spread.append(dict(label, pair_win_half_min=float(v.min()), pair_win_half_median=float(np.median(v)),
            pair_win_half_max=float(v.max()), pair_win_half_sd=float(v.std(ddof=1)),
            pair_win_half_q25=float(np.quantile(v, .25)), pair_win_half_q75=float(np.quantile(v, .75)),
            layout_swap_win_half_min=float(lv.min()), layout_swap_win_half_median=float(np.median(lv)),
            layout_swap_win_half_max=float(lv.max()), layout_swap_win_half_sd=float(lv.std(ddof=1)),
            layout_swap_margin_min=float(lm.min()), layout_swap_margin_max=float(lm.max()),
            layout_swap_margin_sd=float(lm.std(ddof=1))))
        for pair in range(npairs):
            pair_rows.append(make_row(dict(pair=pair, **label), main_totals[pair, g], pair_metrics[pair, g]))
            for swap in range(2):
                cell = swap_totals.reshape(npairs, nd * no, 2, len(FIELDS))[pair, g, swap]
                pair_swap_rows.append(make_row(dict(pair=pair, swap=swap, **label), cell, metrics(cell)))
    roots, symmetry_residuals = np.zeros((npairs, 2, 2)), []
    for pair in range(npairs):
        metadata = json.loads((input_dir / f"dp-{pair}.json").read_text())
        meta = {(r["firstPlayer"] - 1, r["swap"]): r for r in metadata}
        assert len(meta) == 4
        for seat in range(2):
            for swap in range(2):
                roots[pair, seat, swap] = meta[(seat, swap)]["initialValue"]
                reflected = meta[(1 - seat, 1 - swap)]
                assert meta[(seat, swap)]["p1"] == reflected["p2"]
                assert meta[(seat, swap)]["p2"] == reflected["p1"]
                symmetry_residuals.append(abs(meta[(seat, swap)]["initialValue"] + reflected["initialValue"]))
        for di, d in enumerate(diffs):
            for oi, o in enumerate(opps):
                for seat in range(2):
                    for swap in range(2):
                        m = meta[(seat, swap)]
                        cell = totals[pair, di, oi, seat, swap]
                        label = dict(pair=pair, difficulty=d, opponent=o, cpu_seat=("second", "first")[seat],
                            swap=swap, p1=" ".join(map(str, m["p1"])), p2=" ".join(map(str, m["p2"])),
                            nash_initial_utility=m["initialValue"])
                        layout_rows.append(make_row(label, cell, metrics(cell)))
    symmetry = dict(max_abs_reflected_root_sum=max(symmetry_residuals),
        reflected_conditions=len(symmetry_residuals), tolerance=1e-5,
        passed=max(symmetry_residuals) <= 1e-5)
    if not symmetry["passed"]:
        raise ValueError(f"Nash root label-reflection validation failed: {symmetry}")
    outcome_indices = [list(METRICS).index(n) for n in ("win_plus_half_draw", "mean_margin", "mean_utility")]
    condition_metrics = metrics(totals.reshape(npairs, nd * no, 4, len(FIELDS)))
    correlations = cluster_correlations(roots.reshape(npairs, 4), condition_metrics[..., outcome_indices], counts, labels)

    tables = {"main": main, "seats": seats, "seat_difference": seat_diff, "swaps": swaps,
              "swap_difference": swap_diff, "orientations": orientations, "comparisons": comparisons,
              "pairs": pair_rows, "layout_spread": spread, "layout_conditions": layout_rows,
              "layout_pair_swaps": pair_swap_rows, "layout_correlations": correlations}
    for name, rows in tables.items():
        write_csv(input_dir / f"summary_{name}.csv", rows)
    summary = dict(protocol=design["protocol"], source_sha256=design["source_sha256"],
        analysis_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        design_sha256=hashlib.sha256((ROOT / "design.json").read_bytes()).hexdigest(),
        games=row_count, independent_layout_pairs=npairs,
        bootstrap=dict(resamples=BOOTSTRAP_RESAMPLES, seed=BOOTSTRAP_SEED, generator="PCG64",
            sampling_unit="independent layout pair; retain all seats, swaps, opponents, difficulties and replicates",
            interval="pointwise 95% percentile; NumPy quantile method=linear"),
        python=platform.python_version(), numpy=np.__version__, input_sha256=hashes,
        metric_definitions={k: f"sum({n}) / sum({d})" for k, (n, d) in METRICS.items()},
        nash_root_symmetry=symmetry, tables=tables)
    (input_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    (input_dir / "tables.md").write_text(tables_markdown(main, seats, seat_diff, swap_diff, comparisons, spread, correlations, symmetry, row_count))
    print(json.dumps(dict(event="analysis_complete", games=row_count, independent_layout_pairs=npairs,
        bootstrap_resamples=BOOTSTRAP_RESAMPLES, bootstrap_seed=BOOTSTRAP_SEED,
        outputs=[f"summary_{x}.csv" for x in tables] + ["summary.json", "tables.md"])))


def smoke(path, design):
    totals, count, _ = load_records([path], design, smoke=True)
    assert count > 0
    # Check all metric calculations against direct individual-record sums.
    direct = [json.loads(line) for line in path.read_text().splitlines()]
    collapsed = totals.sum(axis=(0, 1, 2, 3, 4))
    assert collapsed[F["games"]] == len(direct)
    assert collapsed[F["defBlocks"]] == sum(x["defBlocks"] for x in direct)
    assert metrics(collapsed)[list(METRICS).index("win_plus_half_draw")] == sum(x["win"] + .5*x["draw"] for x in direct) / count
    assert totals[:, :, :, 1, :, F["games"]].sum() == sum(x["firstPlayer"] == 2 for x in direct)
    # A synthetic bootstrap verifies pairing algebra. This is not experimental data.
    synthetic = np.stack([collapsed, collapsed, collapsed])[:, None, :]
    weights = bootstrap_counts(3)
    assert np.all(weights.sum(axis=1) == 3)
    assert np.array_equal(weights, bootstrap_counts(3))
    _, point, lo, hi, draws = ratio_summary(synthetic, weights)
    assert np.allclose(point, lo) and np.allclose(point, hi)
    difference = difference_rows(point, point, draws, draws, [{"check": "same_minus_same"}])[0]
    assert all(v == 0 for k, v in difference.items() if k != "check")
    x = np.array([[-3., -1., 1., 3.], [-6., -2., 2., 6.], [-9., -3., 3., 9.]])
    y = np.stack([x, -x, 2*x + 1], axis=-1)[:, None, :, :]
    correlations = cluster_correlations(x, y, weights, [{"check": "synthetic_linear"}])[0]
    assert np.isclose(correlations["win_plus_half_draw_pearson_r"], 1)
    assert np.isclose(correlations["mean_margin_pearson_r"], -1)
    assert np.isclose(correlations["mean_utility_pearson_r"], 1)
    print(json.dumps(dict(event="analysis_smoke_pass", rows=count,
        checks=["record algebra", "direct aggregation", "CPU first=P2", "fixed bootstrap seed", "cluster retention", "paired zero contrast", "synthetic correlation sign"],
        statistical_results_published=False)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, default=ROOT / "results")
    parser.add_argument("--smoke", type=Path)
    args = parser.parse_args()
    design = json.loads((ROOT / "design.json").read_text())
    actual_source_hash = hashlib.sha256((ROOT / "source.html").read_bytes()).hexdigest()
    if actual_source_hash != design["source_sha256"]:
        raise ValueError("source.html SHA256 differs from the fixed evaluation design")
    if args.smoke:
        smoke(args.smoke, design)
        return
    files = [args.input_dir / f"pair-{i}.jsonl" for i in range(design["layout_pairs"])]
    totals, count, hashes = load_records(files, design)
    full_analysis(totals, design, hashes, count, args.input_dir)


if __name__ == "__main__":
    main()
