# CPU差分の切捨てとincremental state clear

**現SDKはCPUのns差分を毎回usへ整数除算し、切り捨てた余りを次回へ持ち越さない。** clear後は同じthread CPU時計の絶対値を0基準から送り直すため、以前のepochで積み上がった損失が解消され、表示上のCPU値が増える構成が可能である。今回の1ms超過26sliceは全てclearを跨ぎ、全てその切捨て損失の理論上限内だった。実際に失われた各ns余りはprotoにないため、26件の全超過量をこれだけへ帰属したとはしない。

既存proto/ledger/公式SQLと固定ソースの読み取り・演算のみを行った。ブラウザー・DP・性能ジョブの追加はない。collector、PLAN、raw、凍結decoder、過去成果物は変更していない。

## ソースで確定する仕組み

固定Perfetto revision `5dbeaad4ceb91470a835426b52e0cb43a3e5ef10` の [track_event_internal.cc:603–610](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/src/tracing/internal/track_event_internal.cc#L603-L610) は、次の順で処理する。

1. `thread_time_ns = GetThreadCPUTimeNs()`。
2. `delta_ns = thread_time_ns − last_thread_time_ns`。
3. **`last_thread_time_ns = thread_time_ns`（切捨て前の実測ns）**。
4. `extra_counter_values = delta_ns / timestamp_unit_multiplier`。

したがって「CPU絶対値を先にusへ変換し、その値同士を引く」方式ではない。今回のCPU counter descriptor倍率は1000で、encoded CPU差分は全167,205 samplesで非負だった。非負差分では整数除算はfloorとなり、1更新につき0–999nsの余りが捨てられる。

対照的にwallのincremental timestampは [同535–542](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/src/tracing/internal/track_event_internal.cc#L535-L542) で `diff_units = diff_ns / unit` を送り、**`last_timestamp_ns += diff_units×unit`** と表現できた分だけbaselineを進める。余りは次回diffへ残る。CPUとwallに同じ倍率1000を使っても、累積誤差の挙動は同じではない。

[TrackEventIncrementalState::Clear:200–209](https://github.com/google/perfetto/blob/5dbeaad4ceb91470a835426b52e0cb43a3e5ef10/include/perfetto/tracing/internal/track_event_internal.h#L200-L209) は `last_thread_time_ns=0` に戻す。次のCPU更新はthreadの真の累積CPUに近い絶対値を0からの差として送り、consumerのcounter accumulatorもsequence clearで0基準へ戻る。Linuxのthread CPU時計自体を0へ戻す動作ではない。

## 損失上限の式

倍率を `m`、保存前の真の累積CPU読取を `C_i` とする。1epochの開始はSDKの `C_0=0`。各更新は `floor((C_i−C_(i−1))/m)×m` をconsumerへ加える。nonnegative差分の余りを `r_i` とすると、consumerに見える値は

`E_i = C_i − L_i`、`L_i = sum(r_1…r_i)`、`0 ≤ L_i ≤ N_i×(m−1)`。

clearを跨ぐbegin/endでは

`E_end−E_begin = C_end−C_begin + L_begin−L_end`。

従って、begin側epochに既にあった損失が回復すると、見かけの区間CPUに正の分が加わり得る。正の寄与の上限は `N_begin×999ns`（今回m=1000）。このNはbeginを含むそのepoch内のCPU更新回数であり、begin/end区間内だけの更新回数ではない。

これは量子化モデルとの必要な整合条件であり、真CPUの未知のns余りを復元する式ではない。実wall区間とCPU snapshotの境界差、wall clock変換は別の問題として残る。

## 既存26sliceとの対応

[verify_quantization_resets.py](/workspace/bingo-stage16-20261015/verify_quantization_resets.py) は、凍結raw decoderが復元した全CPU更新をpacket順で数え、各endpointのsequence/epoch、同sequenceのclear、counter倍率とraw差分符号を照合した。入力・実装hashと各26件の数値は [cpu-quantization-model-check.json](/workspace/bingo-stage16-20261015/cpu-quantization-model-check.json) に保存した。最初のepoch対応だけの結果も [cpu-quantization-reset-review.json](/workspace/bingo-stage16-20261015/cpu-quantization-reset-review.json) に残している。

| run | 1ms超過slice | 異なるepoch | 同sequence clearを内包 | begin側切捨て上限と整合 |
|---|---:|---:|---:|---:|
| 1 | 12 | 12 | 12 | 12 |
| 2 | 6 | 6 | 6 | 6 |
| 3 | 3 | 3 | 3 | 3 |
| 4 | 5 | 5 | 5 | 5 |
| 合計 | **26** | **26** | **26** | **26** |

各sliceのCPU begin/endは既に原packetから公式SQLへ一意対応済み。begin側損失上限は3,926,070–17,611,371nsの範囲で、観測した26件の超過を全て覆う。これは上限内という結果であり、損失がその上限に達したという推定ではない。26件はnested sliceを含み、26個の独立したjumpとして足し合わせない。

## clear直前・直後のcounter

対象main threadには、最初のclear後にもさらに14個のclear境界があった。各境界で同sequence/counterの直前最後と直後最初のCPU値を選び、公式SQL counterのUUID/valueでwall timestampへ対応した。

- 9境界は両端をそれぞれ1点に対応できた。8境界で `CPUstep−wallgap` が正（0.191–8.972ms）、1境界は負（−6.958ms）。正の8件は全て旧epochの更新回数×999nsの上限内。
- 残る5境界は同じCPU値のSQL counter候補が複数あり、wall gapを未確定のまま残した。都合のよい候補や平均値を選んでいない。
- 一意対応の例としてrun3 clear packet27504は、旧epochの3,930更新後、CPUstep=2,017,000ns、wallgap=3,380ns、差2,013,620ns。旧epochの損失上限は3,926,070ns。
- run4 clear packet78225は、18,779更新後、CPUstep=8,985,000ns、wallgap=12,887ns、差8,972,113ns。損失上限は18,760,221ns。

以上はclearに伴う増加と量子化モデルが整合する観測である。境界の元CPU ns余りが失われているので、全ての差をfloor回復量へ等置しない。負の1境界も除外していない。

## 構成による正対照と解釈

新ブラウザーを用いず、ソースの符号化が真CPU≤wallからCPU>wallを構成できるかを別の有限fixtureで確認する計画を、生成前に [CONTROL_PLAN.md](/workspace/bingo-stage16-20261015/decoder-validation/CONTROL_PLAN.md) へ固定した。真CPU=wallを1500nsずつ20,000回進め、CPU差分だけを各回floor、wallは余りを持ち越す。BEGIN直後にclear、その後1500nsでENDを置く。これは機構の十分な構成例を調べるもので、実traceの全26件が同じ単独原因で生じたことの証明にはしない。

CPU値がrawから公式SQL/JSONまで一致することは、producerのこの量子化・clear効果を除外しない。むしろ同じ符号化値が一貫して伝わる。今回の主要な追加発見は、**CPUとwallの余り処理が非対称であり、26/26超過sliceがclearを跨いでその損失上限と整合したこと**である。stage14の元protoはなく、stage16のこの対応をそのまま過去169件へ適用しない。
