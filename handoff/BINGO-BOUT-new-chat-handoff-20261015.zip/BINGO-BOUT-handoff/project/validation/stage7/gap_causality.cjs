'use strict';

// Read-only causal probe. Both versions execute in one V8 realm and on the
// same receiver, typed arrays, child value tables and actual saved DP values.
// No HTML or worker is modified. Run --benchmark only when no other CPU job
// is running; the default verifies the predefined cases without timing loops.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const { performance } = require('node:perf_hooks');

const root = path.resolve(__dirname, '../..');
const args = process.argv.slice(2);
const timing = args.includes('--benchmark');
function option(name, fallback) {
    const at = args.indexOf(name);
    return at < 0 ? fallback : args[at + 1];
}
const pairs = Number(option('--pairs', 9));
const calls = Number(option('--calls', 100000));
const warmup = Number(option('--warmup', 20000));
assert(Number.isInteger(pairs) && pairs >= 3);
assert(Number.isInteger(calls) && calls > 0);
assert(Number.isInteger(warmup) && warmup > 0);
const output = path.resolve(option('--output', path.join(__dirname,
    timing ? 'gap-causality.json' : 'gap-equality.json')));
const oldPath = path.join(root, 'index.before.html');
const newPath = path.join(root, 'index.html');
const oldHtml = fs.readFileSync(oldPath, 'utf8');
const newHtml = fs.readFileSync(newPath, 'utf8');
function classes(html) {
    const shared = html.indexOf('        class CpuEquilibriumSolver');
    const start = shared >= 0 ? shared : html.indexOf('        class WholeGameDP');
    const end = html.indexOf('        function wholeGameWorkerSource()', start);
    assert(start >= 0 && end > start);
    return html.slice(start, end);
}
const snapshot = JSON.parse(fs.readFileSync(path.join(root,
    'validation/before/snapshot.json'), 'utf8'));
const data = [1, 2].map(firstPlayer => {
    const buffer = fs.readFileSync(path.join(root,
        `validation/before/whole-first${firstPlayer}.bin`));
    assert(buffer.length % 8 === 0);
    return buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
});
const context = vm.createContext({performance, savedData:data,
    snapshot, pairs, calls, warmup, timing});
vm.runInContext(classes(newHtml) + '\n' + classes(oldHtml).replace(
    'class WholeGameDP {', 'class OriginalWholeGameDP {') + `
    const methods = ['solveState', 'packStrategy', 'equilibrium',
        'sanitizePair', 'sanitize', 'strategyGap'];
    const original = Object.fromEntries(methods.map(name =>
        [name, OriginalWholeGameDP.prototype[name]]));
    const current = Object.fromEntries(methods.map(name =>
        [name, WholeGameDP.prototype[name]]));

    // Candidate only: for one/two actions retain the original inner loop;
    // larger counts retain stage3's diagonal split. Every multiplication and
    // addition has the same left-to-right row order as the original source.
    function smallCountGap(count, pay, stay, value) {
        const p = this.probP;
        const q = this.probQ;
        let minCol = Infinity;
        let maxRow = -Infinity;
        if (count <= 2) {
            for (let col = 0; col < count; col++) {
                let expected = 0;
                for (let row = 0; row < count; row++) {
                    expected += p[row] * (row === col ? stay : pay[row]);
                }
                if (expected < minCol) minCol = expected;
            }
        } else {
            for (let col = 0; col < count; col++) {
                let expected = 0;
                for (let row = 0; row < col; row++) expected += p[row] * pay[row];
                expected += p[col] * stay;
                for (let row = col + 1; row < count; row++) expected += p[row] * pay[row];
                if (expected < minCol) minCol = expected;
            }
        }
        for (let row = 0; row < count; row++) {
            const expected = pay[row] + q[row] * (stay - pay[row]);
            if (expected > maxRow) maxRow = expected;
        }
        return Math.max(Math.abs(minCol - value), Math.abs(maxRow - value));
    }
    const variants = {
        original,
        current,
        currentOldGap: {...current, strategyGap:original.strategyGap},
        currentSmallGap: {...current, strategyGap:smallCountGap},
        currentOldSolve: {...current, solveState:original.solveState}
    };
    const work = new WholeGameDP({layoutP1:snapshot.layouts.p1,
        layoutP2:snapshot.layouts.p2, firstPlayer:1}, false);
    function install(variant) {
        for (const name of methods) work[name] = variant[name];
    }
    function reset(test) {
        work.pay.fill(0); work.pay.set(test.pay);
        work.probP.fill(0); work.probQ.fill(0); work.order.fill(0);
        work.monotone = false;
    }
    function attach(firstPlayer) {
        // The receiver stays identical; only layer metadata/value views for
        // the same predefined first player are installed outside timing.
        const topology = new WholeGameDP({layoutP1:snapshot.layouts.p1,
            layoutP2:snapshot.layouts.p2, firstPlayer}, false);
        const values = new Float64Array(savedData[firstPlayer - 1]);
        let offset = 0;
        for (const layer of topology.layers) {
            const length = layer.n1 * layer.n2;
            layer.values = values.subarray(offset, offset + length);
            offset += length;
        }
        if (offset !== values.length) throw new Error('Saved DP length mismatch');
        work.layers = topology.layers;
        work.attacker = topology.attacker;
        work.turns1 = topology.turns1;
        work.turns2 = topology.turns2;
        work.firstPlayer = firstPlayer;
    }
    function exact(left, right) {
        if (typeof left !== typeof right) return false;
        if (left === null || right === null) return left === right;
        if (typeof left !== 'object') return Object.is(left, right);
        if (ArrayBuffer.isView(left) || Array.isArray(left)) {
            if (!(ArrayBuffer.isView(right) || Array.isArray(right)) ||
                left.length !== right.length) return false;
            for (let i = 0; i < left.length; i++) if (!exact(left[i], right[i])) return false;
            return true;
        }
        const keys = Object.keys(left);
        if (keys.length !== Object.keys(right).length) return false;
        return keys.every(key => Object.hasOwn(right, key) && exact(left[key], right[key]));
    }
    function captureEquilibrium(variant, test) {
        install(variant); reset(test);
        let result;
        try { result = {answer:work.equilibrium(test.pay.length, work.pay, test.stay)}; }
        catch (error) { result = {error:error.message}; }
        return {...result, p:work.probP.slice(0, test.pay.length),
            q:work.probQ.slice(0, test.pay.length)};
    }
    let seed = 0x41b12;
    function random() {
        seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
        return seed / 4294967296;
    }
    const cases = [
        {name:'one-positive',pay:[11],stay:2},
        {name:'one-negative',pay:[-11],stay:2},
        {name:'zero-gains',pay:[7,7,7],stay:7},
        {name:'positive-ties',pay:[9,9,6,4],stay:2},
        {name:'signed-mixed',pay:[-12,7,-2,7],stay:0},
        {name:'negative-mixed-support',pay:[0,0,0],stay:1},
        {name:'negative-pure',pay:[0,-100,-100],stay:1},
        {name:'threshold-low',pay:[1+5e-13,1,1-5e-13],stay:1},
        {name:'threshold-high',pay:[1+2e-12,1+2e-12,1],stay:1},
        {name:'count2-positive',pay:[9,6],stay:2},
        {name:'count2-zero',pay:[7,7],stay:7},
        {name:'count2-negative',pay:[-3,-5],stay:1},
        {name:'signed-zero',pay:[-0,0],stay:-0},
        {name:'subnormal',pay:[Number.MIN_VALUE,-Number.MIN_VALUE],stay:0},
        {name:'large-finite',pay:[1e150,-1e150],stay:0},
        {name:'small-fraction',pay:[0.1,-0.3],stay:0.2}
    ];
    for (let count = 1; count <= 9; count++) {
        for (let trial = 0; trial < 512; trial++) {
            const stay = Math.floor(random()*2101)-1050;
            const pay = Array.from({length:count},()=>Math.floor(random()*2101)-1050);
            cases.push({name:'signed-'+count+'-'+trial,stay,pay});
        }
    }
    const target = {firstPlayer:1,maskP1:508,maskP2:502,t:14,attacker:1};
    attach(1);
    // Derive the real count=2 gains from the complete original DP archive,
    // using the exact production child addressing and attacker sign.
    install(current); work.pay.fill(0);
    const targetAnswer = work.solveState(target.attacker, target.maskP1,
        target.maskP2, work.layers[target.t+1], true);
    const child = work.layers[target.t+1];
    const realStay = -child.values[child.index1[target.maskP1]*child.n2+
        child.index2[target.maskP2]];
    const targetTest = {name:'actual-P1-late-BLOCK',stay:realStay,
        pay:Array.from(work.pay.slice(0,work.closedCount[target.maskP1]))};
    cases.push(targetTest);

    const failures = [];
    let certified = 0, matchingErrors = 0, directGapComparisons = 0;
    for (const test of cases) {
        const expected = captureEquilibrium(original,test);
        if (expected.error) matchingErrors++; else certified++;
        for (const name of ['current','currentOldGap','currentSmallGap']) {
            const actual = captureEquilibrium(variants[name],test);
            if (!exact(expected,actual)) failures.push({scope:'equilibrium',name,test,expected,actual});
        }
        if (!expected.error) {
            reset(test);
            work.probP.set(expected.p); work.probQ.set(expected.q);
            const expectedGap = original.strategyGap.call(work,test.pay.length,work.pay,
                test.stay,expected.answer.value);
            for (const gap of [current.strategyGap,smallCountGap]) {
                const pBefore = work.probP.slice(), qBefore = work.probQ.slice(), payBefore = work.pay.slice();
                const actualGap = gap.call(work,test.pay.length,work.pay,test.stay,expected.answer.value);
                if (!Object.is(expectedGap,actualGap) || !exact(pBefore,work.probP) ||
                    !exact(qBefore,work.probQ) || !exact(payBefore,work.pay)) {
                    failures.push({scope:'gap-or-input-mutation',test,expectedGap,actualGap});
                }
                directGapComparisons++;
            }
        }
    }
    // Arbitrary (including non-normalized) distributions test operation order
    // independently of which branches the equilibrium solver selected.
    const distributionFixtures = [];
    for (let count = 0; count <= 9; count++) {
        for (let trial = 0; trial < 64; trial++) {
            const pay = Array.from({length:count},()=> (random()-.5)*1e4);
            const p = Array.from({length:count},()=> random()-.1);
            const q = Array.from({length:count},()=> random()-.1);
            distributionFixtures.push({count,pay,p,q,stay:(random()-.5)*1e4,value:(random()-.5)*1e4});
        }
    }
    distributionFixtures.push({count:2,pay:[-0,0],p:[-0,1],q:[1,-0],stay:-0,value:-0});
    for (const test of distributionFixtures) {
        work.pay.fill(0); work.pay.set(test.pay);
        work.probP.fill(0);work.probP.set(test.p);
        work.probQ.fill(0);work.probQ.set(test.q);
        const expected = original.strategyGap.call(work,test.count,work.pay,test.stay,test.value);
        for (const gap of [current.strategyGap,smallCountGap]) {
            const actual = gap.call(work,test.count,work.pay,test.stay,test.value);
            if (!Object.is(expected,actual)) failures.push({scope:'arbitrary-gap',test,expected,actual});
            directGapComparisons++;
        }
    }
    let stateCases = 0, stateComparisons = 0;
    const states = [...snapshot.policies.filter(item => !item.terminal), target];
    for (const state of states) {
        attach(state.firstPlayer);
        const attacker = work.attacker[state.t];
        function captureState(variant,wantStrategy) {
            install(variant);reset({pay:[]});
            let answer;
            try {answer = {result:work.solveState(attacker,state.maskP1,state.maskP2,
                work.layers[state.t+1],wantStrategy)};}
            catch(error) {answer = {error:error.message};}
            const acted = attacker===2 ? state.maskP2 : state.maskP1;
            const count = work.closedCount[acted];
            return {...answer,p:work.probP.slice(0,count),q:work.probQ.slice(0,count)};
        }
        for (const wantStrategy of [false,true]) {
            const expected = captureState(original,wantStrategy);
            for (const name of ['current','currentOldGap','currentSmallGap','currentOldSolve']) {
                const actual = captureState(variants[name],wantStrategy);
                if (!exact(expected,actual)) failures.push({scope:'solveState',name,state,wantStrategy,expected,actual});
                stateComparisons++;
            }
            stateCases++;
        }
    }
    function median(values) {
        const sorted = values.slice().sort((a,b)=>a-b);
        const n = sorted.length;
        return n&1 ? sorted[n>>1] : (sorted[n/2-1]+sorted[n/2])/2;
    }
    function summary(rows) {
        return {aMedianNs:median(rows.map(r=>r.a.nsPerCall)),
            bMedianNs:median(rows.map(r=>r.b.nsPerCall)),
            pairedMedianDeltaNs:median(rows.map(r=>r.b.nsPerCall-r.a.nsPerCall)),
            pairedMinDeltaNs:Math.min(...rows.map(r=>r.b.nsPerCall-r.a.nsPerCall)),
            pairedMaxDeltaNs:Math.max(...rows.map(r=>r.b.nsPerCall-r.a.nsPerCall))};
    }
    const timings = [];
    function paired(scope,test,aName,bName,runner) {
        const a = variants[aName],b = variants[bName];
        runner(a,warmup);runner(b,warmup);
        const rows = [];
        for(let pair=0;pair<pairs;pair++) {
            // Identical untimed preparation restores the same receiver/arrays.
            runner(a,2000);runner(b,2000);
            let first,second;
            if(pair&1) {second=runner(b,calls);first=runner(a,calls);}
            else {first=runner(a,calls);second=runner(b,calls);}
            if(!Object.is(first.checksum,second.checksum)) throw new Error('Timed checksum mismatch');
            rows.push({pair:pair+1,order:pair&1?'B,A':'A,B',a:first,b:second});
        }
        timings.push({scope,test,aName,bName,summary:summary(rows),pairs:rows});
    }
    if (timing && failures.length === 0) {
        const chosen = [targetTest,...cases.filter(test=>
            ['count2-positive','count2-zero','count2-negative','positive-ties'].includes(test.name)),
            cases.find(test=>test.name==='signed-9-0')];
        for (const test of chosen) {
            const eq = captureEquilibrium(current,test);
            if(eq.error) continue;
            function gapBatch(variant,count) {
                install(variant);reset(test);work.probP.set(eq.p);work.probQ.set(eq.q);
                const method = variant.strategyGap;
                let checksum = 0;
                const started=performance.now();
                for(let i=0;i<count;i++) checksum += method.call(work,test.pay.length,
                    work.pay,test.stay,eq.answer.value);
                const elapsedMs=performance.now()-started;
                return {elapsedMs,calls:count,nsPerCall:elapsedMs*1e6/count,checksum};
            }
            paired('strategyGap',test.name,'current','current',gapBatch);
            paired('strategyGap',test.name,'currentOldGap','current',gapBatch);
            paired('strategyGap',test.name,'current','currentSmallGap',gapBatch);
        }
        for (const test of [targetTest,...cases.filter(test=>
            ['count2-positive','count2-zero','count2-negative'].includes(test.name))]) {
            function eqBatch(variant,count) {
                install(variant);reset(test);
                const method=variant.equilibrium;
                let checksum=0;
                const started=performance.now();
                for(let i=0;i<count;i++) {
                    const result=method.call(work,test.pay.length,work.pay,test.stay);
                    checksum+=result.value+result.gap;
                }
                const elapsedMs=performance.now()-started;
                return {elapsedMs,calls:count,nsPerCall:elapsedMs*1e6/count,checksum};
            }
            paired('equilibrium',test.name,'current','current',eqBatch);
            paired('equilibrium',test.name,'currentOldGap','current',eqBatch);
            paired('equilibrium',test.name,'current','currentSmallGap',eqBatch);
            paired('equilibrium',test.name,'original','current',eqBatch);
        }
        attach(1);
        function stateBatch(variant,count) {
            install(variant);reset({pay:[]});
            const method=variant.solveState;
            const child=work.layers[target.t+1];
            let checksum=0;
            const started=performance.now();
            for(let i=0;i<count;i++) {
                const result=method.call(work,target.attacker,target.maskP1,target.maskP2,child,true);
                checksum+=result.value+result.gap+result.breakStrategy[0]+result.blockStrategy[0];
            }
            const elapsedMs=performance.now()-started;
            return {elapsedMs,calls:count,nsPerCall:elapsedMs*1e6/count,checksum};
        }
        paired('solveState+packStrategy',targetTest.name,'current','current',stateBatch);
        paired('solveState+packStrategy',targetTest.name,'currentOldGap','current',stateBatch);
        paired('solveState+packStrategy',targetTest.name,'current','currentSmallGap',stateBatch);
        paired('solveState+packStrategy',targetTest.name,'original','current',stateBatch);
        paired('solveState+packStrategy',targetTest.name,'currentOldSolve','current',stateBatch);
    }
    this.result = {
        passed:failures.length===0,
        productionModified:false,
        equality:'Object.is recursively; signed zero and NaN distinguished/preserved',
        equilibriumCases:cases.length,certified,matchingErrors,
        equilibriumComparisons:cases.length*3,
        arbitraryDistributionCases:distributionFixtures.length,
        directGapComparisons,stateCases,stateComparisons,
        target:{...target,pay:targetTest.pay,stay:targetTest.stay,
            value:targetAnswer.value,gap:targetAnswer.gap,
            p:Array.from(targetAnswer.breakStrategy),q:Array.from(targetAnswer.blockStrategy)},
        failures,
        candidateSource:smallCountGap.toString(),
        timingPerformed:timing,
        timingScope:'One Node V8 realm/receiver; not Chromium selector or real-click timings',
        timingConditions:{pairs,callsPerBatch:calls,warmupPerVariant:warmup,
            preBatchWarmup:2000,alternatingOrder:true,aaUsesSameFunctionReferences:true},
        strictNonRegressionGuarantee:false,
        timings
    };
`, context, {filename:'same-realm-gap-cause-probe.js'});
const result = context.result;
function sha256(bytes) { return crypto.createHash('sha256').update(bytes).digest('hex'); }
Object.assign(result, {runtime:process.version,
    sources:{before:{path:oldPath,sha256:sha256(oldHtml)},
        after:{path:newPath,sha256:sha256(newHtml)}},
    savedValues:[1,2].map(firstPlayer => ({firstPlayer,
        path:path.join(root,`validation/before/whole-first${firstPlayer}.bin`),
        sha256:sha256(Buffer.from(data[firstPlayer-1]))}))});
fs.mkdirSync(path.dirname(output), {recursive:true});
fs.writeFileSync(output, JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({output,passed:result.passed,
    equilibriumCases:result.equilibriumCases,directGapComparisons:result.directGapComparisons,
    stateCases:result.stateCases,stateComparisons:result.stateComparisons,
    target:result.target,timingPerformed:result.timingPerformed,
    timings:result.timings.map(row=>({scope:row.scope,test:row.test,
        aName:row.aName,bName:row.bName,...row.summary})),
    failures:result.failures.slice(0,3)},null,2));
if (!result.passed) process.exitCode=1;
