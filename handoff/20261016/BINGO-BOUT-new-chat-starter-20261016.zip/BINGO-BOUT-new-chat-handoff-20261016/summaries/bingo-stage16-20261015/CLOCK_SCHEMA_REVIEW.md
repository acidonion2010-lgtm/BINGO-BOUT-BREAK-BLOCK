# Pinned Perfetto packet-clock schema review

Revision: Perfetto `5dbeaad4ceb91470a835426b52e0cb43a3e5ef10`, pinned by Chromium `73c14f6228d7cd537c855007e8f88678969cc0eb` (stage15 DEPS evidence). This is a static source review for a minimal wire decoder. No browser, jobs, runtime/performance experiment, installation or system change. New source originals are in `official-sources/clock-schema-review/`, with immutable official URLs, SHA-256, byte counts and preserved original license headers in `MANIFEST.json`; the upstream LICENSE is also included. Stage15 files were read/copied, not changed.

## Wire field map

All scalar fields below use protobuf **wire type 0 (varint)** unless stated otherwise. A message / bytes field uses **wire type 2 (length delimited)**. Field key is `(field_number << 3) | wire_type`. `uint64` / `uint32` are unsigned varints, not ZigZag.

| Message | Field | Number | Declared type | Meaning |
|---|---|---:|---|---|
| Trace | packet | 1 | repeated TracePacket (wire 2) | Saved-file packet wrapper; process packets in file order |
| TracePacket | timestamp | 8 | uint64 | Clock-domain timestamp; absolute or unsigned delta according to the selected clock |
| TracePacket | timestamp_clock_id | 58 | uint32 | Explicit nonzero clock ID takes priority over sequence defaults |
| TracePacket | trusted_packet_sequence_id | 10 | uint32 | Producer/writer sequence; 0 is invalid for sequence clocks |
| TracePacket | clock_snapshot | 6 | ClockSnapshot (wire 2) | Defines / reanchors clock domains |
| TracePacket | sequence_flags | 13 | uint32 | Bit 0 cleared; bit 1 needs incremental state |
| TracePacket | incremental_state_cleared | 41 | bool | Deprecated equivalent to clear flag |
| TracePacket | previous_packet_dropped | 42 | uint32 | 0=no drop; any nonzero invalidates incremental state unless this packet clears it |
| TracePacket | trace_packet_defaults | 59 | TracePacketDefaults (wire 2) | Updated before timestamp resolution, including same packet |
| TracePacket | interned_data | 12 | InternedData (wire 2) | Sequence incremental state, separate from clock accumulator |
| TracePacket | track_event | 11 | TrackEvent (wire 2) | Event data, not the outer packet timestamp |
| TracePacket | track_descriptor | 60 | TrackDescriptor (wire 2) | May also be carried in timestamped packets |
| TracePacket | first_packet_on_sequence | 87 | bool | First writer packet; absence does not prove a loss |
| TracePacket | machine_id | 98 | uint32 | Requires machine scoping if nonzero / multi-machine |
| TracePacket | compressed_packets | 50 | bytes (wire 2) | Compressed nested Trace data; do not parse as a TrackEvent |
| TracePacket | zstd_compressed_packets | 133 | bytes (wire 2) | zstd counterpart; unsupported codec must be diagnosed |
| TracePacketDefaults | timestamp_clock_id | 58 | uint32 | Per-sequence default; not a global clock ID replacement |
| ClockSnapshot | clocks | 1 | repeated Clock (wire 2) | Snapshot readings of domains at the same reference instant, within sampling limits |
| ClockSnapshot | primary_trace_clock | 2 | BuiltinClock enum | Authoritative trace time clock, when set |
| ClockSnapshot.Clock | clock_id | 1 | uint32 | Domain ID, scoped as below |
| ClockSnapshot.Clock | timestamp | 2 | uint64 | **Absolute snapshot reference**, even for incremental clocks |
| ClockSnapshot.Clock | is_incremental | 3 | bool | Packet timestamps referring to this clock are deltas |
| ClockSnapshot.Clock | unit_multiplier_ns | 4 | uint64 | Raw timestamp units → ns; absent / 0 is treated as 1 by pinned importer |

Authoritative field references: `trace.proto:23–24`; `trace_packet.proto:132–145,153–154,181,256–261,367–412,422,473,487,493`; `trace_packet_defaults.proto:31–32`; `clock_snapshot.proto:42–81`.

## Clock IDs and numeric types

- Builtin IDs: UNKNOWN=0, REALTIME=1, REALTIME_COARSE=2, **MONOTONIC=3**, MONOTONIC_COARSE=4, MONOTONIC_RAW=5, **BOOTTIME=6**, reserved 7/8, TSC=9, PERF=10, synthetic TRACE_FILE=11, MAX builtin=63 (`builtin_clock.proto:34–76`). Builtins are shared across packet sequences on the same machine; they are not a per-thread CPU counter.
- IDs **64–127 are sequence-scoped** (`clock_snapshot.proto:42–49`; `clock_synchronizer.h:150–152,173–175`). State must be keyed by trace/file, machine where applicable, trusted packet sequence, and clock ID. Never share clock64's accumulator across sequences. The schema reserves 128+ for future global user clocks; a restricted decoder should diagnose unfamiliar IDs / missing mappings instead of guessing.
- TrackEvent writer specifically uses **64 for incremental timestamp units** and **65 for absolute custom timestamp units** (`include/perfetto/tracing/internal/track_event_internal.h:142–151`). These are writer conventions, not universal definitions hardcoded by the clock schema.
- Outer `TracePacket.timestamp` and snapshot reference are **uint64**. Do not apply ZigZag or signed-delta decoding. The pinned importer casts them into signed int64 internally (`proto_trace_reader.cc:478–480`); a minimal decoder should retain exact integers and flag values/products outside its supported int64 range rather than silently overflowing or losing precision. Do not use floating point for raw nanosecond arithmetic.
- Legacy TrackEvent timestamp/thread-time fields are a separate scheme: `timestamp_delta_us=1`, `timestamp_absolute_us=16`, `thread_time_delta_us=2`, `thread_time_absolute_us=17`, all **int64**, not sint64 (`track_event.proto:405–436`). Standard int64 negative values use two's-complement varints, not ZigZag. Legacy absolutes are one-off and do not advance the corresponding legacy delta baseline. Modern `extra_counter_values=12` is repeated int64; it is also separate from the packet wall-clock delta. CPU/counter reconstruction is outside this clock-only review.

## Correct processing order and state

The pinned official reader order is explicit (`proto_trace_reader.cc:321–365`):

1. Obtain sequence ID. If either deprecated clear=true or `sequence_flags & 1`, clear incremental state. Otherwise, if drop is nonzero, mark incremental state invalid. Thus clear takes priority when clear and drop occur on the same packet.
2. Read / replace `trace_packet_defaults`, then interned data. Defaults can affect the timestamp on **this same packet** (`:349–359`).
3. If a ClockSnapshot is present, parse it and **return** (`:361–362`). Do **not** also feed this packet's outer timestamp through the normal incremental clock conversion; that would double-apply a reference/delta in an ad hoc decoder.
4. For ordinary packets requiring incremental state (`sequence_flags & 2`), reject seq=0 and skip when state is invalid (`:397–426`). The initial generation is invalid; clear makes it valid and clears defaults; drop produces an invalid generation (`packet_sequence_state_generation.cc:69–103`).
5. For a normal timestamped packet choose nonzero explicit clock ID, else nonzero per-sequence default, else format / trace default (`proto_trace_reader.cc:478–497`). Sequence IDs64–127 require a nonzero sequence ID (`:520–529`). Decode timestamp and advance a delta accumulator **once, in raw packet order**. Do this for every relevant timestamped packet, including descriptor packets, not just packets containing a TrackEvent.

Clock accumulation is a different layer from interned/default validity. The official clock accumulator lives in `ClockSynchronizer::ClockDomain`, not the generation object. A clear flag alone does not imply a zero wall-clock value; a valid new snapshot reanchors the domain (`clock_synchronizer.cc:115–116`). After loss or an unsupported/unresolved interval, a restricted decoder must not claim continuous timing without a new valid reference / source-backed recovery.

If timestamp is absent the full importer uses the latest/sorter maximum (`proto_trace_reader.cc:540–541`); that is an ordering fallback, not a new measured clock sample. A forensic decoder should label the value inferred or leave it absent.

## Snapshot units, reference mapping, and increments

`proto_trace_reader.cc:739–761` scopes sequence clocks, defaults multiplier 0 to 1, and passes each absolute snapshot reading to ClockTracker. `ClockSynchronizer::AddSnapshot` verifies that incremental encoding only belongs to sequence clocks (`clock_synchronizer.cc:81–89`), that a domain's unit/incremental properties do not change (`:91–105`), that the trace/primary clock has multiplier 1 (`:107–113`), and that snapshots do not repeat a domain (`:118–125`). It sets:

`last_clock_ns = snapshot.timestamp * unit_multiplier_ns`

For a subsequent packet on this domain (`clock_synchronizer.h:392–400`):

- Absolute clock: `clock_ns = packet.timestamp * unit_multiplier_ns`.
- Incremental clock: `last_clock_ns += packet.timestamp * unit_multiplier_ns`; result is the new absolute clock value. Delta zero is valid. Only packets referencing that exact scoped clock update its accumulator.
- A later ClockSnapshot containing the domain resets `last_clock_ns` to its newly supplied absolute reference, rather than adding the snapshot reading as a delta.

A paired snapshot `(source_clock, S_ns)` and `(target_clock, T_ns)` relates them by an offset. For the simple supported one-reference/same-rate case:

`target_ns = source_ns + (T_ns - S_ns)`.

For example, a snapshot of MONOTONIC3 at `A_ns` and clock64 at `B_units`, multiplier1000/incremental=true, makes the next raw64 delta `d` map to `A_ns + d*1000`. Subsequent packet deltas accumulate from that reference. Explicit clock3 packet timestamps remain clock3 ns and must **not** receive clock64's multiplier1000.

The full importer maintains a graph across snapshot sets, selects the preceding source snapshot using upper_bound (the first snapshot when timestamp predates all), and adds matching target-source offsets per hop (`clock_synchronizer.cc:240–284`); it does not simply apply one final snapshot offset to every packet. It rejects / excludes nonmonotonic source domains (`:137–176`), validates primary monotonicity, supports cached paths and graph hops. If a restricted decoder supports only direct64↔3 and65↔3 mappings with stable offsets, it must report all other graph cases and changing mappings as unsupported, not silently generalize.

The SDK writer confirms these rules (`src/tracing/internal/track_event_internal.cc:429–518,526–555`): reset emits a trace clock snapshot and a clock64 snapshot with `is_incremental=true`, optionally clock65 with `is_incremental=false`; units are from configuration. `NewTracePacket` encodes nonnegative timestamp differences in clock64, advances its own saved baseline by represented units, and uses an explicit absolute clock ID (global trace clock or clock65) if the timestamp is earlier than its saved baseline (`:535–547`). Backdating is **not** encoded as a negative uint64 delta.

## Primary clock and minimal-decoder limits

ClockSnapshot primary_trace_clock, when nonzero, sets both trace-default clock and global trace clock (`proto_trace_reader.cc:764–768`). The pinned builtin documentation defines initial synthetic TRACE_FILE11; legacy proto fallback is BOOTTIME6 when appropriate. The reader also infers BOOTTIME if a snapshot contains BOOTTIME but no TRACE_FILE and lacks a primary (`:770–788`). Schema comments mentioning default BOOTTIME are not a reason to hardcode every unspecified modern packet to6. For the current Chromium profile, verify the emitted primary/default/snapshot fields before applying MONOTONIC3 assumptions.

A minimal decoder may authoritatively report wire fields, scoped references, raw accumulated clock values and direct verified mappings. It cannot claim general Perfetto import/export equivalence without compression handling, loss/recovery, multiple snapshots/clock paths, machine/file scoping, defaults, and legacy field support. It should retain packet byte offsets / sequence / selected clock / units / raw delta / reference and diagnostics to make every conversion reproducible. It must not use a wall-clock schema success to validate a thread CPU clock reading or attribute CPU>wall to a particular runtime cause.
