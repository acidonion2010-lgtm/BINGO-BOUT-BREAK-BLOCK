# 段階14：HARDクリックと描画区間の同時記録

**過去のHARD増加の原因は未確定。** 今回の4回では、原本→段階3の同期handler差、原本→段階5の2RAF差はいずれも増減が混在した。同時記録から、各クリックの同期Style/Layoutと描画callbackの区間を確認できた。一方、3区間でCPU時間差がwallを2.3〜6.7ms超え、CPU寄与率を厳密に示せないという時計の制約も見つかった。

正式288クリック＋別記録warmup32、16通常読込の自己テスト5,152件、16実Worker準備、32計時外selector監査が完了。全16trace・1,280marker・640 RAFのframe対応と区間集計を独立照合した。本体・元480ファイル・過去成果物・リポジトリmainは変更していない。

## 対象と今回の条件

原本、段階3.final、段階5、現在の段階9を4fresh Chromiumで通常読込。Williams4順序で各版のvisit位置を均衡した。P1先攻の固定中盤（maskP1=3、maskP2=24、両者4ターン済み）で人間P1がcell2をBREAKし、CPU(P2)がBLOCKする。

HARD readyDPは固定乱数0.8、対照のHARD従来分岐は0.3。従来分岐でもWorkerはreadyのままであり、fallbackではない。各visit・分岐はwarmup1＋正式9。通常locator.clickを使い、音・BGM・CSS演出を残した。ゲーム関数参照は交換していない。

各visitを連続traceに取り、capture、handler後、1回目・2回目RAFの4markで切り分けた。trace/mark/RAF監視・事前監査自体が実行を変える診断であり、無計装の製品latencyではない。物理入力、画面提示、演出完了、スピーカー出力は測定しない。

## 主要な操作時間

9正式クリックのvisit中央値同士の差（後−前、ms）。trialを独立した版間対標本とは扱わず、4runを記述する。

| HARD readyDP比較 | run1 | run2 | run3 | run4 |
| --- | ---: | ---: | ---: | ---: |
| 原本→段階3・同期handler | −0.30 | −0.10 | +0.30 | 0.00 |
| 原本→段階5・2RAF | +1.10 | −0.50 | −0.50 | +0.20 |
| 段階5→段階9・同期handler | +0.20 | +0.20 | −0.20 | +0.20 |
| 原本→段階9・同期handler | −0.40 | +0.10 | +0.30 | −0.10 |

HARD従来分岐の原本→3 handler差も−0.30,+0.10,+0.10,−0.10ms、原本→5 2RAF差も+0.20,−0.20,+0.30,−0.10msだった。対照をDP結果から差し引かない。

過去の+0.45msは原本→3、+0.50msは原本→4、+0.80msは原本→5の別々の測定だった。今回stage4は対象外。旧stage3ではHARD前にNORMALのクリック履歴もあり、無traceの旧標本と今回をプールしない。今回の符号反転で旧観測を消したり原因解消としたりしない。出典・旧集計の違いはHISTORICAL_SCOPE.md。

## 同期処理と描画callbackのwall区間

HARD readyDPの16visit中央値の範囲を示す。各分類はそのwindowへclipしたXイベントのunionであり、重複分類を合計して総費用としない。

| 区間・直接観測 | visit中央値の範囲（ms） |
| --- | ---: |
| 同期handler・trace wall | 2.982〜3.600 |
| 同区間のStyle/Layout union | 1.632〜1.875 |
| handler後→1RAF・trace wall | 6.218〜8.852 |
| 同区間のStyle/Layout union | 0.735〜0.861 |
| 1RAF→2RAF・trace wall | 15.953〜16.338 |
| 同区間のPaint系union | 0.649〜0.787 |
| 同区間のcommit待ちunion | 0.236〜0.289 |

同期handlerにStyle/Layoutのwall区間を多く観測したが、これをCPU自己時間やselector単体の費用とは呼ばない。原本→3のhandler trace wall差は−0.239,−0.008,+0.339,−0.017ms、Style/Layout差も−0.098,−0.027,+0.153,−0.007msで、増加方向は固定されなかった。

原本→5の2RAFが増えたrun1では、capture→2RAF trace wall差+1.143ms、handler後→1RAF差+2.147ms、1→2RAF差−0.137msだった。個々の中央値差は加算できず、これだけで因果寄与を割り振らない。

全640 callbackについてmain_frame_id、SendBeginMainFrame、Scheduler sequence、Viz tickを対応付けた。遅いcallbackの出る区間も一様ではなかった。例えば、run2段階9・DP trial3ではframe時刻→送信0.337ms、送信→main開始0.112ms、main開始→marker4.163ms。一方、run1段階3・従来trial1は3.376/0.096/0.673msだった。この対応は遅れた区間を示すが、最終的なOS/GPU原因や物理提示を特定しない。

全288正式試行の1→2RAFでcommit待ちイベントを観測した。最大は2.589ms。特定名のcommit待ちはGPU待ち総量ではない。全正式responseに交差する記録GC区間はなかったが、GCイベント自体は各visitで記録されており、GC全般が0コストという証明ではない。

## 新たに見つかったCPU時計の制約

| 試行 | 区間 | wall / 記録tts差（ms） |
| --- | --- | ---: |
| run1 原本 従来 trial9 | handler→1RAF | 7.347 / 9.630 |
| run3 原本 従来 trial3 | handler | 3.416 / 8.583 |
| run4 段階5 DP trial3 | handler | 3.128 / 9.848 |

console TimeStampでも同様にCPU差がwallを上回り、近傍の完了Xにもtdur>durを観測した。単純なserializationや丸めの誤差とは扱わない。元の値・負の残差・全試行を保持し、除外や0補正をしない。今回のCPU寄与率やwall−CPUによる待機量は確定しない。長い親区間がCPU<=wallでも、含まれる時計増分の妥当性は自動で回復しない。

追加の固定計画に従い、別native processでLinuxのCLOCK_MONOTONICとCLOCK_THREAD_CPUTIME_IDを512区間確認した。外側wallでCPU区間を包み、全件でCPU差<=外側wall差だった。これは異なる取得法・実行条件の限定確認で、Chromium側の原因やCPU会計を承認するものではない。追加ブラウザー計測はしていない。詳細はCLOCK_VALIDITY.md、clock-audit.json、native-clocks.json。

## 機能と完全性

- 全320クリックがtrustedでcell2受理、REVEAL表示、可視/disabled/処理状態、audioCtx runningと音/BGMフラグを確認。
- 全DPクリックがwhole=1/DP=1/legacy=0、従来クリックがwhole=0/DP=0/legacy=1。
- 32計時外監査ではCPU BLOCKがDP cell7・乱数2回、従来cell2・乱数4回で全版一致。公開入力・履歴も不変。**正式クリック内のlocalなCPU BLOCK戻り値を保存した証拠ではない。** 正式probeのselectedBreakCell=2は人間のBREAK。
- 16×322=5,152自己テストと16実Worker準備が成功。page errorなし。全版のWorker statsも一致。
- 全16traceはhash・EOF・dataLoss=false・buffer未充満。buffer最大約9.412%。getCategoriesは4回とも空だったが、要求リストをfilterせず実traceのtimeline/task/frameを検証した。
- 全1,280marker、4区間×320試行の時計差、カテゴリunion、640frame対応、visit中央値と版間差、CSV320行を別実装で独立照合。算術の一致とCPU会計の妥当性は区別する。
- 元480ファイルと段階13成果物のhashは不変、リポジトリmainはclean。今回のindex.htmlも段階9そのまま。

未確定62条件、過去のHARD差の直接原因、段階8のraster/GPU/通知ごとの寄与、cold入力・実端末・全配置/全browserの未確認を保持する。今回の結果を厳密な全経路非悪化PASSへ拡張しない。

再現はREPRODUCE.md、事前計画はPLAN.mdとCLOCK_PLAN.md、独立レビューはPRE_RUN_REVIEW.mdとPOST_RUN_REVIEW.md。全詳細値はanalysis.json/.csvとINTERPRETATION.md、生データはreport.jsonとtraces/。
