# Stage 4 validation

This is historical stage4 evidence. The standalone scripts use the frozen
`stages/index.stage4.html`. To reproduce stage4 browser runs below, use that file
in place of the `index.html` argument. The latest validation is in `stage5/`.

Production needs only `index.html`. These are development tools using the existing
Node, Python Playwright, and Chromium. Run browser jobs sequentially. Commands
below run from the unpacked `bingo-refactor` directory.

```bash
node validation/stage4/max_scores.cjs
node validation/stage4/max_scores_performance.cjs
node validation/equilibrium_edges.cjs
python3 validation/capture.py index.html validation/stage4/after --repeats 1 --port 8004
python3 validation/compare.py validation/before validation/stage4/after --output validation/stage4/comparison.json
python3 validation/worker_lifecycle.py index.html --out validation/stage4/worker.json
python3 validation/performance.py index.before.html index.html validation/stage4/startup-performance.json --port 8004
python3 validation/stage3/ui_response.py index.before.html index.html validation/stage4/ui-response.json --runs 5 --difficulties hard --trials 9
python3 validation/gameplay_smoke.py --file index.html --out validation/stage4/gameplay-smoke.json
python3 validation/stage4/click_causality.py
```

If original DP binaries are absent after unpacking, regenerate them before compare:

```bash
python3 validation/capture.py index.before.html validation/before --repeats 1 --port 8004
```

The standalone max-score comparison uses actual buildScores-generated inputs and
Object.is, including signed zero and nonfinite values. It does not solve a full game.
The method benchmark uses one VM and shared topology, an A/A control and alternating
A/B pairs. Reported array construction bytes come from source, not measured process
memory. Normal fresh-page startup/Worker preparation are measured separately.

The causal diagnostic deliberately uses the frozen stage3.final HTML. It switches
six methods on the same DP receiver, validates policy equality, records inclusive
component timings, and observes finite animations finishing naturally. It changes
callsite feedback and uses COOP/COEP for a finer performance clock. Results are not
a whole-HTML or all-device performance guarantee. Overlapping inclusive timings
must not be summed. The regular UI comparison uses current unmodified HTML, actual
sound/animations, 90 measured trusted clicks and 10 separate warmup clicks. Two RAF
callbacks do not measure physical presentation or input-device latency.

`summary.json` distinguishes functional completion from the still-unverified
strict all-path performance requirement. The latest HARD handler difference is
-0.10 ms, but two-RAF difference is +0.50 ms. The earlier +0.45 ms handler result is
not uniquely explained. All samples remain in the JSON reports. See
`段階4比較結果.md` for the implementation, comparisons, resolved harness issues and
unfinished items. Historical stage2/3 evidence remains available.
