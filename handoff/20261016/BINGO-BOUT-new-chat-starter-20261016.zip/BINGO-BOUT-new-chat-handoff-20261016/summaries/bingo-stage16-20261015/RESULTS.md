# 段階16：元protobufとCPU時計経路の照合（2026-10-15 JST）

**JSON変換前にもCPU時間超過があり、今回の大きな超過26件はすべて差分記録状態のリセットをまたいでいた。CPU差分の端数切り捨てが累積し、リセットで回復する仕組みが有力な候補になった。実データでの単独原因はまだ確定していない。** ゲーム本体は変更していない。

## 固定回数の取得

事前確認1ブラウザーの成功後、原版HTMLだけを4つの新規Chromiumで逐次取得した。HARDのDP/ready-engine legacy分岐を交互の順序にし、各分岐でウォームアップ1回・本計測3回。合計は本計測24回、暖機8回。途中再試行、追加ブラウザー、サンプル除外、A/A差し引き、許容幅の後付けはない。性能比較を行う試験ではない。

全5回の通常ロードで自己テスト322/322、合計1,610件が成功し、正式4回は実Worker準備完了。全クリックで機能・状態・分岐・可視性・通常のtrusted入力・4段階markerの対応を確認した。ゲーム関数参照の置換はない。サウンド/BGM/アニメーションは有効、headlessの標準mute-audio条件なので物理音声や画面提示の遅延を表さない。無計測selector auditは入力・乱数・選択の確認であり、実クリック中のローカルCPU選択cellを直接記録したものではない。

raw protobuf 5本（40,137,136 bytes）と、その**同一入力**から生成したJSON（85,014,725 bytes、338,523 events）を保存した。stream EOF・dataLossOccurred=false・buffer-fullなしを確認。公式Perfetto v58.2 binaryはChromiumの固定Perfetto原文の配布manifest SHAに一致するが、Chromium内蔵exporterと同じbuildであるとは主張しない。

## 元カウンターまでの対応

| 対象 | 結果 |
| --- | --- |
| renderer-mainのXイベント全体 | 78,837件 |
| wall/CPU両方を持つX | 69,376件（欠測9,461件はこの分母に含まない） |
| JSONでCPU > wall | 1,468件。入れ子を含み、独立事象の件数ではない |
| JSONでCPU超過 > 1ms | 26件、正式runごと12 / 6 / 3 / 5 |
| 同一proto公式SQLのns値との対応 | 全69,376件が整数µs化後に一致、欠落0 |
| ns単位で厳密にCPU > wall | 1,478件。JSONとの10件差はns/µsの表現差として区別 |
| 元thread_timeカウンター | 167,205 samplesが公式SQLとUUID/value多重集合で全数一致 |
| 元marker CPU端点 | 260/260がJSON ttsに一致、欠測0 |
| 大きな超過のraw BEGIN/END CPU端点 | 26/26で一意に対応 |
| 本計測marker区間 | 144区間、全て両clockあり、超過0 |
| 暖機marker区間 | 48区間、全て両clockあり、超過0 |

大きな26件はいずれも正式・暖機のcapture→second RAF区間と交差しなかった。これを理由に全traceの超過から除外していない。独立補助decoderはwall clockを共通化しない。未対応legacy nested annotationの診断も全て保持し、完全なPerfetto decoderとして成功したとは扱わない。

## リセットと端数の関係

26件のraw BEGIN/ENDは全て異なるsequence epochにあり、同じsequenceのclearを内部に含む。固定PerfettoソースのCPU処理は、`current_cpu_ns - previous_actual_cpu_ns`で差を取り、前値を除算前のactual nsへ更新してから、差を単位倍率で整数除算して記録する。倍率が1,000なら各回の端数が失われうる。リセット後は前値ゼロからCPU絶対値を記録するため、それまでの切り捨て分が見かけ上戻る可能性がある。

これに対しwallのincremental timestamp処理は、前値へ`encoded_delta × multiplier`だけを足し、端数を次回へ持ち越す。CPUとwallの処理は同じではない。リセットをまたぐことだけで個々の異常の単独原因とは断定せず、真のCPU差分が非負である場合に導く切り捨て誤差上限に、26/26件が適合した。zero emissionを含める数え方は上限を緩くし、実際の端数を推定するものではない。14の追加clear境界では、前後counterを一意対応できた9境界のうち8でCPUstep−wallgapが正（0.191–8.972ms）、1で負、5境界は同値counter候補が複数のため保留した。全て残し、有利な対応候補を選んでいない。独立レビューもこの条件付き上限を確認した。

### 構成対照の結果

[固定計画](decoder-validation/CONTROL_PLAN.md)を保存してから、構成データ1本・公式JSON変換1回を実施し、事前の数値予測7項目が全て一致した。再試行はない。真のCPUとwallがともに1,500nsずつ進む20,000回の差分で、CPUだけ10,000,000nsの端数損失を作り、BEGIN直後のclearで回復させた。

対象BEGIN→ENDの真のCPU/wall経過は双方1,500ns。それでも公式JSONは **wall 1µs、CPU 10,001µs** を出した。実時計の異常を入れず、ソースの符号化方式とclearだけで見かけの超過を構成できた。この十分な構成例と実データの整合性は区別する。実際のclear実行時点・失われた端数まで再現したとは主張しない。

生成器、raw fixture、期待値、唯一の変換コマンド、stdout/stderr、7項目の照合、hashは[構成対照の結果](decoder-validation/source-quantization-control/RESULTS.md)に保存した。ブラウザーやゲームの追加実行ではない。

## exportを経ないCPU記録

CDP Performance.ThreadTimeは、固定Chromiumソースではrenderer mainのThreadTicksを直接読み、trace exportを経ない。下位のCLOCK_THREAD_CPUTIME_IDはPerfettoと共有するため、独立した物理CPU時計ではない。TaskDurationもthreadTicksで記録したが、JS handlerだけの時間ではない。

全33操作の前後でCDP・host MONOTONIC・proc schedstatを保存した。正式24回のThreadTime差・TaskDuration差はいずれもhost外側wallを超えなかった。marker CPUとCDP前後CPUから作る固定originの可能区間は各visitで共通部分があったが、広い包絡区間における弱い整合性であり、細かなCPU会計の正確さを証明しない。

Linuxの外部thread clockidは同じthread-group制限により取得不可。schedstatはns表記でも読取時点まで更新される保証がない。66個のproc端点で対象identityが一致し、正式24件のruntime差は12.013–18.829ms、外側wallは58.338–81.411ms。core両端値の変化は2件あったが、完全なmigration履歴や原因の証拠とはしない。

## 残る範囲と保存

今回除けたのは、CPUカウンター値がJSON exporterだけで別の値に変わったという説明の必要性である。wall取得・clock snapshot・clock変換、採取時点、カーネルCPU時計、量子化以外の要因も未確定。段階14の3応答区間や段階15の169件を、元protobufのないまま今回の候補で説明済みに変更しない。

旧104条件の分類は42件が反復非増加・62件が未確定のまま。HARDの旧差の原因、全経路の厳密非退行、Chromiumの厳密CPU会計を確認したとはしない。元handoff 480ファイル、段階14/15の全manifest、repo mainのclean状態、原版/current HTMLのhashが不変であることを確認した。

再現方法は[REPRODUCE.md](REPRODUCE.md)、固定予算は[PLAN.md](PLAN.md)。[POST_RUN_REVIEW.md](POST_RUN_REVIEW.md)、[CPU_OUTER_REVIEW.md](CPU_OUTER_REVIEW.md)、[PROTO_DECODE_REVIEW.md](PROTO_DECODE_REVIEW.md)、元raw/SQL/JSON/全ledger・診断・公式ソースとLICENSEを一式に保持する。
