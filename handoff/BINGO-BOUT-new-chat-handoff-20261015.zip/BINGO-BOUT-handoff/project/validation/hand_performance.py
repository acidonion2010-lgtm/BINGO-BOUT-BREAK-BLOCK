#!/usr/bin/env python3
"""Paired, interleaved warmed selection timing for both first players."""
import argparse
import functools
import http.server
import json
from pathlib import Path
import statistics
import threading
from playwright.sync_api import sync_playwright
from performance import MEASURE_PREPARATION

CONFIGURE = '''({firstPlayer,role,difficulty}) => {
  const dp=cpuWholeDp;
  const t=dp.attacker[8] === (role === 'break' ? 2 : 1) ? 8 : 9;
  Object.assign(state,{cpuDifficulty:difficulty,firstPlayer,
    p1Marks:Array.from({length:9},(_,i) => Boolean(3 & (1 << i))),
    p2Marks:Array.from({length:9},(_,i) => Boolean(24 & (1 << i))),
    p1TurnsTaken:firstPlayer === 1 ? (t+1)>>1 : t>>1,
    p2TurnsTaken:firstPlayer === 2 ? (t+1)>>1 : t>>1,
    cpuBlockedBreakCell:0,cpuBlockedBreakStreak:2,cpuBlockedCooldown:0,
    cpuSuccessfulBlockCell:0,cpuSuccessfulBlockStreak:2,cpuSuccessfulBlockCooldown:0});
  Math.random=() => 0.8;
}'''
TIMED = '''({role,count}) => {
  const available=[0,1,2,5,6,7,8];
  const started=performance.now();
  for (let i=0;i<count;i++) {
    if (role==='break') selectCpuBreakCell(available);
    else selectCpuBlockCell(state.p1Marks,state.p1NumberLayout);
  }
  return (performance.now()-started)/count;
}'''

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('before',type=Path);parser.add_argument('after',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--port',type=int,default=8001)
    args=parser.parse_args()
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*unused):pass
    server=http.server.ThreadingHTTPServer(('127.0.0.1',args.port),functools.partial(Handler,directory='/workspace'))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    result={'conditions':{'executable':'/usr/bin/chromium','firstPlayers':[1,2],
        'warmupCalls':20000,'callsPerBatch':20000,'pairedBatches':9,'fixedRandom':0.8,
        'normalization':'ms per decision; available cells precomputed in both versions',
        'hardBranch':'whole-game branch (random 0.8 >= 0.7)'},'rows':[]}
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,
                args=['--no-sandbox','--disable-dev-shm-usage'])
            pages={key:browser.new_page(viewport={'width':1280,'height':900}) for key in ['before','after']}
            for key,page in pages.items():
                path=getattr(args,key).resolve()
                page.goto(f'http://127.0.0.1:{args.port}/{path.relative_to(Path("/workspace"))}',wait_until='load',timeout=60000)
            for firstPlayer in [1,2]:
                for page in pages.values():
                    source=MEASURE_PREPARATION.replace('firstPlayer:1,',f'firstPlayer:{firstPlayer},').replace('releaseWholeGameCpu(); return metrics;','return metrics;')
                    page.evaluate(source)
                for role in ['break','block']:
                    for difficulty in ['normal','hard','master']:
                        for page in pages.values():
                            page.evaluate(CONFIGURE,{'firstPlayer':firstPlayer,'role':role,'difficulty':difficulty})
                            page.evaluate(TIMED,{'role':role,'count':20000})
                        samples={'before':[],'after':[]}
                        for batch in range(9):
                            order=['before','after'] if batch%2==0 else ['after','before']
                            for key in order:samples[key].append(pages[key].evaluate(TIMED,{'role':role,'count':20000}))
                        b=statistics.median(samples['before']);a=statistics.median(samples['after'])
                        result['rows'].append({'firstPlayer':firstPlayer,'role':role,'difficulty':difficulty,
                            'beforeMedianMs':b,'afterMedianMs':a,'changePercent':(a/b-1)*100,'samples':samples})
                        print(f'first {firstPlayer} {difficulty} {role}: {b*1000:.3f} → {a*1000:.3f} us',flush=True)
                for page in pages.values():page.evaluate('() => releaseWholeGameCpu()')
            browser.close()
    finally:
        server.shutdown();server.server_close()
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
