#!/usr/bin/env python3
"""Capture an unmodified HTML's CPU behavior in the installed Chromium."""
import argparse
import functools
import http.server
import json
from pathlib import Path
import statistics
import threading
import time
from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('html', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--port', type=int, default=8001)
    parser.add_argument('--repeats', type=int, default=5)
    args = parser.parse_args()
    html = args.html.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *unused):
            pass
        def do_POST(self):
            if not self.path.startswith('/__snapshot__/'):
                self.send_error(404); return
            name = Path(self.path).name
            if name not in ('whole-first1.bin','whole-first2.bin'):
                self.send_error(400); return
            (output / name).write_bytes(self.rfile.read(int(self.headers['Content-Length'])))
            self.send_response(200); self.end_headers()
    handler = functools.partial(Handler,directory=str(ROOT))
    server = http.server.ThreadingHTTPServer(('127.0.0.1',args.port),handler)
    thread = threading.Thread(target=server.serve_forever,daemon=True)
    thread.start()
    records = {'source':str(html),'chromium':'/usr/bin/chromium','startupMs':[], 'selfTests':[], 'preparationMs':[]}
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(executable_path='/usr/bin/chromium',headless=True,
                args=['--no-sandbox','--disable-dev-shm-usage'])
            records['browserVersion'] = browser.version
            page = browser.new_page(viewport={'width':1280,'height':900})
            errors = []
            page.on('pageerror',lambda error: errors.append(str(error)))
            url = f'http://127.0.0.1:{args.port}/{html.relative_to(ROOT)}'
            for iteration in range(args.repeats):
                started = time.perf_counter()
                page.goto(url,wait_until='load',timeout=60000)
                records['startupMs'].append((time.perf_counter()-started)*1000)
                summary = json.loads(page.locator('#rule-test-results').text_content())
                records['selfTests'].append(summary)
                prep = page.evaluate('''async () => {
                  Object.assign(state,{gameMode:'cpu',cpuDifficulty:'master',seatChosen:true,isStarting:true,
                    gameEnded:false,firstPlayer:1,p1NumberLayout:[8,1,6,3,5,7,4,9,2],p2NumberLayout:[5,9,1,7,2,6,3,8,4]});
                  const start=performance.now(); startWholeGameCpu();
                  await new Promise((resolve,reject) => { const poll=() => {
                    if (cpuWholeStatus==='ready') return resolve();
                    if (cpuWholeStatus==='fallback') return reject(new Error(cpuWholeFailure));
                    setTimeout(poll,5); }; poll(); });
                  const elapsed=performance.now()-start; releaseWholeGameCpu(); return elapsed;
                }''')
                records['preparationMs'].append(prep)
                print(f'{output.name}: repeat {iteration+1}/{args.repeats}, tests {summary["passed"]}/{summary["total"]}, startup {records["startupMs"][-1]:.1f} ms, prepare {prep:.1f} ms',flush=True)
            # Time an explicit self-test execution independently of navigation.
            # Preparation above deliberately sets seatChosen/isStarting; the UI
            # tests expect initial menu state, so restore it with a fresh load.
            page.goto(url,wait_until='load',timeout=60000)
            records['selfTestTiming'] = page.evaluate('''() => {const started=performance.now();
              const summary=runRuleSelfTests();return {elapsedMs:performance.now()-started,summary};}''')
            snapshot = page.evaluate((HERE/'snapshot.js').read_text())
            (output/'snapshot.json').write_text(json.dumps(snapshot,ensure_ascii=False,indent=2))
            records['pageErrors'] = errors
            records['startupMedianMs'] = statistics.median(records['startupMs'])
            records['preparationMedianMs'] = statistics.median(records['preparationMs'])
            records['sourceBytes'] = html.stat().st_size
            records['sourceLines'] = len(html.read_text().splitlines())
            browser.close()
    finally:
        server.shutdown(); server.server_close()
        (output/'measurements.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
    print(f'Capture saved to {output}',flush=True)

if __name__=='__main__':
    main()
