# 段階16 最終独立照合

2026-10-15 JST。保存済みファイルだけを読み、`RESULTS.md` の主要数値と適用範囲を照合した。新しいブラウザー、DP、ベンチマーク、公式変換は実行していない。本レビューのために計測・解析ファイルを変更していない。公開を妨げる数値・結論の不一致は見つからなかった。

## 独立再集計

主解析スクリプトを呼ばず、5本の保存JSONから同じrenderer-mainのXイベントとmarker端点を再集計した。全5本のJSON/protobufの現物SHA-256・byte数をreportと照合し、JSON event数も一致した。

| 項目 | 再集計結果 |
| --- | ---: |
| 完了visit / 自己テスト成功合計 | 5 / 1,610 |
| protobuf bytes / JSON bytes | 40,137,136 / 85,014,725 |
| JSON events | 338,523 |
| main X全件 / 両clock付き / CPU時計欠測 | 78,837 / 69,376 / 9,461 |
| JSONの厳密CPU超過 / 1ms超 | 1,468 / 26 |
| 各正式runの1ms超 | 12 / 6 / 3 / 5 |
| 正式marker区間 / 暖機marker区間 | 144 / 48 |
| 上記192 marker区間のCPU超過 | 0 |

事前確認は別枠1操作、正式クリック24、暖機8で、正式4visitのWorker状態は全てreadyだった。正式visitのbranch順はDP→legacy / legacy→DP / DP→legacy / legacy→DP。欠測を超過なしとして分母へ足していない。Xの件数は入れ子を含む。

## 保存済み照合結果との一致

`official-sql-summary.json`、`same-proto-sql-json-check.json`、`raw-counter-official-check.json`、`cpu-quantization-model-check.json`、`cpu-outer-review.json` と `POST_RUN_REVIEW.md` を確認した。

- 同一protoの公式SQLとJSONに対応欠落0、ns単位の正の超過は1,478件。JSONの1,468件と混同していない。
- 元thread_timeは167,205 samples、marker CPU端点260/260、大超過26/26の一意raw BEGIN/END対応という記載が保存結果に一致した。本レビューでprotobuf decoderを再実行したわけではない。
- 26件全て異なるepochで、内部に同じsequenceのclearがあり、条件付きfloor誤差上限内。追加clear境界14のうち一意対応9、正8・負1、保留5。正の値の範囲を別集計して191,063–8,972,113nsと確認した。
- proc端点66、正式runtime差12.013–18.829ms、proc読取の外側wall58.338–81.411ms、CPU両端値変化2件は保存結果と一致した。CDP側の外側wall59.525–82.823msと混同していない。

ソースの厳密な処理順は、CPU差を取り、前値をactual nsへ更新してから整数除算して記録する。wallは符号化済み差分だけ前値へ足す。RESULTSの処理順説明がこの順序へ修正されたことも確認した。数値・結論は変わらず、量子化モデルの算術と整合する。CPU値がJSON exporterだけで変わったという説明の必要性を除いたことは、独立した物理CPU時計による正常性確認を意味しない。

## 構成対照と残る範囲

`decoder-validation/source-quantization-control/result.json` の唯一の公式変換は成功し、固定予測7項目が全てtrue、関連するnonzero error statsは空。構成上の真のCPU/wall経過はいずれも1,500nsなのに、公式JSONの対象1イベントは `dur=1µs`、`tdur=10,001µs`、`tts=20,000µs`。RESULTS追記の数値と一致した。

これはCPU差分の切り捨てと明示したclear条件で見かけのCPU超過を構成できた対照であり、実トレースの原因・寄与率を確定していない。実測26件のepoch跨ぎと上限適合は必要条件の整合性検査である。真のCPU差分の非負、採取時点の違い、zero emissionを含めた緩い上限という留保が保持されている。

段階14/15を説明済みに変更せず、旧104条件の42反復非増加・62未確定、全経路の厳密非退行未確認という範囲も保持されている。元handoff・過去manifest・repo状態の保全監査と最終ZIP監査はroot担当で、本レビューの独立再検証範囲には含めない。

## 入力識別

| ファイル | SHA-256 |
| --- | --- |
| report.json | `6c181c8c2300795f32814c8752f19a7463647b23cf99ef3604503566cc268169` |
| analysis.json | `d1e2fac34ccad5064c8d9968de4399a3456ba1aa998f98d727dc68a24a7327d4` |
| official-sql-summary.json | `7159770cfd50f8849c7036f24c228bd710cbca2116bc72365ca26f221b709afd` |
| raw-counter-official-check.json | `378957fba43c0c778b3d80399a57bfc135ad414aa6946171706a30d189c620ed` |
| cpu-quantization-model-check.json | `cff7b8bb2e5dff756a7534899297e56e2e55b76474f1d82e5cf5a6a0f58043bd` |
| POST_RUN_REVIEW.md | `28dacf4dc0ddfb24d0aa0438c39982384e0841be6643fcb4776a8e43855dd0e9` |
| source-quantization-control/result.json | `97d37df6cae797620ad1806b3351eae8122bf02b00833c25e3e7c14908313515` |
