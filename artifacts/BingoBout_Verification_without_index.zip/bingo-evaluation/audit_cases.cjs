#!/usr/bin/env node
'use strict';
// Extracts only the audited, unchanged class and BREAK transformation from the upload.
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const crypto = require('node:crypto');
const DEFAULT_SOURCE = path.join(__dirname, 'source.html');
function loadAudit(source = process.env.BINGO_SOURCE || DEFAULT_SOURCE) {
  const html = fs.readFileSync(source, 'utf8');
  const classText = html.slice(html.indexOf('        class WholeGameDP {'), html.indexOf('        function wholeGameWorkerSource()'));
  const fnText = html.slice(html.indexOf('        function cpuBreakSelectionWeights('), html.indexOf('        function selectWholeGameCpuCell('));
  if (!classText || !fnText) throw new Error('Source extraction markers missing');
  const api = vm.runInNewContext(`${classText}\n${fnText}\n({WholeGameDP,cpuBreakSelectionWeights})`, {CONFIG: {BOARD_SIZE: 9}});
  return {...api, source, sourceSha256: crypto.createHash('sha256').update(html).digest('hex')};
}
function rng(seed) { let s = seed >>> 0; return () => {s += 0x6D2B79F5; let x = s; x = Math.imul(x ^ x >>> 15, x | 1); x ^= x + Math.imul(x ^ x >>> 7, x | 61); return ((x ^ x >>> 14) >>> 0) / 4294967296;}; }
function shuffle(r) { const a = [1,2,3,4,5,6,7,8,9]; for (let i = 8; i > 0; i--) {const j = Math.floor(r() * (i+1)); [a[i],a[j]]=[a[j],a[i]];} return a; }
function plainPolicy(p) {const a={}; for(const [k,v] of Object.entries(p)) a[k]=ArrayBuffer.isView(v)?Array.from(v):v; return a;}
function localAudit(dp,m1,m2,t,fn) {
  const a=dp.analyze({maskP1:m1,maskP2:m2,t});
  if(a.terminal.isTerminal || a.attacker!==2 || a.legalActions.length<2) return null;
  const p=Array.from(a.breakStrategy), q=Array.from(a.blockStrategy), pay=Array.from(a.actionValues), stay=a.stayValue;
  const full=fn(a,dp.resultGap), actual=a.legalActions.map(c=>full[c]);
  const tv=p.reduce((s,x,i)=>s+Math.abs(x-actual[i]),0)/2;
  const worst=(dist)=>Math.min(...q.map((_,j)=>pay.reduce((s,v,i)=>s+dist[i]*(i===j?stay:v),0)));
  const vsQ=dist=>pay.reduce((s,v,i)=>s+dist[i]*(q[i]*stay+(1-q[i])*v),0);
  const value=dp.getValue({maskP1:m1,maskP2:m2,t});
  return {t,maskP1:m1,maskP2:m2,legalActions:a.legalActions,p,q,pActual:actual,pay,stay,value,totalVariation:tv,nashWorst:worst(p),actualWorst:worst(actual),actualVsNashBlock:vsQ(actual),loss:Math.max(0,value-worst(actual))};
}
// Exact backward evaluation of fixed P2 policy against a perfect-information,
// state-dependent P1 best response. Hidden simultaneous picks remain hidden.
function bestResponse(dp, transform) {
  const started=performance.now(), layers=dp.layers.map(l=>({values:new Float64Array(l.values.length),wins:new Float64Array(l.values.length),losses:new Float64Array(l.values.length),margins:new Float64Array(l.values.length)}));
  let transformed=0, decisions=0, maxLocalLoss=0;
  for(let t=18;t>=0;t--) {
    const base=dp.layers[t],out=layers[t],attacker=dp.attacker[t];
    for(let i1=0;i1<base.n1;i1++) for(let i2=0;i2<base.n2;i2++) {
      const m1=base.masks1[i1],m2=base.masks2[i2],ix=i1*base.n2+i2;
      const s1=dp.score1[m1],s2=dp.score2[m2];
      if(dp.isTerminal(t,s1,s2,dp.max1[dp.turns1[t]][m1],dp.max2[dp.turns2[t]][m2])) {
        out.values[ix]=dp.terminalValue(s1,s2);out.wins[ix]=s2>s1?1:0;out.losses[ix]=s2<s1?1:0;out.margins[ix]=s2-s1;continue;
      }
      const policy=dp.analyze({t,maskP1:m1,maskP2:m2}),actions=policy.legalActions;
      const cb=dp.layers[t+1],child=layers[t+1],stay=cb.index1[m1]*cb.n2+cb.index2[m2];
      const next=actions.map(c=>attacker===2?cb.index1[m1]*cb.n2+cb.index2[m2|(1<<c)]:cb.index1[m1|(1<<c)]*cb.n2+cb.index2[m2]);
      let probs;
      if(attacker===2) {
        decisions++;
        const raw=transform?transform(policy,dp.resultGap):null;
        probs=raw?actions.map(c=>raw[c]):Array.from(policy.breakStrategy);
        if(raw && probs.some((v,i)=>Math.abs(v-policy.breakStrategy[i])>1e-10)) transformed++;
        if(policy.actionValues) { const localWorst=Math.min(...actions.map((_,j)=>actions.reduce((sum,__,i)=>sum+probs[i]*(i===j?policy.stayValue:policy.actionValues[i]),0))); maxLocalLoss=Math.max(maxLocalLoss,base.values[ix]-localWorst); }
      } else probs=Array.from(policy.blockStrategy);
      let best=Infinity,bestAction=0;
      for(let j=0;j<actions.length;j++) {
        let val=0;
        if(attacker===2) for(let i=0;i<actions.length;i++)val+=probs[i]*child.values[i===j?stay:next[i]];
        else val=probs[j]*child.values[stay]+(1-probs[j])*child.values[next[j]];
        if(val<best-1e-12){best=val;bestAction=j;}
      }
      out.values[ix]=best;
      for(const key of ['wins','losses','margins']) {
        if(attacker===2) for(let i=0;i<actions.length;i++)out[key][ix]+=probs[i]*child[key][i===bestAction?stay:next[i]];
        else out[key][ix]=probs[bestAction]*child[key][stay]+(1-probs[bestAction])*child[key][next[bestAction]];
      }
    }
  }
  const root=layers[0],value=dp.layers[0].values[0];
  return {utility:root.values[0],nashValue:value,exploitability:value-root.values[0],pWin:root.wins[0],pDraw:1-root.wins[0]-root.losses[0],pLoss:root.losses[0],meanMargin:root.margins[0],cpuBreakDecisionStates:decisions,transformedStates:transformed,maxOneDecisionUtilityLoss:maxLocalLoss,seconds:(performance.now()-started)/1000};
}
async function main(){
  const api=loadAudit(),r=rng(0xA0D17),outdir=process.argv[2]||path.join(__dirname,'results');fs.mkdirSync(outdir,{recursive:true});
  const records=[],toy=new api.WholeGameDP({layoutP1:[1,2,3,4,5,6,7,8,9],layoutP2:[9,8,7,6,5,4,3,2,1]});
  const add=(kind,pay,stay)=>{try{const eq=toy.equilibrium(pay.length,pay,stay);records.push({kind,pay,stay,...eq,p:Array.from(toy.probP.slice(0,pay.length)),q:Array.from(toy.probQ.slice(0,pay.length))});}catch(e){records.push({kind,pay,stay,error:String(e.message)});}};
  for(let n=2;n<=9;n++){
    add('equal',Array(n).fill(1005),1005);add('all_positive',Array(n).fill(1005),0);add('all_negative',Array(n).fill(-1005),0);
    add('one_positive',Array.from({length:n},(_,i)=>i===0?1005:-1005),-1008);
    add('mixed_sign',Array.from({length:n},(_,i)=>i%2?10:-10),0);
    add('ties_negative',Array.from({length:n},(_,i)=>i<2?-1:-1000),0);
    add('near_equal',Array.from({length:n},(_,i)=>1000+(i-2)*1e-9),1000);
    for(let j=0;j<150;j++){
      const stay=(r()-.5)*2090;
      const pay=Array.from({length:n},()=>j%3===0?stay+r()*1045:j%3===1?stay-r()*1045:(r()-.5)*2090);
      add('random',pay,stay);
    }
  }
  const {seed}=require('./loader.cjs');
  const configs=[];
  for(let index=0;index<2;index++){
    const layoutRng=rng(seed('bingo-v1','layout',index));
    const p1=shuffle(layoutRng);let p2;
    do{p2=shuffle(layoutRng);}while(p1.join(',')===p2.join(','));
    for(const firstPlayer of [1,2])configs.push({id:`benchmark-layout${index}-first${firstPlayer}`,layoutP1:p1,layoutP2:p2,firstPlayer});
  }
  configs.push({id:'source-selftest-magic',layoutP1:[8,1,6,3,5,7,4,9,2],layoutP2:[8,1,6,3,5,7,4,9,2],firstPlayer:1});
  const games=[];
  for(const config of configs){
    const start=performance.now(),dp=new api.WholeGameDP({...config,earlyTermination:true}),stats=dp.solve();
    process.stderr.write(`Solved ${config.id} in ${((performance.now()-start)/1000).toFixed(2)} s\n`);
    const samples=[],tails=[];
    for(let j=0;j<1600;j++) {
      const t=1+Math.floor(r()*17),layer=dp.layers[t],m1=layer.masks1[Math.floor(r()*layer.n1)],m2=layer.masks2[Math.floor(r()*layer.n2)];
      const a=dp.analyze({t,maskP1:m1,maskP2:m2});if(a.terminal.isTerminal)continue;
      const pay=Array.from(a.actionValues||[]);
      // For P1 attacker, build the maximizer-oriented pay independently from child table.
      if(a.attacker===1){const c=dp.layers[t+1];for(const cell of a.legalActions)pay.push(-c.values[c.index1[m1|(1<<cell)]*c.n2+c.index2[m2]]);}
      const c=dp.layers[t+1],rawstay=c.values[c.index1[m1]*c.n2+c.index2[m2]],stay=a.attacker===2?rawstay:-rawstay;
      if(pay.length>=2)records.push({kind:'actual_dp',config:config.id,t,maskP1:m1,maskP2:m2,pay,stay,value:a.attacker===2?dp.getValue({t,maskP1:m1,maskP2:m2}):-dp.getValue({t,maskP1:m1,maskP2:m2}),gap:a.gap,p:Array.from(a.breakStrategy),q:Array.from(a.blockStrategy)});
      const local=localAudit(dp,m1,m2,t,api.cpuBreakSelectionWeights);if(local)samples.push(local);
    }
    for(let j=0;j<24;j++){
      const t=16+Math.floor(r()*2),m1=Math.floor(r()*512),m2=Math.floor(r()*512);
      if(dp.layers[t].index1[m1]===65535||dp.layers[t].index2[m2]===65535)continue;
      tails.push({t,maskP1:m1,maskP2:m2,value:dp.getValue({t,maskP1:m1,maskP2:m2})});
    }
    samples.sort((a,b)=>b.loss-a.loss);
    const known=localAudit(dp,191,381,17,api.cpuBreakSelectionWeights);
    const nashBR=bestResponse(dp,null);process.stderr.write(`Nash BR ${config.id}: ${JSON.stringify(nashBR)}\n`);
    const actualBR=bestResponse(dp,api.cpuBreakSelectionWeights);process.stderr.write(`Actual BR ${config.id}: ${JSON.stringify(actualBR)}\n`);
    games.push({config,stats,seconds:(performance.now()-start)/1000,nashBR,actualBR,tailStates:tails,localSampleCount:samples.length,transformedLocalSampleCount:samples.filter(x=>x.totalVariation>1e-10).length,meanSampleTV:samples.reduce((s,x)=>s+x.totalVariation,0)/Math.max(1,samples.length),meanSampleLoss:samples.reduce((s,x)=>s+x.loss,0)/Math.max(1,samples.length),topLocalLoss:samples.slice(0,12),knownCase:known});
    fs.writeFileSync(path.join(outdir,'dp_game_audit.json'),JSON.stringify({source:api.source,sourceSha256:api.sourceSha256,seed:0xA0D17,utility:'1000*(Pwin-Ploss)+E[score2-score1]',games},null,2));
  }
  fs.writeFileSync(path.join(outdir,'matrix_cases.json'),JSON.stringify(records));
  process.stdout.write(JSON.stringify({sourceSha256:api.sourceSha256,matrixCases:records.length,games:games.map(g=>({id:g.config.id,stats:g.stats,nashBR:g.nashBR,actualBR:g.actualBR}))},null,2)+'\n');
}
module.exports={loadAudit,rng,shuffle,localAudit,bestResponse};
if(require.main===module)main().catch(e=>{process.stderr.write(e.stack+'\n');process.exitCode=1;});
