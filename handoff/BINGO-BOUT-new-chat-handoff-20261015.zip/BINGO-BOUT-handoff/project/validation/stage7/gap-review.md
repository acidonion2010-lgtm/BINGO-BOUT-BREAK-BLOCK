# Stage7: small-count CPU review

This review proposes a causal diagnostic, without changing production HTML.

The stage6 pooled-positive full-DP condition is `firstPlayer=1`, `late`,
`BLOCK`, `hard-full`: the actual decision is `t=14`, attacker P1, two closed
cells. Its two independent runs have paired medians +0.015 and +0.060 µs.
The first run's interval includes zero; the second is positive. The pooled
conditional paired median is +0.0375 µs with [0.005, 0.070] µs bounds, while
the report's repeated-run classification remains `unconfirmed`.

The original `strategyGap` calculates each column with one inner row loop
and a diagonal ternary. The current code splits that into a before-diagonal
loop, one diagonal multiplication/addition, and an after-diagonal loop.
At count=2, the original needs four row-loop iterations with four ternaries;
the split version needs only two off-diagonal iterations, but initializes
four inner loops, including two empty loops. This is a plausible source-level
tradeoff, not evidence that the split code is slower: V8 may remove branches
or specialize either implementation, and the complete selector also packs
two distributions, validates them and samples a cell.

Other changed code on the same general path includes inheritance/shared
equilibrium, the false monotone-mode branches, and removal of the unused
`maxPay` calculation from `solveState`. Source shape and previous call-site
feedback can affect JIT compilation even if observable values are identical.

The four other pooled-positive conditions dispatch to the legacy selector.
They do not execute `equilibrium` or `strategyGap`. The legacy production
functions are unchanged, so these four measurements cannot be attributed
directly to the diagonal split. Earlier A/A measurements do not negate their
positive A/B results, either.

`gap_causality.cjs` defines actual original/current methods in one Node V8
realm and invokes them on the same receiver, work arrays and archived original
DP values. It isolates the gap method, equilibrium with only the gap changed,
the complete equilibrium method set, and `solveState` plus distribution packing.
Every timing comparison has an A/A control and alternating order. Untimed
input restoration is identical for both sides. A candidate keeps the original
row loop for count<=2 and the current split loop above that count; every
multiplication and addition retains original row order.

Before optional timing, all predefined signed/boundary cases, arbitrary P/Q
distributions, and nonterminal archived policies are compared with recursive
`Object.is` (including value, P, Q, gap, action values and matching exceptions).
The actual late BLOCK pay/stay is read from the original saved DP, without
solving another full DP. Original/current/candidate must agree exactly.

The Node probe can identify a micro-level tradeoff in this runtime. It cannot
by itself establish the cause of the original two-realm Chromium selector
measurement, real-click waiting, physical paint timing, or a device-independent
non-regression guarantee. A favorable Node candidate still needs a focused
Chromium selector comparison before any production change is considered.

Commands (run sequentially when no other CPU measurement is active):

```bash
node --check validation/stage7/gap_causality.cjs
node validation/stage7/gap_causality.cjs
node validation/stage7/gap_causality.cjs --benchmark --pairs 9 --calls 100000 --warmup 20000
```

Only the syntax command was run when this initial review was prepared.
