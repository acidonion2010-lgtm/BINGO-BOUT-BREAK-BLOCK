#!/usr/bin/env python3
"""Stage18: inspect saved unit=1 residual slice endpoints; launch no browser.

Raw counter decoding is not reimplemented or changed. Endpoint wall times come
from independently saved official SQL counter rows, keyed by (UUID, exact CPU).
Every ambiguity is retained; a candidate is never chosen from a multi-match.
"""
from bisect import bisect_right
from collections import Counter, defaultdict
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'bingo-stage17-20261015'
RUNS = (3, 4, 7, 8)
DECODER_SHA = '91762a94d1e1e05305c2a11fbb237dd4b42bffd3ebb5162f48c4cec42b038c23'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as file:
        for block in iter(lambda: file.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def integer(value):
    if value in (None, '[NULL]', ''):
        return None
    value = Decimal(str(value))
    result = int(value)
    assert result == value, ('noninteger', value)
    return result


def read_csv(path):
    with path.open() as file:
        return list(csv.DictReader(file))


def sign(value):
    return 'positive' if value > 0 else ('negative' if value < 0 else 'zero')


def clock_kind(row):
    if row.get('event_timestamp_delta_us_raw') is not None or row.get('event_timestamp_absolute_us_raw') is not None:
        return 'legacyEventTimestamp'
    if row.get('packet_clock_id_raw') is not None:
        return 'explicitPacketClock'
    if row.get('default_clock_id_raw') == 64:
        return 'defaultIncrementalPacketClock64'
    return 'otherOrMissingDefaultPacketClock'


def run_census(visit):
    run = visit['run']
    paths = {'rawLedger': OLD / f'raw-counter-run{run}.json',
             'officialCounters': OLD / f'official-sql/run{run}-counters.csv',
             'officialSlices': OLD / f'official-sql/run{run}-slices.csv',
             'proto': OLD / f'run{run}.pftrace'}
    inputs = {name: {'path': str(path), 'sha256': sha(path)} for name, path in paths.items()}
    ledger = json.loads(paths['rawLedger'].read_bytes())
    assert ledger['script_sha256'] == DECODER_SHA
    assert ledger['input']['sha256'] == inputs['proto']['sha256']
    assert ledger['status'] == 'limited_scope_complete'
    pid, tid = visit['conversion']['rendererPidTid']
    rows = [r for r in ledger['ledger'] if r['event_association_at_end'].get('status') == 'thread'
            and (r['event_association_at_end'].get('pid'), r['event_association_at_end'].get('tid')) == (pid, tid)
            and r['cpu_ns'] is not None]
    assert rows == sorted(rows, key=lambda row: row['packet_index'])
    counter_wall = defaultdict(list)
    for row in read_csv(paths['officialCounters']):
        if row['name'] == 'thread_time':
            key = (str(integer(row['uuid']) & ((1 << 64) - 1)), integer(row['value']))
            counter_wall[key].append(integer(row['ts']))
    points = {}
    for row in rows:
        p = {'packetIndex': row['packet_index'], 'sequenceId': row['sequence_id'],
             'epoch': row['sequence_epoch'], 'name': row['name'], 'type': row['type'],
             'cpuNs': integer(row['cpu_ns']), 'cpuCounterUuid': row['cpu_counter_uuid'],
             'wallCandidatesNs': counter_wall[(row['cpu_counter_uuid'], integer(row['cpu_ns']))],
             'clockKind': clock_kind(row), 'packetClockIdRaw': row.get('packet_clock_id_raw'),
             'defaultClockIdRaw': row.get('default_clock_id_raw'),
             'packetTimestampRaw': row.get('packet_timestamp_raw'),
             'eventTimestampDeltaUsRaw': row.get('event_timestamp_delta_us_raw'),
             'eventTimestampAbsoluteUsRaw': row.get('event_timestamp_absolute_us_raw')}
        p['wallNs'] = p['wallCandidatesNs'][0] if len(p['wallCandidatesNs']) == 1 else None
        points[p['packetIndex']] = p
    packet_next = {a['packetIndex']: b for a, b in zip(points.values(), list(points.values())[1:])}
    wall_sorted = sorted((p for p in points.values() if p['wallNs'] is not None),
                         key=lambda p: (p['wallNs'], p['packetIndex']))
    wall_next = {a['packetIndex']: b for a, b in zip(wall_sorted, wall_sorted[1:])}
    transitions = defaultdict(list)
    for t in ledger['transitions']:
        transitions[t['sequence_id']].append(t)
    transition_indices = {seq: [t['packet_index'] for t in ts] for seq, ts in transitions.items()}

    def inside_transitions(begin, end):
        if begin['sequenceId'] != end['sequenceId']:
            return None
        seq = begin['sequenceId']
        lo = bisect_right(transition_indices[seq], begin['packetIndex'])
        hi = bisect_right(transition_indices[seq], end['packetIndex'])
        return transitions[seq][lo:hi]

    stacks = defaultdict(list)
    pairs = defaultdict(list)
    unmatched_ends = 0
    for row in rows:
        key = (row['sequence_id'], row['event_track_uuid'])
        if row['type'] == 1:
            stacks[key].append(row)
        elif row['type'] == 2:
            if not stacks[key]:
                unmatched_ends += 1
                continue
            begin = stacks[key].pop()
            pairs[(begin['name'], integer(begin['cpu_ns']), integer(row['cpu_ns']))].append(
                (points[begin['packet_index']], points[row['packet_index']]))

    counts = Counter()
    groups = {key: Counter() for key in ('negative', 'zero', 'positive')}
    residuals = []
    examples = []

    def boundary(end, next_point, excess):
        if next_point is None:
            return {'status': 'noNextRetainedPoint'}
        wall = next_point['wallNs'] - end['wallNs'] if end['wallNs'] is not None and next_point['wallNs'] is not None else None
        cpu = next_point['cpuNs'] - end['cpuNs']
        inside = inside_transitions(end, next_point) if next_point['packetIndex'] > end['packetIndex'] else None
        return {'status': 'uniqueWalls' if wall is not None else 'missingOrAmbiguousWall',
                'nextPacketIndex': next_point['packetIndex'], 'nextName': next_point['name'],
                'nextType': next_point['type'], 'nextWallCandidatesNs': next_point['wallCandidatesNs'],
                'nextCpuNs': next_point['cpuNs'], 'nextClockKind': next_point['clockKind'],
                'nextPacketClockIdRaw': next_point['packetClockIdRaw'],
                'nextDefaultClockIdRaw': next_point['defaultClockIdRaw'],
                'nextEpoch': next_point['epoch'], 'nextSequenceId': next_point['sequenceId'],
                'wallGapNs': wall, 'cpuGapNs': cpu,
                'wallGapAtLeastSliceExcess': wall >= excess if wall is not None else None,
                'bothDefaultPacketClock64': end['clockKind'] == next_point['clockKind'] == 'defaultIncrementalPacketClock64',
                'nextPacketAfterEndPacket': next_point['packetIndex'] > end['packetIndex'],
                'epochsDiffer': end['epoch'] != next_point['epoch'],
                'clearInsidePacketInterval': any(t['action'] == 'clear' for t in inside) if inside is not None else None,
                'lossInsidePacketInterval': any(t['action'] == 'loss' for t in inside) if inside is not None else None}

    for raw_sql in read_csv(paths['officialSlices']):
        sql = {k: (v if k == 'name' else integer(v)) for k, v in raw_sql.items()}
        if sql['dur'] is None or sql['dur'] < 0 or sql['thread_ts'] is None or sql['thread_dur'] is None:
            counts['incompleteOrNoCpuSqlSlices'] += 1
            continue
        excess = sql['thread_dur'] - sql['dur']
        category = sign(excess)
        group = groups[category]
        group['allCompleteCpuSqlSlices'] += 1
        candidates = pairs.get((sql['name'], sql['thread_ts'], sql['thread_ts'] + sql['thread_dur']), [])
        result = {'sql': sql, 'excessNs': excess, 'rawPairCandidates': len(candidates)}
        if len(candidates) != 1:
            group['missingRawPair' if not candidates else 'ambiguousRawPair'] += 1
            result['candidatePacketPairs'] = [[b['packetIndex'], e['packetIndex']] for b, e in candidates]
        else:
            group['uniqueRawPair'] += 1
            begin, end = candidates[0]
            inside = inside_transitions(begin, end)
            has_clear = any(t['action'] == 'clear' for t in inside) if inside is not None else None
            has_loss = any(t['action'] == 'loss' for t in inside) if inside is not None else None
            group['pairAcrossEpoch' if begin['epoch'] != end['epoch'] else 'pairSameEpoch'] += 1
            group['pairHasClearInside'] += bool(has_clear)
            group['pairHasLossInside'] += bool(has_loss)
            exact_wall = begin['wallNs'] is not None and end['wallNs'] is not None
            group['uniqueBeginAndEndWalls' if exact_wall else 'missingOrAmbiguousBeginOrEndWall'] += 1
            if exact_wall:
                begin_delta = begin['wallNs'] - sql['ts']
                end_delta = end['wallNs'] - (sql['ts'] + sql['dur'])
                group['rawCounterWallsExactlyEqualSqlSlice' if begin_delta == end_delta == 0 else 'rawCounterWallsDifferFromSqlSlice'] += 1
            else:
                begin_delta = end_delta = None
            result.update({'begin': begin, 'end': end, 'pairEpochsDiffer': begin['epoch'] != end['epoch'],
                           'pairHasClearInside': has_clear, 'pairHasLossInside': has_loss,
                           'beginCounterWallMinusSqlNs': begin_delta, 'endCounterWallMinusSqlNs': end_delta})
            for order_name, next_point in [('packetOrder', packet_next.get(end['packetIndex'])),
                                            ('wallOrder', wall_next.get(end['packetIndex']))]:
                b = boundary(end, next_point, excess)
                result[order_name] = b
                group[f'{order_name}.{b["status"]}'] += 1
                if b['status'] == 'uniqueWalls':
                    group[f'{order_name}.wallGap.{sign(b["wallGapNs"])}'] += 1
                    group[f'{order_name}.cpuGap.{sign(b["cpuGapNs"])}'] += 1
                    group[f'{order_name}.gapAtLeastExcess.{str(b["wallGapAtLeastSliceExcess"]).lower()}'] += 1
                    group[f'{order_name}.bothDefault.{str(b["bothDefaultPacketClock64"]).lower()}'] += 1
                    group[f'{order_name}.epochsDiffer.{str(b["epochsDiffer"]).lower()}'] += 1
                    group[f'{order_name}.nextPacketAfterEnd.{str(b["nextPacketAfterEndPacket"]).lower()}'] += 1
                    if b['bothDefaultPacketClock64']:
                        group[f'{order_name}.bothDefault.gapAtLeastExcess.{str(b["wallGapAtLeastSliceExcess"]).lower()}'] += 1
            pnext = result['packetOrder'].get('nextPacketIndex')
            wnext = result['wallOrder'].get('nextPacketIndex')
            if pnext is not None and wnext is not None:
                group['packetAndWallNextSame' if pnext == wnext else 'packetAndWallNextDifferent'] += 1
        if excess > 0:
            residuals.append(result)
            examples.append(result)
    counts.update({'mainRawCpuBearingEvents': len(rows), 'rawBeginEndPairs': sum(map(len, pairs.values())),
                   'unmatchedRawEnds': unmatched_ends, 'unclosedRawBegins': sum(map(len, stacks.values())),
                   'rawPointsWithUniqueOfficialWall': sum(p['wallNs'] is not None for p in points.values()),
                   'rawPointsWithoutUniqueOfficialWall': sum(p['wallNs'] is None for p in points.values())})
    for a, b in zip(points.values(), list(points.values())[1:]):
        if a['wallNs'] is not None and b['wallNs'] is not None:
            counts[f'allAdjacentRawPoints.wallGap.{sign(b["wallNs"] - a["wallNs"])}'] += 1
        counts[f'allAdjacentRawPoints.cpuGap.{sign(b["cpuNs"] - a["cpuNs"])}'] += 1
        counts['allAdjacentRawPoints.epochsDiffer'] += a['epoch'] != b['epoch']
    return {'run': run, 'unit': visit['unit'], 'pid': pid, 'tid': tid,
            'inputs': inputs, 'counts': dict(counts), 'bySliceExcessSign': {k: dict(v) for k, v in groups.items()},
            'clockKindCounts': dict(Counter(p['clockKind'] for p in points.values())),
            'maximumPositiveExamples': sorted(examples, key=lambda r: (-r['excessNs'], r['sql']['id']))[:4],
            'strictPositiveSliceRecords': residuals}


def main():
    report_path = OLD / 'report.json'
    report = json.loads(report_path.read_bytes())
    visits = {v['run']: v for v in report['visits']}
    result = {'scriptSha256': sha(Path(__file__)), 'report': {'path': str(report_path), 'sha256': sha(report_path)},
              'rawDecoderSha256': DECODER_SHA,
              'scope': 'saved formal unit1 runs3/4/7/8 only; no browser or new measurements',
              'definitions': {
                  'pair': 'same raw sequence+event track B/E stack; unique name+exact CPU start+end SQL match only',
                  'wall': 'unique saved SQL thread_time counter.ts match on UUID+exact absolute CPU',
                  'packetOrderNext': 'immediate next retained same-thread CPU-bearing raw TrackEvent in packet order, regardless of event type, sequence, epoch or clock kind',
                  'wallOrderNext': 'next uniquely wall-mapped same-thread CPU-bearing raw TrackEvent after sorting (SQL wall ns, packet index); this is not acquisition order',
                  'defaultClock': 'raw packet_clock_id absent, default_clock_id=64, no legacy event timestamp fields; packet metadata classification, not proof of a source callsite',
                  'conditionalDiagnostic': 'If a default wall endpoint is acquired before a delayed CPU endpoint and the next default wall timestamp is acquired after that CPU read, simple CPU-end read delay alone requires next wall gap >= current slice CPU-minus-wall excess. Trace timestamp metadata alone does not establish source acquisition order.'},
              'visits': []}
    for run in RUNS:
        assert visits[run]['completed'] and not visits[run]['preflight'] and visits[run]['unit'] == 1
        visit = run_census(visits[run])
        result['visits'].append(visit)
        print(json.dumps({'run': run, 'counts': visit['counts'], 'bySliceExcessSign': visit['bySliceExcessSign']}), flush=True)
    totals = {sign_name: Counter() for sign_name in ('negative', 'zero', 'positive')}
    for visit in result['visits']:
        for sign_name, counts in visit['bySliceExcessSign'].items():
            totals[sign_name].update(counts)
    result['totalBySliceExcessSign'] = {k: dict(v) for k, v in totals.items()}
    all_positive = [(v['run'], r) for v in result['visits'] for r in v['strictPositiveSliceRecords']]
    result['maximumPositiveExamples'] = [{'run': run, **r} for run, r in sorted(all_positive, key=lambda pair: (-pair[1]['excessNs'], pair[0], pair[1]['sql']['id']))[:4]]
    assert len(all_positive) == 27879, len(all_positive)
    with (ROOT / 'boundary-census.json').open('x') as file:
        json.dump(result, file, indent=2)
        file.write('\n')
    print(json.dumps({'totalBySliceExcessSign': result['totalBySliceExcessSign']}), flush=True)


if __name__ == '__main__':
    main()
