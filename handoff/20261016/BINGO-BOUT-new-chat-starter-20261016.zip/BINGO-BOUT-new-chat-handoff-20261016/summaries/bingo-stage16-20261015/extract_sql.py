#!/usr/bin/env python3
import csv,hashlib,json,subprocess
from pathlib import Path
R=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 report=json.loads((R/'report.json').read_text());assert report['status']=='completed'
 dest=R/'official-sql';dest.mkdir(exist_ok=False)
 summary={'scriptSha256':sha(Path(__file__)),'reportSha256':sha(R/'report.json'),'binarySha256':sha(R/'trace_processor_shell'),'visits':[]}
 for visit in report['visits']:
  run=visit['run'];pid,tid=visit['conversion']['rendererPidTid'];trace=R/f'run{run}.pftrace'
  queries={
  'slices':f'SELECT s.id,s.ts,s.dur,s.thread_ts,s.thread_dur,s.name,s.depth,s.parent_id FROM slice s JOIN thread_track tt ON s.track_id=tt.id JOIN thread t ON tt.utid=t.utid JOIN process p ON t.upid=p.upid WHERE p.pid={pid} AND t.tid={tid} ORDER BY s.id',
  'counters':f"SELECT c.id,c.ts,c.value,ct.id AS track_id,ct.name,(SELECT int_value FROM args WHERE arg_set_id=ct.source_arg_set_id AND key='trace_id') AS uuid FROM counter c JOIN thread_counter_track ct ON c.track_id=ct.id JOIN thread t ON ct.utid=t.utid JOIN process p ON t.upid=p.upid WHERE p.pid={pid} AND t.tid={tid} ORDER BY c.id",
  'stats':'SELECT name,idx,severity,source,value FROM stats WHERE value != 0 ORDER BY name,idx'}
  v={'run':run,'protoSha256':sha(trace),'outputs':{}};summary['visits'].append(v)
  for key,q in queries.items():
   prefix=dest/f'run{run}-{key}';prefix.with_suffix('.sql').write_text(q+';\n')
   p=subprocess.run([str(R/'trace_processor_shell'),'query',str(trace),q],capture_output=True,text=True,timeout=120)
   prefix.with_suffix('.csv').write_text(p.stdout);prefix.with_suffix('.stderr').write_text(p.stderr);assert p.returncode==0,(run,key,p.stderr)
   v['outputs'][key]={'sha256':sha(prefix.with_suffix('.csv')),'rows':len(list(csv.DictReader(p.stdout.splitlines()))),'returncode':p.returncode}
 (R/'official-sql-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
