#!/usr/bin/env python3
"""Saved unit1 SQL census, with exact strict signs and descriptive bins."""
import csv,json,hashlib,math
from collections import defaultdict,Counter
from pathlib import Path
R=Path(__file__).resolve().parent;S=Path('/workspace/bingo-stage17-20261015')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def number(v):return None if v=='[NULL]' else int(v)
def percentile(values,p):
 return sorted(values)[max(0,math.ceil(len(values)*p)-1)] if values else None

def bins(values):
 out={'negative':0,'zero':0,'positive_le_100ns':0,'positive_le_1us':0,'positive_le_10us':0,'positive_le_100us':0,'positive_le_1ms':0,'positive_gt_1ms':0}
 for v in values:
  key='negative' if v<0 else 'zero' if v==0 else 'positive_le_100ns' if v<=100 else 'positive_le_1us' if v<=1000 else 'positive_le_10us' if v<=10000 else 'positive_le_100us' if v<=100000 else 'positive_le_1ms' if v<=1000000 else 'positive_gt_1ms'
  out[key]+=1
 return out

def summarize(rows):
 cpu=[r for r in rows if r['thread_ts'] is not None and r['thread_dur'] is not None];values=[r['thread_dur']-r['dur'] for r in cpu];positive=[v for v in values if v>0]
 return {'complete':len(rows),'withCpu':len(cpu),'missingCpu':len(rows)-len(cpu),'signBins':bins(values),'strictPositive':len(positive),'maxPositiveNs':max(positive) if positive else None,'positiveP50Ns':percentile(positive,.5),'positiveP95Ns':percentile(positive,.95),'positiveP99Ns':percentile(positive,.99)}

def main():
 output=R/'residual-census.json';assert not output.exists()
 report=json.loads((S/'report.json').read_bytes());assert report['status']=='completed'
 result={'scope':'Saved-data residual census only, not new measurements or validated physical CPU duration.','scriptSha256':sha(Path(__file__)),'planSha256':sha(R/'PLAN.md'),'sourceReportSha256':sha(S/'report.json'),'visits':[],'summary':{}}
 allrows=[]
 for visit in report['visits']:
  if visit['preflight'] or visit['unit']!=1:continue
  run=visit['run'];p=S/f'official-sql/run{run}-slices.csv';rows=[]
  for raw in csv.DictReader(p.open()):
   row={k:v if k=='name' else number(v) for k,v in raw.items()};row['run']=run;rows.append(row)
  complete=[r for r in rows if r['dur'] is not None and r['dur']>=0];allrows.extend(complete)
  byname=defaultdict(list)
  for row in complete:byname[row['name']].append(row)
  summary=summarize(complete)
  result['visits'].append({'run':run,'unit':1,'inputSha256':sha(p),'incomplete':len(rows)-len(complete),'summary':summary,'eventNames':{name:summarize(rs) for name,rs in sorted(byname.items())}})
 byname=defaultdict(list)
 for row in allrows:byname[row['name']].append(row)
 result['summary']=summarize(allrows)
 result['allEventNames']={name:summarize(rs) for name,rs in sorted(byname.items())}
 positive=[r for r in allrows if r['thread_dur'] is not None and r['thread_ts'] is not None and r['thread_dur']>r['dur']]
 result['largest20']=sorted([dict(r,excessNs=r['thread_dur']-r['dur']) for r in positive],key=lambda r:(-r['excessNs'],r['run'],r['id']))[:20]
 result['positiveNameRankingByCount']=sorted([{'name':name,**s} for name,s in result['allEventNames'].items() if s['strictPositive']],key=lambda x:(-x['strictPositive'],x['name']))
 with output.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps(result['summary'],indent=2))
 print(json.dumps(result['positiveNameRankingByCount'][:7],indent=2))
if __name__=='__main__':main()
