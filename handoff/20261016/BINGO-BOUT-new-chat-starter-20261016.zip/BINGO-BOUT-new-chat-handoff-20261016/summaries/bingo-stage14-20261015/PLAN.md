# 段階14：HARD入力処理と描画callbackの同時記録

計測前の固定計画。原本→段階3で過去に観測した同期handler +0.45ms、原本→段階5の2RAF +0.8msを新しい同時記録で調べる。旧試行に同時traceがないので、今回の直接観測を遡って旧試行の原因へ当てはめない。元HTML、過去記録、リポジトリ、UI・音・演出を変更しない。

## 対象と有限予算

- 原本、段階3.final、段階5、現在の段階9を通常HTMLとして読み込む。scriptへ4ファイルの既知SHA-256を固定する。
- fresh Chromium4プロセス、各プロセスは1前面ページで4版を順にvisit。各1280×900、全ジョブ逐次。
- Williams基底[0,1,3,2]を0〜3循環加算した4順序。各版×visit位置を1回、異なる版の有向隣接12組を各1回。原本→3のhandler、原本→5の2RAFを主要焦点、5→9と原本→9を現在版の診断比較にする。
- 各visitで通常自己テスト322/322と実Blob Workerのreadyを確認。16通常読込・16準備。
- P1先攻、中盤maskP1=3、maskP2=24、t=8、5回表、人間P1がboard1 cell2をBREAKし、CPU(P2)がBLOCKする。
- HARD readyDP、乱数0.8のDP分岐を主要対象。乱数0.3の従来分岐を対照とする。全乱数をその定数に固定する。
- 各visit・分岐で1回のwarmupと9回の正式クリック。4×4×2×9=288正式、32warmup。warmupも別記録で保持。
- 分岐順は(runの0-based番号+visit位置の0-based番号)が偶数ならDP→legacy、奇数なら逆。各版の分岐順も2回ずつ。
- 入力は通常のPlaywright locator.click()、forceなし。旧試行と同様にfixtureの3RAFを待つ。音・BGM・CSS演出を停止/取消/強制完了しない。headless Chromiumの標準mute-audio条件は残り、物理音声出力は測らない。

## 記録と整合性

stage3 ui_response、stage5 RAF phase、stage7 trace_responseの凍結helperをhash固定して再利用。fixtureは引数をdifficulty/rollへ拡張し、固定乱数0.8の箇所を引数rollに変える2箇所のみ。stage7の同一capture/bubble/2RAF内部へ置く4markを再利用し、prefixだけstage14にする。RAFモニターと事前descriptorは計装として明示する。

ゲームのhandleCellClick、CPU selector、描画・演出等の関数参照を交換しない。各visitで7関数の参照を保存し、各trial前とvisit後に同一性を確認する。

各分岐の計時前にnative selectCpuBlockCellを1回だけ別途監査する。乱数の消費列、合法なCPU選択、分岐counter、公開入力・履歴の不変を記録し全版で照合。その監査では一時的に乱数を計数するが、正式クリックとwarmupには非計数の固定乱数を戻す。監査は追加のwarm履歴でありcold latencyの観測ではない。

クリックはtrusted、cell2の受理、REVEAL表示・可視性・disabled・処理状態、audioCtx running、音/BGMフラグ、ready状態、[4,4]手番を要求。DPはwhole=1/hardDP=1/hardLegacy=0、従来はwhole=0/hardDP=0/hardLegacy=1を要求。従来分岐では共通の非DP挙動assertに加え従来counterを明示する。

各visit全体で1本の連続traceを記録する。計16trace。監査・warmup・fixture更新・正式trialが含まれるが、分析はunique tokenのcapture/handler-end/first-raf/second-rafにclipする。各sampleに全4markを保存し、分析器が全320×4=1,280markerを検証。既存stream collectorは最終trialの4markとstream/loss/bufferを検査し、全trialのmarker検査は分析器で行う。

カテゴリはtoplevel/cc/viz/devtools.timeline/blink.user_timing/renderer.scheduler/v8/disabled-by-default-devtools.timeline.frameを明示する。getCategoriesの列挙は記録するが、過去に空列挙があったためemptyは未判明として扱い、要求リストを空にしたり列挙内容でフィルターしたりしない。実際のmarker、timeline、task/frameの可用性は生traceで照合し、ない分類は利用不能/未観測として保持する。stream EOF・hash・dataLossOccurred=false・buffer未充満を確認。markerのts/ttsは同じCrRendererMain PID/TIDに結び付ける。

## 分析と結論の範囲

各handler、handler→1RAF、1→2RAF、capture→2RAFでwallと同一thread CPU差を記録する。ttsがない区間はCPUをnullにしてwallを保持し、0に補わない。wall−CPUは待機・ブロック・未schedule等を含み、特定原因と同一視しない。

Layout/UpdateLayoutTree、Paint系、GC、commit待ち、task等の完了X区間をclipし、分類内でunionする。重複する分類同士を合計して総費用としない。B/Eを応答範囲へ影響する未完了scopeとして黙って無視せず、境界を検証する。page時計とtrace marker startTimeはULP単位のserialization対応だけを確認し、後付け性能許容差にしない。

各run・版・分岐の9正式clickのvisit中央値と、同じrunの版間visit中央値差を報告する。版間は同時クリックでも完全な位相一致でもないため、trial番号を独立の対標本と見なした狭いCIを付けない。4runは記述的な反復とし、旧標本とプールしない。RAF位相で補正しない。大きい差/遅延も含め全正式trialを保持し、期待する符号まで追加しない。

trace/mark/monitorと連続収集自体が動作を変える診断条件。非計装の製品latency、画面提示、物理入力、cold input、スピーカー出力、全配置/全browserの保証ではない。過去62条件、古いHARD差や段階8のraster/GPU待ちの原因未確定を自動で完了扱いにしない。

自己テスト/機能/乱数/参照不一致、page error、load60秒、Worker31秒、clickまたはcallback10秒、trace完了15秒の超過で停止し失敗を保存する。機器の欠陥だけは旧結果と理由を保存し、別の有限修正計画を宣言して修正する。実行前に独立レビューを受け、完了後は生trace・JSON/CSV・結果・再現手順・独立レビュー・hash manifestを保存する。
