#!/usr/bin/env python3
"""Retain strict signs and compare outer CPU snapshots, without tolerances."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def metrics(snapshot):return {x['name']:x['value'] for x in snapshot['metrics']['metrics']}
def outer(before,after,pid):
 b,a=metrics(before),metrics(after)
 cpu=(a['ThreadTime']-b['ThreadTime'])*1e9
 # ThreadTime reads occur inside these host protocol send/return brackets.
 wall=after['metricReturnMonotonicNs']-before['metricSendMonotonicNs']
 rb=next(r for r in before['renderers'] if r['pid']==pid);ra=next(r for r in after['renderers'] if r['pid']==pid)
 sb,sa=list(map(int,rb['schedstat'].split())),list(map(int,ra['schedstat'].split()))
 return {'threadTimeDeltaNs':cpu,'hostMetricOuterWallNs':wall,'threadTimeCpuMinusOuterWallNs':cpu-wall,
  'cdpTimestampDeltaNs':(a['Timestamp']-b['Timestamp'])*1e9,
  'schedstatRuntimeDeltaNs':sa[0]-sb[0],'schedstatRunqueueDeltaNs':sa[1]-sb[1],'schedstatSwitchesDelta':sa[2]-sb[2],
  'schedstatHostOuterWallNs':ra['hostAfterReadNs']-rb['hostBeforeReadNs'],
  'schedstatEndpointFreshnessNotGuaranteed':True}
def main():
 report=json.loads((ROOT/'report.json').read_text());out={'scriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'reportSha256':hashlib.sha256((ROOT/'report.json').read_bytes()).hexdigest(),'visits':[]}
 for v in report['visits']:
  if not v.get('completed'):continue
  trace=json.loads(Path(v['conversion']['path']).read_bytes());pid,tid=v['conversion']['rendererPidTid'];events=trace['traceEvents']
  xs=[e for e in events if (e.get('pid'),e.get('tid'))==(pid,tid) and e.get('ph')=='X' and 'dur' in e and 'tdur' in e]
  positive=[dict(name=e.get('name'),ts=e['ts'],tts=e.get('tts'),dur=e['dur'],tdur=e['tdur'],excessUs=e['tdur']-e['dur']) for e in xs if e['tdur']>e['dur']]
  rows=[]
  for s in v['samples']:
   ms={m['label']:m['name'] for m in s['markers']};record={'branch':s['branch'],'trial':s['trial'],'warmup':s['warmup'],'outer':outer(s['before'],s['after'],pid),'windows':[]}
   for kind in ['mark','stamp']:
    found={m['name']:m[kind] for m in v['conversion']['markers']}
    start=found[ms['capture']]
    for label in ['handler-end','first-raf','second-raf']:
     end=found[ms[label]];wall=end['ts']-start['ts'];cpu=end['tts']-start['tts'] if 'tts' in start and 'tts' in end else None
     record['windows'].append({'kind':kind,'to':label,'wallUs':wall,'cpuUs':cpu,'excessUs':None if cpu is None else cpu-wall,'cpuGreaterThanWall':None if cpu is None else cpu>wall})
   rows.append(record)
  item={'run':v['run'],'preflight':v['preflight'],'pid':pid,'tid':tid,'mainCompleteWithBothClocks':len(xs),'strictCpuGreaterThanWall':len(positive),'greaterThan1ms':sum(e['excessUs']>1000 for e in positive),'positiveEvents':positive,'samples':rows}
  if v['preflight']:item['outer']=outer(v['before'],v['after'],pid)
  out['visits'].append(item)
 out['summary']={'completedVisits':len(out['visits']),'mainCompleteWithBothClocks':sum(v['mainCompleteWithBothClocks'] for v in out['visits']),'strictCpuGreaterThanWall':sum(v['strictCpuGreaterThanWall'] for v in out['visits']),'greaterThan1ms':sum(v['greaterThan1ms'] for v in out['visits'])}
 for warmup in [False,True]:
  samples=[s for v in out['visits'] for s in v['samples'] if s['warmup']==warmup];windows=[w for s in samples for w in s['windows']]
  out['summary']['warmups' if warmup else 'formal']={'samples':len(samples),'markerWindows':len(windows),'strictMarkerCpuGreaterThanWall':sum(w['cpuGreaterThanWall'] is True for w in windows),'markerGreaterThan1ms':sum(w['excessUs'] is not None and w['excessUs']>1000 for w in windows),'outerThreadTimeGreaterThanHostOuter':sum(s['outer']['threadTimeCpuMinusOuterWallNs']>0 for s in samples),'outerRecords':[s['outer'] for s in samples]}
 (ROOT/'analysis.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in out['summary'].items() if k not in ['formal','warmups']},indent=2))
if __name__=='__main__':main()
