#!/usr/bin/env python3
"""Read-only, exact population/precision census of saved stage17 unit1 runs.

No browser, trace processor, counter decoder, or performance work is executed.
An existing output is never overwritten. --verify-output compares a fresh
in-memory replay with an existing JSON result.
"""
import argparse
from collections import Counter, defaultdict
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path

RUNS = (3, 4, 7, 8)
SIGNS = ('negative', 'zero', 'positive')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(value):
    if value in (None, '', '[NULL]'):
        return None
    decimal = Decimal(str(value))
    integer = int(decimal)
    assert decimal == integer, ('noninteger', value)
    return integer


def sign(value):
    return SIGNS[(value > 0) - (value < 0) + 1]


def tuple_key(row):
    return (row['name'], row['ts'] // 1000, row['dur'] // 1000,
            row['thread_ts'] // 1000, row['thread_dur'] // 1000)


def event_key(event):
    return (event.get('name'), number(event['ts']), number(event['dur']),
            number(event['tts']), number(event['tdur']))


def transition_table(rows):
    count = Counter((sign(r['thread_dur'] - r['dur']),
                     sign(r['thread_dur'] // 1000 - r['dur'] // 1000))
                    for r in rows)
    return {a: {b: count[a, b] for b in SIGNS} for a in SIGNS}


def endpoint_carry_table(rows):
    # X duration fields are divided directly. They are not the difference of
    # individually divided endpoints. All relevant values are nonnegative.
    count = Counter()
    for row in rows:
        wall = (row['ts'] + row['dur']) // 1000 - (
            row['ts'] // 1000 + row['dur'] // 1000)
        cpu = (row['thread_ts'] + row['thread_dur']) // 1000 - (
            row['thread_ts'] // 1000 + row['thread_dur'] // 1000)
        assert wall in (0, 1) and cpu in (0, 1)
        count[wall, cpu] += 1
    return {f'wallCarry{w}_cpuCarry{c}': count[w, c]
            for w in (0, 1) for c in (0, 1)}


def candidate_record(row, json_sign):
    ns_excess = row['thread_dur'] - row['dur']
    us_excess = row['thread_dur'] // 1000 - row['dur'] // 1000
    return {
        'sql': row, 'excessNs': ns_excess,
        'nsSign': sign(ns_excess), 'exportedExcessUs': us_excess,
        'exportedSign': sign(us_excess),
        'nsSignAgreesWithJsonSign': sign(ns_excess) == json_sign,
        'strictPositiveFlagAgreesWithJson': (ns_excess > 0) == (json_sign == 'positive'),
    }


def analyze_run(source, visit):
    run = visit['run']
    assert run in RUNS and visit['unit'] == 1 and not visit['preflight']
    assert visit['completed']
    csv_path = source / f'official-sql/run{run}-slices.csv'
    json_path = source / f'run{run}.json'
    with csv_path.open(newline='') as stream:
        sql_all = [{k: (v if k == 'name' else number(v))
                    for k, v in row.items()} for row in csv.DictReader(stream)]
    complete = [r for r in sql_all if r['dur'] >= 0]
    cpu = [r for r in complete if r['thread_ts'] is not None and r['thread_dur'] is not None]
    positive = [r for r in cpu if r['dur'] > 0]
    instant = [r for r in cpu if r['dur'] == 0]
    missing_cpu = [r for r in complete if r['thread_ts'] is None or r['thread_dur'] is None]
    assert all(r['ts'] >= 0 and r['dur'] >= 0 and r['thread_ts'] > 0
               and r['thread_dur'] >= 0 for r in cpu)

    pid, tid = visit['conversion']['rendererPidTid']
    raw_events = json.loads(json_path.read_text(), parse_float=Decimal)['traceEvents']
    main_x = [(i, e) for i, e in enumerate(raw_events)
              if e.get('ph') == 'X' and (e.get('pid'), e.get('tid')) == (pid, tid)]
    json_cpu = [(i, e) for i, e in main_x if all(k in e for k in ('dur', 'tts', 'tdur'))]
    sql_keys = Counter(tuple_key(r) for r in positive)
    json_keys = Counter(event_key(e) for _, e in json_cpu)
    # Exact population identity as a multiset does not select any candidate for
    # an individual JSON event. Multiplicities are retained on both sides.
    assert sql_keys == json_keys, (run, sql_keys - json_keys, json_keys - sql_keys)
    index = defaultdict(list)
    complete_index = defaultdict(list)
    for row in positive:
        index[tuple_key(row)].append(row)
    for row in cpu:
        complete_index[tuple_key(row)].append(row)
    assert all(index[key] == complete_index[key] for key in json_keys), 'instant/positive tuple collision'

    ambiguous_json = []
    for event_index, event in json_cpu:
        key = event_key(event)
        candidates = index[key]
        assert candidates
        if len(candidates) == 1:
            continue
        json_excess = number(event['tdur']) - number(event['dur'])
        json_sign = sign(json_excess)
        ambiguous_json.append({
            'jsonTraceEventIndex': event_index,
            'tuple': {'name': key[0], 'tsUs': key[1], 'durUs': key[2], 'ttsUs': key[3], 'tdurUs': key[4]},
            'jsonExcessUs': json_excess, 'jsonSign': json_sign,
            'candidateCount': len(candidates),
            'candidates': [candidate_record(r, json_sign) for r in candidates],
        })
    ambiguous_buckets = []
    for key, candidates in index.items():
        if len(candidates) > 1:
            json_sign = sign(key[4] - key[2])
            ambiguous_buckets.append({
                'tuple': {'name': key[0], 'tsUs': key[1], 'durUs': key[2], 'ttsUs': key[3], 'tdurUs': key[4]},
                'jsonMultiplicity': json_keys[key],
                'sqlMultiplicity': len(candidates),
                'candidateNsSignCounts': dict(Counter(sign(r['thread_dur'] - r['dur']) for r in candidates)),
                'candidates': [candidate_record(r, json_sign) for r in candidates],
            })

    ns_strict = sum(r['thread_dur'] > r['dur'] for r in cpu)
    instant_strict = sum(r['thread_dur'] > r['dur'] for r in instant)
    positive_strict = sum(r['thread_dur'] > r['dur'] for r in positive)
    floored_strict = sum(r['thread_dur'] // 1000 > r['dur'] // 1000 for r in positive)
    json_strict = sum(number(e['tdur']) > number(e['dur']) for _, e in json_cpu)
    assert floored_strict == json_strict
    transition = transition_table(positive)
    # Division of two nonnegative durations is monotone: a positive residual
    # may become zero, but no strict sign can flip or appear from a nonpositive.
    assert transition['negative']['positive'] == transition['zero']['positive'] == 0
    assert transition['positive']['negative'] == transition['zero']['negative'] == 0
    assert ns_strict - json_strict == instant_strict + transition['positive']['zero']

    candidate_appearances = [c for e in ambiguous_json for c in e['candidates']]
    candidate_unique = [c for b in ambiguous_buckets for c in b['candidates']]
    counts = {
        'sqlAllSlices': len(sql_all), 'sqlUnfinished': len(sql_all) - len(complete),
        'sqlComplete': len(complete), 'sqlCompleteWithCpu': len(cpu),
        'sqlCompleteMissingCpu': len(missing_cpu),
        'sqlPositiveDurationWithCpu': len(positive), 'sqlInstantWithCpu': len(instant),
        'sqlMissingCpuPositiveDuration': sum(r['dur'] > 0 for r in missing_cpu),
        'sqlMissingCpuInstant': sum(r['dur'] == 0 for r in missing_cpu),
        'jsonMainX': len(main_x), 'jsonMainXWithCpu': len(json_cpu),
        'jsonMainXMissingCpu': len(main_x) - len(json_cpu),
        'sqlAllCompleteCpuStrictPositiveNs': ns_strict,
        'sqlPositiveDurationCpuStrictPositiveNs': positive_strict,
        'sqlInstantCpuStrictPositiveNs': instant_strict,
        'jsonStrictPositiveUs': json_strict,
        'strictCountDifference': ns_strict - json_strict,
        'strictCountDifferenceFromPopulation': instant_strict,
        'strictCountDifferenceFromDurationDivision': transition['positive']['zero'],
        'jsonEventsWithMultipleSqlCandidates': len(ambiguous_json),
        'ambiguousTupleBuckets': len(ambiguous_buckets),
        'ambiguousUniqueSqlCandidateRows': len(candidate_unique),
        'ambiguousCandidateAppearancesAcrossJsonEvents': len(candidate_appearances),
        'ambiguousCandidateAppearanceSignAgreement': sum(c['nsSignAgreesWithJsonSign'] for c in candidate_appearances),
        'ambiguousCandidateAppearanceSignDisagreement': sum(not c['nsSignAgreesWithJsonSign'] for c in candidate_appearances),
        'ambiguousUniqueCandidateSignAgreement': sum(c['nsSignAgreesWithJsonSign'] for c in candidate_unique),
        'ambiguousUniqueCandidateSignDisagreement': sum(not c['nsSignAgreesWithJsonSign'] for c in candidate_unique),
    }
    return {
        'run': run, 'rendererPidTid': [pid, tid], 'counts': counts,
        'samePositiveDurationCpuPopulationExactMultisetEquality': True,
        'instantSqlTupleCollisionsWithJsonX': 0,
        'positiveDurationSignTransitionsNsToUs': transition,
        'instantSignTransitionsNsToUs': transition_table(instant),
        'positiveDurationEndpointCarry': endpoint_carry_table(positive),
        'missingCpuNames': dict(Counter(r['name'] for r in missing_cpu)),
        'ambiguousTupleBuckets': ambiguous_buckets,
        'ambiguousJsonEvents': ambiguous_json,
        'inputs': [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}
                   for p in (csv_path, json_path, source / f'official-sql/run{run}-slices.sql')],
    }


def build(source):
    report_path = source / 'report.json'
    report = json.loads(report_path.read_text())
    visits = {v['run']: v for v in report['visits']}
    runs = [analyze_run(source, visits[run]) for run in RUNS]
    total = dict(sum((Counter(r['counts']) for r in runs), Counter()))
    transitions = {a: {b: sum(r['positiveDurationSignTransitionsNsToUs'][a][b] for r in runs)
                       for b in SIGNS} for a in SIGNS}
    carry = dict(sum((Counter(r['positiveDurationEndpointCarry']) for r in runs), Counter()))
    root = Path(__file__).resolve().parent
    source_manifest = root / 'precision-sources/MANIFEST.json'
    source_evidence = json.loads(source_manifest.read_text())
    for row in source_evidence['files']:
        path = source_manifest.parent / row['file']
        assert row['sha256'] == sha(path) and row['bytes'] == path.stat().st_size
    return {
        'status': 'complete_saved_data_only', 'scriptSha256': sha(Path(__file__)),
        'scope': 'Existing stage17 formal effective-1ns runs 3,4,7,8; saved SQL and same-proto JSON only. No new measurement.',
        'matchingRule': 'Exact name/ts//1000/dur//1000/thread_ts//1000/thread_dur//1000 multiset; every ambiguous per-event candidate retained, no tie broken.',
        'limitations': [
            'Nested trace slices are not independent observations.',
            'An exact tuple multiset establishes population identity under the checked export representation, not a unique identity for an ambiguous JSON event.',
            'Microsecond export loses duration and endpoint precision; multiplying JSON microseconds by 1000 does not restore nanoseconds.',
            'This accounting decomposition does not validate physical CPU clocks, endpoint simultaneity, clock transforms, or strict CPU attribution.',
            'Producer-pinned and official-binary-version exporter source files were fetched/copied separately and are byte-identical. This does not establish arbitrary build equivalence; the saved data representation is checked independently.',
        ],
        'reportInput': {'path': str(report_path), 'bytes': report_path.stat().st_size, 'sha256': sha(report_path)},
        'sourceEvidenceManifest': {'path': str(source_manifest), 'sha256': sha(source_manifest)},
        'totals': total, 'positiveDurationSignTransitionsNsToUs': transitions,
        'positiveDurationEndpointCarry': carry, 'runs': runs,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=Path('/workspace/bingo-stage17-20261015'))
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent / 'precision-census.json')
    parser.add_argument('--verify-output', type=Path)
    args = parser.parse_args()
    result = build(args.source.resolve())
    if args.verify_output:
        assert not args.output.exists() or args.output == args.verify_output, 'no output is used in replay mode'
        assert result == json.loads(args.verify_output.read_text()), 'replay differs'
        print(json.dumps({'replayExact': True, 'totals': result['totals']}))
    else:
        with args.output.open('x') as stream:
            json.dump(result, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
        print(json.dumps({'output': str(args.output), 'totals': result['totals']}))


if __name__ == '__main__':
    main()
