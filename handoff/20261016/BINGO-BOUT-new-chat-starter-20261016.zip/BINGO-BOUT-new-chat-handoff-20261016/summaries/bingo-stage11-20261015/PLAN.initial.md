# 段階11：Worker solveのCPU・待機・GC/JITの同時記録

計測前の計画。段階10の記録・HTML・添付ZIP・リポジトリmainを変更しない。
今回の対象は起動/準備差のうちWorker solve内の経過時間の変動。62 selector条件の
再測定、実端末、GPUの旧記録の追加解析は今回の実験には含めない。

## 仮説と区別

- H1: solveの経過時間の変動に、WorkerスレッドがCPU上で動いていない時間が寄与する。
- H2: CPU実行時間の変動には、同じスレッドのGCまたはコンパイル/JITイベントが寄与する。
- どちらも候補。同期GC/JITイベントの重なりと、算術的な時間内訳を示す。
  直接原因・過去の別試行への因果説明・全経路非悪化を自動で確定しない。

## 比較対象と固定予算

- 段階5: fea09e995bfc1036515b92771925bd7968f3c453425ea5517b7a5b480293be64
- 段階9: 59fff4685ff3f36e18d73fe9fa524ee57d81a348352e7b2912db4b7ecc1bb513
- 固定配置P1先攻: P1=[8,1,6,3,5,7,4,9,2], P2=[5,9,1,7,2,6,3,8,4]、earlyTermination=true。
- Chromium 154系、headless、1280×900、既存の322自己テストを通常実行。
- 独立ブラウザー2プロセス、各4対、2版、計16読込/solve。
  対内順序を毎ラウンド反転、run2で初期順序反転。初回も保存。
- ブラウザー・DP・性能ジョブは直列。独立したソース/記録レビューだけ並行する。
- 好ましい符号を得るため追加しない。未確定でも16標本で終了する。

## 記録方法

HTMLはそのまま読み込む。準備前にWorker生成関数を診断用にラップし、
Worker handlerへsolve開始/終了の一意なPerformanceMarkと2つの待機handshakeを挿入する。
solverクラス本文はそのまま。constructor後・solve前と、solve後・READY送信前に待機し、
全rendererスレッドのschedstatをread-onlyで保存する。対象スレッドは後から
trace markerのpid/tidで一意に選択し、名前や新規スレッド数では推測しない。
元のREADY/転送/受信検証まで実行する。通常の30秒watchdogを無効化しない。

Traceカテゴリ候補: toplevel,blink.user_timing,devtools.timeline,v8,
disabled-by-default-v8.gc,disabled-by-default-v8.compile。
利用可能カテゴリをCDPで確認し、要求/利用可能/実記録を保存する。
solve markerのts差は経過時間、tts差は当該スレッドのCPU時間。
tts欠落は不明とし、0として扱わない。差は測定精度内の境界を含む。
wall−CPUはCPU上で動いていない時間であり、runqueue待ちだけとは呼ばない。

schedstatのCPU差・runqueue待ち差はhandshake間の**包絡区間**。
dispatch、mark、probe通知も含み、solveだけの厳密値ではない。
read不能、負差、未確認の0待ちは欠測/限界として保存する。
cgroup cpu.statは前後の環境情報に留め、特定Workerへの配賦は行わない。

GC/JITイベントは対象pid/tidとsolve時刻範囲に限定。
GC: V8.GC*、MinorGC/MajorGC/Scavenge/MarkCompact。
JIT候補: 名称にcompile/optimize/maglev/turbofan/deopt（大文字小文字無視）を含むV8イベント。
ネストは区間和を取り、GC/JIT間の重複も二重計上しない。
CPU時間はtts/tdurの区間和が取得できた場合だけ示す。
event名・カテゴリの全件集計を残し、候補分類であることを明示する。
背景スレッドの重なりを直接の遅延寄与へ換算しない。

## 有用な検証と停止条件

各読込322/322、Worker初期値/gap/bytesの検証に加え、受信した全値配列のSHA-256を
計時後に計算し、16結果が一致するか確認する（固定配置P1先攻の範囲）。
同じ配置の過去の原本/段階9記録 `ba68eace30ba61d0e99ad06a824edebf04cf202b90e807c436091c10b2cd6ede`
との一致も確認する。これはP1先攻2,290,622値であり両先攻の再実行ではない。
コードhashと計画hash、生trace・CPU snapshot・分類前イベント名を保存する。
ゲーム本体への最適化は、原因と必要性が確認できるまで行わない。

60秒load/30秒worker、自己テスト失敗、値不一致、marker欠落/重複、trace data lossなら
失敗として残し、原因を調べる。カテゴリ欠落やCPU時計欠落だけなら、その項目を欠測とし、
残りの独立した記録を取得する。検証器の不具合が判明した場合だけ、変更理由と
旧記録を残した上で修正版の有限回数を別途宣言する。

出力: 本フォルダ。通常性能比較や段階10の値と集約しない。
