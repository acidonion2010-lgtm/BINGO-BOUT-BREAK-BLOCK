#!/usr/bin/env python3
"""Restore the preserved evidence without running its programs or replacing files."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import uuid
import zipfile

ROOT = Path(__file__).resolve().parent


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def safe_relative(name):
    p = PurePosixPath(name)
    if not name or '\\' in name or p.is_absolute() or '..' in p.parts or ':' in name:
        raise ValueError('Unsafe relative path: ' + name)
    return p


def safe_path(workspace, name):
    relative = safe_relative(name)
    path = workspace.joinpath(*relative.parts)
    for part in [path, *path.parents]:
        if part == workspace:
            break
        if part.is_symlink():
            raise ValueError('Symlink destination refused: ' + str(part))
    if not path.resolve().is_relative_to(workspace):
        raise ValueError('Destination outside workspace: ' + str(path))
    return path


def restore_one(workspace, entry, verify_only):
    target = safe_path(workspace, entry['target'])
    added = reused = 0
    with zipfile.ZipFile(ROOT / 'archives' / entry['name']) as archive:
        members = {}
        for info in archive.infolist():
            rel = safe_relative(info.filename)
            if rel.parts[0] != entry['prefix']:
                raise ValueError('Unexpected archive prefix')
            if info.is_dir():
                continue
            if stat.S_ISLNK(info.external_attr >> 16):
                raise ValueError('Archive symlink refused: ' + info.filename)
            name = PurePosixPath(*rel.parts[1:]).as_posix()
            safe_relative(name)
            if name in members:
                raise ValueError('Duplicate ZIP member: ' + name)
            members[name] = info
        sums_name = 'MANIFEST.sha256' if entry['target'].startswith('handoff/') else 'SHA256SUMS'
        lines = archive.read(members[sums_name]).decode('utf-8').splitlines()
        expected = {}
        for line in lines:
            checksum, name = line.split('  ', 1)
            safe_relative(name)
            if len(checksum) != 64 or any(c not in '0123456789abcdef' for c in checksum):
                raise ValueError('Invalid checksum')
            if name in expected:
                raise ValueError('Duplicate manifest entry')
            expected[name] = checksum
        if set(expected) != set(members) - {sums_name}:
            raise ValueError('Manifest coverage mismatch: ' + entry['name'])
        for name, info in members.items():
            destination = safe_path(workspace, entry['target'] + '/' + name)
            mode = (info.external_attr >> 16) & 0o777
            required = expected.get(name)
            if required is None:
                required = hashlib.sha256(archive.read(info)).hexdigest()
            if destination.exists():
                if not destination.is_file() or digest(destination) != required:
                    raise FileExistsError('Different existing file; no replacement: ' + str(destination))
                if not verify_only and os.name == 'posix' and mode & 0o111:
                    destination.chmod(stat.S_IMODE(destination.stat().st_mode) | (mode & 0o111))
                reused += 1
                continue
            if verify_only:
                raise FileNotFoundError('Missing restored file: ' + str(destination))
            destination.parent.mkdir(parents=True, exist_ok=True)
            temporary = destination.with_name(destination.name + '.restore-' + uuid.uuid4().hex)
            try:
                with archive.open(info) as source, temporary.open('xb') as output:
                    shutil.copyfileobj(source, output, 1024 * 1024)
                if digest(temporary) != required:
                    raise ValueError('Extracted file checksum mismatch: ' + name)
                if os.name == 'posix' and mode:
                    temporary.chmod(mode)
                os.link(temporary, destination)  # exclusive creation, no replacement
                added += 1
            finally:
                temporary.unlink(missing_ok=True)
        return {'archive': entry['name'], 'target': str(target),
                'manifest_files': len(expected), 'created': added, 'verified_existing': reused}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--original-only', action='store_true', help='starter: restore original stage0-9 archive only')
    parser.add_argument('--verify-only', action='store_true')
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    catalog = json.loads((ROOT / 'ARCHIVES.json').read_text())['archives']
    selected = catalog[:1] if args.original_only else catalog
    for entry in selected:
        safe_relative(entry['name'])
        archive = ROOT / 'archives' / entry['name']
        if not archive.is_file():
            raise SystemExit('Full archive required (see 03_RESTORE.md); missing: ' + entry['name'])
        if archive.stat().st_size != entry['bytes'] or digest(archive) != entry['sha256']:
            raise SystemExit('Archive checksum mismatch: ' + entry['name'])
    workspace.mkdir(parents=True, exist_ok=True)
    results = [restore_one(workspace, entry, args.verify_only) for entry in selected]
    html = workspace / 'handoff/BINGO-BOUT-handoff/project/index.html'
    expected_html = '59fff4685ff3f36e18d73fe9fa524ee57d81a348352e7b2912db4b7ecc1bb513'
    if digest(html) != expected_html or html.stat().st_size != 499212:
        raise SystemExit('Current stage9 HTML mismatch')
    print(json.dumps({'ok': True, 'archives': results, 'current_html_sha256': expected_html}, indent=2))


if __name__ == '__main__':
    main()
