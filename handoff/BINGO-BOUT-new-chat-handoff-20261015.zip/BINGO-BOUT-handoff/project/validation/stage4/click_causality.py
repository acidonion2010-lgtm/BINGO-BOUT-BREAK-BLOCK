"""Same-page, same-DP trusted-click counterfactual and component timings."""
import collections
import functools
import http.server
import json
from pathlib import Path
import statistics
import sys
import threading
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'stage3'))
from ui_response import PREPARE, INSTRUMENT, FIXTURE, assert_sample
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[2]
METHODS=['solveState','packStrategy','equilibrium','sanitizePair','sanitize','strategyGap']
PAIRS=15
def original_class():
    s=(ROOT/'index.before.html').read_text()
    return s[s.index('        class WholeGameDP'):s.index('        function wholeGameWorkerSource()')]

INSTALL=r'''source => {
    const Original = new Function(source+'\nreturn WholeGameDP;')();
    window.causal = {methods:{original:{},stage3:{}},costs:{},armed:false};
    const names=['solveState','packStrategy','equilibrium','sanitizePair','sanitize','strategyGap'];
    for(const name of names) {
        causal.methods.original[name]=Original.prototype[name];
        causal.methods.stage3[name]=WholeGameDP.prototype[name];
    }
    causal.apply = name => {
        for(const method of names) cpuWholeDp[method]=causal.methods[name][method];
        const policy=cpuWholeDp.analyze({maskP1:3,maskP2:24,t:8});
        const check=JSON.stringify({gap:policy.gap,actions:policy.legalActions,
            p:Array.from(policy.breakStrategy),q:Array.from(policy.blockStrategy)});
        if(causal.policy && causal.policy!==check)throw new Error('Policy changed in counterfactual');
        causal.policy=check;
    };
    causal.animations = () => document.getAnimations().map(a=>{
        const t=a.effect?.getComputedTiming(),el=a.effect?.target;
        return {type:a.constructor.name,name:a.animationName||a.transitionProperty||'',
            target:el?.id||el?.className||el?.tagName,playState:a.playState,pending:a.pending,
            currentTime:a.currentTime,duration:t?.duration,iterations:t?.iterations,endTime:t?.endTime};
    });
    causal.settle = async () => {
        const started=performance.now();let passes=0;
        while(true){
            const active=document.getAnimations().filter(a=>Number.isFinite(a.effect?.getComputedTiming().endTime)
                && (a.playState==='running'||a.pending));
            if(!active.length)break;
            if(performance.now()-started>3000)throw new Error('Finite animations failed to settle');
            await Promise.allSettled(active.map(a=>a.finished));
            await new Promise(resolve=>requestAnimationFrame(resolve));passes++;
        }
        return {elapsedMs:performance.now()-started,passes};
    };
    causal.describe = () => {
        const cell=getCellButton(1,2),root=document.getElementById('game-root'),body=getComputedStyle(document.body);
        return {crossOriginIsolated,animations:causal.animations(),hover:cell.matches(':hover'),
            cellRect:JSON.stringify(cell.getBoundingClientRect()),rootTransform:getComputedStyle(root).transform,
            sizes:['--cell-size','--cell-gap','--hud-score-size'].map(n=>[n,body.getPropertyValue(n)]),
            visibility:document.visibilityState,fontStatus:document.fonts.status,
            audioState:audioCtx?.state||'none',audioTime:audioCtx?.currentTime||0,bgmStep};
    };
    const wrap=(name,fn)=>function(...args){
        if(!causal.armed)return Reflect.apply(fn,this,args);
        const start=performance.now();
        try{return Reflect.apply(fn,this,args)}finally{
            causal.costs[name]=(causal.costs[name]||0)+performance.now()-start;
        }
    };
    selectCpuBlockCell=wrap('cpuSelection',selectCpuBlockCell);
    renderBoards=wrap('renderBoards',renderBoards);
    drawBingoLines=wrap('drawBingoLines',drawBingoLines);
    renderUI=wrap('renderUI',renderUI);
    playCellPress=wrap('playCellPress',playCellPress);
    initAudio=wrap('initAudio',initAudio);
    setActionMessage=wrap('setActionMessage',setActionMessage);
    document.addEventListener('click',e=>{
        // The earlier capture observer has already consumed armed and set pending.
        if(uiResponseProbe.pending&&e.target.closest?.('#board1 .cell')){causal.costs={};causal.armed=true;}
    },true);
    document.addEventListener('click',()=>{
        if(causal.armed){causal.clickCosts={...causal.costs};causal.armed=false;}
    });
}'''

def main():
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*unused):pass
        def end_headers(self):
            self.send_header('Cross-Origin-Opener-Policy','same-origin')
            self.send_header('Cross-Origin-Embedder-Policy','require-corp')
            super().end_headers()
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    result={'conditions':{'samePage':True,'sameDp':True,'cpuMethodsSwitched':METHODS,
        'pairsPerCondition':PAIRS,'gameVersion':'stage3.final snapshot',
        'crossOriginIsolation':'COOP/COEP on localhost to improve clock precision',
        'scope':'CPU-method causal diagnostic, not complete HTML performance guarantee',
        'componentTimings':'inclusive wrappers; do not sum overlapping components',
        'settling':'observed finite animations naturally finish; no animation cancellation or forced finish'},'rows':[]}
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1280,'height':900})
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        try:
            page.goto(f'http://127.0.0.1:{server.server_port}/stages/index.stage3.final.html')
            assert json.loads(page.locator('#rule-test-results').text_content())['passed']==322
            page.evaluate(PREPARE);page.evaluate(INSTRUMENT);page.evaluate(INSTALL,original_class())
            assert page.evaluate('crossOriginIsolated')
            for settled in (False,True):
                for kind in ('aa','cpu-change'):
                    samples=[]
                    targets={'before':'original','after':'original' if kind=='aa' else 'stage3'}
                    for warm in ('before','after'):
                        page.evaluate('name=>causal.apply(name)',targets[warm])
                        page.evaluate(FIXTURE,'hard')
                        if settled:page.evaluate('causal.settle()')
                        page.locator('#board1 .cell:not([disabled])').first.click()
                        page.wait_for_function('uiResponseProbe.result!==null')
                        assert_sample(page.evaluate('uiResponseProbe.result'),'hard')
                    for pair in range(PAIRS):
                        record={'pair':pair+1}
                        order=('before','after') if pair%2==0 else ('after','before')
                        for name in order:
                            page.evaluate('name=>causal.apply(name)',targets[name])
                            page.evaluate(FIXTURE,'hard')
                            initial=page.evaluate('causal.describe()')
                            wait=page.evaluate('causal.settle()') if settled else None
                            descriptor=page.evaluate('causal.describe()')
                            page.locator('#board1 .cell:not([disabled])').first.click()
                            page.wait_for_function('uiResponseProbe.result!==null')
                            sample=page.evaluate('uiResponseProbe.result');assert_sample(sample,'hard')
                            record[name]={'response':sample,'costs':page.evaluate('causal.clickCosts'),
                                'initialDescriptor':initial,'measuredDescriptor':descriptor,'settling':wait}
                        samples.append(record)
                    row={'settled':settled,'kind':kind,'samples':samples,'summary':{}}
                    keys=['cpuSelection','renderBoards','drawBingoLines','renderUI','playCellPress','initAudio','setActionMessage']
                    for key in keys:
                        b=[s['before']['costs'].get(key,0) for s in samples];a=[s['after']['costs'].get(key,0) for s in samples]
                        row['summary'][key]={'beforeMedianMs':statistics.median(b),'afterMedianMs':statistics.median(a),
                            'pairedMedianDeltaMs':statistics.median(y-x for x,y in zip(b,a))}
                    b=[s['before']['response']['handlerMs'] for s in samples];a=[s['after']['response']['handlerMs'] for s in samples]
                    row['summary']['handler']={'beforeMedianMs':statistics.median(b),'afterMedianMs':statistics.median(a),
                        'pairedMedianDeltaMs':statistics.median(y-x for x,y in zip(b,a))}
                    result['rows'].append(row)
                    print(json.dumps({'settled':settled,'kind':kind,'summary':row['summary']}),flush=True)
            result['browserErrors']=errors;assert not errors,errors
            result['passed']=True
        finally:
            browser.close();server.shutdown();server.server_close()
            (ROOT/'validation/stage4/click-causality.json').write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()
