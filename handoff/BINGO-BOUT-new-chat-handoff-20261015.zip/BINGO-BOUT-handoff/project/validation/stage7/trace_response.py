#!/usr/bin/env python3
"""Capture individual trusted HARD clicks with Chromium timeline traces.

Trace timings are a separate diagnostic condition, not normal latency numbers.
Normal locator input and the stage6 RAF/timer/CDP input each visit the original
and current HTML once. Real Workers, sound, BGM, and animation remain enabled.
Game selection, drawing, input, and timer functions are never substituted.
"""

import argparse
import base64
import functools
import hashlib
import http.server
import json
import os
from pathlib import Path
import statistics
import sys
import threading
import time
from urllib.parse import quote

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'stage6'))
import phase_input_probe as phase_input

shared = phase_input.shared
from playwright.sync_api import sync_playwright


CATEGORIES = ('devtools.timeline', 'blink.user_timing', 'renderer.scheduler', 'v8')
LABELS = ('capture', 'handler-end', 'first-raf', 'second-raf')

INSTALL_MARKER = r"""() => {
    window.traceResponseState = {enabled: false, token: '', markers: []};
    window.traceResponseMark = (label, observedNowMs) => {
        const state = traceResponseState;
        if (!state.enabled) return;
        const name = `bingo.stage7.${state.token}.${label}`;
        const mark = performance.mark(name);
        console.timeStamp(name);
        state.markers.push({label, name, observedNowMs,
            performanceMarkStartTimeMs: mark.startTime,
            markerEndNowMs: performance.now()});
    };
}"""


def trace_instrument():
    """Place scalar marks inside the existing capture/bubble/RAF callbacks."""
    source = shared.PHASE_INSTRUMENT
    replacements = (
        ('        const started = performance.now();\n',
         '        const started = performance.now();\n'
         "        traceResponseMark('capture', started);\n"),
        ('        const ended = performance.now();\n',
         '        const ended = performance.now();\n'
         "        traceResponseMark('handler-end', ended);\n"),
        ('            const firstCallbackNow = performance.now();\n',
         '            const firstCallbackNow = performance.now();\n'
         "            traceResponseMark('first-raf', firstCallbackNow);\n"),
        ('                const secondCallbackNow = performance.now();\n',
         '                const secondCallbackNow = performance.now();\n'
         "                traceResponseMark('second-raf', secondCallbackNow);\n"),
    )
    for old, new in replacements:
        if source.count(old) != 1:
            raise ValueError('Shared probe changed; review trace marker insertion')
        source = source.replace(old, new, 1)
    return source


TRACE_INSTRUMENT = trace_instrument()


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2,
                               allow_nan=False) + '\n')


def cpu_group_snapshot():
    """Read shared execution-environment CPU counters outside click timing."""
    snapshot = {'hostMonotonicNs': time.monotonic_ns()}
    for name in ('cpu.max', 'cpu.stat'):
        path = Path('/sys/fs/cgroup') / name
        try:
            value = path.read_text().strip()
            snapshot[name] = ({key: int(number) for key, number in
                               (line.split() for line in value.splitlines())}
                              if name == 'cpu.stat' else value)
        except (OSError, ValueError) as error:
            snapshot[name] = {'unavailable': type(error).__name__}
    return snapshot


class TraceCapture:
    """One ReturnAsStream tracing session; retain partial traces on failure."""

    def __init__(self, session, page, path):
        self.session = session
        self.page = page
        self.path = path
        self.complete = None
        self.buffer_usage = []
        self.active = False
        self.summary = {'path': str(path), 'categories': list(CATEGORIES),
                        'started': False, 'ended': False, 'streamReadComplete': False,
                        'integrityChecksPassed': False}
        self.complete_listener = lambda event: setattr(self, 'complete', event)
        self.usage_listener = lambda event: self.buffer_usage.append(event)
        session.on('Tracing.tracingComplete', self.complete_listener)
        session.on('Tracing.bufferUsage', self.usage_listener)

    def start(self):
        self.summary['hostStartSendMonotonicNs'] = time.monotonic_ns()
        self.session.send('Tracing.start', {
            'categories': ','.join(CATEGORIES),
            'options': 'record-until-full',
            'bufferUsageReportingInterval': 100,
            'transferMode': 'ReturnAsStream',
            'streamFormat': 'json', 'streamCompression': 'none',
        })
        self.active = True
        self.summary['started'] = True
        self.summary['hostStartAcknowledgedMonotonicNs'] = time.monotonic_ns()

    def finish(self, markers):
        try:
            if not self.active:
                raise AssertionError('Trace was not started')
            self.summary['hostEndSendMonotonicNs'] = time.monotonic_ns()
            self.session.send('Tracing.end')
            self.active = False
            self.summary['ended'] = True
            deadline = time.monotonic() + 15
            while self.complete is None and time.monotonic() < deadline:
                self.page.wait_for_timeout(20)
            if self.complete is None:
                raise TimeoutError('Tracing.tracingComplete did not arrive')
            self.summary['tracingComplete'] = self.complete
            self.summary['bufferUsageEvents'] = self.buffer_usage
            stream = self.complete.get('stream')
            if not stream:
                raise AssertionError('ReturnAsStream returned no stream handle')
            self.path.parent.mkdir(parents=True, exist_ok=True)
            reads = 0
            try:
                with self.path.open('wb') as destination:
                    while True:
                        chunk = self.session.send('IO.read', {'handle': stream, 'size': 65536})
                        data = chunk.get('data', '')
                        destination.write(base64.b64decode(data) if chunk.get('base64Encoded')
                                          else data.encode('utf-8'))
                        reads += 1
                        if chunk.get('eof'):
                            break
                        if reads > 10000:
                            raise AssertionError('Unbounded trace stream')
                self.summary['streamReadComplete'] = True
                self.summary['streamReadCalls'] = reads
            finally:
                self.session.send('IO.close', {'handle': stream})
            raw = self.path.read_bytes()
            trace = json.loads(raw)
            events = trace.get('traceEvents')
            if not isinstance(events, list) or not events:
                raise AssertionError('Trace contains no traceEvents array')
            self.summary.update({'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                                 'eventCount': len(events),
                                 'traceMetadata': trace.get('metadata')})
            marker_events = []
            for marker in markers:
                name = marker['name']
                matching = [event for event in events
                            if event.get('name') == name
                            or (event.get('name') == 'TimeStamp'
                                and event.get('args', {}).get('data', {}).get('message') == name)]
                marker_events.append({'label': marker['label'], 'name': name,
                                      'events': matching})
                if not matching:
                    raise AssertionError(f'Trace marker missing: {name}')
            self.summary['markerEvents'] = marker_events
            if [marker['label'] for marker in markers] != list(LABELS):
                raise AssertionError({'incompleteMarkers': markers})
            if self.complete.get('dataLossOccurred') is not False:
                raise AssertionError({'traceDataLossUnknownOrTrue': self.complete})
            if any(event.get('percentFull', 0) >= 1 for event in self.buffer_usage):
                raise AssertionError({'traceBufferFull': self.buffer_usage})
            self.summary['integrityChecksPassed'] = True
        except Exception as error:
            self.summary['failure'] = {'type': type(error).__name__, 'detail': str(error)}
            raise
        finally:
            self.session.remove_listener('Tracing.tracingComplete', self.complete_listener)
            self.session.remove_listener('Tracing.bufferUsage', self.usage_listener)


def prepare_input(page, protocol):
    page.evaluate(shared.FIXTURE, 'hard')
    locator = page.locator('#board1 .cell:not([disabled])').first
    metadata = {'protocol': protocol}
    if protocol == 'cdp-cue':
        locator.click(trial=True, timeout=10000)
        box = locator.bounding_box()
        if not box or box['width'] <= 0 or box['height'] <= 0:
            raise AssertionError({'targetBox': box})
        point = {'x': box['x'] + box['width'] / 2,
                 'y': box['y'] + box['height'] / 2}
        check = page.evaluate(phase_input.CHECK_TARGET, point)
        phase_input.assert_target(check)
        page.mouse.move(point['x'], point['y'])
        metadata.update({'targetBox': box, 'targetPoint': point,
                         'beforeMoveTargetCheck': check})
    descriptor = page.evaluate(shared.DESCRIBE)
    if descriptor['crossOriginIsolated']:
        raise AssertionError(descriptor)
    metadata['preClickDescriptor'] = descriptor
    if protocol == 'cdp-cue':
        check = page.evaluate(phase_input.CHECK_TARGET, metadata['targetPoint'])
        phase_input.assert_target(check)
        metadata['preCueTargetCheck'] = check
    return locator, metadata


def dispatch_input(page, session, locator, metadata, requested_delay):
    if metadata['protocol'] == 'normal-locator':
        metadata['hostLocatorClickSendMonotonicNs'] = time.monotonic_ns()
        locator.click(timeout=10000)
        metadata['hostLocatorClickAcknowledgedMonotonicNs'] = time.monotonic_ns()
    else:
        point = metadata['targetPoint']
        metadata['cue'] = page.evaluate(phase_input.CUE, requested_delay)
        metadata['hostMousePressedSendMonotonicNs'] = time.monotonic_ns()
        session.send('Input.dispatchMouseEvent', {
            'type': 'mousePressed', 'x': point['x'], 'y': point['y'],
            'button': 'left', 'buttons': 1, 'clickCount': 1,
        })
        metadata['hostMouseReleasedSendMonotonicNs'] = time.monotonic_ns()
        session.send('Input.dispatchMouseEvent', {
            'type': 'mouseReleased', 'x': point['x'], 'y': point['y'],
            'button': 'left', 'buttons': 0, 'clickCount': 1,
        })
        metadata['hostMouseReleasedAcknowledgedMonotonicNs'] = time.monotonic_ns()
    page.wait_for_function('uiResponseProbe.result !== null', timeout=10000)
    sample = page.evaluate('uiResponseProbe.result')
    shared.assert_sample(sample, 'hard')
    shared.decompose(sample)
    if metadata['protocol'] == 'cdp-cue':
        metadata.update({
            'captureMinusCueRafTimestampMs': sample['clickCaptureNowMs'] - metadata['cue']['cueRafTimestampMs'],
            'captureMinusCueTimeoutMs': sample['clickCaptureNowMs'] - metadata['cue']['timeoutCallbackNowMs'],
        })
    sample['inputDiagnostic'] = metadata
    return sample


def trial(page, session, protocol, version, number, folder, traced):
    locator, metadata = prepare_input(page, protocol)
    token = f'{protocol}.{version}.{number:02d}'
    page.evaluate('''data => {
        traceResponseState.enabled = data.enabled;
        traceResponseState.token = data.token;
        traceResponseState.markers = [];
    }''', {'enabled': traced, 'token': token})
    trace = TraceCapture(session, page, folder / 'traces' / f'{token}.json') if traced else None
    output = {'trial': number, 'traced': traced, 'outcome': 'preparing'}
    try:
        if trace:
            trace.start()
        output['cpuGroupBeforeInput'] = cpu_group_snapshot()
        output['outcome'] = 'dispatching'
        delay = phase_input.REQUESTED_DELAYS_MS[(number - 1) % len(phase_input.REQUESTED_DELAYS_MS)]
        output['requestedDelayMs'] = delay if protocol == 'cdp-cue' else None
        output['sample'] = dispatch_input(page, session, locator, metadata, delay)
        output['cpuGroupAfterCallbacks'] = cpu_group_snapshot()
        output['outcome'] = 'accepted'
    except Exception as error:
        output.update({'outcome': 'failed',
                       'failure': {'type': type(error).__name__, 'detail': str(error)}})
        raise
    finally:
        # Finish tracing even if input or behavior failed, retaining its raw data.
        # Mark validation intentionally fails an incomplete click/RAF sample.
        try:
            try:
                output['markers'] = page.evaluate('traceResponseState.markers')
            except Exception as error:
                output['markers'] = []
                output['markerReadFailure'] = {'type': type(error).__name__,
                                               'detail': str(error)}
            if trace:
                trace.finish(output['markers'])
        finally:
            if trace:
                output['trace'] = trace.summary
            write_json(folder / 'samples' / f'{token}.json', output)
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('before', type=Path)
    parser.add_argument('after', type=Path)
    parser.add_argument('outputfolder', type=Path)
    parser.add_argument('--trials', type=int, default=8)
    args = parser.parse_args()
    if args.trials < 1:
        parser.error('Use a positive trial count')
    folder = args.outputfolder.resolve()
    paths = {version: getattr(args, version).resolve(strict=True)
             for version in ('before', 'after')}
    serve_root = Path(os.path.commonpath([str(path.parent) for path in paths.values()]))

    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *unused):
            pass

    server = http.server.ThreadingHTTPServer(
        ('127.0.0.1', 0), functools.partial(Handler, directory=str(serve_root)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    report = {
        'conditions': {
            'executable': '/usr/bin/chromium', 'viewport': [1280, 900],
            'foregroundPages': 1, 'trialsPerVisit': args.trials,
            'untracedWarmupClicksPerVisit': 1,
            'visitOrder': 'normal-locator before/after, then cdp-cue after/before; one visit per protocol/version',
            'sources': {version: {'path': str(path),
                        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                        for version, path in paths.items()},
            'httpHeaders': 'Ordinary HTTP; no COOP/COEP',
            'difficulty': 'hard', 'firstPlayer': 1, 'fixedRandom': 0.8,
            'branch': 'whole-game DP (0.8 >= 0.7); actual trusted human BREAK',
            'layouts': {'p1': [8, 1, 6, 3, 5, 7, 4, 9, 2],
                        'p2': [5, 9, 1, 7, 2, 6, 3, 8, 4]},
            'fixture': {'maskP1': 3, 'maskP2': 24, 't': 8, 'inning': 5, 'turnRole': 0},
            'realBlobWorkerPreparationsPerVisit': 1,
            'fixtureWait': 'Shared three RAF callbacks; no animation finishing, cancellation, or audio changes.',
            'trace': {'categories': list(CATEGORIES), 'transferMode': 'ReturnAsStream',
                      'format': 'JSON', 'compression': 'none',
                      'bufferMode': 'record-until-full',
                      'markers': list(LABELS),
                      'startBoundary': 'After fixture/descriptor work, immediately before normal click or CDP cue. CDP trial actionability/hover preparation precedes tracing; normal locator internal actionability/mouse move occur within tracing.',
                      'endBoundary': 'After accepted click and both observed RAF callbacks.'},
            'observerOrder': 'Scalar markers are inside the existing capture/bubble/RAF callbacks. The shared later capture observer reads pending, since the first observer consumed armed.',
            'cdpCue': {'requestedDelaysMs': list(phase_input.REQUESTED_DELAYS_MS),
                       'cycle': 'Measured trials 1,5,9,13 repeated separately in each visit; warmup uses 13 ms.',
                       'actualPhase': 'Cue request and actual click phase are recorded separately, never equated.',
                       'afterCue': 'No added layout, animation, hover, or target queries before input dispatch.'},
            'clockRelation': 'performance marks and observed performance.now share the page origin. Trace marker events supply trace-clock correspondence. Host monotonic timestamps record command order only; host/page clocks are never directly subtracted.',
            'cpuGroupCounters': 'Read outside click timing immediately before input and after observed callbacks. These are shared environment cgroup counters, not per-browser CPU attribution.',
            'limits': 'Tracing and marks perturb scheduling. Trace sample timings must not be mixed with untraced latency values. No timing threshold, all-path guarantee, or physical presentation measurement is assessed.',
        },
        'visits': [], 'pageErrors': [], 'browserLogs': [],
        'behaviorChecksPassed': False, 'traceIntegrityChecksPassed': False,
        'latencyPassAssessed': False,
    }
    current = {}
    report_path = folder / 'report.json'

    def save():
        write_json(report_path, report)

    save()
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(
                executable_path='/usr/bin/chromium', headless=True,
                args=['--no-sandbox', '--disable-dev-shm-usage'])
            report['conditions']['browserVersion'] = browser.version
            page = browser.new_page(viewport={'width': 1280, 'height': 900})
            page.on('pageerror', lambda error: report['pageErrors'].append(
                {**current, 'error': str(error)}))
            page.on('console', lambda message: report['browserLogs'].append(
                {**current, 'type': message.type, 'text': message.text})
                if message.type in ('error', 'warning') else None)
            session = page.context.new_cdp_session(page)
            try:
                for protocol, order in (('normal-locator', ('before', 'after')),
                                        ('cdp-cue', ('after', 'before'))):
                    for version in order:
                        current.clear()
                        current.update({'protocol': protocol, 'version': version, 'trial': None})
                        source = paths[version]
                        relative = quote(source.relative_to(serve_root).as_posix())
                        page.goto(f'http://127.0.0.1:{server.server_port}/{relative}',
                                  wait_until='load', timeout=60000)
                        page.bring_to_front()
                        tests = json.loads(page.locator('#rule-test-results').text_content())
                        if tests['total'] != 322 or tests['passed'] != 322:
                            raise AssertionError(tests)
                        preparation = page.evaluate(shared.PREPARE)
                        page.evaluate(INSTALL_MARKER)
                        page.evaluate(TRACE_INSTRUMENT)
                        page.evaluate(shared.INSTALL_MONITOR)
                        visit = {'protocol': protocol, 'version': version,
                                 'selfTests': tests, 'preparation': preparation,
                                 'samples': []}
                        report['visits'].append(visit)
                        current['trial'] = 0
                        visit['warmup'] = trial(page, session, protocol, version, 0,
                                                folder, False)
                        for number in range(1, args.trials + 1):
                            current['trial'] = number
                            visit['samples'].append(trial(page, session, protocol, version,
                                                          number, folder, True))
                            save()
                        visit['traceConditionMediansMs'] = {
                            key: statistics.median(sample['sample'][key]
                                                   for sample in visit['samples'])
                            for key in shared.METRICS}
                        print(f"{protocol} {version}: {args.trials} accepted traced clicks; "
                              f"handler {visit['traceConditionMediansMs']['handlerMs']:.3f} ms; "
                              f"two RAF {visit['traceConditionMediansMs']['twoRafMs']:.3f} ms",
                              flush=True)
                        page.evaluate('''() => {
                            state.turnToken++;
                            discardThinkTimer();
                            releaseWholeGameCpu();
                            rafPhaseMonitor.running = false;
                            cancelAnimationFrame(rafPhaseMonitor.handle);
                        }''')
                        save()
                if report['pageErrors']:
                    raise AssertionError(report['pageErrors'])
                samples = [sample for visit in report['visits'] for sample in visit['samples']]
                if len(samples) != args.trials * 4 or not all(
                        sample['outcome'] == 'accepted' and sample['trace']['integrityChecksPassed']
                        for sample in samples):
                    raise AssertionError('Incomplete behavior/trace samples')
                report['behaviorChecksPassed'] = True
                report['traceIntegrityChecksPassed'] = True
                report['acceptedMeasuredClicks'] = len(samples)
                report['acceptedWarmupClicks'] = len(report['visits'])
            finally:
                browser.close()
    except Exception as error:
        report['failure'] = {'context': dict(current),
                             'type': type(error).__name__, 'detail': str(error)}
        save()
        raise
    finally:
        server.shutdown()
        server.server_close()
        save()


if __name__ == '__main__':
    main()
