# 段階17: preflight後の単位表現に関する解析改訂

正式計測は開始前。初期 collector は unit1000 / unit1 の各1 traceを取得後、unit1 の raw counter multiplier が希望値1と完全一致しないとして gate で停止した。failed report、collector、PLAN、2本のproto/JSON/raw ledgerは保存し、再取得しない。

停止理由は記録単位の解釈。frozen checker は descriptor の `unit_multiplier` フィールド省略を raw 0 と保存し、`raw_m > 0` のときのみ値を掛ける。したがって raw 0 は identity scale = effective 1 として既に復号される。単位省略はCPU時計の不整合ではない。公式source/configの証拠は別レビューに保存する。

解析を次のように改訂する。

1. raw `unit_multiplier` をそのまま `actualMainMultipliers` / `unitMultiplier` に保持する。raw 0をraw 1へ書き換えない。
2. pinned tokenizerおよびfrozen checkerと同じ `effective_m = raw_m if raw_m > 0 else 1` を別列 `actualMainEffectiveMultipliers` / `effectiveUnitMultiplier` に保存する。希望unitとのgate・比較にはeffective値を使用する。
3. floor-loss bound のmにもeffective値を使用し、unit1（raw0を含む）は `N × (1−1) = 0 ns`。従来の `raw_m > 0` 条件だけでモデルから除外しない。整数incremental sample・非負raw delta・信頼可能な状態の条件は継続する。
4. counter multiset / SQL / JSON / CPU endpoint の復号値、strict / >1ms閾値、zero / missing / clear / epoch の集計方法を変更しない。frozen checker、段階16ファイルも変更しない。
5. 取得済みpreflight2本のみをこの解釈で再検証する。新preflight browserは追加しない。成功後に元の正式4 browser / 8 trace / 48 formal + 16 warm clickの予算を別resume collectorで行う。これらの失敗・改訂を新reportから辿れるよう保存する。
6. `run_formal_ledgers.py` は失敗した初期reportを上書きせず、完成したresume/combined reportをCLI引数で受け取れるようにする。新しいbrowserや計測は解析器から起動しない。

`analyze_counter_units.py` のmetadataにこの文書のSHA-256を記録する。この改訂はsign・性能結果に基づく条件変更ではなく、正式計測前に発見した省略フィールドの既定算術の扱いを直すものである。
