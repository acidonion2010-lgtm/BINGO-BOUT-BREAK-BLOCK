#!/usr/bin/env python3
"""Alternating before/after timing in one Chromium, with no other browser jobs."""
import argparse
import functools
import http.server
import json
from pathlib import Path
import statistics
import threading
import time
from playwright.sync_api import sync_playwright

MEASURE_PREPARATION = '''async () => {
  Object.assign(state,{gameMode:'cpu',cpuDifficulty:'master',seatChosen:true,isStarting:true,
    gameEnded:false,firstPlayer:1,p1NumberLayout:[8,1,6,3,5,7,4,9,2],p2NumberLayout:[5,9,1,7,2,6,3,8,4]});
  const start=performance.now(); startWholeGameCpu();
  await new Promise((resolve,reject) => { const poll=() => {
    if (cpuWholeStatus==='ready') return resolve();
    if (cpuWholeStatus==='fallback') return reject(new Error(cpuWholeFailure));
    setTimeout(poll,5); }; poll(); });
  const elapsed=performance.now()-start;
  const metrics={elapsedMs:elapsed,initialValue:cpuWholeStats.initialValue,maxGap:cpuWholeStats.maxGap};
  releaseWholeGameCpu(); return metrics;
}'''

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('before',type=Path);parser.add_argument('after',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--repeats',type=int,default=5)
    parser.add_argument('--port',type=int,default=8001)
    args=parser.parse_args()
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*unused):pass
    server=http.server.ThreadingHTTPServer(('127.0.0.1',args.port),functools.partial(Handler,directory='/workspace'))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    result={'conditions':{'viewport':[1280,900],'executable':'/usr/bin/chromium','repeats':args.repeats,
        'sampleOrder':'alternating before/after, then after/before',
        'startupDefinition':'navigation through load event, includes existing automatic self tests',
        'preparationDefinition':'startWholeGameCpu through ready, fixed layouts and P1 first, 5ms polling'},'samples':[]}
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,
                args=['--no-sandbox','--disable-dev-shm-usage'])
            result['conditions']['browserVersion']=browser.version
            page=browser.new_page(viewport={'width':1280,'height':900})
            for iteration in range(args.repeats):
                order=['before','after'] if iteration%2==0 else ['after','before']
                for version in order:
                    path=getattr(args,version).resolve()
                    url=f'http://127.0.0.1:{args.port}/{path.relative_to(Path("/workspace"))}'
                    start=time.perf_counter()
                    page.goto(url,wait_until='load',timeout=60000)
                    startup=(time.perf_counter()-start)*1000
                    tests=json.loads(page.locator('#rule-test-results').text_content())
                    preparation=page.evaluate(MEASURE_PREPARATION)
                    result['samples'].append({'round':iteration+1,'version':version,'startupMs':startup,
                        'preparation':preparation,'selfTests':tests})
                    print(f'round {iteration+1} {version}: startup {startup:.1f}ms, prepare {preparation["elapsedMs"]:.1f}ms, tests {tests["passed"]}/{tests["total"]}',flush=True)
            browser.close()
    finally:
        server.shutdown();server.server_close()
    for version in ['before','after']:
        rows=[row for row in result['samples'] if row['version']==version]
        result[version]={'startupMedianMs':statistics.median(row['startupMs'] for row in rows),
            'preparationMedianMs':statistics.median(row['preparation']['elapsedMs'] for row in rows)}
    result['changePercent']={key:(result['after'][key]/result['before'][key]-1)*100 for key in result['before']}
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({key:result[key] for key in ['before','after','changePercent']},ensure_ascii=False),flush=True)

if __name__=='__main__':main()
