#!/usr/bin/env python3
"""Finite, instrumented HARD click diagnostic with simultaneous wall/CPU traces."""
import argparse
import hashlib
import http.server
import json
from pathlib import Path
import sys
import threading
import time

from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parent
PROJECT=Path('/workspace/handoff/BINGO-BOUT-handoff/project')
sys.path.insert(0,str(PROJECT/'validation/stage7'))
import trace_response as stage7

phase=stage7.shared
FILES={'original':PROJECT/'index.before.html','stage3':PROJECT/'stages/index.stage3.final.html',
       'stage5':PROJECT/'stages/index.stage5.html','stage9':PROJECT/'index.html'}
EXPECTED={'original':'e872443dc9764f3b9647f4797d1411ca98f865b9c2f69c6e694529e2685cd3a9',
          'stage3':'11bbe3d0653ca64a07756079125078b86c0abd5ed3927ff664f43ca4e4186275',
          'stage5':'fea09e995bfc1036515b92771925bd7968f3c453425ea5517b7a5b480293be64',
          'stage9':'59fff4685ff3f36e18d73fe9fa524ee57d81a348352e7b2912db4b7ecc1bb513'}
HELPERS={'stage3/ui_response.py':'b2ca7fcbf34ff70287e45f7194632db120b321015465960ef4fa3e8aac35b8f6',
         'stage5/raf_phase_response.py':'b713f791980c2a87f43edbf8b6211a92fc8f9eb26c7b364d74121294fafba504',
         'stage6/phase_input_probe.py':'5b3c9969eae88a2efac7e269589f1b4a6f24eee523f1bf9b2852c9165d603c40',
         'stage7/trace_response.py':'9da1c0cadebdbae9c5883563b8a6cecf3da4a6a4e85eaf61d64ab3224850d769'}
KEYS=list(FILES)
ORDERS=[[KEYS[(n+shift)%4] for n in [0,1,3,2]] for shift in range(4)]
assert len({(a,b) for order in ORDERS for a,b in zip(order,order[1:])})==12
CATEGORIES=('toplevel','cc','viz','devtools.timeline','blink.user_timing',
            'renderer.scheduler','v8','disabled-by-default-devtools.timeline.frame')
TRIALS=9
BRANCHES={'dp':0.8,'legacy':0.3}
INSTALL_MARKER=stage7.INSTALL_MARKER.replace('bingo.stage7.','bingo.stage14.')
FIXTURE=phase.FIXTURE
assert FIXTURE.count('async difficulty => {')==1 and FIXTURE.count('Math.random = () => 0.8;')==1
FIXTURE=FIXTURE.replace('async difficulty => {','async ({difficulty,roll}) => {',1)
FIXTURE=FIXTURE.replace('Math.random = () => 0.8;','Math.random = () => roll;',1)

NATIVE_REFS=r'''() => {
 const originals={handleCellClick,selectCpuBlockCell,selectCpuBreakCell,renderBoards,renderUI,drawBingoLines,playCellPress};
 window.stage14CheckNativeRefs=()=>{
  const current={handleCellClick,selectCpuBlockCell,selectCpuBreakCell,renderBoards,renderUI,drawBingoLines,playCellPress};
  for(const name of Object.keys(originals))if(current[name]!==originals[name])throw Error('Game function reference changed: '+name);
  return true;
 };
 return Object.fromEntries(Object.entries(originals).map(([key,value])=>[key,value.toString()]));
}'''

AUDIT=r'''roll => {
 stage14CheckNativeRefs();
 const nativeRandom=Math.random,draws=[];
 const before={whole:cpuWholeDecisions,legacy:hardLegacyDecisions,dp:hardDpDecisions};
 const publicState=()=>JSON.stringify({marks:state.p1Marks,layout:state.p1NumberLayout,
  otherMarks:state.p2Marks,otherLayout:state.p2NumberLayout,turns:[state.p1TurnsTaken,state.p2TurnsTaken],
  phase:state.phase,selected:state.selectedBreakCell,
  history:[state.cpuBlockedBreakCell,state.cpuBlockedBreakStreak,state.cpuBlockedCooldown,
           state.cpuSuccessfulBlockCell,state.cpuSuccessfulBlockStreak,state.cpuSuccessfulBlockCooldown]});
 const snapshot=publicState();
 Math.random=()=>{draws.push(roll);return roll};
 let cell;
 try{cell=selectCpuBlockCell(state.p1Marks,state.p1NumberLayout)}finally{Math.random=nativeRandom}
 if(snapshot!==publicState())throw Error('Selector changed fixed public inputs/history');
 if(!Number.isInteger(cell)||cell<0||cell>8||state.p1Marks[cell])throw Error('Invalid CPU BLOCK cell');
 return {cell,draws,counters:{whole:cpuWholeDecisions-before.whole,legacy:hardLegacyDecisions-before.legacy,dp:hardDpDecisions-before.dp},
  publicState:JSON.parse(snapshot),status:cpuWholeStatus};
}'''


def sha(raw):return hashlib.sha256(raw).hexdigest()


def write(path,data):
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    tmp.replace(path)


class VisitTrace(stage7.TraceCapture):
    def start(self):
        self.summary['categories']=list(CATEGORIES)
        self.summary['collectorIntegrityScope']='Stream/loss checks and final four markers; analyzer verifies all trial markers.'
        self.summary['hostStartSendMonotonicNs']=time.monotonic_ns()
        self.session.send('Tracing.start',{'categories':','.join(CATEGORIES),'options':'record-until-full',
            'bufferUsageReportingInterval':100,'transferMode':'ReturnAsStream','streamFormat':'json','streamCompression':'none'})
        self.active=True;self.summary['started']=True
        self.summary['hostStartAcknowledgedMonotonicNs']=time.monotonic_ns()


def assert_sample(sample,branch):
    # The historical HARD assertion assumes DP. Reuse every behavior assertion
    # for legacy through the whole=0 common case, then require its own counters.
    phase.assert_sample(sample,'hard' if branch=='dp' else 'normal')
    assert (sample['hardDpDecisions'],sample['hardLegacyDecisions'])==((1,0) if branch=='dp' else (0,1)),sample
    phase.decompose(sample)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();assert not args.output.exists(),'Refuse overwrite report'
    trace_dir=args.output.parent/'traces';assert not trace_dir.exists(),'Refuse existing trace directory'
    args.output.parent.mkdir(parents=True,exist_ok=True);trace_dir.mkdir()
    inputs={key:path.read_bytes() for key,path in FILES.items()}
    for key,raw in inputs.items():assert sha(raw)==EXPECTED[key],key
    for name,expected in HELPERS.items():assert sha((PROJECT/'validation'/name).read_bytes())==expected,name
    result={'status':'running','scriptSha256':sha(Path(__file__).read_bytes()),'planSha256':sha((ROOT/'PLAN.md').read_bytes()),
        'inputs':EXPECTED,'helpers':HELPERS,'visits':[],'pageErrors':[],
        'conditions':{'browserRuns':4,'versionVisitOrders':ORDERS,'formalClicksPerVersionBranchRun':9,
          'warmupClicksPerVersionBranchRun':1,'formalClicksPlanned':288,'warmupClicksPlanned':32,
          'branches':BRANCHES,'viewport':[1280,900],'input':'ordinary Playwright locator.click(), no force',
          'branchOrder':'dp/legacy when (zero-based run+visit-position)%2==0, otherwise reverse',
          'tracing':'One continuous trace per visit includes audits, warmups, fixture resets and all trials; windows clipped to unique markers',
          'categories':list(CATEGORIES),'gameFunctionReferencesReplaced':False,'noConcurrentBrowserJobs':True,
          'notPhysicalInputPresentationOrAudioLatency':True,'notUninstrumentedLatencyBenchmark':True}}
    write(args.output,result)

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            raw=inputs.get(self.path.strip('/'))
            if raw is None:self.send_error(404);return
            self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store')
            self.end_headers();self.wfile.write(raw)
        def log_message(self,*unused):pass

    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
    threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        with sync_playwright() as p:
            for run,order in enumerate(ORDERS):
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,
                    args=['--no-sandbox','--disable-dev-shm-usage'])
                try:
                    page=browser.new_page(viewport={'width':1280,'height':900})
                    result['conditions']['browserVersion']=browser.version
                    page.on('pageerror',lambda e:result['pageErrors'].append(str(e)))
                    session=page.context.new_cdp_session(page)
                    available=session.send('Tracing.getCategories')['categories']
                    result['conditions'].setdefault('categoryDiscovery',[]).append({'run':run+1,
                        'enumerated':available,'emptyMeansUnknown':not bool(available),
                        'requestedButNotEnumerated':sorted(set(CATEGORIES)-set(available)),
                        'requestedCategoriesNotFiltered':True})
                    for position,version in enumerate(order):
                        visit={'run':run+1,'version':version,'position':position+1,'samples':[],'audits':{}}
                        result['visits'].append(visit);write(args.output,result)
                        page.goto(f'http://127.0.0.1:{server.server_port}/{version}',wait_until='load',timeout=60000)
                        tests=json.loads(page.locator('#rule-test-results').text_content())
                        assert tests=={'passed':322,'total':322,'failures':[]},tests
                        visit['selfTests']=tests;visit['prepare']=page.evaluate(phase.PREPARE)
                        assert visit['prepare']['status']=='ready'
                        reference=next(v['prepare'] for v in result['visits'] if 'prepare' in v)
                        assert all(visit['prepare'][k]==reference[k] for k in ['initialValue','maxGap','valueTableBytes','status']),'Worker statistics differ'
                        page.evaluate(INSTALL_MARKER);page.evaluate(stage7.TRACE_INSTRUMENT)
                        page.evaluate(phase.INSTALL_MONITOR)
                        visit['nativeFunctionSources']=page.evaluate(NATIVE_REFS)
                        branches=list(BRANCHES)
                        if (run+position)%2:branches.reverse()
                        visit['branchOrder']=branches
                        trace=VisitTrace(session,page,trace_dir/f'run{run+1}-{version}.json')
                        last_markers=[];body_error=None
                        try:
                            trace.start()
                            for branch in branches:
                                fixture={'difficulty':'hard','roll':BRANCHES[branch]}
                                page.evaluate(FIXTURE,fixture)
                                audit=page.evaluate(AUDIT,BRANCHES[branch]);visit['audits'][branch]=audit
                                assert audit['status']=='ready'
                                assert audit['counters']==({'whole':1,'legacy':0,'dp':1} if branch=='dp' else {'whole':0,'legacy':1,'dp':0}),audit
                                assert audit['draws'] and all(v==BRANCHES[branch] for v in audit['draws'])
                                reference=next(v['audits'][branch] for v in result['visits'] if branch in v['audits'])
                                assert audit==reference,'CPU choice/RNG/input audit differs across versions'
                                for trial in range(TRIALS+1):
                                    record={'branch':branch,'trial':trial,'warmup':trial==0,'outcome':'preparing'}
                                    visit['samples'].append(record);write(args.output,result)
                                    page.evaluate(FIXTURE,fixture)
                                    descriptor=page.evaluate(phase.DESCRIBE)
                                    assert not descriptor['crossOriginIsolated'] and descriptor['visibility']=='visible'
                                    assert page.evaluate('()=>stage14CheckNativeRefs()')
                                    token=f'run{run+1}.{version}.{branch}.trial{trial:02d}'
                                    page.evaluate('''token=>{traceResponseState.enabled=true;traceResponseState.token=token;traceResponseState.markers=[]}''',token)
                                    record['preClickDescriptor']=descriptor
                                    record['hostClickSendMonotonicNs']=time.monotonic_ns()
                                    page.locator('#board1 .cell:not([disabled])').first.click(timeout=10000)
                                    page.wait_for_function('uiResponseProbe.result !== null',timeout=10000)
                                    record['hostClickCollectedMonotonicNs']=time.monotonic_ns()
                                    sample=page.evaluate('uiResponseProbe.result');assert_sample(sample,branch)
                                    last_markers=page.evaluate('traceResponseState.markers')
                                    assert [m['label'] for m in last_markers]==list(stage7.LABELS)
                                    record.update({'sample':sample,'markers':last_markers,'outcome':'accepted'})
                                    assert not result['pageErrors'],result['pageErrors']
                            assert page.evaluate('()=>stage14CheckNativeRefs()')
                        except BaseException as error:
                            body_error=error;visit['failure']=repr(error);raise
                        finally:
                            try:
                                if trace.active:trace.finish(last_markers)
                            except BaseException as error:
                                visit['traceFailure']=repr(error)
                                if body_error is None:raise
                            finally:visit['trace']=trace.summary;write(args.output,result)
                        # Cross-version audit dictionaries compare only identical branch fixtures.
                        for branch,audit in visit['audits'].items():
                            reference=next(v['audits'][branch] for v in result['visits'] if branch in v['audits'])
                            assert audit==reference,'CPU choice/RNG/input audit differs across versions'
                        visit['completed']=True;write(args.output,result)
                        print(f'run{run+1} {version}: 18 formal + 2 warmup trusted HARD clicks; trace verified',flush=True)
                        page.evaluate('()=>{rafPhaseMonitor.running=false;cancelAnimationFrame(rafPhaseMonitor.handle);releaseWholeGameCpu()}')
                finally:browser.close()
        samples=[s for v in result['visits'] for s in v['samples']]
        assert len(result['visits'])==16 and len(samples)==320 and all(s['outcome']=='accepted' for s in samples)
        assert sum(not s['warmup'] for s in samples)==288 and sum(s['warmup'] for s in samples)==32
        assert all(v['trace']['integrityChecksPassed'] for v in result['visits'])
        result.update({'status':'completed','formalClicksExecuted':288,'warmupClicksExecuted':32,'functionalChecksPassed':True})
    except BaseException as error:result.update({'status':'failed','failure':repr(error)});raise
    finally:write(args.output,result);server.shutdown();server.server_close()


if __name__=='__main__':main()
