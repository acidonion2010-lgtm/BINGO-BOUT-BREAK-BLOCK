#!/usr/bin/env python3
"""Read saved Chrome traces; never launch a browser or perform a benchmark.

All Chrome trace timestamps and thread timestamps are interpreted as microseconds.
GC/JIT classifications are name/category heuristics, not an exhaustive profiler.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
import math
from pathlib import Path
import re
from typing import Any


_GC_NAMES = frozenset({"MinorGC", "MajorGC", "Scavenge", "MarkCompact"})
_JIT_NAME = re.compile(r"compile|optimize|maglev|turbofan|deopt", re.IGNORECASE)
_V8_CATEGORY = re.compile(r"(?:^|[-.])v8(?:$|[-.])", re.IGNORECASE)


def _number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _merge(intervals: list[tuple[float, float]]) -> list[tuple[float, float]]:
    """Union positive-length intervals, including nested and touching intervals."""
    result: list[tuple[float, float]] = []
    for start, end in sorted((a, b) for a, b in intervals if b > a):
        if result and start <= result[-1][1]:
            result[-1] = (result[-1][0], max(result[-1][1], end))
        else:
            result.append((start, end))
    return result


def _intersection(left: list[tuple[float, float]], right: list[tuple[float, float]]) -> list[tuple[float, float]]:
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        start = max(left[i][0], right[j][0])
        end = min(left[i][1], right[j][1])
        if end > start:
            result.append((start, end))
        if left[i][1] <= right[j][1]:
            i += 1
        else:
            j += 1
    return result


def _clip(interval: tuple[float, float], bounds: tuple[float, float]) -> tuple[float, float] | None:
    start = max(interval[0], bounds[0])
    end = min(interval[1], bounds[1])
    return (start, end) if end > start else None


def _milliseconds(intervals: list[tuple[float, float]]) -> float:
    return sum(end - start for start, end in intervals) / 1000


def _metadata(event: dict, index: int) -> dict:
    return {"traceIndex": index, **{key: event[key] for key in
            ("name", "cat", "ph", "pid", "tid", "ts", "dur", "tts", "tdur") if key in event}}


def _counts(events: list[dict]) -> list[dict]:
    counts = Counter((str(event.get("name", "")), str(event.get("cat", "")), str(event.get("ph", "")))
                     for event in events if event.get("name"))
    grouped: dict[tuple[str, str], dict] = {}
    for (name, category, phase), count in sorted(counts.items()):
        item = grouped.setdefault((name, category), {"name": name, "category": category,
                                                   "count": 0, "phaseCounts": {}})
        item["count"] += count
        item["phaseCounts"][phase] = count
    return list(grouped.values())


def _roles(event: dict) -> list[str]:
    name = str(event.get("name", ""))
    category = str(event.get("cat", ""))
    is_v8 = name.lower().startswith("v8") or any(
        _V8_CATEGORY.search(part.strip()) for part in category.split(","))
    return (["gc"] if name.startswith("V8.GC") or name in _GC_NAMES else []) + (
        ["jit"] if is_v8 and _JIT_NAME.search(name) else [])


def _group(events: list[dict], cpu_bounds: tuple[float, float] | None) -> tuple[dict, list, list]:
    wall_union = _merge([tuple(item["clippedWallIntervalUs"]) for item in events])
    available_cpu = [tuple(item["clippedThreadCpuIntervalUs"]) for item in events
                     if item["clippedThreadCpuIntervalUs"] is not None]
    cpu_union = _merge(available_cpu)
    missing = [item for item in events if item["cpuIntervalUnavailableReason"] is not None]
    # No event observation is different from observing a timed event of duration zero.
    complete = cpu_bounds is not None and bool(events) and not missing
    result = {
        "eventCount": len(events),
        "wallUnionMs": _milliseconds(wall_union),
        "cpuUnionMs": _milliseconds(cpu_union) if complete else None,
        "observedCpuUnionMs": _milliseconds(cpu_union) if available_cpu else None,
        "cpuCoverageComplete": complete,
        "cpuIntervalEventCount": len(events) - len(missing),
        "missingCpuIntervalEventCount": len(missing),
        "hasObservedEvents": bool(events),
        "wallUnionIntervalsUs": wall_union,
        "observedCpuUnionIntervalsUs": cpu_union,
    }
    return result, wall_union, cpu_union


def analyse_trace(trace_path: str | Path, marker_prefix: str) -> dict:
    """Return JSON-compatible solve/thread/GC/JIT observations from a saved trace.

    Missing/duplicate markers and different marker threads raise ValueError.
    Missing CPU timestamps never become measured zero. Partial CPU coverage is
    reported separately as observedCpuUnionMs; cpuUnionMs remains None.
    Trace-loss detection belongs to the capture harness.
    """
    trace_path = Path(trace_path)
    document = json.loads(trace_path.read_text())
    events = document.get("traceEvents") if isinstance(document, dict) else document
    if not isinstance(events, list) or not all(isinstance(event, dict) for event in events):
        raise ValueError("Trace must be an event array or an object with a traceEvents array")

    markers = []
    for suffix in (".solve.start", ".solve.end"):
        matches = [(index, event) for index, event in enumerate(events)
                   if event.get("name") == marker_prefix + suffix]
        if len(matches) != 1:
            raise ValueError(f"Expected exactly one {marker_prefix + suffix!r} marker, found {len(matches)}")
        markers.append(matches[0])
    (start_index, start), (end_index, end) = markers
    if "pid" not in start or "tid" not in start or (start["pid"], start["tid"]) != (end.get("pid"), end.get("tid")):
        raise ValueError("Solve markers must have the same explicit pid and tid")
    if not _number(start.get("ts")) or not _number(end.get("ts")) or end["ts"] < start["ts"]:
        raise ValueError("Solve markers require finite, ordered wall timestamps")
    pid, tid = start["pid"], start["tid"]
    wall_bounds = (start["ts"], end["ts"])
    marker_cpu_present = _number(start.get("tts")) and _number(end.get("tts"))
    cpu_bounds = (start["tts"], end["tts"]) if marker_cpu_present and end["tts"] >= start["tts"] else None
    solve_wall = (wall_bounds[1] - wall_bounds[0]) / 1000
    solve_cpu = (end["tts"] - start["tts"]) / 1000 if marker_cpu_present else None
    target = [(index, event) for index, event in enumerate(events)
              if (event.get("pid"), event.get("tid")) == (pid, tid)]
    timed = sorted(((index, event) for index, event in target if _number(event.get("ts"))),
                   key=lambda pair: (pair[1]["ts"], pair[0]))
    parsing = {"validCompleteEvents": 0, "balancedBeginEndEvents": 0,
               "invalidIntervalEvents": [], "unmatchedBeginEvents": [], "unmatchedEndEvents": []}
    intervals = []
    stack = []
    for index, event in timed:
        phase = event.get("ph")
        if phase == "B":
            stack.append((index, event))
            continue
        if phase == "E":
            if not stack:
                parsing["unmatchedEndEvents"].append(_metadata(event, index))
                continue
            begin_index, begin = stack.pop()
            if event["ts"] < begin["ts"]:
                parsing["invalidIntervalEvents"].append(_metadata(begin, begin_index))
                continue
            cpu_interval = ((begin["tts"], event["tts"]) if _number(begin.get("tts"))
                            and _number(event.get("tts")) and event["tts"] >= begin["tts"] else None)
            intervals.append({"event": begin, "source": "paired-B/E", "traceIndices": [begin_index, index],
                              "wall": (begin["ts"], event["ts"]), "cpu": cpu_interval})
            parsing["balancedBeginEndEvents"] += 1
        elif phase == "X":
            if not _number(event.get("dur")) or event["dur"] < 0:
                parsing["invalidIntervalEvents"].append(_metadata(event, index))
                continue
            cpu_interval = ((event["tts"], event["tts"] + event["tdur"]) if _number(event.get("tts"))
                            and _number(event.get("tdur")) and event["tdur"] >= 0 else None)
            intervals.append({"event": event, "source": "complete-X", "traceIndices": [index],
                              "wall": (event["ts"], event["ts"] + event["dur"]), "cpu": cpu_interval})
            parsing["validCompleteEvents"] += 1
    parsing["unmatchedBeginEvents"] = [_metadata(event, index) for index, event in stack]

    selected = []
    overlapping_events = []
    for item in intervals:
        wall = _clip(item["wall"], wall_bounds)
        if wall is None:
            continue
        event = item["event"]
        overlapping_events.append(event)
        roles = _roles(event)
        if not roles:
            continue
        reason = ("solve-marker-cpu-bounds-unavailable-or-reversed" if cpu_bounds is None else
                  "event-cpu-timestamps-unavailable-or-reversed" if item["cpu"] is None else None)
        cpu = _clip(item["cpu"], cpu_bounds) if reason is None else None
        # A valid event may have zero CPU duration or no positive overlap with the
        # solve CPU interval. This is an available observation, not missing data.
        selected.append({"name": event.get("name", ""), "category": event.get("cat", ""),
                         "source": item["source"], "traceIndices": item["traceIndices"], "roles": roles,
                         "pid": pid, "tid": tid, "wallIntervalUs": item["wall"],
                         "threadCpuIntervalUs": item["cpu"], "clippedWallIntervalUs": wall,
                         "clippedThreadCpuIntervalUs": cpu,
                         "cpuIntervalUnavailableReason": reason})

    gc_events = [item for item in selected if "gc" in item["roles"]]
    jit_events = [item for item in selected if "jit" in item["roles"]]
    gc, gc_wall, gc_cpu = _group(gc_events, cpu_bounds)
    jit, jit_wall, jit_cpu = _group(jit_events, cpu_bounds)
    combined, _, _ = _group(selected, cpu_bounds)
    overlap_wall = _intersection(gc_wall, jit_wall)
    overlap_cpu = _intersection(gc_cpu, jit_cpu)
    both_cpu_complete = gc["cpuCoverageComplete"] and jit["cpuCoverageComplete"]
    names = [event.get("args", {}).get("name") for _, event in target
             if event.get("ph") == "M" and event.get("name") == "thread_name"]
    names = list(dict.fromkeys(name for name in names if isinstance(name, str)))
    warnings = []
    parsing_complete = not any(parsing[key] for key in
                               ("invalidIntervalEvents", "unmatchedBeginEvents", "unmatchedEndEvents"))
    if not parsing_complete:
        warnings.append("Some target-thread intervals are invalid or unmatched; coverage flags describe parsed events only. Inspect eventParsing.")
    if not marker_cpu_present:
        warnings.append("At least one solve marker lacks a finite tts; solve CPU and non-CPU time are unavailable.")
    elif cpu_bounds is None:
        warnings.append("Solve CPU timestamps run backwards; the signed difference is retained but CPU clipping is unavailable.")
    if solve_cpu is not None and solve_wall - solve_cpu < 0:
        warnings.append("Wall minus thread CPU is negative; retained without clamping or an invented tolerance.")
    for label, group in (("gc", gc), ("jit", jit)):
        if not group["hasObservedEvents"]:
            warnings.append(f"No overlapping {label} candidate interval was observed; this does not prove absence of that activity.")
        elif group["missingCpuIntervalEventCount"]:
            warnings.append(f"{label} has incomplete CPU coverage; observedCpuUnionMs covers only available intervals.")

    return {
        "tracePath": str(trace_path), "markerPrefix": marker_prefix, "pid": pid, "tid": tid,
        "threadName": names[-1] if names else None, "threadNames": names,
        "startMarker": _metadata(start, start_index), "endMarker": _metadata(end, end_index),
        "solveWallMs": solve_wall, "solveThreadCpuMs": solve_cpu,
        "nonCpuMs": solve_wall - solve_cpu if solve_cpu is not None else None,
        "availability": {"markerCpuTimestampsPresent": marker_cpu_present,
                         "cpuBoundsValid": cpu_bounds is not None},
        "gc": gc, "jit": jit, "gcJitCombined": combined,
        "gcJitOverlap": {"wallMs": _milliseconds(overlap_wall),
                         "cpuMs": _milliseconds(overlap_cpu) if both_cpu_complete else None,
                         "observedCpuMs": _milliseconds(overlap_cpu) if gc_cpu and jit_cpu else None,
                         "cpuCoverageComplete": both_cpu_complete,
                         "wallIntervalsUs": overlap_wall, "observedCpuIntervalsUs": overlap_cpu},
        "selectedEventMetadata": selected,
        "allTargetThreadEventNameCategoryCounts": _counts([event for _, event in target]),
        "solveStartTimestampEventNameCategoryCounts": _counts([event for _, event in timed
                                                              if wall_bounds[0] <= event["ts"] <= wall_bounds[1]]),
        "overlappingIntervalEventNameCategoryCounts": _counts(overlapping_events),
        "eventParsing": parsing, "eventParsingComplete": parsing_complete, "warnings": warnings,
        "limitations": [
            "Thread CPU includes all execution on this thread, not only JavaScript arithmetic.",
            "Wall minus thread CPU is not specifically runqueue wait and is not a causal attribution.",
            "GC/JIT classifications are candidate names/categories; absent events do not establish zero cost.",
            "Background-thread events are not charged to this Worker.",
            "Interval unions prevent nested and GC/JIT double counting; CPU unions require available tts/tdur.",
            "CPU coverage flags describe parsed candidate intervals; invalid or unmatched events remain in eventParsing.",
            "Trace capture, selected categories and data loss must be validated by the capture harness.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trace", type=Path)
    parser.add_argument("marker_prefix")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    output = json.dumps(analyse_trace(args.trace, args.marker_prefix), ensure_ascii=False, indent=2, allow_nan=False)
    if args.output:
        if args.output.exists():
            raise FileExistsError(f"Refusing to overwrite {args.output}")
        args.output.write_text(output + "\n")
    else:
        print(output)


if __name__ == "__main__":
    main()
