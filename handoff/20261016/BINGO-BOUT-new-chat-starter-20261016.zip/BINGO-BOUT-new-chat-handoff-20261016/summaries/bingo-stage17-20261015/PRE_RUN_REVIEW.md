# 段階17 実行前の独立静的レビュー

記録時刻: 2026-10-15T15:02:03.381892+00:00

初回レビュー時点の状態: **追加gate統合待ち。下記の再レビュー追記で解消。** 独立review担当はbrowser、Worker、DP、performance収集を起動していない。既存stage16原データの新規解析も起動していない。

## 確認した設計

- preflight 1 fresh browser × unit1000/1の各1visit、Workerなし。formalは4 fresh browser ×2unit visits。unit順AB/BA/AB/BA、browser1/2はDP先、3/4はlegacy先。8formal visits ×2branch ×(1warm+3formal) =48formal+16warm。コードの順序・件数と計画が一致する。
- 原版HTML、段階14fixture/assert/refs、段階16capture/stream/converter、公式tool、frozen raw checkerのSHA guardがある。選択関数の差替えを行わず、逐次収集。page error、stream失敗、Worker/機能failureを保存し停止する。CPU>wallの符号では停止/除外しない。
- protobuf config手書きencoderのfield番号・型を保存した固定revision schemaと照合。2unitで意味上の差はmultiplierのみ。default backend autoは、今回のChrome sourcesだけなら固定Chromium handler上でChrome backendとなる。
- SQL complete判定dur>=0、thread_ts/thread_dur欠測、負/ゼロを別集計。strict符号と>1msをns SQL/整数us JSONで区別する。MarkerのNs値はusから1000倍したもので、ns精度を回復しない。
- raw/SQL CPU sampleは(uuid,absolute_ns) multiset照合。raw BEGIN/ENDのCPU+name照合はunique/ambiguous/missingを全て保持し、limited ledgerはCPUなしeventを一部落とすことを明記する。JSON/SQLは各tuple候補照合で、完全slice-importer parityではない。
- clear/epoch、同epoch大超過、floorモデルの適用条件を保存する。N*(m-1)は非負integer CPU差分モデルの条件付き上限で、真のCPU値やremainderを復元しない。入れ子slice件数を独立試行数と解釈しない。
- SQL抽出/解析器はbrowserを起動しない。既存出力の新規作成を拒否し、script/input/tool hashesを保存する。Pythonコードはast.parseで構文確認した。

## 解消が必要なblocker

1. CONFIG_REVIEW.md採否条件にある echoed TraceConfig（sources/categories/buffers/clock/clear/sampling）、incremental wall-clock snapshots/defaults、CPU is_incremental、importer errorのpreflight gateがcapture_units.py現行raw_gateに未統合。現状は対象threadのactual multiplierのみ確認する。rootへ連絡済みでvalidator統合を予定。formal前に両unit preflightが追加gateを通る設計を再レビューする。

## 参考上の制限（blockerではない）

- broad CDP/proc外側端点は狭いmarker区間の独立CPU真値ではない。両kernel会計の依存、endpoint freshness、protocol workを残す。
- unit変更はwall timestamp表現とoverheadも変えるためゲームの高速化・全経路非退行の証拠にならない。旧62/104未確認は維持する。
- JSON変換成功returncodeはimporter診断がゼロという証明ではないため、上の独立error gateが必要。

## 初回レビューsnapshot SHA-256

| file | bytes | SHA-256 |
|---|---:|---|
| `PLAN.md` | 5186 | `f9783315ab5ae0036ea6e2056e0816846481c987010c73f83e87612f1d6d141f` |
| `make_configs.py` | 2933 | `3a648b7b619e190f6c416b93de9f81a7550ac5b194f8072e2f4af06816748dc2` |
| `capture_units.py` | 12826 | `691f99ca88f5694b54f8a267f212d44857dc4403573d1f9be02ea3ca229a43e3` |
| `ANALYSIS_PLAN.md` | 4464 | `be365795af63c585dbdf959e8066491d1237d89d058975404dd53a0f7b70093b` |
| `analyze_counter_units.py` | 22349 | `e5e317856e48dc3a3c96d4001cf500430487e791a18626868abb2334a0de3e0d` |
| `extract_sql.py` | 3542 | `ea1be1194763639e8e624629deae8a39423ad9d86289d0628a9019206cc2cc17` |
| `CONFIG_REVIEW.md` | 9631 | `17a8055fc98a217370d200f40f5f0672c9a9255623f0b3e36662bdd87751399e` |

## 追加gate統合後の再レビュー

記録時刻: 2026-10-15T15:03:07.905087+00:00

**実行前blockerは解消。固定budgetのpreflightを開始でき、両unit preflightの全gate通過後に計画されたformal収集へ進める。** reviewer自身は新browser/Worker/DP/performance処理を実行していない。

- `capture_units.py` はpreflightのraw CPU sample全件で`is_incremental is True`を要求し、既存actual multiplier gateも維持する。
- `check_effective_config.py`を確認した。TracePacket #33のechoed configを固定schemaの既知semanticで比較し、未解析fieldをnumber/wire/size/digestで保持する。clock snapshot #6とdefaults #59からprimary clock3、incremental clock64と希望倍率、default clock64を確認し、いずれか不一致なら非ゼロ終了する。固定schemaを超える完全なconfig parserとは主張しない。
- `preflight_config_health`は上記validatorの成功後、各preflightで公式SQLの非ゼロstatsをちょうど1回queryする。severity error/data_lossの非ゼロを拒否し、stdout/stderr/argv・timeout/failureを保存する。JSON変換returncodeだけを健康性の証明としない。
- gateは各preflightをcompletedにする前に逐次実行される。最初のformal browserをlaunchするのは両preflight visit完了後。PLAN末尾の収集前clarificationと一致する。
- 保存済みunit1000/1 protobufを追加validatorのconfig readerでread-only decodeし、既知semantic差がtimestamp_unit_multiplierのみであることを独立確認した。これは新たなbrowser観測ではない。
- `run_formal_ledgers.py`はreport.completed・8formal visits・run2..9を要求し、既存formal ledgerを拒否して収集完了後にfrozen checkerを逐次起動する。

### 最終レビューsnapshot SHA-256

| file | bytes | SHA-256 |
|---|---:|---|
| `PLAN.md` | 5186 | `f9783315ab5ae0036ea6e2056e0816846481c987010c73f83e87612f1d6d141f` |
| `make_configs.py` | 2933 | `3a648b7b619e190f6c416b93de9f81a7550ac5b194f8072e2f4af06816748dc2` |
| `capture_units.py` | 12943 | `ec5ed35d0fed7aefe38d13b8ec6414485b3b6e41201164038e09983bd909dabb` |
| `ANALYSIS_PLAN.md` | 4464 | `be365795af63c585dbdf959e8066491d1237d89d058975404dd53a0f7b70093b` |
| `analyze_counter_units.py` | 22349 | `e5e317856e48dc3a3c96d4001cf500430487e791a18626868abb2334a0de3e0d` |
| `extract_sql.py` | 3542 | `ea1be1194763639e8e624629deae8a39423ad9d86289d0628a9019206cc2cc17` |
| `check_effective_config.py` | 10402 | `5b254cda6ddf8a44ccbc295aa252ea1f9ca6e3de5e843f900ac84f4449185b17` |
| `run_formal_ledgers.py` | 2962 | `4dd8d077f6563169db2a23f038992037cb5c46b9b8b054737bd6adf567f0968f` |
| `CONFIG_REVIEW.md` | 11394 | `365c088d860dbd84a90c851de81662e7cc2c1e6f80467b8e3e842a1f0ea158bd` |
| `trace-config.unit1000.pb` | 255 | `f62bd90a59fa9bb19f896e0f7f9f686a78665a4eb0beac1969761f9da518f3f5` |
| `trace-config.unit1.pb` | 254 | `ce1d8a6f23813ce00d86b622de456f158a3eb553491a44e824814c2deff7db52` |
