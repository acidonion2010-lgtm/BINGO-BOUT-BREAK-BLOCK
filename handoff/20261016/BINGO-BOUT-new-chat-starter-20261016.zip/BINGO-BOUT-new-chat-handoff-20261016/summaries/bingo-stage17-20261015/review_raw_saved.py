#!/usr/bin/env python3
"""Independent arithmetic review of saved limited ledgers; does not decode proto."""
import csv,hashlib,json
from collections import Counter
from decimal import Decimal
from pathlib import Path
R=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    out=R/'post-run-independent-raw.json';assert not out.exists()
    analysis=json.loads((R/'unit-analysis.json').read_text()); results=[]
    for visit in analysis['visits']:
        run=visit['run']; path=R/f'raw-counter-run{run}.json'
        assert sha(path)==visit['ledgerSha256']
        data=json.loads(path.read_text());assert data['status']=='limited_scope_complete'
        assert data['script_sha256']==analysis['frozenCheckerSha256']
        assert data['input']['sha256']==visit['protoSha256']
        mainrows=[]; samples=[]; by_index={}
        for row in data['ledger']:
            association=row.get('event_association_at_end',{})
            if (association.get('pid'),association.get('tid'))==(visit['pid'],visit['tid']):
                mainrows.append(row);by_index[row['packet_index']]=row
            for c in row['counters']:
                a=c['association_at_end']
                if (a.get('pid'),a.get('tid'))==(visit['pid'],visit['tid']) and c.get('descriptor_name')=='thread_time' and c.get('status')=='decoded' and c.get('sum_reliable'):
                    samples.append((row,c))
        raw=Counter((c['counter_uuid'],Decimal(str(c['absolute_value']))) for row,c in samples)
        with (R/'official-sql'/f'run{run}-counters.csv').open(newline='') as stream:
            official=Counter((s['uuid'],Decimal(s['value'])) for s in csv.DictReader(stream) if s['name']=='thread_time')
        assert raw==official,(run,'counter multiset mismatch')
        rawunits=sorted({c['unit_multiplier'] for row,c in samples})
        effective=sorted({c['unit_multiplier'] if c['unit_multiplier']>0 else 1 for row,c in samples})
        assert rawunits==visit['actualMainMultipliers'] and effective==[visit['unit']]
        assert all(c['is_incremental'] for row,c in samples)
        assert len(samples)==visit['rawThreadTimeSamples']==visit['officialThreadTimeSamples']
        checks=[]
        for item in visit['largeSqlSlices']:
            assert item['rawPairCandidates']==len(item['rawProofs'])==1
            proof=item['rawProofs'][0]; begin=by_index[proof['beginPacketIndex']];end=by_index[proof['endPacketIndex']]
            assert begin['type']==1 and end['type']==2
            assert begin['event_track_uuid']==end['event_track_uuid']==proof['trackUuid']
            assert begin['sequence_id']==end['sequence_id']==proof['sequenceId']
            assert begin['name']==item['sql']['name']
            assert begin['cpu_ns']==item['sql']['thread_ts']
            assert end['cpu_ns']-begin['cpu_ns']==item['sql']['thread_dur']
            assert begin['sequence_epoch']!=end['sequence_epoch']
            inside=[t for t in data['transitions'] if t['sequence_id']==proof['sequenceId'] and begin['packet_index']<t['packet_index']<=end['packet_index']]
            assert any(t['action']=='clear' for t in inside)
            assert not any(t['action']=='loss' for t in inside)
            b=proof['begin'];m=b['effectiveUnitMultiplier'];n=b['emissionsSinceClear']
            assert m==visit['unit'] and b['cpuNs']==begin['cpu_ns'] and proof['end']['cpuNs']==end['cpu_ns']
            assert n*(m-1)==proof['positiveFloorArtifactUpperBoundNs']
            assert item['excessNs']==item['sql']['thread_dur']-item['sql']['dur']<=n*(m-1)
            checks.append({'sliceId':item['sql']['id'],'rawPairExact':True,'acrossEpoch':True,'clearInside':True,'withinConditionalBound':True})
        zero=sum(c['raw_value']==0 for row,c in samples)
        negative=sum(c['raw_value']<0 for row,c in samples)
        assert zero==visit['counts']['zeroEncodedCpuDeltas'] and negative==visit['counts']['negativeEncodedCpuDeltas']
        results.append({'run':run,'unit':visit['unit'],'preflight':visit['preflight'],'rawUnits':rawunits,'effectiveUnits':effective,
            'acceptedThreadTimeSamples':len(samples),'counterMultisetsEqual':True,'zeroRawDeltas':zero,'negativeRawDeltas':negative,
            'largeSliceChecks':checks,'diagnosticCounts':data['diagnostic_counts'],'ledgerSha256':visit['ledgerSha256']})
        del data,mainrows,by_index,samples
    result={'status':'completed','scriptSha256':sha(Path(__file__)),'analysisSha256':sha(R/'unit-analysis.json'),
        'scope':'Read-only saved ledger arithmetic and official CSV comparison; no proto decoding or new measurements. Does not independently reconstruct every full slice stack or wall clock mapping.',
        'runs':results}
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'runs':len(results),'samples':sum(v['acceptedThreadTimeSamples'] for v in results),'largeExactPairs':sum(len(v['largeSliceChecks']) for v in results)}))
if __name__=='__main__':main()
