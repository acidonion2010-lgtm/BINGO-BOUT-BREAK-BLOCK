# P2 opening MASTER fallback: source and stored-evidence review

The Stage9 raw-weight reuse code does not run on this branch. One of its four
changed functions, `selectCpuBreakCell`, is still the entry point: its NORMAL
branch is skipped and it takes the same MASTER return as before. Therefore it
would be inaccurate to say that all four changed functions are unexecuted or
that every executed function is byte-identical. The other three changed
functions are unreachable on the recorded branch. No runtime solver runs here;
MASTER fallback reads a prepared board-only table and samples its distribution.

This review ran only source/file reads and lightweight stored-JSON comparisons.
It did not run a browser, benchmark, table builder, or solver, and edited no HTML.

## Sources and measured scope

| Source | SHA-256 |
| --- | --- |
| Original `index.before.html` | e872443dc9764f3b9647f4797d1411ca98f865b9c2f69c6e694529e2685cd3a9 |
| Stage5 handoff and unchanged production `index.html` | fea09e995bfc1036515b92771925bd7968f3c453425ea5517b7a5b480293be64 |
| `stages/index.stage9.candidate.html` | 59fff4685ff3f36e18d73fe9fa524ee57d81a348352e7b2912db4b7ecc1bb513 |

`validation/stage9/selector-performance.json` compares original to candidate,
not Stage5 to candidate. It therefore includes all earlier refactor changes.
The Stage9 harness reuses stage6/stage3 normally loaded HTML fixtures and records
integer-encoded absolute clock readings before taking paired differences.

The one pooled-positive condition is P2 opening BREAK `master-fallback`:

| Summary | Original median, us | Candidate median, us | Paired median delta, us | Conditional median interval, us |
| --- | --- | --- | --- | --- |
| Run1 | 0.180 | 0.195 | +0.005 | [-0.020, +0.015] |
| Run2 | 0.190 | 0.230 | +0.040 | [+0.025, +0.090] |
| Pooled | 0.190 | 0.2175 | +0.025 | [+0.005, +0.040] |

The repeated-run classification remains **unconfirmed**: Run1 is unconfirmed,
Run2 positive. The pooled result is a conditional positive result and must be
retained. It is not the earlier floating-point near-zero boundary artifact:
its integer-encoded pooled lower endpoint corresponds to 100,000 ns per
20,000-call batch, or 0.005 us per call. Encoding does not add clock accuracy.
Within-process batch dependence and the 104-condition exploratory scope still
limit inference. This review provides neither an epsilon nor a correction that
would convert this result to a non-regression PASS.

## Actual timed call path

The recorded fixture sets gameMode=cpu, difficulty=master, engine=fallback,
`cpuWholeDp=null`, firstPlayer=2, both masks=0, t=0, both turnsTaken=0, and both
cooldowns=0. The supplied BREAK available array is [0,1,2,3,4,5,6,7,8]. Each
selection runs:

```
selectCpuBreakCell(available, undefined)
  getCpuDifficultyId() -> 'master'
  // NORMAL body skipped; available is not read on the following branch
  selectCpuEquilibriumCell('break', undefined)
    // HARD branch skipped; MASTER ready branch skipped
    cpuWholeLegacyDecisions++             // status is 'fallback'
    layout = state.p2NumberLayout
    marks = state.p2Marks
    turnsTaken = 0
    table = cpuEqBundle.p2
    assertCpuEqLayout(layout, table)
    assertCpuEqState(marks, 9) -> {mask:0, opens:[0..8]}
    getCpuDifficultyId() -> 'master'
    probs = table.breakProbs[9][0]
    value = table.values[9][0]             // checked finite
    assertCpuEqDistribution(probs, 0)
    takeCpuEqSampleRoll(undefined) -> Math.random() -> 0.8
    drawCpuEqDistribution(probs, 0, 0.8) -> 7
    consumeCpuEqCooldown('break')          // zero; no state write
```

There is one RNG draw, no HARD mixture draw, and no call to
`selectHardMixedCell`, `selectHardLegacyCell`, `selectCpuLegacyCell`,
`prepareCpuBreakCandidates`, `getCpuSelectionWeights`, `getCellWeights`,
`selectWholeGameCpuCell`, `analyze`, `equilibrium`, or `strategyGap` during this
timed branch. No scoring or weight-power computation occurs. First player is
not read on the fallback branch; only the derived P2 turn count matters here.

Per selection, source-level allocation operations create the 10-entry layout
validation `seen` array, the nine-entry state-check `opens` array, an examined
state object, and an eight-entry positive-action array for sampling. The ninth
action (cell 2) has zero probability. There are no trial-mark copies, weight
arrays, or scored-cell Sets. The sampling cursor 0.8 selects cell 7 in both
sources. The only persistent write is `cpuWholeLegacyDecisions++` because the
cooldown check finds zero. Recorded probe deltas are
`{whole:0,fallback:1,hardLegacy:0,hardFull:0}`. The last batches of both runs
record fallback=218001 in both realms; the counter does not control selection.

The fixture builds board-only tables once during installation, outside every
timed region. It also prepares a real full-game DP and calls its `analyze` in
configure for reachability/terminal diagnostics, outside the timed region, even
for fallback cases. Retaining `this.dp` in the benchmark does not make it part
of this selection path when `cpuWholeDp=null`.

## Exact source comparison

Complete function spans were extracted at their top-level indentation and
compared across original, Stage5 handoff and candidate. Results:

| Function(s) | Original to Stage5 | Stage5 to candidate | Reached during timed branch? |
| --- | --- | --- | --- |
| getCpuDifficultyId | byte-identical | byte-identical | Yes, twice |
| selectCpuBreakCell | byte-identical | changed, 578 to 225 UTF-8 bytes | Yes; changed NORMAL body skipped |
| selectCpuEquilibriumCell | byte-identical | byte-identical | Yes |
| assertCpuEqLayout, assertCpuEqState | byte-identical | byte-identical | Yes |
| takeCpuEqSampleRoll | byte-identical | byte-identical | Yes |
| assertCpuEqDistribution, drawCpuEqDistribution | byte-identical | byte-identical | Yes |
| consumeCpuEqCooldown | byte-identical | byte-identical | Yes |
| getCpuSelectionWeights | byte-identical | changed | No |
| prepareCpuBreakCandidates | byte-identical | changed | No |
| selectCpuLegacyCell | byte-identical | changed | No |
| buildCpuEqTable | changed in earlier refactor | byte-identical | No; preparation only |
| readCpuEqValue, storeCpuEqDistribution | byte-identical | byte-identical | No; preparation only |

Candidate references are `selectCpuBreakCell:5773`,
`selectCpuEquilibriumCell:5735`, `assertCpuEqLayout:5640`,
`assertCpuEqState:5656`, `takeCpuEqSampleRoll:5679`,
`assertCpuEqDistribution:5552`, `drawCpuEqDistribution:5566`, and
`consumeCpuEqCooldown:5688` in `stages/index.stage9.candidate.html`.

The original wrapper's NORMAL branch directly prepared candidates, weights and
choice. Candidate replaces that branch with one legacy-helper call. The MASTER
condition/return instructions in source are unchanged, but the whole wrapper
has a different source body and size. VM compilation, inlining, code placement
and feedback for that wrapper can therefore differ. Source review cannot prove
that its skipped NORMAL body has zero effect on generated runtime code.

## Prepared table data and earlier refactor scope

`buildCpuEqTable` changed between Stage1 and Stage2.final and remains identical
through Stage3.final, Stage4, Stage5 and the candidate. The original/Stage1
function span is 5251 UTF-8 bytes with SHA-256
`570c11727505f8109e830e597bc0e9f4315d5bdd49586ae5e24e9f1fafebb450`.
The Stage2.final onward span is 2639 bytes with SHA-256
`a7e26e7ba008b5e4193dfad618cdc3e5e0b04ccca45b4adaa06d2062309959c5`.

The earlier implementation allocates/sorts positive-gain items and support
objects inside table construction. The refactor calls the shared solver in
monotone mode and reuses its scratch arrays and the two temporary policy arrays.
Both implementations store fresh length-9 Float64 distributions for the same
reachable table states. This changes preparation work and allocation history,
not the operations used to validate and sample the selected policy at runtime.

Stored captures in `validation/before/snapshot.json`,
`validation/stage5/after/snapshot.json` and
`validation/stage9/capture/snapshot.json` contain the same target row:

```
r = 9, mask = 0, value = 30.466738322540145
break = [0.12085416045759614, 0.1174636758797568, 0,
         0.12906480836972328, 0.11572779126664684, 0.13839631849830727,
         0.1333545713747715, 0.11499045608524149, 0.13014821806795684]
```

For each capture, recoding the target value and both strategy vectors as 19
big-endian IEEE-754 doubles gives SHA-256
`84d2383a7ba73a9b1e057be396f2a867b675580b6e77961b4c1b5eeb23696008`.
Recoding all 99,840 numeric fields, including r/mask descriptors, in the captured
P1/P2 fallback table rows gives the same hash in all three snapshots:
`9b28f76b8768d8ed23c4e0aa1ad7ba806e52862189fc36b30ed2c9e38f61b656`.
Each contains 2816 reachable rows per player. This supplements the existing
comparison's zero maximum numerical difference; it checks exact binary64 values
reconstructed from stored JSON, not heap addresses or the raw timed-run memory.
There is no observed changed policy/data branch explaining the remaining delta.

Earlier full-DP refactors also change value-table preparation and object layout,
and normal page self-tests and prior measured conditions have different
allocation/compilation histories. The Stage9 reuse change reduces allocations
in prior legacy BREAK cases in the same page. Such differences can influence GC,
code placement or tiering when a later MASTER-fallback batch executes. These
are mechanisms to investigate, not established causes or grounds to discard the
stored positive interval.

## Remaining conclusion and useful isolation

The actual local raw-weight reuse operations cannot directly add work to this
MASTER path. An executed entry wrapper does change source, and the comparison
also includes earlier preparation/refactor differences, so source inspection
does not isolate the positive timing delta to or away from Stage9 as a whole.
No behavior difference, changed table value, extra RNG draw, cooldown write or
runtime solver call was found.

A mechanism test could swap only original/Stage5 versus candidate
`selectCpuBreakCell` in one already initialized realm while retaining one
`selectCpuEquilibriumCell` implementation, the same fallback table and state
references, RNG and counters. A/A duplicate-function and construction-order
controls would expose sensitivity to function replacement. A normally loaded
Stage5-to-candidate comparison would instead isolate the local change plus its
page history. Neither should be substituted for the retained original-to-
candidate result, and neither has been run by this reviewer.

As an existing observational comparison, P1 opening BREAK MASTER fallback uses
the same relevant P2 marks/layout/turn count/table row and had pooled delta
-0.020 us with interval [-0.030,-0.005], while its repeated-run classification
was also unconfirmed. This shows different outcomes for equivalent policy
inputs at different positions/history in this fixture. It does not prove a
noise cause and supplies no subtraction or regression allowance.

Strict all-condition non-regression remains unconfirmed. The report's concrete
finding is the limited call path and absence of a direct reuse/data/solver-work
explanation, not a performance clearance for the pooled-positive condition.
