#!/usr/bin/env python3
"""Read echoed TraceConfig + ClockSnapshots independently; no browser or writes to inputs.

Only the fixed schema fields listed here are interpreted. Unknown fields are retained
as a number/wire/size/digest inventory, rather than silently treated as configuration.
This does not decode event counters (the frozen stage16 checker does that).
"""
import argparse, collections, hashlib, json
from pathlib import Path

def sha(data):
    return hashlib.sha256(data).hexdigest()

def varint(data, pos):
    value = 0
    for shift in range(0, 70, 7):
        if pos >= len(data):
            raise ValueError('truncated varint')
        byte = data[pos]; pos += 1
        value |= (byte & 127) << shift
        if not byte & 128:
            if shift == 63 and byte > 1:
                raise ValueError('varint exceeds uint64')
            return value, pos
    raise ValueError('overlong varint')

def fields(data):
    result = collections.defaultdict(list)
    pos = 0
    while pos < len(data):
        tag, pos = varint(data, pos)
        field, wire = tag >> 3, tag & 7
        if not field:
            raise ValueError('zero field number')
        if wire == 0:
            value, pos = varint(data, pos)
        elif wire in (1, 5):
            length = 8 if wire == 1 else 4
            if pos + length > len(data):
                raise ValueError('truncated fixed-width value')
            value = data[pos:pos+length]; pos += length
        elif wire == 2:
            length, pos = varint(data, pos)
            if pos + length > len(data):
                raise ValueError('truncated length-delimited value')
            value = data[pos:pos+length]; pos += length
        else:
            raise ValueError(f'unsupported wire type {wire}')
        result[field].append((wire, value))
    return result

def values(data, field, wire):
    result = []
    for actual, value in data.get(field, []):
        if actual != wire:
            raise ValueError(f'field {field}: wire {actual}, expected {wire}')
        result.append(value)
    return result

def one(data, field, wire, default=None):
    found = values(data, field, wire)
    if len(found) > 1:
        raise ValueError(f'duplicate singular field {field}')
    return found[0] if found else default

def unknown(data, known):
    return [{'field':f, 'wire':w, **({'value':v} if w == 0 else
            {'bytes':len(v), 'sha256':sha(v)})}
            for f in sorted(data) if f not in known for w,v in data[f]]

def text(data, field, default=''):
    return one(data, field, 2, default.encode()).decode('utf8', errors='strict')

def chrome(raw):
    data = fields(raw)
    return {'trace_config': text(data, 1),
            'privacy_filtering_enabled': bool(one(data,2,0,0)),
            'convert_to_legacy_json': bool(one(data,3,0,0)),
            'event_package_name_filter_enabled': bool(one(data,6,0,0)),
            'unparsedFields':unknown(data,{1,2,3,6})}

def track(raw):
    data = fields(raw)
    return {'disabled_categories':[v.decode('utf8') for v in values(data,1,2)],
            'enabled_categories':[v.decode('utf8') for v in values(data,2,2)],
            'disable_incremental_timestamps':bool(one(data,5,0,0)),
            'timestamp_unit_multiplier':one(data,6,0,1),
            'filter_debug_annotations':bool(one(data,7,0,0)),
            'enable_thread_time_sampling':bool(one(data,8,0,0)),
            'filter_dynamic_event_names':bool(one(data,9,0,0)),
            'thread_time_subsampling_ns':one(data,10,0,0),
            'unparsedFields':unknown(data,{1,2,5,6,7,8,9,10})}

def source(raw):
    wrapper = fields(raw)
    data = fields(one(wrapper,1,2,b''))
    result = {'name':text(data,1), 'target_buffer':one(data,2,0,0),
              'chrome_config':chrome(one(data,101,2,b'')),
              'unparsedFields':unknown(data,{1,2,101,113}),
              'wrapperUnparsedFields':unknown(wrapper,{1})}
    te = one(data,113,2)
    if te is not None:
        result['track_event_config'] = track(te)
    return result

def config(raw):
    data = fields(raw)
    buffers=[]
    for rawbuf in values(data,1,2):
        b=fields(rawbuf)
        buffers.append({'size_kb':one(b,1,0,0), 'fill_policy':one(b,4,0,0),
                        'unparsedFields':unknown(b,{1,4})})
    builtin=fields(one(data,20,2,b''))
    incremental=fields(one(data,21,2,b''))
    return {'buffers':buffers,
            'data_sources':[source(v) for v in values(data,2,2)],
            'builtin_data_sources':{
                'primary_trace_clock':one(builtin,5,0,0),
                'disable_clock_snapshotting':bool(one(builtin,1,0,0)),
                'disable_trace_config':bool(one(builtin,2,0,0)),
                'disable_system_info':bool(one(builtin,3,0,0)),
                'disable_service_events':bool(one(builtin,4,0,0)),
                'unparsedFields':unknown(builtin,{1,2,3,4,5})},
            'incremental_state_config':{'clear_period_ms':one(incremental,1,0,0),
                'unparsedFields':unknown(incremental,{1})},
            'unparsedFields':unknown(data,{1,2,20,21})}

def comparable(value):
    """Known semantic settings only; unknown fields remain visible in the report."""
    if isinstance(value,dict):
        return {k:comparable(v) for k,v in value.items()
                if k not in ('unparsedFields','wrapperUnparsedFields')}
    if isinstance(value,list):
        return [comparable(v) for v in value]
    return value

def snapshot(raw):
    data=fields(raw);clocks=[]
    for clockraw in values(data,1,2):
        c=fields(clockraw)
        clocks.append({'clock_id':one(c,1,0), 'timestamp':one(c,2,0),
                       'is_incremental':bool(one(c,3,0,0)),
                       'unit_multiplier_ns':one(c,4,0,1),
                       'unparsedFields':unknown(c,{1,2,3,4})})
    return {'primary_trace_clock':one(data,2,0), 'clocks':clocks,
            'unparsedFields':unknown(data,{1,2})}

def inspect(trace_path, config_path):
    raw=trace_path.read_bytes();requested=config_path.read_bytes()
    request=config(requested)
    tracks=[s['track_event_config'] for s in request['data_sources']
            if s['name']=='track_event' and 'track_event_config' in s]
    if len(tracks)!=1 or tracks[0]['timestamp_unit_multiplier'] not in (1,1000):
        raise ValueError('expected one explicit 1/1000-unit track_event source')
    unit=tracks[0]['timestamp_unit_multiplier']
    report={'trace':str(trace_path), 'traceSha256':sha(raw), 'bytes':len(raw),
            'requestedConfig':str(config_path), 'requestedConfigSha256':sha(requested),
            'requestedDecoded':request, 'expectedUnitMultiplierNs':unit,
            'traceConfigs':[], 'clockSnapshots':[], 'packetDefaults':[]}
    envelope=fields(raw)
    report['envelopeUnparsedFields']=unknown(envelope,{1})
    packets=values(envelope,1,2)
    report['packets']=len(packets)
    for index,rawpacket in enumerate(packets):
        packet=fields(rawpacket)
        for rawconfig in values(packet,33,2):
            decoded=config(rawconfig)
            report['traceConfigs'].append({'packetIndex':index,
                'bytes':len(rawconfig), 'sha256':sha(rawconfig), 'decoded':decoded,
                'knownSemanticsMatchRequested':comparable(decoded)==comparable(request)})
        for rawsnapshot in values(packet,6,2):
            s=snapshot(rawsnapshot)
            s.update(packetIndex=index,
                     trustedPacketSequenceId=one(packet,10,0),
                     packetTimestamp=one(packet,8,0),
                     packetTimestampClockId=one(packet,58,0))
            report['clockSnapshots'].append(s)
        for rawdefaults in values(packet,59,2):
            defaults=fields(rawdefaults)
            trackdefaults=fields(one(defaults,11,2,b''))
            report['packetDefaults'].append({'packetIndex':index,
                'trustedPacketSequenceId':one(packet,10,0),
                'timestamp_clock_id':one(defaults,58,0),
                'track_uuid':one(trackdefaults,11,0),
                'unparsedFields':unknown(defaults,{58,11})})
    report['hasEchoedTraceConfig']=bool(report['traceConfigs'])
    report['allEchoedKnownSemanticsMatch']=bool(report['traceConfigs']) and all(
        c['knownSemanticsMatchRequested'] for c in report['traceConfigs'])
    primary=[s['primary_trace_clock'] for s in report['clockSnapshots']
             if s['primary_trace_clock'] is not None]
    report['primaryClockValues']=sorted(set(primary))
    report['allObservedPrimaryClocksMonotonic']=bool(primary) and set(primary)=={3}
    clocktypes=collections.Counter((c['clock_id'],c['is_incremental'],c['unit_multiplier_ns'])
        for s in report['clockSnapshots'] for c in s['clocks'])
    report['clockKinds']=[{'clockId':cid,'incremental':inc,'unitMultiplierNs':unit,'count':n}
        for (cid,inc,unit),n in sorted(clocktypes.items())]
    incremental=[c for s in report['clockSnapshots'] for c in s['clocks']
                 if c['clock_id']==64]
    report['allIncrementalClock64UnitsMatch']=bool(incremental) and all(
        c['is_incremental'] and c['unit_multiplier_ns']==unit for c in incremental)
    defaults=[d['timestamp_clock_id'] for d in report['packetDefaults']]
    report['allPacketDefaultClocks64']=bool(defaults) and set(defaults)=={64}
    report['allGatesPass']=all(report[k] for k in (
        'allEchoedKnownSemanticsMatch','allObservedPrimaryClocksMonotonic',
        'allIncrementalClock64UnitsMatch','allPacketDefaultClocks64'))
    return report

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('trace',type=Path)
    parser.add_argument('--config',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    result=inspect(args.trace,args.config)
    result['scriptSha256']=sha(Path(__file__).read_bytes())
    with args.output.open('x') as f:
        json.dump(result,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
    print(json.dumps({k:result[k] for k in ('packets','hasEchoedTraceConfig',
        'allEchoedKnownSemanticsMatch','primaryClockValues',
        'allObservedPrimaryClocksMonotonic','clockKinds',
        'allIncrementalClock64UnitsMatch','allPacketDefaultClocks64',
        'allGatesPass')},ensure_ascii=False))
    if not result['allGatesPass']:
        raise SystemExit(1)

if __name__=='__main__':
    main()
