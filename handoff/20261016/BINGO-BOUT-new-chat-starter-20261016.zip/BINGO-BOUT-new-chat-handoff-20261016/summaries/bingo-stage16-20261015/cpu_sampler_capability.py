#!/usr/bin/env python3
"""Fixed idle-child API capability check; no benchmark/browser or busy workload."""
import argparse
import ctypes
import errno
import hashlib
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import threading
import time


CHILD = r'''
import json,os,sys,threading,time
ready=threading.Event(); done=threading.Event(); info={}
def worker():
 info.update({'workerTid':threading.get_native_id(),'workerSelfClockNs':time.thread_time_ns()});ready.set();done.wait(10)
t=threading.Thread(target=worker);t.start();ready.wait(5)
print(json.dumps({'pid':os.getpid(),'mainTid':threading.get_native_id(),'mainSelfClockNs':time.thread_time_ns(),**info}),flush=True)
sys.stdin.readline();done.set();t.join(5)
'''


class Timespec(ctypes.Structure):
    _fields_ = [('tv_sec', ctypes.c_long), ('tv_nsec', ctypes.c_long)]


def clock_probe(clock_id):
    library = ctypes.CDLL(None, use_errno=True)
    library.clock_gettime.argtypes = [ctypes.c_int, ctypes.POINTER(Timespec)]
    library.clock_gettime.restype = ctypes.c_int
    value = Timespec(); ctypes.set_errno(0)
    before = time.monotonic_ns()
    rc = library.clock_gettime(clock_id, ctypes.byref(value))
    after = time.monotonic_ns(); error = ctypes.get_errno()
    return {'clockId': clock_id, 'returnCode': rc,
            'errno': error if rc else 0, 'errnoName': errno.errorcode.get(error) if rc else None,
            'cpuTimeNs': value.tv_sec * 10**9 + value.tv_nsec if rc == 0 else None,
            'hostBeforeMonotonicNs': before, 'hostAfterMonotonicNs': after}


def proc_read(pid, tid):
    base = Path(f'/proc/{pid}/task/{tid}')
    before = time.monotonic_ns()
    schedstat = (base / 'schedstat').read_text().strip()
    after = time.monotonic_ns()
    raw_stat = (base / 'stat').read_text().strip()
    # Field 3 starts after the final ')' of comm. A comm may contain spaces or ')'.
    fields = raw_stat.rsplit(')', 1)[1].split()
    values = list(map(int, schedstat.split()))
    return {'pid': pid, 'tid': tid, 'schedstatRaw': schedstat,
            'cpuRuntimeNs': values[0], 'runqueueWaitNs': values[1], 'scheduleCount': values[2],
            'hostReadBeforeMonotonicNs': before, 'hostReadAfterMonotonicNs': after,
            'stat': {'comm': raw_stat[raw_stat.index('(')+1:raw_stat.rfind(')')],
                     'state': fields[0], 'utimeTicks': int(fields[11]),
                     'stimeTicks': int(fields[12]), 'starttimeTicks': int(fields[19])},
            'statusIdentity': [line for line in (base / 'status').read_text().splitlines()
                               if line.startswith(('Name:', 'Tgid:', 'Pid:', 'NStgid:', 'NSpid:'))]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True); args = parser.parse_args()
    assert not args.output.exists(), 'Refuse overwrite'
    ready = threading.Event(); done = threading.Event(); own = {}
    def worker():
        own['tid'] = threading.get_native_id(); ready.set(); done.wait(10)
    thread = threading.Thread(target=worker); thread.start(); assert ready.wait(5)
    child = subprocess.Popen([sys.executable, '-c', CHILD], text=True,
                             stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        assert select.select([child.stdout], [], [], 5)[0], 'Child readiness timeout'
        child_info = json.loads(child.stdout.readline())
        targets = [('ownMain', os.getpid(), threading.get_native_id()),
                   ('ownWorker', os.getpid(), own['tid']),
                   ('childMain', child_info['pid'], child_info['mainTid']),
                   ('childWorker', child_info['pid'], child_info['workerTid'])]
        records = []
        for name, pid, tid in targets:
            dynamic_id = ((~tid) << 3) | 6
            records.append({'target': name, 'pid': pid, 'tid': tid,
                            'threadDynamicClock': clock_probe(dynamic_id),
                            'processDynamicClock': clock_probe(((~pid) << 3) | 2),
                            'proc': proc_read(pid, tid)})
        output = {'status': 'completed', 'scriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  'scope': 'One libc clock/proc capability snapshot of own idle threads and an idle child process; no browser or workload benchmark.',
                  'sysClkTck': os.sysconf('SC_CLK_TCK'), 'ownPid': os.getpid(), 'child': child_info,
                  'records': records, 'selfClockThreadCputimeId': clock_probe(3)}
        _, stderr = child.communicate('\n', timeout=5)
        assert child.returncode == 0 and not stderr
        output['childCleanup'] = {'returnCode': child.returncode, 'stderr': stderr}
        with args.output.open('x') as file: file.write(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
        print(json.dumps({'targets': [{'target': r['target'], 'threadClockReturn': r['threadDynamicClock']['returnCode'],
                                     'errno': r['threadDynamicClock']['errnoName'], 'schedstatReadable': True}
                                    for r in records], 'sysClkTck': output['sysClkTck']}))
    finally:
        done.set(); thread.join(5)
        if child.poll() is None: child.kill(); child.communicate(timeout=5)


if __name__ == '__main__': main()
