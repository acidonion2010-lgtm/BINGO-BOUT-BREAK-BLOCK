#!/usr/bin/env python3
"""Existing-ledger quantization/reset model checks; no new measurement."""
import bisect
from collections import defaultdict
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    proofs = json.loads((ROOT / 'raw-counter-official-check.json').read_bytes())
    report = json.loads((ROOT / 'report.json').read_bytes())
    visits = {v['run']: v for v in report['visits']}
    result = {'scriptSha256': sha(Path(__file__)), 'rawOfficialCheckSha256': sha(ROOT / 'raw-counter-official-check.json'),
        'scope': 'Source-encoding model association and bounds from existing proto ledgers. Actual pre-division CPU ns/remainders are not saved; no recovery of exact lost time or proof of a sole cause.',
        'bound': 'For nonnegative CPU samples and multiplier m, each producer emission discards r in [0,m-1] ns. After N emissions since clear, cumulative lost L is in [0,N*(m-1)]. A cross-clear represented interval differs from true CPU interval by L_begin-L_end. Positive artifact <= N_begin*(m-1). This is a necessary compatibility bound when comparing excess over elapsed wall; snapshot nonsimultaneity and wall conversion remain separate.',
        'runs': []}
    for runproof in proofs['runs']:
        run = runproof['run']
        ledger = json.loads((ROOT / f'raw-counter-run{run}.json').read_bytes())
        pid, tid = visits[run]['conversion']['rendererPidTid']
        counts = defaultdict(int)
        groups = defaultdict(list)
        row_samples = {}
        negative = 0
        for row in ledger['ledger']:
            for entry in row['counters']:
                a = entry['association_at_end']
                if entry.get('descriptor_name') != 'thread_time' or entry.get('status') != 'decoded' or not entry.get('sum_reliable') or a.get('status') != 'thread' or (a.get('pid'), a.get('tid')) != (pid, tid):
                    continue
                assert entry['is_incremental'] and entry['unit_multiplier'] == 1000
                assert entry['kind'] == 'integer_extra'
                negative += entry['raw_value'] < 0
                key = (row['sequence_id'], row['sequence_epoch'], entry['counter_uuid'])
                counts[key] += 1
                sample = {'packetIndex': row['packet_index'], 'sequenceId': row['sequence_id'], 'epoch': row['sequence_epoch'],
                    'counterUuid': entry['counter_uuid'], 'cpuNs': int(entry['absolute_value']),
                    'rawValue': entry['raw_value'], 'emissionsSinceClear': counts[key],
                    'maxCumulativeFloorLossNs': counts[key] * 999}
                groups[(row['sequence_id'], entry['counter_uuid'])].append(sample)
                if row.get('cpu_counter_uuid') == entry['counter_uuid']:
                    row_samples[row['packet_index']] = sample
        times = defaultdict(list)
        with (ROOT / f'official-sql/run{run}-counters.csv').open() as f:
            for row in csv.DictReader(f):
                if row['name'] != 'thread_time':
                    continue
                key = (str(int(row['uuid']) & ((1 << 64) - 1)), int(Decimal(row['value'])))
                times[key].append(int(row['ts']))
        bounds = []
        for check in runproof['largeSliceChecks']:
            assert len(check['rawProof']) == 1
            proof = check['rawProof'][0]
            b, e = row_samples[proof['beginPacketIndex']], row_samples[proof['endPacketIndex']]
            inside = [t for t in ledger['transitions'] if t['sequence_id'] == b['sequenceId'] and b['packetIndex'] < t['packet_index'] <= e['packetIndex']]
            bounds.append({'sliceId': check['sliceId'], 'name': check['name'], 'sqlExcessNs': check['excessNs'],
                'begin': b, 'end': e, 'epochsDiffer': b['epoch'] != e['epoch'], 'insideTransitions': inside,
                'positiveFloorArtifactUpperBoundNs': b['maxCumulativeFloorLossNs'],
                'excessWithinFloorLossUpperBound': check['excessNs'] <= b['maxCumulativeFloorLossNs']})
        boundaries = []
        for (seq, uuid), samples in groups.items():
            positions = [s['packetIndex'] for s in samples]
            for t in ledger['transitions']:
                if t['sequence_id'] != seq or t['action'] != 'clear':
                    continue
                index = bisect.bisect_left(positions, t['packet_index'])
                if index == 0 or index >= len(samples):
                    continue
                before, after = samples[index - 1], samples[index]
                btimes, etimes = times[(uuid, before['cpuNs'])], times[(uuid, after['cpuNs'])]
                wall = etimes[0] - btimes[0] if len(btimes) == len(etimes) == 1 else None
                cpu = after['cpuNs'] - before['cpuNs']
                excess = cpu - wall if wall is not None else None
                boundaries.append({'clearPacketIndex': t['packet_index'], 'sequenceId': seq, 'counterUuid': uuid,
                    'before': before, 'after': after, 'cpuStepNs': cpu,
                    'officialBeforeCounterWallCandidates': btimes, 'officialAfterCounterWallCandidates': etimes,
                    'officialWallStepNs': wall, 'cpuMinusWallStepNs': excess,
                    'positiveStepWithinPriorFloorLossBound': excess <= before['maxCumulativeFloorLossNs'] if excess is not None else None,
                    'excessPerPriorEmissionNs': excess / before['emissionsSinceClear'] if excess is not None else None})
        record = {'run': run, 'negativeEncodedCpuDeltas': negative, 'largeSlices': len(bounds),
            'largeSlicesAcrossEpoch': sum(b['epochsDiffer'] for b in bounds),
            'largeSlicesWithClearInside': sum(any(t['action'] == 'clear' for t in b['insideTransitions']) for b in bounds),
            'largeSlicesWithinFloorBound': sum(b['excessWithinFloorLossUpperBound'] for b in bounds),
            'largeSliceBounds': bounds, 'subsequentMainClearBoundaries': boundaries}
        result['runs'].append(record)
        print({'run': run, 'large': len(bounds), 'withinFloorBound': record['largeSlicesWithinFloorBound'],
            'boundaries': len(boundaries), 'boundaryExcessesNs': [b['cpuMinusWallStepNs'] for b in boundaries]}, flush=True)
    result['summary'] = {k: sum(r[k] for r in result['runs']) for k in ['negativeEncodedCpuDeltas', 'largeSlices', 'largeSlicesAcrossEpoch', 'largeSlicesWithClearInside', 'largeSlicesWithinFloorBound']}
    result['summary']['mainSubsequentClearBoundaries'] = sum(len(r['subsequentMainClearBoundaries']) for r in result['runs'])
    out = ROOT / 'cpu-quantization-model-check.json'
    with out.open('x') as file:
        json.dump(result, file, ensure_ascii=False, indent=2)
        file.write('\n')
    print(result['summary'], flush=True)


if __name__ == '__main__':
    main()
