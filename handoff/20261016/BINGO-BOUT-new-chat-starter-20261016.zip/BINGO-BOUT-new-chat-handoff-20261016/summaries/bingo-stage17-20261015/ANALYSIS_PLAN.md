# 段階17: counter unit 対照の解析計画

収集前に保存する解析仕様。段階16の実測・解析・原データは変更しない。

- 対象は原版HTML。preflight は別 browser で unit 1000 / 1 の各1 trace、実測は4 fresh browser × 2 trace、unit の順番は AB / BA / AB / BA。各 trace は DP / legacy について1 warmup + 3 formal = 8 click。preflight と実測、warmup と formal を別集計する。全失敗・部分取得・ゼロ・負差・欠測を保存する。
- 希望設定は `report.visits[].unit`。実際の renderer main thread の `thread_time` CounterDescriptor にある `unit_multiplier` を raw protobuf から検査し、希望値との一致を別途示す。希望値だけで成功扱いしない。
- raw counter の算術には段階16の frozen `raw_counter_check.py` (SHA-256 `91762a94d1e1e05305c2a11fbb237dd4b42bffd3ebb5162f48c4cec42b038c23`) を変更せず使用する。段階17へ ledger を出力する。公式同一protoのSQL/JSON変換には段階16の `trace_processor_shell` (SHA-256 `58042408e6cc861fb1a731c26bb082dc222285561eaa4e12a48a8b2b90dca7b9`) を再利用する。
- SQL は各 trace の renderer PID / main TID に限定し、全 slice、全 counter、非ゼロ stats を保存する。slice の完了判定は `dur >= 0`。thread_ts / thread_dur の欠測、負 thread duration、ゼロ duration を個別に数える。slice の strict `thread_dur > dur` と `thread_dur - dur > 1,000,000 ns` を変更せず集計する。入れ子 slice は独立試行数ではない。
- JSON の同一 thread の全 X event を対象に strict `tdur > dur` / 超過 `> 1000 us` を別集計する。SQL からJSONへの整数us変換が signを変える可能性があるため、SQLとJSONのsign数を同一視しない。JSONの各Xを name / wall開始 / wall長 / CPU開始 / CPU長の整数us tupleでSQLへ照合し、未一致を保存する。
- 信頼可能な raw `thread_time` counter sample の `(uuid, absolute_ns)` multiset を公式SQLと照合する。raw BEGIN/END は sequence / thread-track の packet-order stack で対応付け、CPU両端とnameをSQLへ照合する。unique / ambiguous / missing を全 complete CPU sliceについて集計し、特に `> 1 ms` の全例を保存する。limited ledgerはCPUなしイベントを一部保存しないため、stack対応の一意性は完全なslice再実装の保証ではない。
- raw epoch差、区間内 clear / loss、actual multiplier、clear以来の emission数を記録する。全 `> 1 ms` sliceでclearまたぎかを確認し、same-epochの `> 1 ms` もゼロを含めて報告する。clear前後の最寄CPU sampleのCPU差、公式wall候補、floor-loss上限を保存する。公式wall候補が複数なら時刻を一意に決めず欠測にする。
- multiplier `m > 0` の整数incremental sample、非負raw差分に限って、clear以来N回の切捨て上限を `N × (m - 1) ns` とする。unit1ではこのモデルの切捨て上限は0。実測の切捨て前ns値は未保存なので、上限内という結果は単独原因の証明にならない。
- 省略・subsamplingは希望設定と実効記述の区別を残す。raw ledger retained rows中のCPU欠測、SQL complete slice中のCPU欠測、raw delta 0、重複CPU値、markerのCPU欠測を別々に数える。frozen checkerはCPUなしTrackEventの一部を保存しないため、ledgerから「全TrackEventでCPU省略なし」とは推論しない。source/configのsubsampling記録を別証拠として扱う。
- primary集計は実測visit全体のSQL/JSON strictと `>1 ms`、actual倍率、clear数、same-epoch大超過、raw/SQL multiset・JSON/SQL照合である。response marker区間はmarkとconsole stampの両方、warmup/formal・DP/legacy別にstrict / `>1 ms`を残す。計測件数やtrace滞在時間が一致するとは仮定せず、割合と分母も併記する。
- 新たなCPU計測・browser再試行は解析器から起動しない。結果による閾値変更・条件削除・有利になるまでの再計測・A/A差分補正を行わない。unit1で現象が減っても、時計の完全妥当性、CPU選択結果の同一性、アプリ全経路の非退行は結論しない。

解析器は `analyze_counter_units.py`、SQL保存は `extract_sql.py`。どちらも既存出力を上書きせず、入力・script・toolのSHA-256を結果へ記録する。
