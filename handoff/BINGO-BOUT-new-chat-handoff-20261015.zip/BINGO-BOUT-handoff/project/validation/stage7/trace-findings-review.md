# 段階7 trace の読み取りレビュー

2026-10-15（日本時間）。`traced-response` の既存32サンプルを読み取り確認した。追加のブラウザー試験、本番HTMLの編集は行っていない。

## 判定

この trace の `TimeStamp` にある `ts` と `tts` は、同一 renderer main thread 上の経過時間と累積スレッドCPU時間を比較する目的に使える。全32サンプルで4点の `TimeStamp` が同一 `pid` / `tid` にあり、metadata のスレッド名は `CrRendererMain`、`tts` は存在して単調増加していた。確認した各 capture→handler-end、first→second 区間では `0 <= Δtts <= Δts` だった。

`cdp-cue.after.04` の first→second は、同名 **PerformanceMark eventを基点にしたprimary集計では壁時計65.142 ms、当該スレッドCPU2.070 ms、差63.072 ms**。後続TimeStamp event間の参考集計では壁時計65.176 ms、CPU2.088 ms、差63.088 msとなる。したがって「この区間の約63 msは renderer main thread の累積CPU時間に計上されていない」と記載できる。これは同一スレッドのCPU時計の差であり、未記録の main-thread 処理も含む累積量なので、`RunTask` が存在しないこと自体はこの差の計算を無効にしない。

一方、次の表現は裏付けられない。

- 「ブラウザー全体が63 ms何もしていなかった」：compositor、raster、audio、GPU、browser process、他プロセスは別のスレッド・CPU時計を持つ。
- 「63 msすべてが追加の遅延だった」：first→secondには通常の次フレームまでの待ちも含む。
- 「OSのスケジューリングが原因」「GPU待ちが原因」「CPU最適化で待ちが増えた」：今回の記録には、off-CPU部分をこれらの理由へ分配する情報が足りない。
- 「前段階の trace なし計測で観測した差も、この原因だった」：別時刻・別観測条件であり、直接帰属できない。

同サンプルの capture→handler-end のTimeStamp参考集計は **壁時計17.666 ms、CPU12.727 ms**。こちらには実際の main-thread CPU消費も相当量含まれる。first→secondの off-CPU比率を同期handlerへ移して説明してはいけない。

## 時計の対応とマーク負荷

trace metadata の clock-domain は `LINUX_CLOCK_MONOTONIC`。`ts` と `tts` の単位はマイクロ秒であり、差をミリ秒で表示するなら1000で割る。異なるスレッドの `tts` を引いてはいけない。host の `monotonic_ns` と page の `performance.now()` を直接引く必要もない。

各 page marker に対応する `blink.user_timing` event の `args.data.startTime` と保存された `performanceMarkStartTimeMs` は、全128点で1 ULP以内だった。最初のレビューは微小差を許す確認を「一致」と記載していたが、厳密な浮動小数点等価ではない。追加の厳密比較では **101点が完全一致、27点が1 ULP差、最大絶対差9.094947017729282e-13 ms**だった。全差は `clock-serialization-review.json` に保存されている。

末尾の10進表現だけが異なる記録は、page/CDP JSONとtrace JSONという異なる記録経路で生じる丸め差と整合する。ただしserializerの実装や内部変換は追跡しておらず、それを確定原因とはしない。同名マークとpage側startTimeの対応検証を `math.ulp` による1 ULP以内とすることは、この記録上の差を区別するための検証であり、性能悪化を許容する閾値ではない。traceの `ts` / `tts` とその差は変更しない。

page の値と trace を対応させるには、同名の PerformanceMark event を基点にする。`console.timeStamp` の event はその後に実行される別の観測点である。

PerformanceMark event→TimeStamp event の経過は、全128点で **0.017～0.866 ms（中央値0.0415 ms）**だった。特に `cdp-cue.after.03` の second marker は遅れが大きい。TimeStamp の `ts` を page の先行 `observedNowMs` と完全に同時の値として扱うべきではない。TimeStamp間の壁時計／CPU差は TimeStamp間の差として報告し、pageの handlerMs や callback interval と多少ずれることを明記する。

page側で記録した marker処理の区間（observedNow→markerEnd）は0～0.8 ms、中央値約0.1 ms。丸めと途中のスケジューリングを含む観測であり、マーク自身だけの純CPU負荷の測定ではない。この負荷を trace なしの値から一律に引く補正も行わない。

`analyse_trace.py` と生成された `trace-analysis.json` / CSV も確認した。今回32件の壁時計／CPU集計に修正必須の問題は見つからなかった。primaryのPerformanceMark／secondaryのTimeStamp分離、same-thread検証、各category内のunion、category同士を加算しない注意書きは妥当。再利用時の入力チェックとして、`args.data.startTime` と保存marker値の1 ULP以内の対応、metadataのclock-domain検証を明示的なassertにすると、時計対応の前提をコードにも残せる。今回のFunctionCall eventにはすべて `tdur` が存在したため欠落値を0扱いする問題は発生していないが、将来欠落する場合は0ではなく未取得と区別すること。

## CPU制限カウンターと区間の集計

全32サンプルで、読み取った `/sys/fs/cgroup/cpu.stat` の `nr_throttled` と `throttled_usec` の増分は0だった。よってこの読み取り区間・このcgroupのカウンターには新たなquota throttleが記録されていない。共有cgroupの情報であり、OSのrun queue待ち、VMの競合、他のcgroupや祖先側の制限、フレーム待ちなどをすべて否定する結果ではない。`usage_usec` の増分をrenderer main threadへ割り当てることもできない。

`UpdateLayoutTree`、`Layout`、`Paint`、`FunctionCall`、`FireAnimationFrame` 等の `X` event は入れ子になる。例えば同サンプルの Paint は4860 µsの親と4835 µsの子が重なる。これらの `dur` の単純加算は二重計上になる。同一 `pid` / `tid`、マーク区間との交差、重複区間の union を使って、**記録されたイベントが覆う壁時計区間**として算出する必要がある。

その union は総CPU時間でも全taskのbusy時間でもない。カテゴリ外の処理は記録されず、`dur` はevent内部のoff-CPU時間を含み得る。また、境界をまたぐeventの `tdur` を壁時計の交差率で按分しても、区間内CPU時間の正確な値にはならない。総スレッドCPU時間にはマークの `tts` 差を使う。

## 次に原因を分けるなら

1. 少数の追加traceで `toplevel` を加え、実際に `RunTask` 相当が収録されるか確認する。必要な範囲の `cc` / `viz` のフレーム処理も候補。まずイベントの存在を確認し、カテゴリを一括で増やして通常値と比較しない。
2. ブラウザーのtaskが走っていない区間を「次フレーム待ち」「blocked」「runnableだが実行されない」に分けるには、対応時刻のOS scheduler情報（例えば `sched_switch` / `sched_wakeup`）とrenderer/compositorのthread識別が必要。現在のtraceにはこの情報がない。`/proc/.../schedstat` は補助になり得るが、粗いhost側before/after読み取りだけでは各RAF区間へ正確に割り当てられない。
3. 製品の性能評価はtraceなしの別計測で、同じ入力方式・同じfixture・順序を交互にしたA/AとA/Bとして再確認する。今回のtraceは原因の候補を狭める資料であり、過去の時間差の確定原因や全経路の非悪化判定ではない。

状態フラグではsound/BGM有効・AudioContext runningを確認しているが、headlessのブラウザー起動引数にはPlaywright由来の `--mute-audio` がある。実機スピーカーでの音声出力や物理ディスプレイへの提示は、この試験では確認していない。

レビュー結論：**同一renderer main threadの壁時計とCPU時間の分離は有効。off-CPUの直接原因の確定、過去のtraceなし差への帰属、全経路の非悪化証明は未完了。**
