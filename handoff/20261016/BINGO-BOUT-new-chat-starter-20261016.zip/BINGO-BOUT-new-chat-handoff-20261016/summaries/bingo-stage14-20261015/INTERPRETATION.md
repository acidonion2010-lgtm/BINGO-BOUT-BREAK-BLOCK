# 段階14の読み取り解釈

2026-10-15。`report.json` と `analysis.json` の保存値を読み直した。ブラウザー・DP・性能ジョブを追加実行せず、raw、分析器、JSONを変更していない。

HARD readyDPの原本→段階3の同期handlerと、原本→段階5の2RAFは、今回の4回で増減が混在した。過去の増加を再現したとは判定しない。一方、同一threadのCPU時計差がwallを数ms超える3区間が見つかったため、CPU寄与率やwall−CPUによる原因の断定はできない。今回進んだ点は、正式288クリックそれぞれのwall区間、同期Style/Layout、描画準備、commit待ち、RAFのframe対応を同時記録で結び付けたことである。

## 対象と集計単位

原本・段階3.final・段階5・段階9を、4 fresh ChromiumプロセスでWilliams順にvisitした。各版・各runはP1先攻の固定中盤、人間P1のBREAK cell2へ通常のtrusted locator入力を送り、CPU(P2)がBLOCKを選ぶ。HARDの乱数0.8はreadyDP、0.3はreadyを維持した従来分岐であり、Worker fallbackではない。

各visit・分岐のtrial0を事前指定warmupとして保持し、trial1〜9だけの中央値を比較する。4runの9標本中央値差を個別に示す。trial番号を対応する独立対標本と解釈せず、旧標本とプールせず、CI・A/A補正・後付け許容差・厳密PASSを付けない。下表は後−前、単位ms。0.00は表示丸めであり非回帰判定ではない。

| readyDPの比較・page指標 | run1 | run2 | run3 | run4 |
|---|---:|---:|---:|---:|
| 原本→段階3 handler | -0.30 | -0.10 | +0.30 | 0.00 |
| 原本→段階3 2RAF | +1.10 | +0.30 | -1.00 | -0.70 |
| 原本→段階5 handler | -0.60 | -0.10 | +0.50 | -0.30 |
| 原本→段階5 2RAF | +1.10 | -0.50 | -0.50 | +0.20 |
| 段階5→段階9 handler | +0.20 | +0.20 | -0.20 | +0.20 |
| 段階5→段階9 2RAF | -0.20 | -0.30 | 0.00 | 0.00 |
| 原本→段階9 handler | -0.40 | +0.10 | +0.30 | -0.10 |
| 原本→段階9 2RAF | +0.90 | -0.80 | -0.50 | +0.20 |

原本→段階3 handlerの4run差の中央値は-0.05ms、原本→段階5 2RAFは-0.15msだが、増加側のrunもある。過去の+0.45ms/+0.80msは、別の計装・履歴・集計による旧プール中央値差である。今回の中央値が小さいことを理由に旧差の原因を解消したとは扱わない。

従来分岐の原本→段階3 handler差は-0.30,+0.10,+0.10,-0.10ms、原本→段階5 2RAF差は+0.20,-0.20,+0.30,-0.10ms。現在版の原本→段階9 handlerは-0.30,-0.50,+0.30,+0.30ms、2RAFは+0.90,+0.10,0.00,+0.10msだった。この対照もDP結果から差し引かない。

## 同期handlerで直接観測したwall区間

pageのhandlerはcapture observerが`performance.now()`を読む時点からbubble observerまで。traceのhandlerはその直後に置くPerformanceMark間である。計装位置とpage時計の分解能が異なるので、両数値を等値とせず別々に保持する。

readyDPの16visit中央値は、trace handler wallが2.982〜3.600ms、同じ区間の`UpdateLayoutTree`/`Layout`のXイベントunionが1.632〜1.875msだった。原本→段階3のhandler trace wall差は-0.239,-0.008,+0.339,-0.017ms、Style/Layout union差は-0.098,-0.027,+0.153,-0.007ms。増えたrun3では両方が増えたが、4回で一方向のDOM費用増加は観測されていない。Style/Layoutのwall区間はオフCPU時間を含み得るため、CPU自己時間とは呼ばない。

段階5→9のhandler trace wall差は+0.212,+0.052,-0.122,+0.191ms、Style/Layout union差は+0.061,+0.180,-0.024,+0.065ms。3回が増加側であり、現在版の全経路非回帰を証明する結果ではない。ゲーム関数をwrapperで囲っていないため、この包括handler差からselector単体の費用へ帰属させることもできない。

全288正式クリックのhandlerでは、記録されたPaint系・commit待ち・GC分類のX区間は交差していなかった。これはその分類名に対応する記録区間についての事実であり、描画準備やGCのすべてが0コストとの主張ではない。GCに該当するイベント自体は全16visitで観測され、今回の正式response全区間とは重なっていなかった。

## RAFの間で観測したこと

readyDPの16visit中央値では、handler終端→1RAFのtrace wallは6.218〜8.852ms、1RAF→2RAFは15.953〜16.338msだった。前者のStyle/Layout unionは0.735〜0.861ms、Paint系unionは0.258〜0.309ms、後者のPaint系unionは0.649〜0.787msだった。全16visitでrenderer-mainのtop-level taskと関連frameイベントが観測され、warmupを含む全640 RAF markerでframe対応が得られた。

原本→段階5の2RAFが増えたrun1では、capture→2RAF trace wall差は+1.143ms、handler→1RAFは+2.147ms、1RAF→2RAFは-0.137msだった。他のrunのcapture→2RAF差は-0.367,-0.263,+0.132msで、増加する箇所も一様ではない。これらはそれぞれ別の標本中央値差なので、部分の中央値差を加算して全体差を復元しない。

pageのcapture位相のvisit中央値はreadyDPで5.90〜7.90ms、2回目callbackのRAF timestampに対する遅れの中央値は0.40〜1.40msだった。各sampleでは「2RAF = 直前RAF timestamp→2回目timestamp幅 − capture位相 + 2回目callback遅れ」の算術恒等式が保存値で成立する（320件すべて残差0）。これは時計上の分解であり、位相を揃える補正や因果効果の推定ではない。中央値同士には同じ加算則を適用できない。

`LayerTreeHost::WaitForCommitCompletion`は全288正式クリックの1RAF→2RAF内で観測された。readyDPのvisit中央値は0.236〜0.289msで、版間差の符号は混在する。全正式試行の最大はrun3・段階3・DP・trial5の2.589msで、同試行の2回目callback遅れはtraceで4.451msだった。記録されたcommit待ちwallはGPU待ち総量でも、OSの待機原因の識別でもない。task/paint/mainFrame等と重複するため分類間を加算しない。

同時frame照合では、遅いcallbackも一つの箇所に集中していない。例えば次の3件はすべて正式試行で、除外せず保存されている。各行の3区間は**その単一sample内**で加算できる。

| 試行・2回目RAF | frame時刻→送信 | 送信→main frame開始 | main frame開始→marker | markerのframe遅れ |
|---|---:|---:|---:|---:|
| run2 段階9 DP trial3 | 0.337 | 0.112 | 4.163 | 4.612 |
| run3 段階3 DP trial5 | 0.971 | 1.923 | 1.557 | 4.451 |
| run1 段階3 legacy trial1 | 3.376 | 0.096 | 0.673 | 4.145 |

最後の例では対応viz timer tick自体のframe時刻からの遅れが3.078msだった。最初の例では0.119msだった。こうした同時記録は遅延の現れた区間を区別できるが、最終的なOS/GPU/アプリ原因を自動で特定しない。物理画面提示を測った値でもない。

## CPU時計・残差の限界

全markerのpid/tid・startTime対応と`tts`存在は確認されたが、次の3区間で`tts`差がwallを数ms超えた。

| run・版・分岐・trial | 区間 | wall | 記録されたtts差 | wall−tts差 |
|---|---|---:|---:|---:|
| 1 原本 legacy 9 | handler→1RAF | 7.347 | 9.630 | -2.283 |
| 3 原本 legacy 3 | handler | 3.416 | 8.583 | -5.167 |
| 4 段階5 DP 3 | handler | 3.128 | 9.848 | -6.720 |

これは浮動小数点serializationのULPや数µsの丸めで説明できる規模ではない。同時console TimeStamp側でも同じ方向の不整合があり、PerformanceMarkのJSON対応だけの問題とは扱えない。根本原因は未確定である。元の符号付きCPU差・残差をclampせず、試行も除外せず保持した。

したがって今回の`tts`差をすべて厳密なCPU会計とみなしたり、wall−CPUを待機量へ換算したり、DP/DOM/OS別の寄与率を示したりしない。残る区間でCPU≤wallだったことだけでも全時計の信頼性は証明されない。wall、clipしたX区間、frameのts照合はこのCPU差とは分けて記述する。rootの別成果物`clock-audit.json`/`CLOCK_VALIDITY.md`が該当markerと周辺イベントの追加点検を担う。

## 機能一致と未確定範囲

16通常読込の自己テスト5,152件、16実Worker準備、288正式＋32warmupのtrusted入力・分岐counter・REVEAL表示・可視性・処理状態・audio/BGMフラグは検証された。16traceのhashと全1,280unique markerが対応し、responseへ交差するB/E境界scopeはなかった。getCategoriesの列挙は4回とも空だったが、明示要求を保持し、実traceでmarker/timeline/task/frame等の観測を確認した。未観測の分類を処理の不存在証明には使わない。

32回の**計時外selector監査**では、readyDPはCPU BLOCK cell7・乱数[0.8,0.8]、従来はcell2・乱数[0.3,0.3,0.3,0.3]で、分岐counter・固定公開入力・履歴が全版で一致した。これは正式クリック内部のCPU BLOCK戻り値を直接保存した証拠ではない。正式probeの`selectedBreakCell=2`は人間のBREAKセルであり、CPU BLOCKセルとの一致を主張しない。ゲーム関数参照を交換しない制約を優先した。

trace・marker・RAF監視と連続収集自体が実行を変える。旧無traceのhandler +0.45ms、2RAF +0.80ms、過去62条件、段階8のraster/GPU待ち、cold入力・実機入力・音声出力・全配置/全browserの未確定判定は保持する。今回得たwall側の同時対応と、新たに顕在化したCPU時計の検証課題を分けて次へ引き継ぐ。
