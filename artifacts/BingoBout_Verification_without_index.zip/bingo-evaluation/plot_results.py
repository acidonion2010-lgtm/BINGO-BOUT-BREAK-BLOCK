"""Create exportable plots from the fixed-design statistical tables."""
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'


def read(name):
    return list(csv.DictReader((RESULTS / name).open()))


def main():
    rows = read('summary_main.csv')
    opponents = ['uniform', 'greedy', 'normal', 'board_eq', 'nash', 'master_local_br']
    policies = ['normal', 'hard', 'master', 'nash_control']
    colors = ['#4C78A8', '#F58518', '#E45756', '#54A24B']
    fig, axes = plt.subplots(2, 1, figsize=(11, 8), constrained_layout=True)
    for i, (policy, color) in enumerate(zip(policies, colors)):
        selected = [next(r for r in rows if r['difficulty'] == policy and r['opponent'] == o) for o in opponents]
        x = np.arange(len(opponents)) + (i - 1.5) * .16
        for ax, field, scale in [(axes[0], 'win_plus_half_draw', 100), (axes[1], 'mean_margin', 1)]:
            y = np.array([float(r[field]) for r in selected]) * scale
            low = y - np.array([float(r[field + '_ci_low']) for r in selected]) * scale
            high = np.array([float(r[field + '_ci_high']) for r in selected]) * scale - y
            ax.errorbar(x, y, yerr=[low, high], marker='o', capsize=3, linestyle='none', color=color, label=policy.upper())
    axes[0].set_ylabel('Win + 0.5 draw (%)')
    axes[0].axhline(50, color='gray', linewidth=.8, linestyle='--')
    axes[0].legend(ncol=4, loc='upper right')
    axes[1].set_ylabel('Mean score margin (CPU - opponent)')
    axes[1].axhline(0, color='gray', linewidth=.8, linestyle='--')
    for ax in axes:
        ax.set_xticks(range(len(opponents)), opponents)
        ax.grid(axis='y', alpha=.2)
    axes[0].set_title('Bingo Bout uploaded HTML: fixed common-opponent benchmark\n95% layout-pair cluster bootstrap intervals; 32 pairs, 196,608 games')
    fig.savefig(RESULTS / 'difficulty_comparison.png', dpi=180)
    fig.savefig(RESULTS / 'difficulty_comparison.svg')
    plt.close(fig)


if __name__ == '__main__':
    main()
