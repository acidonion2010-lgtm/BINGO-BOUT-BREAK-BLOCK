#!/usr/bin/env python3
"""Fetch immutable official source text; never execute downloaded content."""
import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import urllib.error
import urllib.request

REV = '73c14f6228d7cd537c855007e8f88678969cc0eb'
ROOT = Path(__file__).resolve().parent / 'official-sources'
PATHS = [
    'chrome/VERSION',
    'third_party/blink/renderer/core/timing/user_timing.cc',
    'third_party/blink/renderer/core/timing/performance_mark.cc',
    'third_party/blink/renderer/core/timing/performance.cc',
    'third_party/blink/renderer/core/inspector/inspector_trace_events.cc',
    'third_party/blink/renderer/core/inspector/inspector_trace_events.h',
    'third_party/blink/renderer/bindings/core/v8/thread_debugger.cc',
    'third_party/blink/renderer/bindings/core/v8/main_thread_debugger.cc',
]

def fetch(path):
    url = f'https://raw.githubusercontent.com/chromium/chromium/{REV}/{path}'
    record = {'path': path, 'url': url, 'revision': REV,
              'retrievedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'Codex-source-review'})
        with urllib.request.urlopen(request, timeout=30) as response:
            raw = response.read()
            record.update(httpStatus=response.status, bytes=len(raw),
                          sha256=hashlib.sha256(raw).hexdigest())
        destination = ROOT / 'chromium' / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            assert destination.read_bytes() == raw, 'Refuse changing an existing source capture'
        else:
            destination.write_bytes(raw)
        record.update(savedPath=str(destination), passed=True)
    except Exception as error:
        record.update(passed=False, error=repr(error))
    return record

def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        records = list(executor.map(fetch, PATHS))
    manifest = ROOT / 'blink-manifest.json'
    assert not manifest.exists(), 'Refuse replacing a manifest'
    manifest.write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n')
    for record in records:
        print(record['path'], record['passed'], record.get('bytes'), record.get('error'), flush=True)

if __name__ == '__main__':
    main()
