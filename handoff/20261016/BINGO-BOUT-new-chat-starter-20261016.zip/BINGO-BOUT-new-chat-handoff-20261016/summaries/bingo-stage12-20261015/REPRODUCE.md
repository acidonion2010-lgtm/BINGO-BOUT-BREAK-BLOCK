# 段階12の再現

対象は元の引き継ぎZIPの段階9。ゲーム本体は変更していない。
このZIPは今回の検証資料で、原本・段階5・旧検証コードは元ZIPが必要。

## 配置と準備

- 元の引き継ぎを `/workspace/handoff/BINGO-BOUT-handoff/` へ展開。
- 今回のフォルダを `/workspace/bingo-stage12-20261015/` に配置。
- Python 3.12.14、Python Playwright、Chromium 154.0.8037.57、Node 24.19.0。
- 共有測定器 `project/validation/stage3/frame_performance.py` は期待hash
  `238e31ab7695f7b80b7c59d05270e054124c13774f731d412f630eb253195cf7` に固定。
- 原本・段階5・段階9のHTML hashはPLANに記載。コードが実行前に照合する。
- 別のブラウザー・DP・性能ジョブは同時に実行しない。

`PLAN.md`、別実験Cの `ORDER_PLAN.md`、`RESULTS.md` の限界を先に読む。
以下は新しい出力先に保存する再現例。既存JSONへ上書きしない。

```bash
cd /workspace/bingo-stage12-20261015
mkdir -p reproduction
python3 native_fallback.py --output reproduction/native.json
python3 summarize_native.py reproduction/native.json --output reproduction/native-summary.json
python3 wrapper_crossover.py --output reproduction/wrapper.json
python3 wrapper_order.py --output reproduction/order.json
python3 summarize_order.py reproduction/order.json --output reproduction/order-summary.json
```

Aは6ブラウザー・172,800,000判断、Bは4ブラウザー・57,600,000判断、Cは8ブラウザー・
57,600,000判断。いずれもwarmup・監査は別に実行する。
この回数で終了し、好ましい結果を得るため追加しない。
元HTMLを通常読込し、既存322自己テストと実Blob Worker準備を実行する。
ブラウザーやHTTP serverは各実験終了時に閉じる。ユーザー向けlocalhostリンクは不要。

## Aの計時範囲

原本・段階5・段階9を3つのvisible iframeで同じブラウザーに読み込む。
6種類の作成/配置順を各1回、各条件12batchでは3版の6順列を各2回実行。
先攻P1/P2×opening/middle×BREAK/BLOCKのMASTER fallbackだけを検証する。
各batch100,000判断。counter reset・2,000warmup・状態/政策行/参照検証は計時外。
計時は共通の元bench.loopが返すchecksum生成まで。呼出しごとの時刻ではない。

正常読込されたアプリのselector関数参照は交換していない。
Math.randomとゲーム状態は固定し、RNG監査だけ一時的にカウントする。
原本→5、5→9、原本→9の対差は同じbatch内の整数duration差から算出する。
対差は加算的だが、対差の中央値は一般に加算的ではない。

## B/Cの計時範囲と差

段階5を1realmで読み、旧/新の `selectCpuBreakCell` だけを交換する。
他のCPU関数は監査時の禁止経路hookを除き、元の参照を保つ。
監査hookはwarmup前に復元し、計時中にRNGカウントやプロファイラは入れない。
旧本文を複製したoldA/oldB、元のnativeOld、新本文newを同じcallerで検証する。

Bは生成順と実行履歴の束を同時に反転する診断。Cは両者を独立に割り当てる。
Cで追加した変更は、run割当・case選択・メタデータと、監査呼出し順を固定する1行のみ。
この1行を正規化してBのJSとの完全一致を実行前に検証する。
親Bコードhashも固定し、CをBの単なる追加反復として混ぜない。

各関数の計時外16回は乱数0.8を1回消費してcell7。さらに6乱数値・明示sampleを監査。
全fallback表の配列参照・穴・数値はObject.isで計時外に照合し、NaNと符号付き0も扱う。
P2序盤の政策行は19個のbig-endian binary64のSHA-256
`84d2383a7ba73a9b1e057be396f2a867b675580b6e77961b4c1b5eeb23696008` と照合する。

## 結果の意味

実時計の生endpointと、整数へ表現したendpointを保存する。ns表現はns精度の意味ではない。
100,000判断のbatch平均が小さい単位になっても、単独1判断をその精度で測ったとは扱わない。
区間はブラウザー内batch分布に関する条件付き記述で、独立反復・全経路保証ではない。
同一/別参照のA/Aの差を引いたり、性能許容差へ変換したりしない。
`native-summary.json/.csv`、`order-summary.json/.csv` と各生JSONを別々に読む。
過去104条件の62未確定を再分類せず、新実験を以前の標本とプールしない。
