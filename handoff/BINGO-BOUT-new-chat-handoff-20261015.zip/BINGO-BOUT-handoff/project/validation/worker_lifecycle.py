#!/usr/bin/env python3
"""Run real Blob Worker and deterministic lifecycle faults without source edits.

Usage: python validation/worker_lifecycle.py index.before.html --out validation/worker_before.json
A localhost server can be supplied using --base-url; otherwise one is started.
"""
import argparse
import functools
import http.server
import json
import pathlib
import sys
import threading
import time

from playwright.sync_api import sync_playwright


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('path', type=pathlib.Path)
    parser.add_argument('--out', required=True, type=pathlib.Path)
    parser.add_argument('--base-url')
    args = parser.parse_args()
    path = args.path.resolve()
    server = None
    if args.base_url:
        url = args.base_url.rstrip('/') + '/' + path.name
    else:
        handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(path.parent))
        server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        url = f'http://127.0.0.1:{server.server_port}/{path.name}'
    report = {'file': str(path), 'url': url, 'results': [], 'browserErrors': []}
    started = time.monotonic()
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True,
                                    args=['--no-sandbox'])
        page = browser.new_page()
        page.on('pageerror', lambda error: report['browserErrors'].append(str(error)))
        page.add_init_script(path=str(pathlib.Path(__file__).with_name('worker_lifecycle_harness.js')))
        try:
            page.goto(url, wait_until='domcontentloaded')
            page.wait_for_function('typeof startWholeGameCpu === "function"')
            page.evaluate('__workerHarness.prepare("master", "real")')
            ready_at = time.monotonic()
            page.wait_for_function('cpuWholeStatus === "ready" || cpuWholeStatus === "fallback"', timeout=90000)
            report['realWorkerSeconds'] = round(time.monotonic() - ready_at, 3)
            real = page.evaluate('''() => {
                const H = __workerHarness;
                const w = H.workers.at(-1);
                const s = H.snapshot();
                H.check('actual Blob Worker returns verified ready table', s.status === 'ready' && s.dp && s.stats &&
                    !s.worker && !s.url && !s.watchdog && w.terminated === 1 && H.revoked.includes(w.url), s);
                if (!H.valid) return {valid: false, snapshot: s};
                H.check('actual transferred value-table bytes match stats',
                    H.valid.layers.reduce((n, b) => n + b.byteLength, 0) === H.valid.stats.valueTableBytes,
                    {bytes: H.valid.stats.valueTableBytes, layers: H.valid.layers.length, stats: H.valid.stats});
                H.check('receiver does not allocate another large value table', H.receiveLargeAllocationBytes === 0,
                    {largeAllocationBytes: H.receiveLargeAllocationBytes, numericAllocationBytes: H.receiveNumericAllocationBytes,
                     transferredBytes: H.valid.stats.valueTableBytes});
                const cell = selectCpuEquilibriumCell('block', {sample: 0.5});
                H.check('actual accepted DP serves legal MASTER policy', Number.isInteger(cell) && cell >= 0 && cell < 9 &&
                    cpuWholeDecisions === 1 && cpuWholeLegacyDecisions === 0, {cell, cpuWholeDecisions, cpuWholeLegacyDecisions});
                releaseWholeGameCpu();
                H.check('actual table release clears DP and stats references', cpuWholeDp === null && cpuWholeStats === null &&
                    cpuWholeStatus === 'inactive');
                return {valid: true, stats: H.valid.stats, allocationBytes: H.receiveLargeAllocationBytes};
            }''')
            report['realWorker'] = real
            if real['valid']:
                report['results'] = page.evaluate('__workerHarness.runSynthetic()')
            else:
                report['results'] = page.evaluate('__workerHarness.results')
        except Exception as error:
            report['harnessException'] = str(error)
            try:
                report['results'] = page.evaluate('__workerHarness.results')
            except Exception:
                pass
        finally:
            browser.close()
    if server:
        server.shutdown()
    report['seconds'] = round(time.monotonic() - started, 3)
    report['passed'] = sum(r['pass'] for r in report['results'])
    report['failed'] = [r['name'] for r in report['results'] if not r['pass']]
    report['total'] = len(report['results'])
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: report.get(k) for k in ['file', 'passed', 'total', 'failed', 'realWorkerSeconds', 'seconds', 'harnessException']},
                     ensure_ascii=False, indent=2))
    return 1 if report['failed'] or report.get('harnessException') or report['browserErrors'] else 0


if __name__ == '__main__':
    sys.exit(main())
