﻿[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
$folder = Join-Path $env:USERPROFILE 'Downloads\BINGO-BOUT-completed'
$url = 'https://raw.githubusercontent.com/acidonion2010-lgtm/BINGO-BOUT-BREAK-BLOCK/73c394af9deb3823ef31d79bf287db348c60522a/index.html'
$expected = '59fff4685ff3f36e18d73fe9fa524ee57d81a348352e7b2912db4b7ecc1bb513'
New-Item -ItemType Directory -Path $folder -Force -ErrorAction Stop | Out-Null
$out = Join-Path $folder 'index.html'
$tmp = Join-Path $folder ([guid]::NewGuid().ToString('N') + '.tmp')
try {
    Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing -ErrorAction Stop
    if ((Get-FileHash -LiteralPath $tmp -Algorithm SHA256).Hash -ne $expected) {
        throw 'ファイルの確認に失敗しました。'
    }
    Move-Item -LiteralPath $tmp -Destination $out -Force -ErrorAction Stop
    Write-Host "保存しました: $out"
} finally {
    Remove-Item -LiteralPath $tmp -ErrorAction SilentlyContinue
}
