# 段階11の再現

同梱 `RESULTS.md` と `PLAN.md` を先に読む。ゲーム本体は変更していない。
対象は段階9の `59fff468…` と段階5の `fea09e99…`。元の引き継ぎZIPが必要。

## 環境・配置

- Python 3.12.14 とPython Playwright、Chromium 154.0.8037.57、Node 24.19.0。
- 元ZIPを `/workspace/handoff/BINGO-BOUT-handoff/` に展開。
- 本フォルダを `/workspace/bingo-stage11-20261015/` に配置。
- `/proc` のread-onlyスレッド統計とCDP traceを使う。perfや特権設定の変更は不要。
- ブラウザー・DP・性能ジョブは直列実行。localhostリンクをユーザー向けに公開しない。

以下は新しい出力先への再現例。既存結果へ上書きしない。

```bash
cd /workspace/bingo-stage11-20261015
python3 worker_trace.py --output reproduction
python3 summarize_worker.py reproduction
python3 cpu_coverage_audit.py reproduction/results.json --output reproduction/cpu-coverage.json
```

今回の正式記録は `run-explicit-categories/`。初期の `run/` は明示カテゴリ指定の
不備がある記録で、正式集約に含めていない。
`worker_trace.initial-category-protocol.py`、`PLAN.initial.md`、`analyse_trace.initial.py` は
その初期試行の監査用。再実行には使わない。

独立ブラウザー2回×4対×段階5/9の16読込。時間はsolve前後のtrace markerで測定する。
Workerのconstructor後とsolve後にhostとのhandshake待機が入るため、通常起動の
測定ではない。自己テストは通常通り322件実行する。通常のWorker READY処理・
受信検証は最後まで実行し、計時後に全値配列をSHA-256へまとめる。

## 個々のtraceを再解析

```bash
python3 analyse_trace.py run-explicit-categories/run1.round1.stage5.trace.json bingo.stage11.run1.round1.stage5 --output reproduction-one-analysis.json
```

solve markerの`ts`差が経過時間、`tts`差がWorkerスレッドCPU時間。
`wall−CPU`をrunqueue待ちと同一視しない。
targetのpid/tidでOS snapshotの前後を選び、`schedstat`のCPUとrunqueue待ちを差分化する。
このOS値はhandshakeの包絡区間で、厳密なsolve区間より広い。

GC/JIT候補は計画に書いた名前・カテゴリ条件で抽出。Xと対応するB/Eを区間化し、
入れ子を和集合で扱う。CPU時計のない候補があるため、正式集計のGC/JITの完全な
CPU時間は`null`のまま保存した。観測できたCPU部分とGC/JITの経過時間は別々に示す。
`eventParsingComplete`、`availability.cpuBoundsValid`、traceのdataLossOccurredも確認する。

`cpu_coverage_audit.py` は測定後の別解析。CPU時計のある親候補のwall区間に含まれる
欠測候補と、外に残るwall区間を分ける。CPU時計を補完せず、正式な`null`は変更しない。
CPU時間が同じスレッドの経過時間以下というモデルで上側の包絡を示すが、
trace clockの量子化を含むため物理時間の厳密保証とは呼ばない。

生trace・OS snapshot・計測/解析コードhash・計画hashを保持している。
初回や符号を理由に標本を落とさず、別実験や過去の絶対時間と混ぜない。
