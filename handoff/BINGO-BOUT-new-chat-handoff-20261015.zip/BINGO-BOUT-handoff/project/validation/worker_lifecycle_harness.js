// Browser-only instrumentation; application source stays untouched.
(() => {
    const native = {
        Worker: window.Worker,
        create: URL.createObjectURL.bind(URL),
        revoke: URL.revokeObjectURL.bind(URL),
        timeout: window.setTimeout.bind(window),
        clearTimeout: window.clearTimeout.bind(window),
        Float64Array: window.Float64Array
    };
    const H = window.__workerHarness = {
        mode: 'real', workers: [], urls: [], revoked: [], timers: [],
        valid: null, receiveLargeAllocationBytes: 0, receiveNumericAllocationBytes: 0,
        results: [], exceptions: [], nextTimer: 10000000
    };
    URL.createObjectURL = value => {
        if (H.mode === 'url_error') throw new Error('injected object URL failure');
        const url = native.create(value);
        H.urls.push(url);
        return url;
    };
    URL.revokeObjectURL = url => { H.revoked.push(url); native.revoke(url); };
    window.setTimeout = (fn, delay, ...args) => {
        if (delay === 30000) {
            const timer = {id: H.nextTimer++, fn, args, delay, cleared: false};
            H.timers.push(timer);
            return timer.id;
        }
        return native.timeout(fn, delay, ...args);
    };
    window.clearTimeout = id => {
        const timer = H.timers.find(t => t.id === id);
        if (timer) timer.cleared = true;
        else native.clearTimeout(id);
    };
    window.Worker = class InstrumentedWorker {
        constructor(url, options) {
            if (H.mode === 'constructor_error') throw new Error('injected Worker constructor failure');
            this.terminated = 0;
            this.url = url;
            this.native = H.mode === 'real' ? new native.Worker(url, options) : null;
            H.workers.push(this);
            if (this.native) {
                this.native.onmessage = event => {
                    if (event.data?.type === 'ready') H.valid = structuredClone(event.data);
                    this.deliver(event.data);
                };
                this.native.onerror = event => this.onerror?.(event);
                this.native.onmessageerror = event => this.onmessageerror?.(event);
            }
        }
        postMessage(data, transfers) {
            this.request = structuredClone(data);
            if (H.mode === 'post_error') throw new Error('injected Worker postMessage failure');
            if (this.native) this.native.postMessage(data, transfers || []);
        }
        terminate() { this.terminated++; this.native?.terminate(); }
        deliver(data) {
            const original = window.Float64Array;
            window.Float64Array = new Proxy(native.Float64Array, {
                construct(target, args) {
                    if (typeof args[0] === 'number') {
                        H.receiveNumericAllocationBytes += args[0] * 8;
                        if (args[0] > 512) H.receiveLargeAllocationBytes += args[0] * 8;
                    }
                    return Reflect.construct(target, args);
                }
            });
            try { this.onmessage?.({data}); }
            finally { window.Float64Array = original; }
        }
    };
    H.check = (name, pass, details = {}) => {
        H.results.push({name, pass: Boolean(pass), details});
        return pass;
    };
    H.snapshot = () => ({
        status: cpuWholeStatus, generation: cpuWholeGeneration,
        dp: cpuWholeDp !== null, stats: cpuWholeStats !== null,
        worker: cpuWholeWorker !== null, url: cpuWholeWorkerUrl !== null,
        watchdog: cpuWholeWatchdog !== null, failure: cpuWholeFailure,
        createdUrls: H.urls.length, revokedUrls: H.revoked.length,
        terminations: H.workers.reduce((n, worker) => n + worker.terminated, 0)
    });
    H.prepare = (difficulty = 'master', mode = 'fake', layout = null) => {
        H.mode = mode;
        state.gameMode = 'cpu';
        state.cpuDifficulty = difficulty;
        state.seatChosen = true;
        state.firstPlayer = 1;
        state.phase = 'break';
        state.gameEnded = false;
        state.isStarting = true; // Prevent gameplay animation/timer side effects.
        state.p1TurnsTaken = state.p2TurnsTaken = 0;
        state.p1Marks.fill(false);
        state.p2Marks.fill(false);
        state.p1NumberLayout = layout ? layout.slice() : [1,2,3,4,5,6,7,8,9];
        state.p2NumberLayout = [1,2,3,4,5,6,7,8,9];
        cpuWholeInReset = true;
        try { startWholeGameCpu(); }
        finally { cpuWholeInReset = false; }
        return H.workers.at(-1);
    };
    H.payload = worker => {
        const data = structuredClone(H.valid);
        data.generation = worker.request.generation;
        return data;
    };
    H.expectCleanup = (name, worker, expectedStatus) => {
        const s = H.snapshot();
        return H.check(name, s.status === expectedStatus && !s.dp && !s.worker && !s.url && !s.watchdog &&
            worker.terminated === 1 && H.revoked.includes(worker.url), s);
    };
    H.runSynthetic = () => {
        const mutations = [
            ['layer count short', d => d.layers.pop()],
            ['layer count extra', d => d.layers.push(new ArrayBuffer(8))],
            ['layers non-array', d => d.layers = {}],
            ['layer non-buffer', d => d.layers[0] = new Uint8Array(8)],
            ['layer null buffer', d => d.layers[0] = null],
            ['layer short length', d => d.layers[18] = new ArrayBuffer(d.layers[18].byteLength - 8)],
            ['value bytes mismatch', d => d.stats.valueTableBytes++],
            ['stats missing', d => d.stats = null],
            ['stats initialValue mismatch', d => d.stats.initialValue += 1],
            ['stats initialValue NaN', d => d.stats.initialValue = NaN],
            ['stats initialValue undefined', d => delete d.stats.initialValue],
            ['stats initialValue infinity', d => d.stats.initialValue = Infinity],
            ['stats initialValue numeric string', d => d.stats.initialValue = String(d.stats.initialValue)],
            ['stats maxGap NaN', d => d.stats.maxGap = NaN],
            ['stats maxGap infinity', d => d.stats.maxGap = Infinity],
            ['stats maxGap negative', d => d.stats.maxGap = -1],
            ['stats maxGap above tolerance', d => d.stats.maxGap = CPU_WHOLE_EQ_GAP * 2],
            ['initial table value NaN', d => new Float64Array(d.layers[0])[0] = NaN],
            ['initial table value infinity', d => new Float64Array(d.layers[0])[0] = Infinity]
        ];
        for (const [name, mutate] of mutations) {
            const worker = H.prepare();
            const data = H.payload(worker);
            mutate(data);
            worker.deliver(data);
            H.expectCleanup('reject ' + name, worker, 'fallback');
        }
        for (const kind of ['onerror', 'onmessageerror', 'worker error reply']) {
            const worker = H.prepare();
            let prevented = false;
            if (kind === 'onerror') worker.onerror({message: 'injected runtime error', preventDefault: () => prevented = true});
            if (kind === 'onmessageerror') worker.onmessageerror({});
            if (kind === 'worker error reply') worker.deliver({type: 'error', generation: worker.request.generation, message: 'injected solve error'});
            H.expectCleanup(kind + ' fallback cleanup', worker, 'fallback');
            if (kind === 'onerror') H.check('error default prevented', prevented);
        }
        {
            const worker = H.prepare();
            const timer = H.timers.at(-1);
            H.check('watchdog configured at 30 seconds', timer.delay === 30000 && !timer.cleared && cpuWholeStatus === 'preparing');
            timer.fn(...timer.args);
            H.expectCleanup('30 second watchdog callback fallback cleanup', worker, 'fallback');
            H.check('watchdog explains timeout', /timeout \(30s\)/.test(cpuWholeFailure));
        }
        {
            const worker = H.prepare();
            const data = H.payload(worker);
            data.generation--;
            worker.deliver(data);
            H.check('foreign generation ignored while preparing', cpuWholeStatus === 'preparing' && cpuWholeDp === null && worker.terminated === 0);
            const timer = H.timers.at(-1);
            releaseWholeGameCpu();
            timer.fn(...timer.args);
            H.check('released watchdog callback cannot revive match', cpuWholeStatus === 'inactive' && cpuWholeDp === null && timer.cleared);
        }
        {
            const worker = H.prepare();
            const data = H.payload(worker);
            quitToMenu();
            worker.deliver(data);
            H.expectCleanup('menu return rejects stale result and releases worker', worker, 'inactive');
            H.check('menu clears seat choice', !state.seatChosen);
        }
        {
            const worker = H.prepare();
            const data = H.payload(worker);
            replaySameSeat();
            const newer = H.workers.at(-1);
            worker.deliver(data);
            H.check('rematch rejects old generation', newer !== worker && newer.request.generation !== worker.request.generation &&
                cpuWholeStatus === 'preparing' && cpuWholeDp === null && cpuWholeWorker === newer && worker.terminated === 1 &&
                H.revoked.includes(worker.url), H.snapshot());
            releaseWholeGameCpu();
        }
        {
            const worker = H.prepare();
            const data = H.payload(worker);
            const newer = H.prepare('master', 'fake', [9,8,7,6,5,4,3,2,1]);
            worker.deliver(data);
            H.check('new layout preparation rejects old result', cpuWholeStatus === 'preparing' && cpuWholeDp === null &&
                newer.request.config.layoutP1[0] === 9 && cpuWholeWorker === newer && worker.terminated === 1, H.snapshot());
            releaseWholeGameCpu();
        }
        {
            const worker = H.prepare();
            worker.deliver(H.payload(worker));
            const dp = cpuWholeDp;
            const duplicate = H.payload(worker);
            new Float64Array(duplicate.layers[0])[0] = NaN;
            worker.deliver(duplicate);
            H.check('duplicate ready cannot replace accepted table', cpuWholeStatus === 'ready' && cpuWholeDp === dp && worker.terminated === 1);
            releaseWholeGameCpu();
            H.expectCleanup('release clears accepted DP and stats references', worker, 'inactive');
            H.check('release clears stats', cpuWholeStats === null);
        }
        {
            const worker = H.prepare('hard');
            worker.onerror({message: 'injected HARD failure', preventDefault() {}});
            const cell = selectCpuEquilibriumCell('block', {mix: 0.99, sample: 0.5});
            H.check('HARD fallback selects legal legacy action', cpuWholeStatus === 'fallback' && Number.isInteger(cell) &&
                cell >= 0 && cell < 9 && hardLegacyDecisions === 1 && hardDpDecisions === 0, {cell, hardLegacyDecisions, hardDpDecisions});
        }
        {
            const worker = H.prepare('master');
            refreshCpuEqTables();
            worker.onmessageerror({});
            const cell = selectCpuEquilibriumCell('block', {sample: 0.5});
            H.check('MASTER fallback selects legal board equilibrium action', cpuWholeStatus === 'fallback' && Number.isInteger(cell) &&
                cell >= 0 && cell < 9 && cpuWholeLegacyDecisions === 1 && cpuWholeDecisions === 0,
                {cell, cpuWholeLegacyDecisions, cpuWholeDecisions});
        }
        for (const mode of ['constructor_error', 'url_error', 'post_error']) {
            const before = H.urls.length;
            H.prepare('master', mode);
            const newUrls = H.urls.slice(before);
            H.check(mode + ' returns fallback and releases object URL', cpuWholeStatus === 'fallback' && cpuWholeWorker === null &&
                cpuWholeWorkerUrl === null && cpuWholeWatchdog === null && newUrls.every(url => H.revoked.includes(url)),
                {snapshot: H.snapshot(), newlyCreatedUrls: newUrls.length, newlyRevokedUrls: newUrls.filter(url => H.revoked.includes(url)).length});
        }
        releaseWholeGameCpu();
        return H.results;
    };
})();
