#!/usr/bin/env python3
"""Tiny deterministic wire fixtures for the frozen limited counter checker."""
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
SCRIPT = ROOT / "raw_counter_check.py"
FROZEN_SHA = "91762a94d1e1e05305c2a11fbb237dd4b42bffd3ebb5162f48c4cec42b038c23"
spec = importlib.util.spec_from_file_location("counter_checker", SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def vi(value):
    value &= (1 << 64) - 1
    out = bytearray()
    while value > 127:
        out.append((value & 127) | 128)
        value >>= 7
    out.append(value)
    return bytes(out)


def scalar(number, value):
    return vi(number << 3) + vi(value)


def blob(number, value):
    if isinstance(value, str):
        value = value.encode()
    return vi((number << 3) | 2) + vi(len(value)) + value


def double(number, value):
    return vi((number << 3) | 1) + struct.pack("<d", value)


def defaults(uuid=20):
    return blob(11, scalar(31, uuid))


def desc(uuid=20, parent=10, mult=1000, incremental=True, name=None):
    counter = scalar(1, 1) + scalar(4, mult) + scalar(5, incremental)
    return scalar(1, uuid) + scalar(5, parent) + blob(8, counter) + (blob(2, name) if name else b"")


def packet(seq=1, flags=None, extra=b"", event=None, definition=None, default=None, loss=None, legacy_clear=False):
    result = scalar(10, seq)
    if flags is not None:
        result += scalar(13, flags)
    if legacy_clear:
        result += scalar(41, 1)
    if loss is not None:
        result += scalar(42, loss)
    if default is not None:
        result += blob(59, default)
    if definition is not None:
        result += blob(60, definition)
    if event is not None:
        result += blob(11, event)
    return result + extra


def event(value=None, name="bingo.stage16.synthetic", uuid=None, extras=b""):
    result = scalar(9, 3) + blob(23, name)
    if uuid is not None:
        result += scalar(31, uuid)
    if value is not None:
        result += scalar(12, value)
    return result + extras


def base(counter=None, seq=1):
    thread = scalar(1, 10) + blob(4, scalar(1, 100) + scalar(2, 101))
    return [packet(definition=thread), packet(definition=counter or desc()),
            packet(seq=seq, flags=1, default=defaults())]


def run(packets):
    checker = module.Checker()
    for index, data in enumerate(packets):
        checker.packet = index
        checker.packet_offset = index * 100  # explicit synthetic placeholder
        checker.result["packets_seen"] += 1
        checker.packet_message(data)
    checker.result["status"] = "limited_scope_complete"
    checker.finish()
    return checker.result


def cpus(result):
    return [r["cpu_ns"] for r in result["ledger"]]


def checks():
    outcomes = []

    def check(label, condition):
        if not condition:
            raise AssertionError(label)
        outcomes.append({"case": label, "passed": True})

    check("frozen_checker_hash", hashlib.sha256(SCRIPT.read_bytes()).hexdigest() == FROZEN_SHA)
    r = run(base() + [packet(flags=2, event=event(5)), packet(flags=2, event=event(2)), packet(flags=3, default=defaults(), event=event(3))])
    check("delta_accumulation_and_clear", cpus(r) == [5000, 7000, 3000])
    check("thread_parent_association", r["ledger"][0]["counters"][0]["association_at_end"]["tid"] == 101)
    check("packet_indices_preserved", [v["packet_index"] for v in r["ledger"]] == [3, 4, 5])

    r = run(base() + [packet(flags=2, event=event(5)), packet(flags=2, loss=65, event=event(100)), packet(flags=2, event=event(200)), packet(flags=3, default=defaults(), event=event(3))])
    check("nonzero_loss_mask_and_needs_skip", cpus(r) == [5000, 3000] and r["diagnostic_counts"].get("payload_skipped_needs_invalid_state") == 2)
    r = run(base() + [packet(flags=2, event=event(5)), packet(flags=3, loss=65, default=defaults(), event=event(2))])
    check("clear_wins_same_packet_loss", cpus(r) == [5000, 2000] and r["transitions"][-1]["action"] == "clear")
    r = run(base() + [packet(flags=2, event=event(5)), packet(flags=2, legacy_clear=True, default=defaults(), event=event(2))])
    check("legacy_clear_bool", cpus(r) == [5000, 2000])
    r = run(base() + [packet(flags=2, event=event(5)), packet(flags=2, default=defaults(), event=event(2))])
    check("defaults_change_preserves_counter_sum", cpus(r) == [5000, 7000])
    r = run(base() + [packet(flags=2, event=event(5)), packet(flags=1), packet(flags=2, event=event(2))])
    check("clear_removes_defaults", cpus(r) == [5000, None] and r["diagnostic_counts"].get("extra_counter_uuid_shortage") == 1)
    r = run(base() + [packet(seq=2, flags=3, default=defaults(), event=event(100)), packet(flags=2, event=event(5)), packet(seq=2, flags=2, event=event(2)), packet(flags=2, event=event(3))])
    check("sequence_isolation", cpus(r) == [100000, 5000, 102000, 8000])

    r = run(base() + [packet(flags=2, event=event(5)), packet(flags=0, loss=65, event=event(7))])
    check("unflagged_invalid_incremental_is_not_reliable", cpus(r) == [5000, None] and not r["ledger"][-1]["counters"][0]["sum_reliable"])
    r = run(base()[:2] + [packet(flags=2, default=defaults(), event=event(99)), packet(flags=0, event=event(7))])
    check("defaults_apply_before_invalid_needs_skip", r["ledger"][-1]["counters"][0]["raw_value"] == 7 and r["ledger"][-1]["cpu_ns"] is None)
    r = run(base()[:2] + [packet(extra=scalar(87, 1), flags=2, default=defaults(), event=event(99))])
    check("first_packet_flag_does_not_validate", not r["ledger"] and r["diagnostic_counts"].get("payload_skipped_needs_invalid_state") == 1)

    r = run(base() + [packet(flags=2, event=event(10)), packet(flags=2, event=event(-2))])
    check("negative_int64_not_zigzag", cpus(r) == [10000, 8000] and r["ledger"][1]["counters"][0]["raw_value"] == -2)
    r = run(base(desc(mult=0)) + [packet(flags=2, event=event(5))])
    check("zero_multiplier_means_no_scaling", cpus(r) == [5])
    r = run(base(desc(mult=-2)) + [packet(flags=2, event=event(5))])
    check("negative_multiplier_ignored_as_in_source", cpus(r) == [5])
    r = run(base() + [packet(flags=2, event=event(None, extras=scalar(45, 20) + double(46, 0.5)))])
    check("double_fixed64_counter", cpus(r) == [500])
    r = run(base() + [packet(flags=2, event=event(5, extras=scalar(45, 20) + double(46, 0.5)))])
    check("integer_then_double_shared_accumulator", cpus(r) == [5500])
    r = run(base() + [packet(flags=2, event=event(None, extras=blob(12, vi(5))))])
    check("packed_numeric_recognized_and_rejected", cpus(r) == [None] and r["diagnostic_counts"].get("packed_numeric_rejected") == 1)
    r = run(base() + [packet(flags=2, event=event(5, uuid=999))])
    check("unknown_descriptor_no_accepted_cpu", cpus(r) == [None] and r["diagnostic_counts"].get("unknown_or_non_counter_descriptor") == 1)
    r = run(base() + [packet(flags=2, event=event(5)), packet(definition=desc(mult=2000)), packet(flags=2, event=event(2))])
    check("descriptor_conflict_retroactive_and_future_rejection", cpus(r) == [None, None] and r["descriptors"]["20"]["conflicting"])
    r = run(base() + [packet(flags=2, event=event(None, name="bingo.stage16.missing-cpu"))])
    check("missing_cpu_marker_retained", cpus(r) == [None] and r["cpu_summary"]["target_marker_rows_without_cpu"] == 1)
    r = run(base() + [packet(flags=2, event=event(None, name="TimeStamp", extras=blob(4, blob(10, "data") + blob(11, blob(10, "message") + blob(6, "bingo.stage16.legacy.marker")))) )])
    check("timestamp_nested_message_retained", r["ledger"][0]["data_message"] == "bingo.stage16.legacy.marker" and r["ledger"][0]["target_marker"])

    interned = blob(2, scalar(1, 7) + blob(2, "bingo.stage16.interned"))
    interned_event = scalar(9, 3) + scalar(10, 7) + scalar(12, 2)
    r = run(base() + [packet(flags=3, default=defaults(), extra=blob(12, interned), event=interned_event)])
    check("same_packet_clear_defaults_intern_and_event", r["ledger"][0]["name"] == "bingo.stage16.interned" and cpus(r) == [2000])

    scalar_event = scalar(9, 4) + scalar(11, 20) + scalar(30, 5)
    r = run(base() + [packet(flags=2, event=scalar_event), packet(flags=2, event=event(2))])
    check("scalar_counter_nonmarker_delta_not_dropped", r["ledger"][-1]["cpu_ns"] == 7000)
    r = run(base() + [packet(flags=2, event=event(5, uuid=20, extras=scalar(31, 999)))])
    check("extra_uuid_surplus_allowed", cpus(r) == [5000])
    many = b"".join(scalar(12, 1) for _ in range(9)) + b"".join(scalar(31, 20) for _ in range(9))
    r = run(base() + [packet(flags=2, event=event(None, extras=many))])
    check("combined_extra_budget_eight", cpus(r) == [None] and r["diagnostic_counts"].get("extra_counter_unresolved") == 1)

    # CLI tests exercise exclusive-create and partial-save paths, not just helpers.
    with tempfile.TemporaryDirectory(prefix="raw-counter-synthetic-", dir=ROOT) as tmp:
        tmp = Path(tmp)
        p = tmp / "input.proto"
        good_packets = base() + [packet(flags=2, event=event(5))]
        p.write_bytes(b"".join(blob(1, item) for item in good_packets))
        out = tmp / "ledger.json"
        first = subprocess.run([sys.executable, str(SCRIPT), str(p), str(out)], capture_output=True)
        saved = out.read_bytes()
        second = subprocess.run([sys.executable, str(SCRIPT), str(p), str(out)], capture_output=True)
        check("cli_no_overwrite", first.returncode == 0 and second.returncode == 2 and out.read_bytes() == saved)
        p.write_bytes(p.read_bytes() + b"\x0a\x05\x08")
        bad = tmp / "partial.json"
        failed = subprocess.run([sys.executable, str(SCRIPT), str(p), str(bad)], capture_output=True)
        partial = json.loads(bad.read_text())
        check("malformed_tail_partial_ledger_preserved", failed.returncode == 1 and partial["status"] == "failed_partial_ledger_preserved" and partial["ledger"][-1]["cpu_ns"] == 5000)
        p.write_bytes(blob(1, packet(extra=blob(50, b"not decompressed"))))
        compressed = tmp / "compressed.json"
        failed = subprocess.run([sys.executable, str(SCRIPT), str(p), str(compressed)], capture_output=True)
        check("compression_recognized_and_rejected", failed.returncode == 1 and json.loads(compressed.read_text())["diagnostic_counts"].get("compressed_packets_unsupported") == 1)
    return outcomes


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: raw_counter_synthetic_checks.py new-result.json")
    with Path(sys.argv[1]).open("x", encoding="utf-8") as out:
        result = {"checker_sha256": hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),
                  "scope": "Tiny synthetic fixtures only; no real trace, browser or performance jobs.",
                  "checks": checks()}
        result["passed"] = all(c["passed"] for c in result["checks"])
        result["count"] = len(result["checks"])
        json.dump(result, out, indent=2)
        out.write("\n")
    print(result["count"], "synthetic checks passed")
