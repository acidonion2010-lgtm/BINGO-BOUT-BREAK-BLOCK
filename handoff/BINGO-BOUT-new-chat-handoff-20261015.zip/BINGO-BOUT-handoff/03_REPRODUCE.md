# 新環境での確認と再現

## 開始位置と依存

ゲームを遊ぶだけなら `project/index.html` を開けます。以下は新チャットのLinux開発環境での検証用で、ユーザーのWindowsで実行するPowerShellではありません。本番HTMLの依存を追加する手順でもありません。

ZIP内の `BINGO-BOUT-handoff` ディレクトリを `/workspace` の下へ展開してください。検証コードの一部が `/workspace` と `/usr/bin/chromium` を前提にしています。新環境に既存のAGENTS.md等があれば先に確認してください。

前環境: Linux x86_64、Python 3.12、Node v24.19.0、Python Playwright、`/usr/bin/chromium` 154.0.8037.57。段階8のOS trace解析はLinux固有です。依存が不足していれば新環境に合わせて用意し、バージョンと変更を記録してください。異なるブラウザー版の絶対時間を以前の値から直接引かないでください。

## 整合性だけを確認

引き継ぎフォルダ直下で、標準Pythonのみで同梱ファイルを照合できます:

```bash
cd /workspace/BINGO-BOUT-handoff
python3 verify_manifest.py
```

実際の展開先が異なる場合はcd先だけ変更してください。以降は `project` 内で実行します。

```bash
cd project
python3 --version
node --version
/usr/bin/chromium --version
python3 -c 'from playwright.sync_api import sync_playwright; print("Playwright import OK")'
sha256sum index.html index.before.html stages/index.handoff-20261015.html
mkdir -p validation/new-chat
BINGO_RUN_DIR="$(mktemp -d validation/new-chat/run-XXXXXX)"
```

ここまでが全検証共通の準備です。以下の `$BINGO_RUN_DIR` は、この同じBashセッションで使ってください。別のシェルやツール呼び出しへ移る場合は、作成されたディレクトリの実際のパスを明示して引き継ぎ、未定義の変数でコマンドを実行しないでください。

## 機能の再確認が必要な場合

以下のコマンドは順に実行します。既存記録を上書きせず、新しい出力先へ保存してください。同じブラウザー・DP・性能ジョブを同時に実行しないでください。現在版の原本照合に使う例です:

```bash
node validation/stage9/legacy_equivalence.cjs stages/index.handoff-20261015.html index.html "$BINGO_RUN_DIR/legacy-equivalence.json"
python3 validation/worker_lifecycle.py index.html --out "$BINGO_RUN_DIR/worker.json"
python3 validation/gameplay_smoke.py --file index.html --out "$BINGO_RUN_DIR/gameplay.json"
python3 validation/capture.py index.before.html "$BINGO_RUN_DIR/before" --repeats 1 --port 8014
python3 validation/capture.py index.html "$BINGO_RUN_DIR/after" --repeats 1 --port 8014
python3 validation/compare.py "$BINGO_RUN_DIR/before" "$BINGO_RUN_DIR/after" --output "$BINGO_RUN_DIR/comparison.json"
cmp "$BINGO_RUN_DIR/before/whole-first1.bin" "$BINGO_RUN_DIR/after/whole-first1.bin"
cmp "$BINGO_RUN_DIR/before/whole-first2.bin" "$BINGO_RUN_DIR/after/whole-first2.bin"
```

このNode検証は段階9の4関数以外が一致することもassertします。後続段階で他の関数を変更した場合、無条件にそのまま使える検証ではありません。目的に合わせた新検証を作り、旧ハーネスを都合よく書き換えないでください。一般均衡の4,617件は `validation/equilibrium_edges.cjs` が確認しますが、結果を `validation/equilibrium-edges.json` へ書く実装なので、旧記録を保護した作業コピーで実行してください。

ZIPには全DPの `.bin` を含めていません。保存された `comparison.json` やhashを読むだけなら再生成不要です。`compare.py` を再実行する場合には、上記のように原本と対象版の両方をcaptureしてバイナリを再生成します。captureの付随時間は正式な速度比較として扱いません。

## 性能調査を再現する場合

まず新しい調査計画へ仮説・比較するSHA・回数・条件・停止条件を書いてください。下記は既存の測定を再現する例であり、次のチャットで全部を無条件に再実行する必要はありません。この節だけを実行する場合も、上の共通準備で出力先を作成してください。起動・準備比較は各版5回、同じプロセス内で交互に順序反転します:

```bash
python3 validation/performance.py index.before.html index.html "$BINGO_RUN_DIR/startup-original.json" --port 8016 --repeats 5
python3 validation/performance.py stages/index.handoff-20261015.html index.html "$BINGO_RUN_DIR/startup-handoff.json" --port 8016 --repeats 5
```

段階9のsame-realm診断と104条件の通常HTML比較はそれぞれ別の問いを扱います。合算しないでください:

```bash
python3 validation/stage9/break_candidate.py --baseline stages/index.handoff-20261015.html --candidate index.html --output "$BINGO_RUN_DIR/break-candidate.json"
python3 validation/stage9/selector_performance.py index.before.html index.html "$BINGO_RUN_DIR/selector-performance.json" --port 8015
```

`break_candidate.py` は段階9で変更した4関数の切替実験専用です。別の変更の因果診断に使う場合は、適用条件を確認して新しい測定器へ分けてください。`selector_performance.py` の検証用ラベルも段階9用です。前チャットの実行結果ではなく、新しい実行として条件と結果を記録してください。

## 古い描画待ちの調査を続ける場合

最初に `未完了検証8結果.md` と `validation/stage8/README.md`、`commit-wait-review.md`、`perf-review.md` を読んでください。当時の対象は原本と段階5で、現在版は段階9です。過去条件の再現ではafterを `stages/index.handoff-20261015.html` に、現在版の新調査ではafterを `index.html` にして区別します。出力先も新しい場所にします。

trace/perf自体の負荷、入力位相、headless・mute-audio、OS記録の対応条件を維持して記録してください。環境がperfのrenderer threadへの接続を許さない場合は、未取得として明記し、取得したことにして解析しないでください。特権やシステム設定の変更を前提とする計画にはしていません。
