# renderer-mainの独立CPU取得方法

2026-10-15。ブラウザー・DP・負荷測定を追加実行せず、Linux公式sourceの読み取りと、自己process/idle childを使う小さなnative API capability確認だけを行った。元成果物は変更していない。

**外部processからrenderer TIDのdynamic thread CPU clockを直接読む案は、この環境では使えない。** `(~tid << 3) | 6`は自己processのmain/workerで成功したが、別childのmain/workerでは`clock_gettime`が`EINVAL`だった。`/proc/PID/task/TID/schedstat`は読めるものの、ns表記の値がread時点まで更新されるとは限らず、host側のread bracketだけで厳密な同一CPU区間とは保証できない。

## capability確認

`cpu_sampler_capability.py`はlibcの`clock_gettime`をctypesで直接呼び、自己main・自己idle worker・別idle child main/workerを各1回調べた。busy loopやbrowserを起動せず、childとworkerを終了させた。保存結果は`cpu-sampler-capability.json`。

| target | dynamic thread clock | dynamic process clock | task schedstat |
|---|---|---|---|
| 自己main | 成功 | 成功 | 読取り可 |
| 自己worker | 成功 | 成功 | 読取り可 |
| 別child main | EINVAL | 成功 | 読取り可 |
| 別child worker | EINVAL | 成功 | 読取り可 |

process用は`(~pid << 3) | 2`。別processのCPU合計を取得できても、renderer-mainだけのCPU時間とは違う。rendererには他のthreadがあるので、この合計でmainの`tts`を置き換えたり、main wall区間とのCPU≤wallを要求したりしない。`pthread_getcpuclockid`も別processのTIDを外部から渡すAPIではない。

同じcapability確認で`SC_CLK_TCK=100`だった。`/proc/.../stat`のutime/stimeはこの単位なので1tick=10msであり、数msの異常を細かく検証する主時計には使わない。

## Linux sourceで確認した範囲

実行kernelのversion文字列と同じLinux stable v6.18.44の公式sourceを取得し、URL・元SHA-256を`official-sources/linux-cpu-sampler/MANIFEST.json`へ保存した。version一致は実行kernel binaryとの完全同一性の証明ではないが、capability結果に対応する制約をsourceで確認できる。

- `kernel/time/posix-cpu-timers.c`の`pid_for_clock`（57行〜）はper-thread clockで`same_thread_group(tsk,current)`を要求する。別childへの`EINVAL`と整合する。失敗値を0 CPUとして補わない。
- 同sourceの`cpu_clock_sample`（194行〜）は`CPUCLOCK_SCHED`で`task_sched_runtime(p)`を呼ぶ。自己`CLOCK_THREAD_CPUTIME_ID`側の経路とscheduler runtimeは共通基盤を持つ。
- `fs/proc/base.c`の`proc_pid_schedstat`（508行〜）は`task->se.sum_exec_runtime`、`task->sched_info.run_delay`、`pcount`を直接出力し、`task_sched_runtime()`によるread時点の更新を呼ばない。sched-infoが無効なら`0 0 0`を出す経路もある。

したがってschedstatはPerfettoのpacket/JSON exportとは別経路の証拠にはなるが、kernel CPU会計から完全に独立した時計ではない。また単位がnsでも、更新粒度や鮮度がnsという意味ではない。before値が古く、afterでその分が追い付いた場合、read時刻だけで作った外側wallにCPU差が収まらないこともあり得る。これをそのまま新しいkernel clock異常やtrace異常へ認定しない。

## 外側bracketの実装案

rootが所有するbrowser診断へ追加するなら、選択したrenderer-mainのPID/TIDごとに次を保存する。

1. UserTiming markerのtrack/PID/TIDを元protobuf/traceから特定し、同じhostの`/proc/PID/task/TID`へ対応することを検証する。名前`CrRendererMain`だけで複数rendererから選ばない。PID namespaceが異なる場合は`NSpid`/`NStgid`も保存して対応を確認する。
2. process/threadのstat starttime、Tgid/Pid、commを前後に記録し、終了・再利用・process変更を検知する。procディレクトリFDやpidfdを保つ実装もidentity保護に使える。情報が消えた場合は欠測として保持する。
3. 各schedstat readの直前/直後にhost `CLOCK_MONOTONIC` nsを読む。runtime、runqueue wait、schedule countの元文字列とparsed値を保存する。identity/stat/statusのIO時刻とschedstat自身のread bracketを混同しない。
4. before-read完了後に開始markerを出し、終了marker受領後にafter-readを開始する。trace wall domainが同じLinux MONOTONICであることを別途確認し、`beforeReadEnd <= startMark <= endMark <= afterReadStart`を要求する。page `performance.now()`の絶対値をhost nsから引かない。
5. runtime差・runqueue差・schedule-count差の符号を記録する。必要なら既存の有限回数で連続readの値/更新頻度を調べるが、marker窓に値を内挿したり、0補完したりしない。

この順で得る差は、開始前後のCDP dispatch・wrapper外の仕事・trace準備やcallback回収を含む、**広いhost bracketに対応する補助差**である。しかもschedstat endpoint鮮度は保証されないので、host時刻の包含だけで厳密なCPU upper boundには昇格しない。対象が確実にdescheduleされた後の値を使う設計は鮮度改善に役立ち得るが、statのstateが一瞬Sだっただけで保証しない。ゲームの処理をpause/ptrace/注入で変える必要があるなら、今回の通常診断とは別条件として扱う。

## 代替経路と結論の限界

CDP `Performance.getMetrics`のThreadTime系metricや`timeDomain='threadTicks'`の実装・実可用性を別途確認できれば、renderer内の直接ThreadTicksをexport外で読む対照になり得る。ただしこのcapability確認ではbrowserを起動しておらず、そのmetricの存在・対象thread・時点は未確認である。取得command自身のCPU費用と広いbracketを保持し、同じOS ThreadTicks源を共有することも明記する必要がある。

per-thread perf task-clockも候補だが、実際のpermission・更新方式・readの対象thread対応を確認する前に使えるとはしない。外部process CPU合計、共有cgroup CPU、粗いstat ticksは文脈・整合性の補助として保存し、main-thread `tts`の代用にしない。

今回確定したのはdynamic外部thread clockの利用不可と、schedstat読取りの可用性・鮮度制約である。元169件の原因、CPU寄与率、全経路性能PASSは確定していない。新しいbrowser/protobuf比較の採取と有限計画はrootへ引き継ぐ。
