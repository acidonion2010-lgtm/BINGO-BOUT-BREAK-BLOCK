# Stage16 限定 raw counter checker の確認

`raw_counter_check.py` は、公式 Trace Processor の独立補助として raw の counter 算術と marker 対応を記録する。公式変換・SQL の結果を優先し、このスクリプトを完全な Perfetto importer として扱わない。

固定 SHA-256:

`91762a94d1e1e05305c2a11fbb237dd4b42bffd3ebb5162f48c4cec42b038c23`

実行形式は `python raw_counter_check.py input.proto new-output.json`。既存 output は変更せず終了する。途中の wire 破損や未対応 compression では失敗理由と、それまでの ledger を JSON に保存する。各出力に input・実行 script・参照した固定版公式原文の hash を含める。

対象範囲:

- Trace.packet framing と wire type 0 / 1 / 2 / 5 の上限付き解読。入力 512 MiB、単独 message 64 MiB、packet / ledger 各 2,000,000、field 合計 20,000,000、保存診断 10,000 件が上限。
- sequence / flags / clear / loss、defaults、interned event / annotation 名の関連付け。counter UUID / parent thread、倍率、integer / double、sequence ごとの加算を入力順に扱う。
- `bingo.stage16.*` と preflight marker を CPU の有無によらず保存する。`TimeStamp` の modern debug annotation `data.message` と legacy JSON も読み取る。
- ledger は packet index・trace offset・raw counter・倍率後値・加算後値・`cpu_ns`・関連 descriptor を保存する。wall timestamp / clock ID は変換せず raw のまま残す。
- descriptor conflict、未知 counter、packed repeated、無効 state の unflagged incremental counter などは診断し、該当する CPU を採用しない。parse 完了と CPU coverage は別の summary にする。

範囲外: compression 展開、clock conversion、ClockSnapshot の解釈、slice matching、PID namespace / TID reuse、全 DebugAnnotation 形式、descriptor 名の完全な merge 規則。関連 thread の表示は入力完了後の descriptor 階層に基づく。ここでの「reliable」は対応した算術の範囲であり、サンプリング時点や物理的な CPU ≤ wall の保証ではない。

## 独立確認

wire / descriptor / math / marker coverage は親 reviewer が静的確認し、reset / defaults / NEEDS / interning は別 reviewer が固定版公式ソースと照合した。指摘された descriptor conflict の信頼性、parse 完了と CPU coverage の区別、CPU 欠測 marker の保持、loss 後の unflagged incremental 値の信頼性を修正後、上の hash で固定した。

[30 件の合成回帰確認](RAW_COUNTER_SYNTHETIC_CHECKS_v2.json)はすべて成功した。実行可能な生成・検証コードは [raw_counter_synthetic_checks.py](raw_counter_synthetic_checks.py)。loss mask 65、clear 優先、legacy clear、defaults 更新・削除、初期 invalid / NEEDS、first-packet flag、sequence 分離、負 int64、倍率、double、packed 拒否、conflict の遡及無効化、CPU 欠測 marker、TimeStamp `data.message`、途中の単独 counter、8 値上限、既存出力保護、途中失敗保存、compression 拒否を含む。

別担当が作った [公式ツールとの合成照合](decoder-validation/RESULTS.md)も、固定した最終 checker で 48 checks、8 marker endpoints、11 counter values が一致した。公式ツールは利用可能な release v58.2 `add693d8b` であり、ブラウザーが固定する `5dbeaad…` と同一 revision のバイナリではない。この差は公式照合の適用限界として保持する。独立 fixture は TimeStamp annotation の coverage を含まず、その点は上の合成回帰確認で別に検証した。

この担当は実ブラウザー・DP・性能測定・実 trace の解析を行っていない。本 checker を正式採取 raw に適用し、公式変換と突き合わせる作業は親担当が実施する。
