#!/usr/bin/env python3
"""Fixed encoding positive control. Run once, create one fixture exclusively.

Implements ../CONTROL_PLAN.md. CPU and wall true elapsed values are identical.
Only protobuf wire helpers are reused; no checker/decoder code is imported.
No browsers, real traces or runtime/performance sampling are involved.
"""
from pathlib import Path
import hashlib
import json
import wire_helpers_snapshot as w

ROOT = Path(__file__).resolve().parent
WALL_BASE = 1_000_000_000
STEP = 1_500
OLD_STEPS = 20_000
UNIT = 1_000
SEQ = 31
THREAD_UUID = 3101
COUNTER_UUID = 3102
MARKER = "S16_source_quantization_control"


def packet(data):
    return w.packet(SEQ, data)


def clock(cid, ts, incremental=False, unit=1):
    data = w.scalar(1, cid) + w.scalar(2, ts)
    if incremental:
        data += w.scalar(3, 1)
    if unit != 1:
        data += w.scalar(4, unit)
    return w.message(1, data)


def clear_and_describe(wall):
    snapshot = clock(3, wall) + clock(64, wall // UNIT, True, UNIT) + w.scalar(2, 3)
    track_defaults = w.scalar(11, THREAD_UUID) + w.scalar(31, COUNTER_UUID)
    defaults = w.scalar(58, 64) + w.message(11, track_defaults)
    names = w.message(1, w.scalar(1, 1) + w.message(2, "source-quantization-control"))
    names += w.message(2, w.scalar(1, 1) + w.message(2, "source_quantization_noise"))
    names += w.message(2, w.scalar(1, 2) + w.message(2, MARKER))
    yield packet(w.scalar(13, 1) + w.message(59, defaults) + w.message(12, names) + w.message(6, snapshot))
    thread = w.scalar(1, 4343) + w.scalar(2, 3131) + w.message(5, "SourceQuantizationControlThread")
    descriptor = w.scalar(1, THREAD_UUID) + w.message(4, thread)
    yield packet(w.scalar(13, 2) + w.scalar(8, 0) + w.message(60, descriptor))
    counter = w.scalar(1, 1) + w.scalar(4, UNIT) + w.scalar(5, 1)
    descriptor = (w.scalar(1, COUNTER_UUID) + w.scalar(5, THREAD_UUID)
                  + w.message(2, "thread_time") + w.message(8, counter))
    yield packet(w.scalar(13, 2) + w.scalar(8, 0) + w.message(60, descriptor))


def event(typ, iid, wall_delta_units, cpu_delta_units):
    data = w.scalar(9, typ) + w.scalar(3, 1) + w.scalar(12, cpu_delta_units)
    if iid is not None:
        data += w.scalar(10, iid)
    return packet(w.scalar(13, 2) + w.scalar(8, wall_delta_units) + w.message(11, data))


def main():
    parts = []
    # Explicitly synthetic builtin relation avoids a loader default-clock gap.
    global_snapshot = clock(3, WALL_BASE) + clock(6, WALL_BASE) + w.scalar(2, 3)
    parts.append(w.message(1, w.message(6, global_snapshot)))
    parts.extend(clear_and_describe(WALL_BASE))
    saved_wall_ns = WALL_BASE
    previous_true_cpu_ns = 0
    represented_cpu_ns = 0
    wall_deltas = {1: 0, 2: 0}
    for index in range(1, OLD_STEPS + 1):
        true_cpu_ns = index * STEP
        true_wall_ns = WALL_BASE + true_cpu_ns
        assert true_cpu_ns == true_wall_ns - WALL_BASE
        wall_delta_units = (true_wall_ns - saved_wall_ns) // UNIT
        saved_wall_ns += wall_delta_units * UNIT  # SDK wall carry-forward.
        wall_deltas[wall_delta_units] += 1
        cpu_delta_units = (true_cpu_ns - previous_true_cpu_ns) // UNIT
        previous_true_cpu_ns = true_cpu_ns  # Full ns sample, no CPU carry.
        represented_cpu_ns += cpu_delta_units * UNIT
        final_old_step = index == OLD_STEPS
        parts.append(event(1 if final_old_step else 3, 2 if final_old_step else 1,
                           wall_delta_units, cpu_delta_units))
    begin_true_cpu_ns = previous_true_cpu_ns
    begin_true_wall_ns = WALL_BASE + begin_true_cpu_ns
    begin_represented_cpu_ns = represented_cpu_ns
    begin_represented_wall_ns = saved_wall_ns
    assert begin_true_cpu_ns == 30_000_000
    assert begin_represented_cpu_ns == 20_000_000
    assert begin_represented_wall_ns == begin_true_wall_ns == 1_030_000_000
    assert wall_deltas == {1: 10_000, 2: 10_000}

    # Explicit construction assumption: standalone clear/snapshot occurs at
    # exactly BEGIN's true instant, and no CPU sample occurs before END.
    parts.extend(clear_and_describe(begin_true_wall_ns))
    saved_wall_ns = begin_true_wall_ns
    represented_cpu_ns = 0
    previous_true_cpu_ns = 0
    end_true_cpu_ns = (OLD_STEPS + 1) * STEP
    end_true_wall_ns = WALL_BASE + end_true_cpu_ns
    assert end_true_cpu_ns == end_true_wall_ns - WALL_BASE
    wall_delta_units = (end_true_wall_ns - saved_wall_ns) // UNIT
    saved_wall_ns += wall_delta_units * UNIT
    cpu_delta_units = (end_true_cpu_ns - previous_true_cpu_ns) // UNIT
    represented_cpu_ns += cpu_delta_units * UNIT
    parts.append(event(2, None, wall_delta_units, cpu_delta_units))

    expected = {
        "true_cpu_equals_elapsed_wall_by_construction": True,
        "step_ns": STEP, "old_epoch_steps": OLD_STEPS, "unit_multiplier": UNIT,
        "true_begin_cpu_ns": begin_true_cpu_ns,
        "true_end_cpu_ns": end_true_cpu_ns,
        "true_interval_wall_ns": 1500, "true_interval_cpu_ns": 1500,
        "old_epoch_quantization_loss_ns": 10000000,
        "begin_represented_wall_ns": begin_represented_wall_ns,
        "end_represented_wall_ns": saved_wall_ns,
        "begin_represented_cpu_ns": begin_represented_cpu_ns,
        "end_represented_cpu_ns": represented_cpu_ns,
        "expected_json_marker": MARKER,
        "expected_json_ph": "X", "expected_json_ts_us": 1030000,
        "expected_json_dur_us": 1, "expected_json_tts_us": 20000,
        "expected_json_tdur_us": 10001,
        "packet_count": len(parts), "track_event_count": OLD_STEPS + 1,
        "wall_delta_units_frequency": wall_deltas,
        "assumptions": ["same true CPU/wall rate", "same track UUID across clear",
                        "clear snapshot at BEGIN true instant", "no CPU sample between clear and END"],
        "scope_limit": "Constructed source encoding control, not same-cause evidence for actual traces.",
    }
    assert expected["packet_count"] == 20008
    assert represented_cpu_ns - begin_represented_cpu_ns == 10001000
    assert saved_wall_ns - begin_represented_wall_ns == 1000
    data = b"".join(parts)
    output = ROOT / "source-quantization-control.pftrace"
    with output.open("xb") as f:
        f.write(data)
    with (ROOT / "expected.json").open("x") as f:
        f.write(json.dumps(expected, indent=2) + "\n")
    print(json.dumps({"fixture": str(output), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                      "packets": len(parts), "events": OLD_STEPS + 1}))


if __name__ == "__main__":
    main()
