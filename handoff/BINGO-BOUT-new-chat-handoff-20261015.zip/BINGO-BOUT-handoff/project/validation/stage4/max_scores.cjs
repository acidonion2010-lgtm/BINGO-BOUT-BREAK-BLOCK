'use strict';

// Lightweight comparison: extract the real methods; never construct WholeGameDP
// or allocate/solve its full-game value layers.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { performance } = require('node:perf_hooks');

const root = path.resolve(__dirname, '../..');
const paths = {
    original: path.join(root, 'index.before.html'),
    stage3: path.join(root, 'stages/index.stage3.final.html'),
    stage4: path.join(root, 'stages/index.stage4.html')
};
const source = Object.fromEntries(Object.entries(paths).map(([name, file]) => [name, fs.readFileSync(file, 'utf8')]));

function methodRange(html, name, followingName) {
    const start = html.indexOf(`            ${name}(`);
    const end = html.indexOf(`            ${followingName}(`, start + 1);
    assert(start >= 0 && end > start, `Cannot find ${name}`);
    return { start, end, text: html.slice(start, end) };
}

function extract(html, name, followingName) {
    const range = methodRange(html, name, followingName);
    return new Function(`return ({${range.text}})` )()[name];
}

function withoutMaxScores(html) {
    const range = methodRange(html, 'buildMaxScores', 'buildLayer');
    return html.slice(0, range.start) + html.slice(range.end);
}

assert.equal(withoutMaxScores(source.stage4), withoutMaxScores(source.stage3), 'Changes outside buildMaxScores');
const oldScores = extract(source.original, 'buildScores', 'buildMaxScores');
const newScores = extract(source.stage4, 'buildScores', 'buildMaxScores');
const oldMax = extract(source.original, 'buildMaxScores', 'buildLayer');
const newMax = extract(source.stage4, 'buildMaxScores', 'buildLayer');
const lines = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]
];
const context = { lines, closedCount: new Uint8Array(512), closedCells: new Uint8Array(512 * 9) };
for (let mask = 0; mask < 512; mask++) {
    for (let cell = 0; cell < 9; cell++) {
        if (!(mask & (1 << cell))) context.closedCells[mask * 9 + context.closedCount[mask]++] = cell;
    }
}

let seed = 0x24681357;
function random() {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
}
const fixtures = [];
for (let sample = 0; sample < 96; sample++) {
    const layout = Array.from({ length: 9 }, (_, cell) => cell + 1);
    for (let cell = 8; cell > 0; cell--) {
        const other = Math.floor(random() * (cell + 1));
        [layout[cell], layout[other]] = [layout[other], layout[cell]];
    }
    fixtures.push({ kind: 'valid-shuffled', layout });
}
for (let sample = 0; sample < 32; sample++) {
    fixtures.push({ kind: 'finite-negative-fractional', layout: Array.from({ length: 9 }, () => (random() - 0.5) * 20) });
}
fixtures.push(
    { kind: 'finite-zero', layout: Array(9).fill(0) },
    { kind: 'finite-signed-zero', layout: Array(9).fill(-0) },
    { kind: 'finite-subnormal', layout: Array.from({ length: 9 }, (_, cell) => cell & 1 ? -Number.MIN_VALUE : Number.MIN_VALUE) },
    { kind: 'positive-infinity', layout: [Infinity, 2, 3, 4, 5, 6, 7, 8, 9] },
    { kind: 'negative-infinity', layout: [-Infinity, 2, 3, 4, 5, 6, 7, 8, 9] },
    { kind: 'opposing-infinities', layout: [Infinity, 2, 3, 4, 5, 6, 7, 8, -Infinity] },
    { kind: 'nan', layout: [1, 2, 3, 4, NaN, 6, 7, 8, 9] },
    { kind: 'finite-overflow', layout: Array.from({ length: 9 }, (_, cell) => cell & 1 ? -Number.MAX_VALUE : Number.MAX_VALUE) }
);

let comparedScores = 0;
let comparedMaxScores = 0;
let checkedLastClosed = 0;
let checkedNoTurns = 0;
const counts = {};
const specialOutputs = { finite: 0, positiveInfinity: 0, negativeInfinity: 0, nan: 0 };
const started = performance.now();
for (let sample = 0; sample < fixtures.length; sample++) {
    const fixture = fixtures[sample];
    counts[fixture.kind] = (counts[fixture.kind] || 0) + 1;
    const scores = oldScores.call(context, fixture.layout);
    const candidateScores = newScores.call(context, fixture.layout);
    const inputCopy = scores.slice();
    for (let mask = 0; mask < 512; mask++) {
        assert(Object.is(scores[mask], candidateScores[mask]), `Score mismatch at sample ${sample}, mask ${mask}`);
        comparedScores++;
    }
    const before = oldMax.call(context, scores);
    const after = newMax.call(context, candidateScores);
    assert.equal(before.length, 10);
    assert.equal(after.length, 10);
    for (let turns = 0; turns <= 9; turns++) {
        assert(after[turns] instanceof Float64Array);
        assert.equal(after[turns].length, 512);
        for (let mask = 0; mask < 512; mask++) {
            assert(Object.is(before[turns][mask], after[turns][mask]), `Max mismatch at ${fixture.kind} sample ${sample}, turns ${turns}, mask ${mask}`);
            comparedMaxScores++;
            const value = after[turns][mask];
            if (Number.isNaN(value)) specialOutputs.nan++;
            else if (value === Infinity) specialOutputs.positiveInfinity++;
            else if (value === -Infinity) specialOutputs.negativeInfinity++;
            else specialOutputs.finite++;
            const noFurtherOpen = scores[mask] < -1 ? -1 : scores[mask];
            if (context.closedCount[mask] <= 1) {
                assert(Object.is(after[turns][mask], noFurtherOpen), 'Last closed cell must remain closed');
                checkedLastClosed++;
            }
            if (turns === 9) {
                assert(Object.is(after[turns][mask], noFurtherOpen), 'No turns remaining');
                checkedNoTurns++;
            }
        }
    }
    for (let mask = 0; mask < 512; mask++) assert(Object.is(scores[mask], inputCopy[mask]), 'Input mutation');
}

const methodMetrics = Object.fromEntries(Object.entries(source).map(([name, html]) => {
    const text = methodRange(html, 'buildMaxScores', 'buildLayer').text.trimEnd();
    return [name, { bytes: Buffer.byteLength(text), lines: text.split('\n').length }];
}));
const result = {
    passed: true,
    scope: 'Real buildScores(layout) and buildMaxScores methods; no WholeGameDP constructor or full-game solve',
    equality: 'Object.is for every result, including NaN and signed zero',
    layouts: fixtures.length,
    layoutKinds: counts,
    comparedScores,
    comparedMaxScores,
    checkedLastClosed,
    checkedNoTurns,
    specialOutputs,
    inputUnchanged: true,
    stage4ChangesOnlyBuildMaxScores: true,
    methodMetrics,
    elapsedMs: performance.now() - started
};
const output = path.join(__dirname, 'max-scores.json');
fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n');
process.stdout.write(JSON.stringify(result, null, 2) + '\n');
