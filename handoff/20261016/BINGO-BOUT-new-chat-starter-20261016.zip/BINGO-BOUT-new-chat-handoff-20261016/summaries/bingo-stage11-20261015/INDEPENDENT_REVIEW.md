# 段階11 正式16標本の独立レビュー

2026-10-15。対象は `run-explicit-categories/` の保存済み記録と凍結済みソース。
ブラウザー、DP、性能ジョブは追加実行していない。解析器を呼び直さず、別の短い
Python処理で生traceのmarker、区間和、ファイルhash、`/proc`差分を照合した。
初期 `run/` の16標本は以下の数値へ混ぜていない。

## 記録の整合性

- 正式結果のstatusはcompleted、16標本。全標本で322/322自己テスト成功。
- 16個の生traceについて保存済みSHA-256とbytesが一致。開始・終了markerは各1個で、
  pid/tidが一致し、wallのtsとthread CPUのttsがともに有限・単調。marker差を独立再計算し、
  保存済みwall/CPU差と一致した。
- 対象スレッドの同期B/E対応を独立照合し、未対応なし。不正区間もなし。
  GC/JIT候補のwall区間和も別実装で16/16一致した。
- CDPのdataLossOccurredは全16標本でfalse。生traceのtrace_processor_statsでも、
  packet loss・buffer overwrite/discard・data lossに該当するカウンターは0。
- 全16標本でmarkerのpid/tidに一致する`/proc`行が前後に存在し、保存済み個別snapshotと
  組snapshotが一致。readエラーなし。schedstatのCPU・runqueue待ち・timesliceの差は非負で、
  保存済み集計と一致した。スレッド名や新規スレッド数による推定ではない。
- 受信したP1先攻2,290,622値のSHA-256は全16標本で
  `ba68eace30ba61d0e99ad06a824edebf04cf202b90e807c436091c10b2cd6ede`。
  事前に指定した過去の固定配置値とも一致。初期値は-119.69864675486676、
  maxGapは3.9714154809189495e-7、値配列は18,324,976 bytes。
  この確認は固定配置P1先攻の範囲で、両先攻・全配置の再実行ではない。
- 2版のHTML実ファイルhashはPLANの値と一致。全16標本のpristine Worker source hashは
  `9d54c0c06f6f80320d3f3e07284b75d39a9ebbe3163321ca964ca685aeecb722`で共通。
  script・analyser・planの実ファイルhashも正式results.jsonの記録と一致した。

## カテゴリの修正と実記録

`Tracing.getCategories`の空配列は非対応の証拠にはならない。初期コードは空の積集合を
categoriesへ渡したため、意図した明示指定にならなかった。この16標本と当時のコードを
保持し、正式結果から除外した処置は妥当である。修正版の固定16標本はPLANに追記済みで、
初回を含めて全標本を保持している。好ましい差だけを残す処理は確認されなかった。

正式コードとresults.jsonでは、toplevel、blink.user_timing、devtools.timeline、v8、
disabled-by-default-v8.gc、disabled-by-default-v8.compileの6カテゴリを明示指定。
6つすべてのカテゴリが各生traceの実イベントに存在することを確認した。
metadataや複数カテゴリを持つイベントなど追加カテゴリもあり、「指定した6つだけを記録」
とは解釈しない。環境はChromium 154.0.8037.57、headless、1280×900、cpu.maxは
400000/100000。診断用のasync待機・traceによる影響があるため通常時の性能値と集約しない。

## CPUと待機の解釈

solveのwallは563.648–679.689 ms、中央値590.778 ms。対象スレッドCPUは
553.865–660.180 ms、中央値583.975 ms。標本ごとのCPU/wallは97.130–99.332%、
中央値98.698%。wall−CPUは3.883–19.509 ms、中央値7.609 msであり、
今回のsolve時間の大部分は対象WorkerスレッドのCPU実行として記録されている。
CPU時間にはJavaScript演算以外の同スレッド処理も含まれる。

`/proc`のCPU差はmarker間のCPUより0.730–3.739 ms大きい。前後snapshotは
constructor後・solve前からsolve後・READY前までのhandshake包絡区間で、
resume dispatch、mark、probe通知などを含むため、この差は矛盾ではない。
runqueue待ち差は0.679–15.365 ms、中央値5.141 msだが、solveの厳密区間とは一致しない。
wall−CPUをrunqueue待ちへ置き換えたり、両者を同一分母で厳密に配賦したりしない。
cgroup全体の値を個別Workerへ配賦する根拠もない。

## GC/JITと変動

対象Workerのsolve区間に限定した候補イベントのwall区間和は、GCが18.313–24.890 ms、
JITが2.685–7.558 ms、重複を除いた合計が21.530–30.146 ms。
候補分類はPLANで先に定めたGC名と、V8系のcompile/optimize/maglev/turbofan/deopt名に
限定する。全GC/JITコストを網羅する分類ではなく、背景スレッドは配賦していない。

GC・JITとも全16標本で一部イベントのtts/tdurが不足し、完全なCPU区間和はnull。
取得できたイベントだけのCPU区間和はGC13.799–17.382 ms、JIT2.309–5.359 msであり、
これを完全なCPU寄与へ読み替えない。欠落にはV8.GC_HEAP_*、V8.DeoptimizeCode、
V8.MaglevConcurrentPrepareなどの短い区間が多い。
同分類のCPU時計付きwall区間に覆われない欠落wall区間和を別途調べると、
GC0.087–0.126 ms、JIT0.034–0.356 msであった。大部分が時計付き親区間に覆われるが、
すべてではない。この補助的な被覆確認は、凍結済み解析器の欠測判定を変更しない。

同一run・同一版内の最速/最遅を事後に選んだ範囲例を、全4組そのまま示す。
差は「遅い標本−速い標本」。極値の選択なので代表的効果や因果推定とはしない。

| run・版 | wall差 ms | CPU差 ms | 非CPU差 ms | GC/JIT候補wall区間和の差 ms |
|---|---:|---:|---:|---:|
| run1・段階5 | 104.592 | 92.502 | 12.090 | 3.717 |
| run1・段階9 | 65.464 | 61.044 | 4.420 | 8.488 |
| run2・段階5 | 9.755 | 15.062 | -5.307 | -4.697 |
| run2・段階9 | 31.398 | 29.083 | 2.315 | 0.338 |

変動例でもCPU差の比重が大きい。非CPU差は存在するが、単独でwall差全体を説明しない。
観測したGC/JIT候補区間の増減もwall差と一貫して対応せず、この候補分類だけから
変動の直接原因は確定できない。候補wall区間の差をsolve CPU差から引いて
厳密な「残りの原因」を作る計算も行わない。

段階9−段階5の対ごとの差の中央値は、run1がwall -3.512 ms、CPU -7.243 ms、
run2がwall +5.462 ms、CPU +11.381 ms。符号はrun間で異なる。
2プロセス・各4対・1固定配置の診断記録から、厳密な非悪化、全経路の同等性、
過去の別試行の遅延原因、実端末性能を結論づける根拠はない。

本レビューの範囲では記録の破損や誤った対象スレッド配賦は見つからず、
「今回のsolveは主にCPU実行時間で、その変動を観測したGC/JIT候補だけでは説明し切れない」
という限定した記述を支持する。過去増加の直接原因と62条件の性能確認は未確定のままである。
